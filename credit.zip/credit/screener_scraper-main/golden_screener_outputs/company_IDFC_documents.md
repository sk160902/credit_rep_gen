# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/idfc-ltd/idfc/532659/corp-announcements/)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018
5 Jul - Copy of certificate under Regulation 74(5) for June 30, 2024 issued by KFIN to NSDL and CDSL.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=683089b2-ae05-4a24-9b1a-465010d41f79.pdf)
- [Declaration Of Interim Dividend And Record Date 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bf4c2f57-a7c5-4c4a-8be6-13658c1f80e9.pdf)
- [Board Meeting Outcome for Outcome Of 184Th Board Meeting Of IDFC Limited 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e75cb5b9-b880-4e80-aa9a-5018e0f55c58.pdf)
- [Corporate Action-Board to consider Dividend 1 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a2f6691-7756-4dc8-9b8b-cbe872c7da38.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49849cc0-9092-4eab-9c26-3f9b1136f482.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\a9d9b73a-f59c-470d-9f95-2912a91dc5db.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/75138532659.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/69918532659_15_09_21.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/65400532659_10_09_20.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_IDFC_2011_2012_20062012101256.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_IDFC_2010_2011_04072011150505.zip)

## Credit Ratings
- [Rating update
31 Dec 2018 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=76291)
- [Rating update
3 Nov 2017 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=63941)
- [Rating update
22 Sep 2017 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=62614)
- [Rating update
4 Aug 2016 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=28493)
- [Rating update
1 Feb 2016 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=8397)
- [](https://www.indiaratings.co.in/pressrelease/21820)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d8563013-666f-47a5-9af1-8fc8ced66b08.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b82ef201-6ed4-4bf3-b4fe-7c2705ec683e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8716118d-a91a-4021-9a40-4ab48991b6ce.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2f982562-fd39-44a2-9b43-1eee4292e198.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f73e3a12-31e1-4fe8-bdd1-dd5846f7613e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=89a57984-5286-4649-baad-4f01ccd51e0d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=242f6f4a-76df-4f59-ac4e-ba812cdeceb7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=09121026-5f0f-402f-be0e-7b199f348acc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b554de17-405f-499b-8628-7b19002ef6a6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=96a34f9f-9518-4793-ba6c-84304cab8a92.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c5abbfbf-956a-4568-a8d2-1c4c1ab743ac.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8d5e3add-531d-4fe0-a2de-be793bfb0540.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a7e46e3a-447e-4dbb-b414-0fe53803118f.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_21/Q3/Q3-FY21-IDFC-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2ef30cf4-3853-4859-a46b-4f859c1660f9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fb72bc8d-f53b-433c-9451-6173a843567e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3374b4fc-09e5-4071-a667-e68fd8cd95cb.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q4/Q4-FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fef6322e-2d24-486c-9a94-c5100ca0c716.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ddb99d7a-111d-4998-b853-c466bba87164.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q2/Q2-FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a6986361-9858-43d8-935b-2609aba4ef46.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q1/IDFC_Q1FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bca5828-7d61-46ce-afcf-66674a26c167.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q4/Q4-FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d93328b8-0024-47ce-8ed6-957795d88d2c.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q3/Q3-FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e426765b-1247-406d-9e5f-3679ae693794.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q2/IDFC_Q2FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d71a4391-a390-44b8-b323-e4ceb79af58f.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q1/IDFC_Q1FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=032f9a00-b254-45c8-8f3d-5125596d02ae.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=294eac61-90f2-458a-bb7e-7c4e3205fb97.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_18/Q3/Q3-FY18-Concall-Transcript-Earnings.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_18/Q2/IDFC_Q2FY18-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=efa5dd32-99aa-4b28-9bab-ba799334e8b3.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q4/Q4-FY17-Concall-Invite.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q3/Transcript-IDFC-Ltd-Q3FY17-Earnings-Call-31Jan2017.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q2/Q2-FY17_IDFC_Concall-Transcript.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q1/IDFCLimited-Concall-Transcript-IDFC-Ltd-Q1FY17-Earnings.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_16/Q4/IDFC-Limited-Q4FY16-Concall-Transcript-bank.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_16/Q3/IDFC-Limited-Q3FY16-Concall-Transcript.pdf)

