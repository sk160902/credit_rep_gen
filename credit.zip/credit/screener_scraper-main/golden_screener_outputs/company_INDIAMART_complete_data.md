# Complete Company Data

## Modal Content
About
[
edit
]
IndiaMART, the first and largest B2B digital marketplace in the country, today stands out as a game-changer on the B2B landscape. It focuses on integrating the Small and Medium Businesses (SMEs) into the new paradigm with speed and ease, we are constantly pushing the frontiers of innovation to make the online marketplace more accessible, visible and engaging to them.
[1]
Key Points
[
edit
]
Largest in the industry
[1]
The company commands nearly
60% market share
of the online B2B classifieds space which makes it the largest player in the industry. It has a portfolio of ~7.9 million supplier storefronts, ~2,14,000 paying subscription suppliers,~108 mn live product listings, ~24 mn unique business enquiries & a total traffic of 252 million repeated users. The company has ~194 mn registered buyers with a repeat of 53%. CRM has ~136Mn replies & callbacks. 37% suppliers are buyers.
Well Diversified Marketplace
[2]
As of FY24, their website has ~108 million product listings from 56 different industries, making them one of the most diversified marketplaces in Indian. No single industry accounts for >8% of total paying suppliers. Construction & Building Raw Material is the largest category in the marketplace and covers ~8% of it. There are ~98,000 product categories.
Geographical Presence
[3]
As of FY24, the buyers and paying subscription suppliers are spread across as under:
Metro cities: Buyers(30%) Sellers (54%)
Tier II cities: Buyers(25%) Sellers (27%)
Rest of India: Buyers(45%) Sellers (19%)
As of FY23, company has access to 1000+ cities in India through 150+ Channel Sales Partners, Field, Tele and Online Sales and 4,400+ Inhouse Sales Supervision & Client Servicing team (Renewal & Upsell).
[4]
The company's sales and distribution costs are 20% of the revenue.
[5]
Customer Profile
The business for the company largely comes from small and medium enterprises (SMEs). The platform makes it easier for buyers & suppliers through its offerings which include the marketplace, convenient price discovery, intelligent connect & easy and secure payments.
[6]
Subscription based revenue Model
[7]
The company has subscription based revenue model and RFQ quota. Their top 10% subscribers generate 47% of the revenue with ARPU of Rs. 2,61,000 and top 1% generate 16% of the revenue with ARPU of Rs. 9,05,000.
Logistics Partner
[8]
Commercial Vehicles - Tata Motors, Mahindra, Piaggio, Atul Auto, TVS.
Accounting Space Investments
In FY23, company invested ~650 crs in accounting space to increase its business in the segment.
[9]
The company has made some strategic investments in equities as : Vyapar (27.5%), Real Books (26%), Busy (100%), around ~6mn in Live Keeping (65.97%)
[10]
. Live Keeping is Tally on Mobile - Integration with Tally software to provide Value Added Services with Mobile and Cloud first approach.
[11]
In May,24, invested further Rs. 13.39 crs. in Live keeping to make it to 65.97%.
[10]
Other Strategic Investments
[12]
As of FY24, company's strategic investments in equities are: Bizom( 25.1%), Shipway(26%), Aerchain(26.2%), Easyecom (26%), Superprocure (27.4%), PM(13%), industrybuying (26.6%), Legistify(15.4%), Fleetx (16.5%), M1(9.3%), Zimyo(10%).
~95% of revenue contributed by IndiaMART standalone business.
[13]
Merger of Subsidiaries
[14]
In March,24, the company merged the WOS Hello Trade Online Private Limited and Tolexo Online Private Limited into Busy Infotech Private Limited.
Last edited 2 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 176 | 254 | 318 | 411 | 507 | 639 | 670 | 753 | 985 | 1,197 |
| Expenses + | 228 | 373 | 391 | 487 | 490 | 472 | 344 | 458 | 755 | 906 |
| Operating Profit | -52 | -119 | -74 | -76 | 17 | 167 | 326 | 296 | 230 | 291 |
| OPM % | -29% | -47% | -23% | -19% | 3% | 26% | 49% | 39% | 23% | 24% |
| Other Income + | 23 | 8 | 14 | 19 | 41 | 69 | 87 | 112 | 181 | 209 |
| Interest | 0 | 1 | 0 | 0 | 0 | 3 | 7 | 5 | 8 | 9 |
| Depreciation | 3 | 4 | 5 | 3 | 4 | 21 | 16 | 12 | 31 | 36 |
| Profit before tax | -32 | -115 | -64 | -60 | 54 | 211 | 389 | 390 | 371 | 454 |
| Tax % | 0% | 0% | 0% | -191% | 63% | 30% | 28% | 24% | 24% | 26% |
| Net Profit + | -32 | -116 | -64 | 55 | 20 | 147 | 280 | 298 | 284 | 334 |
| EPS in Rs | -17.43 | -63.34 | -35.16 | 27.38 | 3.50 | 25.50 | 46.09 | 48.71 | 46.38 | 55.68 |
| Dividend Payout % | 0% | 0% | 0% | 0% | 0% | 20% | 16% | 2% | 22% | 36% |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 76% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 37% |  |  |  |  |  |  |  |  |  |
| 3 Years: | -6% |  |  |  |  |  |  |  |  |  |
| 1 Year: | 0% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| IB MonotaRO Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 104 | 118 |
| Investment in associates |  |  |  |  | 104 |  | 14 |
| Investment in associates (At cost) |  |  |  |  | 104 |  |  |
| Simply Vyapar Apps Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 97 | 97 |
| Investment in associates (At cost) |  |  |  | 31 | 93 |  |  |
| Investment in associates |  |  |  |  | 62 | 3.98 |  |
| Investment in |  |  | 31 |  |  |  |  |
| Web, advertisement & marketing services provided to |  |  |  |  |  | 1.65 | 0.72 |
| Compulsory convertible preference shares (Face value 100/- each) |  |  |  |  |  |  | 1.48 |
| Web & Advertisement services provided to |  |  |  |  | 0.84 |  |  |
| Miscellaneous services provided to |  |  |  |  | 0.24 | 0.04 |  |
| Trade receivables |  |  |  |  |  | 0.20 | 0.06 |
| Contract Liabilities |  |  |  |  |  | 0.25 |  |
| Deferred Revenue |  |  |  | 0.05 | 0.10 |  |  |
| Equity Shares Capital (Face value 10/- each) |  |  |  |  |  |  | 0.01 |
| Mynd Solutions Private Limited |  |  |  |  |  |  |  |
| Investment in Entities where KMP and Individuals exercise Significant influence (at FVTPL) |  |  |  |  |  | 58 | 58 |
| Purchase of Investment |  |  |  |  |  | 24 |  |
| Sale of Investment |  |  |  |  |  | 14 |  |
| Web, advertisement & marketing services provided to |  |  |  |  |  |  | 0.50 |
| Mobisy Technologies Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 46 | 46 |
| Investment in associates |  |  |  |  |  | 23 | 8 |
| Investment in debt instruments of associates (at FVTPL) |  |  |  |  |  | 8 | 16 |
| Agillos E-Commerce Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 26 | 26 |
| Investment in associates |  |  |  |  | 26 |  |  |
| Investment in associates (At cost) |  |  |  |  | 26 |  |  |
| Shipway Technology Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 18 | 18 |
| Investment in associates |  |  |  |  | 18 |  |  |
| Investment in associates (At cost) |  |  |  |  | 18 |  |  |
| Truckhall Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 11 | 19 |
| Investment in associates |  |  |  |  | 11 | 7.50 | 3 |
| Investment in associates (At cost) |  |  |  |  | 11 |  |  |
| Investment in debt instruments of associates (at FVTPL) |  |  |  |  |  | 7.50 | 3 |
| Edgewise Technologies Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 13 | 13 |
| Investment in associates |  |  |  |  | 13 |  |  |
| Investment in associates (At cost) |  |  |  |  | 13 |  |  |
| Adansa Solutions Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 14 | 14 |
| Investment in associates |  |  |  |  |  | 14 |  |
| Dinesh Chandra Agarwal Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 8.63 |  | 13 |  |  |
| Brijesh Kumar Agrawal Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 5.85 |  | 8.77 |  |  |
| Mansa Enterprises Private Limited |  |  |  |  |  |  |  |
| Expenses for rent | 0.55 | 0.42 | 0.31 | 0.16 | 0.17 |  |  |
| Rent & related miscellaneous expenses |  |  |  |  |  | 0.26 | 0.53 |
| Trade Payable (including accrued expenses) |  |  |  |  |  |  | 0.01 |
| Indiamart Employee Benefit Trust |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.04 |  | 0.33 |  |  |
| Repayment of loan given |  |  |  | 0.12 | 0.20 |  |  |
| Loan given |  |  | 0.15 | 0.15 |  |  |  |
| Share capital issued |  |  | -0.14 | 0.14 | 0.17 |  |  |
| Interest free loan given |  |  |  | 0.12 | 0.05 |  |  |
| Interest free Loan given |  |  | 0.15 |  |  |  |  |
| Dhruv Prakash Key Person |  |  |  |  |  |  |  |
| Recruitment and training expenses | 0.21 | 0.18 | 0.31 | 0.04 |  |  |  |
| Dividend paid |  |  | 0.04 |  | 0.04 |  |  |
| Amount Payable |  |  | 0.01 |  |  |  |  |
| IB Monotaro Private Limited Associate |  |  |  |  |  |  |  |
| Contract Liabilities |  |  |  |  |  | 0.11 | 0.37 |
| Web, advertisement & marketing services provided to |  |  |  |  |  | 0.03 | 0.14 |
| Marketing services availed from |  |  |  |  |  |  | 0.01 |
| S R Dinodia & Co LLP |  |  |  |  |  |  |  |
| Tax consultancy and litigation support service |  |  |  |  |  |  | 0.16 |
| Trade Payable (including accrued expenses) |  |  |  |  |  |  | 0.10 |
| Prateek Chandra Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.10 |  | 0.15 |  |  |
| Ten Times Online Private Limited Associate |  |  |  |  |  |  |  |
| Investment in associates (At cost) |  |  |  | 0.09 | 0.09 |  |  |
| Internet and online services availed |  |  |  |  | 0.02 |  |  |
| Manoj Bhargava Key Person |  |  |  |  |  |  |  |
| Loans |  |  |  |  | 0.15 |  |  |
| Ten Times Online Pvt. Ltd Associate |  |  |  |  |  |  |  |
| Sale of Investment in associates |  |  |  |  |  | 0.12 |  |
| Rajesh Sawhney Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.02 |  | 0.01 |  |  |
| Vivek Narayan Gour Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.01 |  | 0.02 |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 176 | 254 | 318 | 411 | 507 | 639 | 670 | 753 | 985 | 1,197 |
| Expenses + | 228 | 373 | 391 | 487 | 490 | 472 | 344 | 458 | 755 | 906 |
| Operating Profit | -52 | -119 | -74 | -76 | 17 | 167 | 326 | 296 | 230 | 291 |
| OPM % | -29% | -47% | -23% | -19% | 3% | 26% | 49% | 39% | 23% | 24% |
| Other Income + | 23 | 8 | 14 | 19 | 41 | 69 | 87 | 112 | 181 | 209 |
| Interest | 0 | 1 | 0 | 0 | 0 | 3 | 7 | 5 | 8 | 9 |
| Depreciation | 3 | 4 | 5 | 3 | 4 | 21 | 16 | 12 | 31 | 36 |
| Profit before tax | -32 | -115 | -64 | -60 | 54 | 211 | 389 | 390 | 371 | 454 |
| Tax % | 0% | 0% | 0% | -191% | 63% | 30% | 28% | 24% | 24% | 26% |
| Net Profit + | -32 | -116 | -64 | 55 | 20 | 147 | 280 | 298 | 284 | 334 |
| EPS in Rs | -17.43 | -63.34 | -35.16 | 27.38 | 3.50 | 25.50 | 46.09 | 48.71 | 46.38 | 55.68 |
| Dividend Payout % | 0% | 0% | 0% | 0% | 0% | 20% | 16% | 2% | 22% | 36% |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 76% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 37% |  |  |  |  |  |  |  |  |  |
| 3 Years: | -6% |  |  |  |  |  |  |  |  |  |
| 1 Year: | 0% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 7 | -55 | -1 | 179 | 255 | 261 | 322 | 402 | 476 | 559 |
| Cash from Investing Activity + | -4 | -75 | -8 | -165 | -276 | -233 | -1,338 | -335 | -324 | 162 |
| Cash from Financing Activity + | -0 | 133 | 7 | 15 | 14 | -51 | 1,038 | -58 | -143 | -695 |
| Net Cash Flow | 3 | 2 | -1 | 29 | -7 | -23 | 23 | 9 | 9 | 27 |

## Ratios Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 1 | 0 | 1 | 1 | 0 | 1 | 1 | 1 | 3 | 1 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 1 | 0 | 1 | 1 | 0 | 1 | 1 | 1 | 3 | 1 |
| Working Capital Days | -272 | -241 | -243 | -260 | -277 | -258 | -240 | -284 | -300 | -308 |
| ROCE % |  |  |  |  |  | 84% | 39% | 22% | 19% | 24% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 49.52% | 49.52% | 49.52% | 49.22% | 49.22% | 49.22% | 49.22% | 49.22% | 49.21% | 49.21% | 49.21% | 49.21% |
| FIIs + | 27.91% | 26.53% | 23.93% | 23.59% | 25.00% | 25.38% | 26.60% | 26.76% | 27.33% | 24.16% | 23.08% | 23.37% |
| DIIs + | 4.68% | 5.34% | 5.46% | 4.96% | 5.24% | 5.81% | 5.62% | 5.62% | 5.46% | 8.23% | 10.60% | 11.81% |
| Public + | 17.16% | 18.57% | 21.05% | 21.50% | 20.33% | 19.46% | 18.45% | 18.27% | 17.87% | 18.30% | 17.08% | 15.56% |
| Others + | 0.72% | 0.04% | 0.04% | 0.72% | 0.21% | 0.15% | 0.12% | 0.12% | 0.11% | 0.08% | 0.05% | 0.05% |
| No. of Shareholders | 1,34,182 | 1,59,617 | 2,10,173 | 2,41,409 | 2,14,640 | 1,95,249 | 1,77,654 | 1,65,627 | 1,71,470 | 1,71,361 | 1,61,823 | 1,59,877 |

## Yearly Data
| Unknown | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 52.34% | 49.85% | 49.52% | 49.22% | 49.21% | 49.21% |
| FIIs + | 12.24% | 27.53% | 23.93% | 26.60% | 23.08% | 23.37% |
| DIIs + | 3.08% | 4.52% | 5.46% | 5.62% | 10.60% | 11.81% |
| Public + | 32.19% | 17.94% | 21.05% | 18.45% | 17.08% | 15.56% |
| Others + | 0.15% | 0.16% | 0.04% | 0.12% | 0.05% | 0.05% |
| No. of Shareholders | 18,007 | 94,678 | 2,10,173 | 1,77,654 | 1,61,823 | 1,59,877 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/indiamart-intermesh-ltd/indiamart/542726/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation
2d - With Part A of Schedule III of the Regulation, the Company has scheduled an Earnings Conference Call for investors and analysts on Tuesday, July 30, …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c507083d-27ec-43cb-9f0b-e575dc7e5eca.pdf)
- [Closure of Trading Window 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2f6b4910-e9fe-49f7-b8a2-6c6e305afef4.pdf)
- [Board Meeting Intimation for Consideration And Approval Of The Audited Standalone And Consolidated Financial Results ('Financial Results') Of The Company For The Quarter Ended June 30, 2024 And Closure Of Trading Window](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57bb2439-5710-4432-a858-a32d44cca712.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6686a16b-c9e8-4ace-91e1-007ab403940e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=334c968b-65b7-4bb4-b1ea-23ec3f5f53c4.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba5c19f8-b5a8-474f-a9a0-6ade1a4d3cb5.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\77fe5099-871e-4d9d-84f9-a5c4c93a6acf.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/542726/74710542726_06_09_22.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/542726/69302542726.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/542726/5427260320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/542726/5427260319.pdf)
- [DRHP](https://www.sebi.gov.in/filings/public-issues/jun-2019/indiamart-intermesh-ltd_43513.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=410304a4-b128-400e-85a0-cc77566b5c84.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01314bc4-6637-4706-8ad1-1a48ae649607.pdf)
- [REC](https://www.youtube.com/watch?v=-9D0bLhh3Sk)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=482b1170-89cf-42c3-8c6c-3ddf4f0d32b7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2e4c0081-f1ea-4e3f-824f-1dfbf8a164df.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=931c7a54-e958-4147-8b95-4eb297d789b7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b174001b-93f8-4cb2-a1e8-69157b46c2d6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=299ee5de-8163-49d7-9e7a-b265640d5ef4.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a864e8ce-9257-4011-9eeb-c839b613626a.pdf)
- [REC](https://www.youtube.com/watch?v=wM4qky1LnIE&list=PL2o4J51MqpL2CVbYxVR530XdzJyddiSbz&ab_channel=IndiaMARTInterMESHLtd)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e4d1b690-a5a5-4091-9904-3e6e13668d94.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8cc6837d-489c-4a7e-a536-6514ebddd3d8.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0c08771-95af-4324-8349-7f809c848c4e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=64a1c770-aa3f-4a60-aebc-aab5ec201694.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1f8db735-75c9-4d57-bbc3-67bb1059e2ca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=792aa0e0-8af0-4b63-a99b-c4a03dd122c3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cc9c5005-c891-41e8-8487-8571b5091cf9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ff8d127e-a441-4f3e-a4ec-9090cf6f2ed0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e45b2589-4d2f-4490-ae82-765dee7c0f7b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7ae54d63-b1f2-4ba0-ad9e-b20c4dac57f1.pdf)
- [](https://investor.indiamart.com/z_Indiamart/files/IndiaMART_Q3FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=840dcfd5-ed3b-47ac-af47-842d3b4c0da2.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2_FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=37bf1a62-d4d0-4530-899a-01a8c6758cdd.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q1_FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8bd09808-0891-4500-8d39-28c33b10067e.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q4_FY21_Earnings_Webinar_Transcript_Final.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e693c6d9-5966-4ebd-9458-f32437ba50ee.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q3_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b64c41af-6df7-45de-9f4c-7584cd3d0bd6.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ab291016-8a4f-4665-91f1-e75ca4cb2ab3.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q1_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f49d0ed7-02e7-4f47-ba0a-7ac4ed1b825e.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/results_pdf/2019-20/IndiaMART_Q4_FY20_Earnings_Call_Transcript_18th_May_2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b478416d-7c56-4032-aa0d-55f02b2290c5.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/results_pdf/2019-20/IndiaMART_Q3FY20_Earnings_Concall_Transcript_31012020.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2FY20_Earnings_Concall_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ff790f8f-e8b6-46eb-8bae-ae6febc6e83d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3adf150b-220f-4877-ace8-c196052c7314.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Concall_Transcript_Q1FY2020__1_.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9d826cc4-c08a-4786-add4-0de55024c60d.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Zomato Ltd | 220.25 | 194414.44 | 553.83 | 9.55 | 16.05 | -466.00 | 218.71 |  | 0.00 | 1.77 | 1.56 | 1.76 | 0.54 | 0.04 | 5.04 | 1.10 | 12114.00 | 0.35 | 351.00 | 3562.00 | 175.00 | 73.25 | 193.09 | 0.40 | 749.00 | 0.00 | 0.00 | 0.19 | 57.82 | 0.00 | 71.12 | 133.01 | 194432.44 | 2.62 | 33.18 | 16.59 | 61.08 | 18.26 | 158.16 | -4.55 | -9.28 | 16.69 | 38.16 | 55.97 | 82.47 | -5.91 | -5.79 | 2.58 | 0.40 | 14.87 | 487.56 | 487.56 | 487.56 | -77.14 | 855.35 |
| 2. | Info Edg.(India) | 7195.75 | 93101.60 | 143.99 | 3.07 | 36.71 | 176.57 | 82.87 | 25.79 | 0.31 | 4.36 | 2.54 | 2.96 | 0.10 | 0.01 | 45.41 | 0.87 | 2536.34 | 27.53 | 646.90 | 657.42 | 120.61 | 8.70 | 153.17 | 44.46 | 246.39 | 37.88 | 0.00 | 1.13 | 57.82 | 0.00 | 8.13 | 357.64 | 92155.01 | 2.90 | 2.58 | 18.94 | 40.76 | 10.62 | 53.45 | 5.92 | 4.92 | 55.86 | 71.42 | 17.12 | 31.01 | -1.64 | 2.76 | 2.90 | 44.46 | 54.07 | 130.00 | 124.33 | 111.09 | 1.53 | 12.92 |
| 3. | One 97 | 508.85 | 32376.84 |  | 2.49 | 3.54 | -44.49 | -25.00 |  | 0.00 | -10.19 | -8.07 | -10.72 | 0.57 | 0.01 | -84.75 | 1.32 | 9137.80 | -18.11 | -1893.38 | 1501.60 | -838.90 | -35.87 | -134.99 | -29.88 | 176.60 | 0.00 | 0.00 | -7.58 | 57.82 | 0.00 | 5.61 | -27.28 | 27307.24 | 3.46 |  | 22.79 | -39.35 |  | -40.63 | -15.04 | -19.09 | 10.61 | 4.91 | 25.35 | 52.72 | -13.09 | -12.49 | 3.46 | -22.30 | 14.51 |  |  |  | 60.38 | 63.38 |
| 4. | Indiamart Inter. | 3026.20 | 18150.89 | 54.27 | 10.44 | 15.17 | 38.84 | 36.12 | 37.38 | 0.67 | 23.93 | 9.72 | 17.65 | 0.35 | 0.02 | 52.12 | 1.98 | 1196.78 | 24.31 | 334.79 | 314.70 | 99.60 | 17.08 | 78.49 | 55.68 | 40.67 | 49.21 | 0.00 | 2.60 | 57.82 | 0.00 | 21.45 | 18.20 | 18090.36 | 0.14 | 0.72 | 13.60 | 22.17 | -5.89 | -0.28 | 16.33 | 19.83 | 75.62 | 6.28 | 18.72 | 21.36 | 14.41 | 18.77 | 0.14 | 55.68 | 73.96 | 54.99 | 53.81 | 55.17 | 1.46 | 6.12 |
| 5. | Just Dial | 1274.25 | 10836.26 | 57.38 | 2.63 | 10.07 | 81.60 | 38.30 | 12.57 | 0.00 | 4.81 | 3.04 | 3.63 | 0.23 | 0.02 | 25.61 | 1.14 | 1076.50 | 24.19 | 188.90 | 280.57 | 68.96 | 13.60 | 186.50 | 49.47 | 85.31 | 74.18 | -0.11 | 2.16 | 57.82 | 13.94 | 18.80 | 127.21 | 10903.88 | 0.13 | -7.60 | 20.40 | 52.61 | 10.37 | 65.12 | 1.70 | 4.71 | -7.55 | 0.82 | 3.19 | 15.60 | 1.30 | 1.70 | 0.13 | 42.67 | -12.46 | 58.34 | 75.53 | 26.28 | 0.00 | 8.43 |
| 6. | Intrasoft Tech. | 135.60 | 221.19 | 22.58 | 1.07 | 0.46 | -12.07 | 13.32 | 9.28 | 0.00 | 7.64 | 2.62 | 5.03 | 1.30 | 0.66 | 2.18 | 1.77 | 485.47 | 4.01 | 9.80 | 121.50 | 2.36 | 2.96 | -3.67 | 6.01 | 139.40 | 43.06 | 0.00 | 7.23 | 57.82 | 0.00 | 6.24 | 17.22 | 357.62 | 6.49 | 0.84 | -0.61 | -21.50 | 7.51 | 1.44 | 5.87 | 4.81 | 26.80 | 5.15 | -10.31 | -7.49 | 4.84 | 6.31 | 3.15 | 6.01 | 24.24 | 20.69 | 20.81 | 22.75 | 89.25 | 1.47 |
| 7. | Suvidhaa Info. | 6.29 | 131.98 |  | 2.42 | 17.34 | 11.90 | -35.23 |  | 0.00 | -24.79 | -15.45 | -25.81 | 0.07 | 0.00 | -46.44 | 1.92 | 7.61 | -86.07 | -16.13 | 2.09 | -3.43 | -74.73 | -376.61 | -0.78 | 0.00 | 38.33 | -0.44 | -14.93 | 57.82 | 0.00 | -75.68 | -821.71 | 117.30 | 1.30 |  | -3.53 | -22.43 | -38.56 | 51.05 | -11.07 |  |  |  |  | -58.62 | -2.46 | -1.89 | 1.30 | -0.78 |  |  |  |  | 493.54 | 20.74 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | Sales | ₹ 1,197 Cr. |
| INDIAMART | OPM | 24.3 % |
| INDIAMART | Profit after tax | ₹ 335 Cr. |
| INDIAMART | Mar Cap | ₹ 18,151 Cr. |
| INDIAMART | Sales Qtr | ₹ 315 Cr. |
| INDIAMART | PAT Qtr | ₹ 99.6 Cr. |
| INDIAMART | Qtr Sales Var | 17.1 % |
| INDIAMART | Qtr Profit Var | 78.5 % |
| INDIAMART | Price to Earning | 54.3 |
| INDIAMART | Dividend yield | 0.67 % |
| INDIAMART | Price to book value | 10.4 |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | Return on assets | 9.72 % |
| INDIAMART | Debt to equity | 0.02 |
| INDIAMART | Return on equity | 17.6 % |
| INDIAMART | EPS | ₹ 55.7 |
| INDIAMART | Debt | ₹ 40.7 Cr. |
| INDIAMART | Promoter holding | 49.2 % |
| INDIAMART | Change in Prom Hold | 0.00 % |
| INDIAMART | Earnings yield | 2.60 % |
| INDIAMART | Pledged percentage | 0.00 % |
| INDIAMART | Industry PE | 57.8 |
| INDIAMART | Sales growth | 21.4 % |
| INDIAMART | Profit growth | 18.2 % |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | Price to Sales | 15.2 |
| INDIAMART | CMP / FCF | 38.8 |
| INDIAMART | EVEBITDA | 36.1 |
| INDIAMART | Enterprise Value | ₹ 18,091 Cr. |
| INDIAMART | Current ratio | 0.14 |
| INDIAMART | Int Coverage | 52.1 |
| INDIAMART | PEG Ratio | 0.72 |
| INDIAMART | Return over 3months | 13.6 % |
| INDIAMART | Return over 6months | 22.2 % |
| INDIAMART | No. Eq. Shares | 6.00 |
| INDIAMART | Sales growth 3Years | 21.4 % |
| INDIAMART | Sales growth 5Years | 18.7 % |
| INDIAMART | Profit Var 3Yrs | 6.28 % |
| INDIAMART | Profit Var 5Yrs | 75.6 % |
| INDIAMART | ROE 5Yr | 19.8 % |
| INDIAMART | ROE 3Yr | 16.3 % |
| INDIAMART | Return over 1year | -0.28 % |
| INDIAMART | Return over 3years | -5.89 % |
| INDIAMART | Return over 5years | 37.4 % |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | Sales last year | ₹ 1,197 Cr. |
| INDIAMART | OP Ann | ₹ 291 Cr. |
| INDIAMART | Other Inc Ann | ₹ 209 Cr. |
| INDIAMART | EBIDT last year | ₹ 501 Cr. |
| INDIAMART | Dep Ann | ₹ 36.5 Cr. |
| INDIAMART | EBIT last year | ₹ 464 Cr. |
| INDIAMART | Interest last year | ₹ 8.91 Cr. |
| INDIAMART | PBT Ann | ₹ 454 Cr. |
| INDIAMART | Tax last year | ₹ 120 Cr. |
| INDIAMART | PAT Ann | ₹ 335 Cr. |
| INDIAMART | Extra Ord Item Ann | ₹ -1.14 Cr. |
| INDIAMART | NP Ann | ₹ 334 Cr. |
| INDIAMART | Dividend last year | ₹ 120 Cr. |
| INDIAMART | Raw Material | 0.00 % |
| INDIAMART | Employee cost | ₹ 545 Cr. |
| INDIAMART | OPM last year | 24.3 % |
| INDIAMART | NPM last year | 28.0 % |
| INDIAMART | Operating profit | ₹ 291 Cr. |
| INDIAMART | Interest | ₹ 8.91 Cr. |
| INDIAMART | Depreciation | ₹ 36.5 Cr. |
| INDIAMART | EPS last year | ₹ 55.7 |
| INDIAMART | EBIT | ₹ 464 Cr. |
| INDIAMART | Net profit | ₹ 334 Cr. |
| INDIAMART | Current Tax | ₹ 95.4 Cr. |
| INDIAMART | Tax | ₹ 120 Cr. |
| INDIAMART | Other income | ₹ 209 Cr. |
| INDIAMART | Ann Date | 2,02,403 |
| INDIAMART | Sales Prev Ann | ₹ 985 Cr. |
| INDIAMART | OP Prev Ann | ₹ 230 Cr. |
| INDIAMART | Other Inc Prev Ann | ₹ 181 Cr. |
| INDIAMART | EBIDT Prev Ann | ₹ 410 Cr. |
| INDIAMART | Dep Prev Ann | ₹ 31.1 Cr. |
| INDIAMART | EBIT preceding year | ₹ 379 Cr. |
| INDIAMART | Interest Prev Ann | ₹ 8.15 Cr. |
| INDIAMART | PBT Prev Ann | ₹ 371 Cr. |
| INDIAMART | Tax preceding year | ₹ 87.4 Cr. |
| INDIAMART | PAT Prev Ann | ₹ 283 Cr. |
| INDIAMART | Extra Ord Prev Ann | ₹ 0.79 Cr. |
| INDIAMART | NP Prev Ann | ₹ 284 Cr. |
| INDIAMART | Dividend Prev Ann | ₹ 61.2 Cr. |
| INDIAMART | OPM preceding year | 23.3 % |
| INDIAMART | NPM preceding year | 28.7 % |
| INDIAMART | EPS preceding year | ₹ 46.4 |
| INDIAMART | Sales Prev 12M | ₹ 1,151 Cr. |
| INDIAMART | Profit Prev 12M | ₹ 290 Cr. |
| INDIAMART | Med Sales Gwth 10Yrs | 25.0 % |
| INDIAMART | Med Sales Gwth 5Yrs | 21.4 % |
| INDIAMART | Sales growth 7Years | 20.9 % |
| INDIAMART | Sales Var 10Yrs | % |
| INDIAMART | EBIDT growth 3Years | 6.82 % |
| INDIAMART | EBIDT growth 5Years | 53.9 % |
| INDIAMART | EBIDT growth 7Years | 39.8 % |
| INDIAMART | EBIDT Var 10Yrs | % |
| INDIAMART | EPS growth 3Years | 6.70 % |
| INDIAMART | EPS growth 5Years | 74.0 % |
| INDIAMART | EPS growth 7Years | 20.0 % |
| INDIAMART | EPS growth 10Years | % |
| INDIAMART | Profit Var 7Yrs | 32.6 % |
| INDIAMART | Profit Var 10Yrs | % |
| INDIAMART | Chg in Prom Hold 3Yr | -0.61 % |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | OP Qtr | ₹ 76.8 Cr. |
| INDIAMART | Other Inc Qtr | ₹ 77.2 Cr. |
| INDIAMART | EBIDT Qtr | ₹ 154 Cr. |
| INDIAMART | Dep Qtr | ₹ 12.7 Cr. |
| INDIAMART | EBIT latest quarter | ₹ 141 Cr. |
| INDIAMART | Interest Qtr | ₹ 2.20 Cr. |
| INDIAMART | PBT Qtr | ₹ 139 Cr. |
| INDIAMART | Tax latest quarter | ₹ 39.5 Cr. |
| INDIAMART | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| INDIAMART | NP Qtr | ₹ 99.6 Cr. |
| INDIAMART | GPM latest quarter | 100 % |
| INDIAMART | OPM latest quarter | 24.4 % |
| INDIAMART | NPM latest quarter | 31.6 % |
| INDIAMART | Eq Cap Qtr | ₹ 59.9 Cr. |
| INDIAMART | EPS latest quarter | ₹ 16.6 |
| INDIAMART | OP 2Qtr Bk | ₹ 69.0 Cr. |
| INDIAMART | OP 3Qtr Bk | ₹ 66.7 Cr. |
| INDIAMART | Sales 2Qtr Bk | ₹ 295 Cr. |
| INDIAMART | Sales 3Qtr Bk | ₹ 282 Cr. |
| INDIAMART | NP 2Qtr Bk | ₹ 69.4 Cr. |
| INDIAMART | NP 3Qtr Bk | ₹ 83.1 Cr. |
| INDIAMART | Opert Prft Gwth | 26.5 % |
| INDIAMART | Last result date | 2,02,403 |
| INDIAMART | Exp Qtr Sales Var | 21.5 % |
| INDIAMART | Exp Qtr Sales | ₹ 343 Cr. |
| INDIAMART | Exp Qtr OP | ₹ 82.6 Cr. |
| INDIAMART | Exp Qtr NP | ₹ 69.8 Cr. |
| INDIAMART | Exp Qtr EPS | ₹ 11.6 |
| INDIAMART | Sales Prev Qtr | ₹ 305 Cr. |
| INDIAMART | OP Prev Qtr | ₹ 78.5 Cr. |
| INDIAMART | Other Inc Prev Qtr | ₹ 41.7 Cr. |
| INDIAMART | EBIDT Prev Qtr | ₹ 120 Cr. |
| INDIAMART | Dep Prev Qtr | ₹ 8.40 Cr. |
| INDIAMART | EBIT Prev Qtr | ₹ 112 Cr. |
| INDIAMART | Interest Prev Qtr | ₹ 2.20 Cr. |
| INDIAMART | PBT Prev Qtr | ₹ 110 Cr. |
| INDIAMART | Tax Prev Qtr | ₹ 27.7 Cr. |
| INDIAMART | PAT Prev Qtr | ₹ 81.9 Cr. |
| INDIAMART | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| INDIAMART | NP Prev Qtr | ₹ 81.9 Cr. |
| INDIAMART | OPM Prev Qtr | 25.7 % |
| INDIAMART | NPM Prev Qtr | 26.8 % |
| INDIAMART | Eq Cap Prev Qtr | ₹ 59.9 Cr. |
| INDIAMART | EPS Prev Qtr | ₹ 13.6 |
| INDIAMART | Sales PY Qtr | ₹ 269 Cr. |
| INDIAMART | OP PY Qtr | ₹ 55.6 Cr. |
| INDIAMART | Other Inc PY Qtr | ₹ 30.7 Cr. |
| INDIAMART | EBIDT PY Qtr | ₹ 86.3 Cr. |
| INDIAMART | Dep PY Qtr | ₹ 8.60 Cr. |
| INDIAMART | EBIT PY Qtr | ₹ 77.7 Cr. |
| INDIAMART | Interest PY Qtr | ₹ 2.10 Cr. |
| INDIAMART | PBT PY Qtr | ₹ 75.6 Cr. |
| INDIAMART | Tax PY Qtr | ₹ 19.8 Cr. |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | Equity capital | ₹ 60.0 Cr. |
| INDIAMART | Preference capital | ₹ 0.00 Cr. |
| INDIAMART | Reserves | ₹ 1,676 Cr. |
| INDIAMART | Secured loan | ₹ 0.00 Cr. |
| INDIAMART | Unsecured loan | ₹ 40.7 Cr. |
| INDIAMART | Balance sheet total | ₹ 3,449 Cr. |
| INDIAMART | Gross block | ₹ 644 Cr. |
| INDIAMART | Revaluation reserve | ₹ 0.00 Cr. |
| INDIAMART | Accum Dep | ₹ 108 Cr. |
| INDIAMART | Net block | ₹ 536 Cr. |
| INDIAMART | CWIP | ₹ 0.50 Cr. |
| INDIAMART | Investments | ₹ 2,746 Cr. |
| INDIAMART | Current assets | ₹ 148 Cr. |
| INDIAMART | Current liabilities | ₹ 1,068 Cr. |
| INDIAMART | BV Unq Invest | ₹ 0.00 Cr. |
| INDIAMART | MV Quoted Inv | ₹ 2,222 Cr. |
| INDIAMART | Cont Liab | ₹ 31.8 Cr. |
| INDIAMART | Total Assets | ₹ 3,449 Cr. |
| INDIAMART | Working capital | ₹ -908 Cr. |
| INDIAMART | Lease liabilities | ₹ 40.7 Cr. |
| INDIAMART | Inventory | ₹ 0.00 Cr. |
| INDIAMART | Trade receivables | ₹ 4.78 Cr. |
| INDIAMART | Face value | ₹ 10.0 |
| INDIAMART | Cash Equivalents | ₹ 101 Cr. |
| INDIAMART | Adv Cust | ₹ 87.6 Cr. |
| INDIAMART | Trade Payables | ₹ 34.4 Cr. |
| INDIAMART | No. Eq. Shares PY | 6.12 |
| INDIAMART | Debt preceding year | ₹ 45.9 Cr. |
| INDIAMART | Work Cap PY | ₹ -753 Cr. |
| INDIAMART | Net Block PY | ₹ 553 Cr. |
| INDIAMART | Gross Block PY | ₹ 630 Cr. |
| INDIAMART | CWIP PY | ₹ 0.18 Cr. |
| INDIAMART | Work Cap 3Yr | ₹ -363 Cr. |
| INDIAMART | Work Cap 5Yr | ₹ -307 Cr. |
| INDIAMART | Work Cap 7Yr | ₹ -171 Cr. |
| INDIAMART | Work Cap 10Yr | ₹ Cr. |
| INDIAMART | Debt 3Years back | ₹ 63.4 Cr. |
| INDIAMART | Debt 5Years back | ₹ 0.00 Cr. |
| INDIAMART | Debt 7Years back | ₹ 0.00 Cr. |
| INDIAMART | Debt 10Years back | ₹ Cr. |
| INDIAMART | Net Block 3Yrs Back | ₹ 65.1 Cr. |
| INDIAMART | Net Block 5Yrs Back | ₹ 9.06 Cr. |
| INDIAMART | Net Block 7Yrs Back | ₹ 8.71 Cr. |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | CF Operations | ₹ 559 Cr. |
| INDIAMART | Free Cash Flow | ₹ 545 Cr. |
| INDIAMART | CF Investing | ₹ 162 Cr. |
| INDIAMART | CF Financing | ₹ -695 Cr. |
| INDIAMART | Net CF | ₹ 26.7 Cr. |
| INDIAMART | Cash Beginning | ₹ 58.1 Cr. |
| INDIAMART | Cash End | ₹ 101 Cr. |
| INDIAMART | FCF Prev Ann | ₹ 460 Cr. |
| INDIAMART | CF Operations PY | ₹ 476 Cr. |
| INDIAMART | CF Investing PY | ₹ -324 Cr. |
| INDIAMART | CF Financing PY | ₹ -143 Cr. |
| INDIAMART | Net CF PY | ₹ 8.56 Cr. |
| INDIAMART | Cash Beginning PY | ₹ 49.6 Cr. |
| INDIAMART | Cash End PY | ₹ 58.3 Cr. |
| INDIAMART | Free Cash Flow 3Yrs | ₹ 1,403 Cr. |
| INDIAMART | Free Cash Flow 5Yrs | ₹ 1,982 Cr. |
| INDIAMART | Free Cash Flow 7Yrs | ₹ 2,408 Cr. |
| INDIAMART | Free Cash Flow 10Yrs | ₹ 2,347 Cr. |
| INDIAMART | CF Opr 3Yrs | ₹ 1,437 Cr. |
| INDIAMART | CF Opr 5Yrs | ₹ 2,020 Cr. |
| INDIAMART | CF Opr 7Yrs | ₹ 2,455 Cr. |
| INDIAMART | CF Opr 10Yrs | ₹ 2,406 Cr. |
| INDIAMART | CF Inv 10Yrs | ₹ -2,595 Cr. |
| INDIAMART | CF Inv 7Yrs | ₹ -2,508 Cr. |
| INDIAMART | CF Inv 5Yrs | ₹ -2,067 Cr. |
| INDIAMART | CF Inv 3Yrs | ₹ -497 Cr. |
| INDIAMART | Cash 3Years back | ₹ 77.7 Cr. |
| INDIAMART | Cash 5Years back | ₹ 77.7 Cr. |
| INDIAMART | Cash 7Years back | ₹ 40.7 Cr. |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | No. Eq. Shares | 6.00 |
| INDIAMART | Book value | ₹ 289 |
| INDIAMART | Inven TO |  |
| INDIAMART | Quick ratio | 0.14 |
| INDIAMART | Exports percentage | 0.00 % |
| INDIAMART | Piotroski score | 9.00 |
| INDIAMART | G Factor | 5.00 |
| INDIAMART | Asset Turnover | 0.35 |
| INDIAMART | Financial leverage | 1.98 |
| INDIAMART | No. of Share Holders | 1,59,877 |
| INDIAMART | Unpledged Prom Hold | 49.2 % |
| INDIAMART | ROIC | 23.9 % |
| INDIAMART | Debtor days | 1.46 |
| INDIAMART | Industry PBV | 2.71 |
| INDIAMART | Credit rating |  |
| INDIAMART | WC Days | -308 |
| INDIAMART | Earning Power | 13.5 % |
| INDIAMART | Graham Number | ₹ 602 |
| INDIAMART | Cash Cycle | 1.46 |
| INDIAMART | Days Payable |  |
| INDIAMART | Days Receivable | 1.46 |
| INDIAMART | Inventory Days |  |
| INDIAMART | Public holding | 15.6 % |
| INDIAMART | FII holding | 23.4 % |
| INDIAMART | Chg in FII Hold | 0.29 % |
| INDIAMART | DII holding | 11.8 % |
| INDIAMART | Chg in DII Hold | 1.21 % |
| INDIAMART | B.V. Prev Ann | ₹ 336 |
| INDIAMART | ROCE Prev Yr | 18.8 % |
| INDIAMART | ROA Prev Yr | 8.86 % |
| INDIAMART | ROE Prev Ann | 14.4 % |
| INDIAMART | No. of Share Holders Prev Qtr | 1,61,823 |
| INDIAMART | No. Eq. Shares 10 Yrs | 1.83 |
| INDIAMART | BV 3yrs back | ₹ 265 |
| INDIAMART | BV 5yrs back | ₹ 47.6 |
| INDIAMART | BV 10yrs back | ₹ |
| INDIAMART | Inven TO 3Yr |  |
| INDIAMART | Inven TO 5Yr |  |
| INDIAMART | Inven TO 7Yr |  |
| INDIAMART | Inven TO 10Yr |  |
| INDIAMART | Export 3Yr | 0.00 % |
| INDIAMART | Export 5Yr | 0.00 % |
| INDIAMART | Div 5Yrs | ₹ 52.3 Cr. |
| INDIAMART | ROCE 3Yr | 21.6 % |
| INDIAMART | ROCE 5Yr | 37.5 % |
| INDIAMART | ROCE 7Yr | 37.5 % |
| INDIAMART | ROCE 10Yr | 37.5 % |
| INDIAMART | ROE 10Yr | % |
| INDIAMART | ROE 7Yr | % |
| INDIAMART | ROE 5Yr Var | % |
| INDIAMART | OPM 5Year | 30.8 % |
| INDIAMART | OPM 10Year | 17.0 % |
| INDIAMART | No. of Share Holders 1Yr | 1,65,627 |
| INDIAMART | Avg Div Payout 3Yrs | 19.8 % |
| INDIAMART | Debtor days 3yrs | 1.57 |
| INDIAMART | Debtor days 3yrs back | 0.68 |
| INDIAMART | Debtor days 5yrs back | 0.41 |
| INDIAMART | ROA 5Yr | 12.0 % |
| INDIAMART | ROA 3Yr | 9.82 % |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | Avg Vol 1Mth | 2,84,898 |
| INDIAMART | Avg Vol 1Wk | 3,61,168 |
| INDIAMART | Volume | 4,85,084 |
| INDIAMART | High price | ₹ 3,293 |
| INDIAMART | Low price | ₹ 2,229 |
| INDIAMART | High price all time | ₹ 4,976 |
| INDIAMART | Low price all time | ₹ 476 |
| INDIAMART | Return over 1day | 1.13 % |
| INDIAMART | Return over 1week | 6.94 % |
| INDIAMART | Return over 1month | 11.5 % |
| INDIAMART | DMA 50 | ₹ 2,714 |
| INDIAMART | DMA 200 | ₹ 2,677 |
| INDIAMART | DMA 50 previous day | ₹ 2,703 |
| INDIAMART | 200 DMA prev. | ₹ 2,674 |
| INDIAMART | RSI | 69.2 |
| INDIAMART | MACD | 85.2 |
| INDIAMART | MACD Previous Day | 79.0 |
| INDIAMART | MACD Signal | 66.3 |
| INDIAMART | MACD Signal Prev | 61.6 |
| INDIAMART | Avg Vol 1Yr | 2,35,366 |
| INDIAMART | Return over 7years | % |
| INDIAMART | Return over 10years | % |
| INDIAMART | Market Cap | ₹ 18,151 Cr. |
| INDIAMART | Current Price | ₹ 3,026 |
| INDIAMART | High / Low | ₹ 3,293 / 2,229 |
| INDIAMART | Stock P/E | 54.3 |
| INDIAMART | Book Value | ₹ 289 |
| INDIAMART | Dividend Yield | 0.67 % |
| INDIAMART | ROCE | 23.9 % |
| INDIAMART | ROE | 17.6 % |
| INDIAMART | Face Value | ₹ 10.0 |
| INDIAMART | WC to Sales | -75.9 % |
| INDIAMART | QoQ Profits | 21.6 % |
| INDIAMART | QoQ Sales | 3.08 % |
| INDIAMART | Net worth | ₹ 1,736 Cr. |
| INDIAMART | Market Cap to Sales | 15.2 |
| INDIAMART | Interest Coverage | 52.1 |
| INDIAMART | EV / EBIT | 39.0 |
| INDIAMART | Debt Capacity | 0.22 |
| INDIAMART | Debt To Profit | 0.12 |
| INDIAMART | Capital Employed | ₹ -372 Cr. |
| INDIAMART | CROIC | 24.1 % |
| INDIAMART | debtplus | 0.04 |
| INDIAMART | Leverage | ₹ 1.98 |
| INDIAMART | Dividend Payout | 35.9 % |
| INDIAMART | Intrinsic Value | ₹ 1,559 |
| INDIAMART | CDL | 0.16 % |
| INDIAMART | Cash by market cap | 0.00 |
| INDIAMART | 52w Index | 74.9 % |
| INDIAMART | Down from 52w high | 8.11 % |
| INDIAMART | Up from 52w low | 35.8 % |
| INDIAMART | From 52w high | 0.92 |
| INDIAMART | Mkt Cap To Debt Cap | 3.59 |
| INDIAMART | Dividend Payout | 35.9 % |
| INDIAMART | Graham | ₹ 602 |
| INDIAMART | Price to Cash Flow | 32.5 |
| INDIAMART | ROCE3yr avg | 21.6 % |
| INDIAMART | PB X PE | 567 |
| INDIAMART | NCAVPS | ₹ -151 |
| INDIAMART | Mar Cap to CF | 32.5 |
| INDIAMART | Altman Z Score | 9.60 |
| INDIAMART | M.Cap / Qtr Profit | 182 |