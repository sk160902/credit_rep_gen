# Complete Company Data

## Modal Content
About
[
edit
]
Bajaj Finserv Ltd. is the holding company for the various financial services businesses under the Bajaj group. It serves millions of customers by providing solutions for asset acquisition through financing, asset protection through general insurance, family and income protection in the form of life and health insurance, and retirement and savings solutions.
[1]
Key Points
[
edit
]
Revenue Split
Life Insurance: 25% in FY22 vs 55% in FY18
General Insurance: 28% in FY22 vs 0% in FY18
Retail Financing: 45% in FY22 vs 43% in FY18
Investment:1% in FY22 vs 2% in FY18.
[1]
[2]
[3]
Group
[4]
The co. offers both general & life insurance, and lending solutions to its customers through its subsidiaries namely
Bajaj Allianz General Insurance Company Limited, Bajaj Allianz Life Insurance Company Limited, Bajaj Finance Limited, Bajaj Housing Finance Limited and Bajaj Finserv Asset Management.
Bajaj Finserv Limited (BFS) is the financial services arm under Bajaj Holdings and Investment Ltd (BHIL)
.
Platforms
1 Bajaj Finserv Direct Limited - Digital Marketplace & Technology Services
2 Bajaj Finserv Health Limited - Health-tech Platform
3 Bajaj Financial Securities Limited - Digital Stockbroker
Bajaj Allianz General Insurance Company Limited
- Diversified product portfolio offering across retail and corporate segments. Multi channel distribution network encompassing multiline agents, bancassurance, motor dealers’ broking, direct, and ecommerce network servingall segments. It is focused on penetrating small towns (Geo model) and retail segment.
[5]
Business Mix 9MFY24
Motor (Retail) - 28%
Health (Retail) - 4%
Group Health - 14%
Govt health - 16%
Property, Liability, Engg - 17%
Agri (Crop Insurance) - 12%
Others - 9%
[6]
Channel Mix
[7]
Direct Business - 40%
Brokers - 34%
Individual Agents - 15%
Others - 11%
Bajaj Allianz Life Insurance
- It is the fastest growing private Life Insurance co. and in Top 10 Players in FY23 & 9M FY24. It has the highest solvency ratio in the industry and covered  2.76 crore group lives in FY23. The company has a Pan India distribution reach with a presence of 500+ branches. It has 1.43 Lakh+ agents.
[8]
Product Mix
Individual - 58% Group - 42%
IRNB Mix
Unit Linked -38%
Annuity - 5%
Non Par Protection - 4%
Non Par Savings - 25%
Par - 28%
[9]
Bajaj Finserv Health Limited
- Health Management platform to solve for Access and Financing of healthcare to Indian consumers.
100,000+ Doctors on platform, 5,500+ lab touch points and 2,100+ hospitals on network.
Bajaj MARKETS
- BFSI marketplace is a unique & diversified Marketplace for Financial Services which attracts large number of consumers and cross-sells products by leveraging Technology & Analytics. Its an open Architecture platform offers Financial products’ variants across Loans, Cards, Insurance, Investments & Payments in partnership with leading industry players. It offers a wide choice from offerings of ~81 manufacturers and  ~121 financial products.
[10]
Bajaj Finserv AMC
- Bajaj Finserv Asset Management Limited filed for its first 7 products with SEBI in Mar-23 and Apr23.Total Assets Under Managements stood at $ 770 MM.
Network
General Insurance
: The co’s general insurance business has over 238 Bank partners, 47,600+ agents, 36 NBFCs, 5 SFBs, 1 Payments Bank, 138 Co-operative banks, 9 RRBs, and over 9000 networks of automobile dealers across pan India, 34,800+ active CSC centers, 17+ partnerships across insurance companies, aggregators, wallets such as Phone Pe, payments bank, etc.
Lending
: As of Q3FY24, the consolidated AUM for lending mix for Urban was 34%, Rural,9% ,Commercial - 13%, SME - 13%, Commercial - 13% and mortgages - 31%.
[11]
Co-Branded Offerings
Bajaj Finserv RBL Bank co-branded credit card users stood at 2.75 Mn as of 31 March 2022.
Bajaj Finserv Mobikwik active wallet users stood at 22.1 Mn as of 31 March 2022 who have linked EMI card to wallet.
[12]
Key Digital Initiatives
The company undertook many digital initiatives to increase customer satisfaction and ease. Few of these initiatives include DigiSwasth, WhatsApp + BOING 2.0, Data Lake, Smart Assist, etc.
[13]
[14]
Stock Split
[15]
In July,22, Bajaj Finserv Limited announced a 5:1 Stock Split along with a 1:1 Bonus Issue.
Strategic Acquisition
[16]
The company acquired Vidal Health Care Services (VHC) for $ 39.16 MM to be settled in cash. It is One of the top health services management Companies and amongst the largest third-party administrators (TPA) in India.
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,055 | 6,023 | 11,335 | 20,533 | 24,507 | 32,862 | 42,605 | 54,351 | 60,592 | 68,406 | 82,072 | 110,382 | 118,582 |
| Expenses + | 4,124 | 1,531 | 5,823 | 13,795 | 15,794 | 22,074 | 27,569 | 36,094 | 40,950 | 46,951 | 52,204 | 69,497 | 75,437 |
| Operating Profit | 3,931 | 4,491 | 5,511 | 6,739 | 8,713 | 10,788 | 15,037 | 18,258 | 19,641 | 21,455 | 29,868 | 40,886 | 43,145 |
| OPM % | 49% | 75% | 49% | 33% | 36% | 33% | 35% | 34% | 32% | 31% | 36% | 37% | 36% |
| Other Income + | 2 | 3 | 8 | 0 | 0 | 1 | 2 | 0 | -7 | 8 | 1 | -4 | 9 |
| Interest | 1,204 | 1,562 | 2,230 | 2,877 | 3,716 | 4,531 | 6,657 | 9,500 | 9,274 | 9,629 | 12,380 | 18,607 | 19,971 |
| Depreciation | 22 | 31 | 38 | 58 | 73 | 160 | 226 | 457 | 498 | 563 | 678 | 900 | 965 |
| Profit before tax | 2,708 | 2,902 | 3,251 | 3,804 | 4,925 | 6,099 | 8,155 | 8,302 | 9,862 | 11,271 | 16,811 | 21,375 | 22,218 |
| Tax % | 18% | 24% | 26% | 27% | 30% | 32% | 34% | 28% | 25% | 26% | 27% | 27% |  |
| Net Profit + | 2,214 | 2,191 | 2,409 | 2,775 | 3,450 | 4,176 | 5,374 | 5,994 | 7,367 | 8,314 | 12,210 | 15,595 | 16,095 |
| EPS in Rs | 9.89 | 9.71 | 10.62 | 11.71 | 14.21 | 16.65 | 20.23 | 21.17 | 28.09 | 28.63 | 40.29 | 51.07 | 52.28 |
| Dividend Payout % | 2% | 2% | 2% | 1% | 1% | 1% | 1% | 2% | 1% | 1% | 2% | 2% |  |
| 10 Years: | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Allianz SE Reinsurance, Branch Asia Pacific JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 171 | 432 | 144 |  | 14 | 4.67 | 22 |  |  |  |
| Reinsurance premium paid/payable | 442 | 106 | -4.11 | -9.17 |  |  |  |  |  |  |
| CAT XOL claim recovered | 155 | 18 | 8.09 |  | 2.04 | 0.78 |  |  |  |  |
| Commission on reinsurance received/receivable | 105 | 47 | 2.19 |  |  |  |  |  |  |  |
| CAT XOL premium paid/payable | 12 | 14 | 1.88 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | 29 |  |  | -1.77 |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  | 7.41 | 7.01 | 7.40 |  |  |  |
| Profit commission on reinsurance |  | 5.29 |  |  |  |  |  |  |  |  |
| Balance - Claims recovery on reinsurance | 4.60 |  |  |  |  |  |  |  |  |  |
| Reinsurance profit commssion receivable | 0.91 | 1.74 |  |  |  |  |  |  |  |  |
| CAT XOL premium paid |  |  |  |  | 0.27 | 0.32 | 0.26 |  |  |  |
| Balance - Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -9.17 | -5.50 | 6.96 |  |  |  |
| Bajaj Auto Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  |  |  | 500 |
| Inter-corporate deposit repaid |  |  |  |  |  |  |  |  |  | 500 |
| Fixed deposit repaid |  |  |  |  |  |  | 400 | 100 |  |  |
| Investments held |  | 30 | 35 |  | 36 | 25 | 46 | 46 | 49 | 114 |
| Investment sold | 151 |  |  |  |  |  |  |  |  |  |
| Business support services received | 17 | -0.02 | 21 |  |  |  |  | 27 | 32 | 39 |
| Sale of windpower | 1.67 | 18 | 22 |  | 14 | 15 | 11 | 6.81 | 0.66 |  |
| Insurance premium received by BAGICL/BALICL | 9.29 | 14 | 16 |  | 13 | 12 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 16 |  | 25 | 23 |
| Interest paid on non convertible debentures |  |  |  |  |  |  |  |  | 25 | 25 |
| Interest subsidy | 7.24 | 0.08 | 8.33 |  | 9.85 | 0.04 | 1.72 | 11 | 0.46 | 1.35 |
| Insurance claims paid by BAGICL/BALICL | 7.27 | 19 | 3.14 |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 21 |  |  |
| OA charges reimbursement |  |  |  |  |  |  | 8.14 | 5.20 | 0.52 |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 14 |  |  |
| Bad debts sharing received |  |  |  |  |  |  |  |  | 8.46 | 2.90 |
| Interest accrued on Inter-corporate deposits |  |  |  |  |  |  |  |  | -9.52 | 18 |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.55 |  | 6.75 | 1.06 |
| Dividend income |  |  |  |  | 0.75 | 2.25 |  | 1.75 | 1.75 | 1.75 |
| Business support services rendered | 1.52 | 0.82 | 0.65 |  |  |  | 0.02 | 0.59 | 0.18 | 0.17 |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 2.30 | 1.65 |  |  |  |  |
| Payment towards lease obligation |  |  |  |  |  | 1.06 | 1.29 | 1.34 |  |  |
| Rent and maintenance expenses |  |  |  |  |  |  |  |  | 1.55 | 1.65 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  | 2.27 |  |
| Security deposit paid |  | 0.21 | 0.21 |  | 0.23 | 0.23 | 0.23 | 0.24 | 0.24 | 0.24 |
| Aviation charges paid | 0.54 |  |  |  |  |  |  |  |  |  |
| Revenue expenses reimbursement paid |  |  |  |  |  | 0.10 | 0.08 | 0.04 | 0.05 | 0.04 |
| Balance - Security deposit paid | 0.21 |  |  |  |  |  |  |  |  |  |
| Balance - Interest subsidy | 0.07 |  |  |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  | 0.01 |  |  |  |  |  |
| Inter-corporate deposit accepted |  |  |  |  |  |  |  |  | 500 | 500 |
| Balance - Business support services received | -0.69 |  |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | -0.83 | 0.23 | -0.88 |  |  |  |
| Lease liability recognised at inception |  |  |  |  |  | -1.91 |  |  |  |  |
| Balance - Unallocated premium | -6.46 |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -4.67 | -8.09 |  |  |  |  |
| Fixed deposit interest accrued |  |  |  |  |  | -16 | -10 | 0.90 |  |  |
| Unallocated premium |  | -6.65 | -3.53 |  |  |  | -8.37 | -11 | -12 | 16 |
| Fixed deposit accepted |  |  |  |  |  | 500 | 100 |  |  |  |
| Secured non-convertible debentures issued |  |  |  |  |  |  |  | 500 | 500 |  |
| Mukand Ltd. |  |  |  |  |  |  |  |  |  |  |
| Loan given | 35 | 31 | 34 | 24 | 24 | 25 |  |  |  |  |
| Principal repayment received | 16 | 16 | 22 |  | 18 | 24 | 25 |  |  |  |
| Balance - Loan given | 47 |  |  | 43 |  |  |  |  |  |  |
| Sale of windpower | 40 | 1.99 | 0.63 | 0.29 | 0.29 | 0.44 | 0.52 | 3.87 | 0.25 |  |
| Interest received | 5.59 | 5.14 | 3.63 |  | 4.17 | 4.21 | 1.34 |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 5.85 |  | 7.08 | 5.87 |
| Insurance premium received | 3.97 | 3.85 | 3.61 |  |  |  |  | 6.82 |  |  |
| Security deposit paid |  | 4 | 4 | 4 | 4 | 0.10 | -0.10 |  |  |  |
| Insurance claims paid | 3.07 | 6.98 | 2.13 |  |  |  |  |  |  |  |
| Balance - Security deposit paid | 4 |  |  | 4 |  |  |  |  |  |  |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.98 |  | 4.55 | 1.37 |
| Balance - Sale of windpower | 3.74 |  |  | 1.80 |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 1.02 | 4.18 |  |  |  |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 2.42 |  |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 0.61 | 0.87 |  |  |  |  |
| OA charges reimbursement |  |  |  |  |  |  | 0.55 |  |  |  |
| Rent and other expenses paid | 0.06 | 0.06 | 0.06 |  | 0.06 | 0.05 |  |  |  | 0.24 |
| Balance - Unallocated premium | -0.01 |  |  | -0.02 |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  |  | -0.51 |  |  |  |  |
| Unallocated premium |  | -0.01 | -0.01 |  |  |  | -0.32 | -0.70 | -0.52 | 0.21 |
| Bajaj Allianz Staffing Solutions Ltd. |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges |  | 178 | -3.35 |  |  |  |  | 86 | 98 | 165 |
| Insurance premium received |  | 1.25 | 0.70 |  |  |  |  | 1.30 |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  | 1.30 | 1.65 |
| Business support services received |  |  |  |  |  |  |  | 0.10 | 0.28 | 2.34 |
| Other receipts |  |  |  |  |  |  |  | 0.12 | 0.13 | 0.22 |
| Insurance claim paid |  | 0.43 |  |  |  |  |  |  |  |  |
| Other income |  | 0.20 | 0.12 |  |  |  |  |  |  |  |
| Reimursement of expenses received |  | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Security deposits received |  |  |  |  |  |  |  |  | -0.05 | 0.07 |
| Balance - Unallocated premium |  |  |  | -0.01 |  |  |  |  |  |  |
| Security deposit received |  |  |  |  |  |  |  | -0.05 |  |  |
| Unallocated premium |  | -0.02 | -0.02 | -0.05 |  |  |  | -0.07 | -0.02 | 0.05 |
| AWP P&C SA Saint Ouen Paris JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance paid |  |  |  |  | 104 | 173 | 18 |  |  |  |
| Claims paid on reinsurance accepted |  |  | 0.25 |  | 18 | 72 | 56 |  |  |  |
| Reinsurance premium received/receivable |  |  | -2.40 | 30 |  |  |  |  |  |  |
| Other expenses paid |  |  |  |  |  |  | 5.65 |  |  |  |
| Commission on reinsurance paid/payable |  |  | 4.16 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium received/receivable |  |  |  | -4.58 |  |  |  |  |  |  |
| Reinsurance premium received |  |  |  |  |  |  | -46 |  |  |  |
| Reinsurance premium paid |  |  |  |  | -30 | -17 |  |  |  |  |
| Bajaj Electricals Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 11 |  | 46 | 82 |
| Inter-corporate deposit repaid |  |  |  |  |  |  |  |  |  | 105 |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 7.20 |  | 9.46 | 54 |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 8.41 | 19 |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 22 |  |  |
| Insurance premia received | 4.22 | 4.78 | 5.67 |  |  |  |  |  |  |  |
| Insurance claims paid | 4.98 | 4.46 | 0.52 |  |  |  |  |  |  |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 6.54 |  |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 1.58 | 4.09 |  |  |  |  |
| Interest accrued on Inter-corporate deposits |  |  |  |  |  |  |  |  | -0.48 | 1.46 |
| Purchases | 0.34 | -0.01 | 0.20 | -0.06 | -0.06 |  |  |  |  |  |
| Interest subsidy |  |  |  |  |  | 0.03 | 0.02 | 0.02 | 0.07 | 0.06 |
| Purchase of property, plant and equipment |  |  |  |  |  | -0.08 | -0.12 | 0.01 | 0.20 | 0.19 |
| Other expenses |  |  |  |  |  |  | 0.03 |  |  |  |
| Balance - Purchases |  |  |  | 0.01 |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.09 |  |  | -4.79 |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -0.13 | -6.22 |  |  |  |  |
| Inter-corporate deposit accepted |  |  |  |  |  |  |  |  | 70 | 60 |
| Unallocated premium |  | -0.12 | -0.05 | -0.13 |  |  | -6.67 | -7.62 | -7.86 | 12 |
| Bajaj Allianz Financial Distributors Ltd. |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges | 222 | 67 |  |  |  |  |  |  |  |  |
| Services received | 0.36 | 0.39 | 0.53 |  | 1.05 | 1.76 |  | 1.94 | 2.06 | 2.64 |
| Insurance commission paid/payable | 12 | -0.75 | -0.59 | -1.74 |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | 1.20 | 1.20 |  |  | 1.20 | 1.20 |
| Contribution to Equity |  |  |  | 1.20 |  |  |  | 1.20 |  |  |
| Balance - Contribution to Equity | 1.20 |  |  | 1.20 |  |  |  |  |  |  |
| Contribution to Equity (12,00,000 shares of H 10 each) |  | 1.20 | 1.20 |  |  |  |  |  |  |  |
| Insurance commission paid by BAGIC/BALIC |  |  |  |  |  |  |  | 0.08 | 0.44 | 1.20 |
| Insurance premium received | 0.24 | 0.06 | 0.09 |  |  |  |  | 0.02 |  |  |
| Rental income | 0.28 | 0.05 | 0.04 |  |  |  |  |  |  |  |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 0.11 | 0.10 |  |  |  |  |
| Insurance claim paid |  | 0.16 |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  | 0.04 | 0.06 |
| Benefits paid | 0.03 | 0.02 |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | 0.03 |  |  |  |  |  |
| Unallocated premium |  | -0.01 | -0.05 |  |  |  |  |  | -0.04 | 0.12 |
| Reimursement of expenses received |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  |  | -0.01 |  |  |  |  |
| Security deposit received |  |  |  |  |  | -0.01 |  | -0.01 |  |  |
| Balance - Services received | -0.03 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | 0.01 |  |  | -0.07 |  |  |  |  |  |  |
| Balance - Manpower supply charges | -0.07 |  |  |  |  |  |  |  |  |  |
| Insurance commission paid by BAGICL/BALICL |  |  |  |  | -1.74 | -1.29 |  |  |  |  |
| Balance - Insurance commission paid/payable | -0.65 |  |  | -3.68 |  |  |  |  |  |  |
| Pennant Technologies Pvt. Ltd |  |  |  |  |  |  |  |  |  |  |
| Investment in compulsorily convertible preference shares (Deemed equity) |  |  |  |  |  |  |  |  |  | 154 |
| Investment in equity shares |  |  |  |  |  |  |  |  |  | 114 |
| Information technology design and development charges |  |  |  |  |  |  |  |  |  | 12 |
| Annual maintenance charges paid |  |  |  |  |  |  |  |  |  | 0.82 |
| Bajaj Allianz Staffing Solutions Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges |  |  |  |  | 103 | 0.01 | 93 |  |  |  |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 1.01 | 0.01 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 1 |  |  |  |
| Business support charges received |  |  |  |  |  | 0.11 | 0.08 |  |  |  |
| Other receipts |  |  |  |  |  |  | 0.11 |  |  |  |
| Claims paid |  |  |  |  |  | 0.05 | 0.05 |  |  |  |
| Unallocated premium |  |  |  |  |  |  | -0.05 |  |  |  |
| Superannuation contribution |  |  |  |  | -0.05 | -0.02 |  |  |  |  |
| Security deposit received |  |  |  |  |  | -0.05 | -0.05 |  |  |  |
| Snapwork Technologies Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Investment in compulsorily convertible preference shares (Deemed equity) |  |  |  |  |  |  |  |  | 64 | 64 |
| Investment in equity shares |  |  |  |  |  |  |  |  | 28 | 28 |
| Information technology design and development charges |  |  |  |  |  |  |  |  | 5.61 | 0.83 |
| Support charges |  |  |  |  |  |  |  |  |  | 0.48 |
| Allianz Global Corporate & Speciality SE, Munich JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 36 | 13 | 48 |  |  |  |
| Reinsurance premium paid/payable |  |  |  | 20 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | 20 | -3.19 | -2.51 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.22 |  | 0.12 |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.03 |  |  |  |  |  |  |
| Billable expenses incurred on behalf |  |  |  | -0.03 | -0.03 |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.28 |  |  |  |  |  |  |
| Allianz Global Risks US Insurance Company JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  | 0.18 |  | 0.01 | 45 | 98 |  |  |  |
| Commission on reinsurance premium | 0.06 | 0.10 | 0.22 |  | 0.02 | 18 | 20 |  |  |  |
| Reinsurance premium paid/payable | 0.53 | 0.16 | -0.29 | -0.04 |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.44 |  |  | -0.03 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.04 | -38 | -15 |  |  |  |
| Bajaj Auto Senior staff Group Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Gratuity contribution |  |  |  |  | 23 | 29 | 4.80 | 22 | 25 | 23 |
| Allianz Global Corporate & Speciality SE - France Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 93 | 1.40 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 3.14 | 1.71 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -9.15 | -9.48 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE Munich Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 59 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 18 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 12 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -8.67 |  |  |  |  |  |  |  |  |  |
| Bajaj Auto Employees Group Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Gratuity contribution |  |  |  |  | 6.02 | 14 | 15 | 14 | 14 | 14 |
| Sanjiv Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  |  |  | 91 |  |  |
| Post-employment benefits |  |  |  |  | 0.63 | 0.91 | 0.91 | 1.26 | 1.63 | 2.04 |
| Deposit paid |  |  |  | 0.39 | 0.39 | 0.41 | 0.41 | 1.08 | 1.08 | 1.08 |
| Remuneration | 1.37 | 1.46 | 1.54 |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  | 0.33 | 0.41 | 0.43 | 0.77 | 1.10 | 1.15 |
| Sitting fees |  | 0.09 | 0.09 |  | 0.09 | 0.22 | 0.25 | 0.42 | 0.37 | 0.39 |
| Sitting Fees | 0.09 |  |  |  |  |  |  |  |  |  |
| Brokerage |  |  |  |  |  |  |  | 0.01 |  |  |
| Short-term employee benefits (including commission) |  |  |  |  |  |  |  | -11 | -14 | 24 |
| Balance - Commission | -2.90 |  |  |  |  |  |  |  |  |  |
| Balance - Short-term employee benefits (including Commission) |  |  |  | -3.57 |  |  |  |  |  |  |
| Commission | 2.90 | -3.24 | -3.42 |  |  |  |  |  |  |  |
| Short-term employee benefits (including Commission) |  |  |  | -5.46 | -5.46 | -7.39 | -8.04 |  |  |  |
| Allianz Risk Transfer AG Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 29 | 33 | -0.03 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.27 | 0.78 | 0.36 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 0.14 |  |  | 0.50 |  |  |  |  |  |
| Bajaj Auto Ltd |  |  |  |  |  |  |  |  |  |  |
| Investments held |  |  |  | 36 |  |  |  |  |  |  |
| Balance - Investments held |  |  |  | 34 |  |  |  |  |  |  |
| Balance - Interest subsidy |  |  |  | 1.87 |  |  |  |  |  |  |
| Security deposit paid |  |  |  | 0.23 |  |  |  |  |  |  |
| Balance - Security deposit paid |  |  |  | 0.21 |  |  |  |  |  |  |
| Balance - Business support services rendered |  |  |  | 0.03 |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.56 |  |  |  |  |  |  |
| Business support services received |  |  |  | -0.83 |  |  |  |  |  |  |
| Balance - Unallocated premium |  |  |  | -3.24 |  |  |  |  |  |  |
| Unallocated premium |  |  |  | -4.67 |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE Munich Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 15 | 44 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 8.74 | 10 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -7.39 | -11 |  |  |  |  |  |  |  |
| Rajeev Jain Individual |  |  |  |  |  |  |  |  |  |  |
| Fair value of stock options granted |  |  |  |  | 11 | 13 | 16 |  |  |  |
| Equity shares issued pursuant to stock option scheme |  |  |  |  | 2.19 | 1.65 | 8.11 |  |  |  |
| ESOPs exercised | 2.86 |  |  |  |  |  |  |  |  |  |
| Remuneration | 5.14 |  |  | -6.36 | -6.36 | 11 | -1.50 |  |  |  |
| Brokerage and service charges received |  |  |  |  |  | 0.03 | 0.09 |  |  |  |
| Balance - Remuneration | -2.28 |  |  | -5.16 |  |  |  |  |  |  |
| AWP Services India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  |  |  |  | 17 | 10 | 18 |  |  |  |
| Claim assisstance fee paid |  |  |  |  | 3.17 |  |  |  |  |  |
| Balance - Other expenses paid/payable |  |  |  | -0.36 |  |  |  |  |  |  |
| Other expenses paid/payable |  |  |  | -2.65 |  |  |  |  |  |  |
| Other expenses paid |  |  |  |  | -2.65 | -0.44 | -0.01 |  |  |  |
| AGA Services (India) Private Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  | 13 | 24 |  |  |  |  |  |  |  |
| Claim assisstance fee paid |  | 2.59 | 3.22 |  |  |  |  |  |  |  |
| Other expenses paid/payable |  | -0.13 | -1.07 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE -France Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 24 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 23 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 2.15 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -9.72 |  |  |  |  |  |  |  |  |  |
| Tapan Singhel Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 3.83 |  |  |  | 9.68 | 12 | 13 |  |  |  |
| AWP Assistance India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  |  |  |  | 7.75 | 8.19 | 9.69 |  |  |  |
| Claim assisstance fee paid |  |  |  |  | 5.01 |  |  |  |  |  |
| Benefits paid |  |  |  |  | 3.36 |  |  |  |  |  |
| Insurance commission paid |  |  |  |  | -0.12 | 1.24 | 0.30 |  |  |  |
| Billable expenses incurred on behalf |  |  |  | 0.03 | 0.03 | 0.01 | 0.01 |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | 0.03 |  |  |  |  |  |  |
| Insurance commission paid/payable |  |  |  | -0.12 |  |  |  |  |  |  |
| Balance - Insurance commission paid/payable |  |  |  | -0.20 |  |  |  |  |  |  |
| Balance - Premium received as an agent |  |  |  | -0.32 |  |  |  |  |  |  |
| Premium received as an agent |  |  |  | -0.69 | -0.69 | -0.10 | -0.07 |  |  |  |
| Allianz Global Corporate & Speciality AG, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 2.31 | 28 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 2.94 | 1.42 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -1.11 | -0.79 | 1.51 |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.79 |  |  |  |  |  |  |
| Euler Hermes Deutschland Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 4.22 | 10 | 0.04 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 9.24 | -0.16 | 0.18 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 1.69 | 1.51 |  |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf | 0.85 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.44 |  |  | 0.96 |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 2.48 | 0.99 | 0.54 | -1.85 | -1.85 |  |  |  |  |  |
| Tarun Chugh Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  | 8.45 | 9.86 | 8.22 |  |  |  |
| Euler Hermes Europe, Singapore Branch JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 1.10 | 2.43 |  | 3.78 | 3.93 | 4.21 |  |  |  |
| Commission on reinsurance received/receivable | 0.78 | 2.27 | 1.47 |  |  |  |  |  |  |  |
| Billable expenses recovery |  |  |  |  |  | 2.50 | 2 |  |  |  |
| Other receivables |  |  |  |  |  | 0.40 | 2.07 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.72 | 0.70 | 1.02 |  |  |  |
| Reinsurance premium paid |  |  |  |  | 1.21 | 1.27 | -2.19 |  |  |  |
| Balance - Reinsurance premium paid/payable | -3.09 |  |  | -0.57 |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 3.87 | -4.04 | -4.75 | 1.21 |  |  |  |  |  |  |
| AGA Services (India) Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 20 |  |  |  |  |  |  |  |  |  |
| Other expenses paid/payable | 1.25 |  |  |  |  |  |  |  |  |  |
| Fees received for loss minimisation activity | 0.19 |  |  |  |  |  |  |  |  |  |
| Balance - Other expenses paid/payable | -0.33 |  |  |  |  |  |  |  |  |  |
| Bajaj Allianz Life Insurance Co Ltd Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 16 |  |  |
| Manish Kejriwal Individual |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  |  | 15 |  |
| Interest paid on non convertible debentures |  |  |  |  |  |  |  |  | 1.07 |  |
| Sitting fees |  |  |  |  | 0.01 | 0.03 | 0.13 | 0.15 | 0.13 | 0.10 |
| Commission |  |  |  | -0.01 | -0.01 | -0.05 | -0.20 | -0.29 | -0.26 | 0.30 |
| Bajaj Allianz Life Insurance Co. Ltd. - Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  | 7.22 | 7.13 |  |  |  |  |
| Allianz Global Corporate and Speciality AG, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 11 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 3.65 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.55 |  |  |  |  |  |  |  |  |  |
| Risk survey fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Risk survey fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -2.10 |  |  |  |  |  |  |  |  |  |
| AGCS Marine Insurance Company Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.99 | 2.38 | 5.51 |  | 0.03 |  |  |  |  |  |
| Reinsurance premium paid/payable | 2.49 | -1.66 | 1.27 | 0.03 | 0.03 |  |  |  |  |  |
| Commission on reinsurance premium | 0.65 | 0.77 | 0.61 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | 0.22 |  |  | 0.05 |  |  |  |  |  |  |
| Poddar Housing and Development Ltd. |  |  |  |  |  |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | 13 |  |  |  |
| Interest Income |  |  |  |  |  |  | 0.02 |  |  |  |
| Hind Musafir Agency Ltd. |  |  |  |  |  |  |  |  |  |  |
| Services received | 23 | -0.78 | -2.25 | -3.18 | -3.18 | -0.41 | -0.04 | -0.17 | -0.20 | 1.33 |
| Service charges paid |  |  |  |  | 0.29 | 0.40 | 0.06 | 0.13 | 0.35 |  |
| Advances |  |  |  |  |  | 0.09 | 0.06 |  | 0.01 |  |
| Other expenses paid/payable | 0.11 | 0.01 |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.02 | 0.03 |  |  |  |  |
| Insurance claims paid |  | 0.01 |  |  |  |  |  |  |  |  |
| Balance - Other expenses paid/payable | -0.01 |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.01 | 0.02 | 0.02 |  |  |  |  | -0.22 |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.04 |  | -3.76 | 2.04 |
| Balance - Services received | -0.46 |  |  | -1.70 |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE, UK JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 12 |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  | -0.01 | 0.01 | 0.02 |  |  |  |
| Reinsurance premium paid |  |  |  |  | 1.51 | -1.36 | -0.23 |  |  |  |
| Allianz CP General Ins Co. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claims paid/payable | 9.65 | 0.53 |  |  |  |  |  |  |  |  |
| Software consultancy fees |  | 0.97 |  |  |  |  |  |  |  |  |
| AGA Assistance (India) Private Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claim assisstance fee paid |  | 4.99 | 3.93 |  |  |  |  |  |  |  |
| Insurance claims paid |  | 1.19 | 1.16 |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf |  | 0.08 | 0.07 |  |  |  |  |  |  |  |
| Unallocated premium |  |  | 0.02 |  |  |  |  |  |  |  |
| Insurance premium received |  |  | 0.01 |  |  |  |  |  |  |  |
| Insurance commission paid/payable |  | -0.04 | -0.06 |  |  |  |  |  |  |  |
| Premium received as an agent |  | -0.05 | -0.23 |  |  |  |  |  |  |  |
| Atul Jain Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 7.51 |  |  |  |
| Fair value of stock options granted |  |  |  |  |  |  | 3.23 |  |  |  |
| Tapan Singhel (MD and CEO - BAGICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 4.01 | 4.99 |  |  |  |  |  |  |  |
| AGA Assistance (India) Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 7.44 |  |  |  |  |  |  |  |  |  |
| Insurance commission paid/payable | 0.54 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.19 |  |  |  |  |  |  |  |  |  |
| Balance - Premium received as an agent | 0.02 |  |  |  |  |  |  |  |  |  |
| Balance - Insurance commission paid/payable | -0.05 |  |  |  |  |  |  |  |  |  |
| Anuj Agarwal (MD and CEO - BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 2.49 | 4.25 |  |  |  |  |  |  |  |
| Bajaj Auto Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | 0.92 | 1.06 | 0.99 | 1.11 | 1.31 | 1.21 |
| Allianz Technlogy SE, India JV |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  | 0.01 | 0.01 | 6.39 |  |  |  |
| Euler Hermes Services India Pvt Ltd. |  |  |  |  |  |  |  |  |  |  |
| Credit risk assessment fees paid |  | 2.11 | -0.17 |  | 2.06 | 2.21 |  |  |  |  |
| Bajaj Allianz Life Insurance Co Ltd. Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  | 5.79 |  |  |  |
| Allianz Global Corporate & Speciality AG Singapore JV |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | 0.49 | 0.73 | 1.06 |  |  |  |
| Claim recovery on reinsurance |  |  | 0.24 |  | 0.66 | 0.28 | 0.59 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.90 | 0.02 |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.21 | 0.18 |  |  |  |  |  |  |  |
| Risk survey fee |  | 0.18 |  |  |  |  |  |  |  |  |
| Billable expenses reimbursed on behalf |  |  | 0.03 | 0.05 | 0.05 |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.16 | -0.30 | 0.49 |  |  |  |  |  |  |
| Reinsurance premium received/receivable |  | 0.02 |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.45 |  |  |  |  |  |  |
| Indian School of Business |  |  |  |  |  |  |  |  |  |  |
| Training expenses |  |  |  |  |  |  |  |  | 1.39 | 3.21 |
| Reimbursement of expenses paid |  | 0.30 |  |  |  |  |  |  |  |  |
| Jamnalal Sons Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Rent and other expenses |  | 0.08 | 0.22 |  | 0.70 | 0.31 |  | 0.87 |  |  |
| Security deposit |  | 0.09 | 0.09 |  | 0.29 | 0.29 |  | 0.32 | 0.26 | 0.14 |
| Rent and other expenses paid |  |  |  |  |  |  |  |  | 0.61 | 0.37 |
| Dividend paid |  |  |  |  |  |  |  | -0.03 | 0.26 | 0.38 |
| Payment towards lease obligation |  |  |  |  |  | 0.34 |  |  |  |  |
| Security deposit received |  |  |  |  |  |  |  |  |  | 0.13 |
| Interest expense on lease obligation |  |  |  |  |  | 0.10 |  |  |  |  |
| Revenue expenses reimbursement received |  |  |  |  |  |  |  |  | 0.05 | 0.03 |
| Contribution to equity |  |  |  |  |  | -0.03 |  |  | -0.03 | 0.03 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.03 |  |  |
| Lease liability recognised at inception |  |  |  |  |  | -0.97 |  |  |  |  |
| Bajaj Allianz Financial Distributors Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Insurance commission paid by BAGIC/BALIC |  |  |  |  |  |  | 1.72 |  |  |  |
| Services received |  |  |  |  |  |  | 1.72 |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | 1.20 |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.01 |  |  |  |
| Security deposit received |  |  |  |  |  |  | -0.01 |  |  |  |
| Unallocated premium |  |  |  |  |  |  | -0.01 |  |  |  |
| Mukand Engineers Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.35 | 0.26 | 0.35 |  |  |  |  | 0.50 |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.73 | 0.51 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.72 |  | 0.05 |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 0.33 | 0.26 |  |  |  |  |
| Insurance claims paid | 0.21 | 0.12 | 0.11 |  |  |  |  |  |  |  |
| Annual maintenance charges paid |  |  |  |  |  |  |  |  |  | 0.43 |
| Insurance claims paid by |  |  |  |  |  |  |  | 0.10 |  |  |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.10 |  |  |  |
| Balance - Insurance claims paid | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.01 |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -0.01 | -0.30 |  |  |  |  |
| Unallocated premium |  | -0.13 | -0.01 |  |  |  | -0.08 | -0.14 |  |  |
| Allianz Global Corporate and Speciality AG Singapore Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium received/receivable | 2.55 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.62 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium received/receivable | 0.55 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance premium | 0.28 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.21 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.08 |  |  |  |  |  |  |  |  |  |
| Risk survey fee | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Risk survey fee | -0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.23 |  |  |  |  |  |  |  |  |  |
| Euler Hermes Services India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Credit risk assessment fees paid | 1.89 |  |  |  |  |  | 1.99 |  |  |  |
| Sanjali Family Trust |  |  |  |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  |  | 0.14 | 0.55 | 0.57 | 0.60 | 0.63 |
| Security deposit paid |  |  |  |  |  | 0.14 | 0.14 | 0.14 | 0.14 | 0.14 |
| Revenue expenses reimbursement received |  |  |  |  |  | 0.03 | 0.07 | 0.08 | 0.09 | 0.09 |
| Allianz Global Corporate & Speciality SE, France JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 3.50 | 0.10 | 0.06 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.02 | 0.01 |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.61 | -0.39 |  |  |  |  |
| Shefali Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Deposit paid |  |  |  |  |  |  |  | 0.41 | 0.41 | 0.41 |
| Rent paid |  |  |  |  |  |  |  | 0.04 | 0.48 | 0.50 |
| Allianz Investment Management Singapore Pte. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Data provision charges | 3.18 | -0.33 | -0.33 |  |  |  |  |  |  |  |
| Investment management | 0.32 | -0.06 | -0.06 |  |  |  |  |  |  |  |
| Balance - Investment management | -0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Data provision charges | -0.72 |  |  |  |  |  |  |  |  |  |
| Anuj Agarwal Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 1.79 |  |  |  |  |  |  |  |  |  |
| Anami Roy Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.01 | 0.13 | 0.17 | 0.39 | 0.43 | 0.60 |
| Commission |  |  |  | -0.01 | -0.01 | -0.23 | -0.24 | -0.60 | -0.67 | 1.73 |
| Allianz Risk Transfer N.V. Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.60 | 0.91 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  |  | 0.04 |  |  |  |  |  |  |  |
| Pramit Jhaveri Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  |  | 0.08 | 0.29 | 0.40 |
| Commission |  |  |  |  |  |  |  | -0.18 | -0.62 | 1.34 |
| Allianz Belgium Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.47 | 0.37 | -0.12 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.67 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.05 | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Claim recovery on reinsurance |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.28 |  |  | 0.06 |  |  |  |  |  |  |
| Hercules Hoists Ltd. |  |  |  |  |  |  |  |  |  |  |
| Fixed deposits repaid | 3 | 14 | 6.70 |  |  |  |  |  | 6.50 |  |
| Interest paid on fixed deposits | 0.29 | 1.72 | 0.97 |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 0.03 | 0.04 | 0.09 |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.09 | 0.11 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.05 |  |  |
| Interest accrued on fixed deposits | 1.27 | -0.50 | -0.23 |  |  | -0.09 | -0.58 | -1.09 | 0.51 |  |
| Balance - Interest accrued on fixed deposits | -1.27 |  |  |  |  |  |  |  |  |  |
| Fixed deposit accepted |  |  |  |  |  |  | -6.50 |  |  |  |
| Fixed deposits accepted | 14 | -8.37 | -1.67 |  |  | -6.50 |  | -6.50 |  |  |
| Balance - Fixed deposits accepted | -14 |  |  |  |  |  |  |  |  |  |
| Radhika Haribhakti Individual |  |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  |  |  | -0.34 | 1.03 |
| Sitting fees |  |  |  |  |  |  |  |  | 0.16 | 0.31 |
| Dr. Arindam Kumar Bhattacharya Individual |  |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  |  |  |  | 0.76 |
| Sitting fees |  |  |  |  |  |  |  |  |  | 0.32 |
| Allianz Elementar Versicherungs - Austria Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.30 | 0.02 | 0.12 |  |  |  |  |  |  |  |
| Claim recovery on reinsurance |  | 0.26 | 0.14 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.08 | 0.06 | 0.09 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.15 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.17 |  |  |  |  |  |  |  |  |  |
| Bajaj Finserv Charitable Trust |  |  |  |  |  |  |  |  |  |  |
| CSR payment |  |  |  |  | 0.25 | 0.25 |  |  | 0.50 |  |
| Bajaj Auto Credit Ltd. |  |  |  |  |  |  |  |  |  |  |
| Asset sales |  |  |  |  |  |  |  |  |  | 0.94 |
| Allianz Global Corporate & Speciality SE, Switzerland Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.62 |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.22 |  |  |  |  |  |  |  |  |
| Baroda Industries Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 0.24 | 0.35 |
| Divdend paid |  |  |  |  |  |  |  | 0.12 |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.02 | 0.02 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.02 |  |  |
| Allianz Global Corporate & Speciality AG, Spain Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.30 | 0.24 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.06 | 0.06 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Denmark - Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.58 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.01 |  |  |  |  |  |  |  |  |  |
| Dr. Naushad Forbes Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 | 0.17 | 0.24 | 0.30 | 0.33 | 0.37 |
| Commission |  |  |  |  | -0.05 | -0.30 | -0.40 | -0.62 | -0.70 | 1.21 |
| Allianz Managed Operations and Services SE Associate |  |  |  |  |  |  |  |  |  |  |
| Paid towards opus revenue expenditure | 4.02 |  |  |  |  |  |  |  |  |  |
| License and Maintenance fees paid | 1.01 |  |  |  |  |  |  |  |  |  |
| SAS license fees | 0.20 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.08 |  |  |  |  |  |  |  |  |  |
| Income from software consultancy | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - SAS license fees | -2.09 |  |  |  |  |  |  |  |  |  |
| Balance - Paid towards opus revenue expenditure | -2.67 |  |  |  |  |  |  |  |  |  |
| Jamnalal Sons Pvt. Ltd |  |  |  |  |  |  |  |  |  |  |
| Security deposit |  |  |  | 0.29 |  |  |  |  |  |  |
| Balance - Security deposit |  |  |  | 0.29 |  |  |  |  |  |  |
| Chetak Technology Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  |  | 0.53 |
| Unallocated premium |  |  |  |  |  |  |  |  |  | 0.04 |
| Late D J Balaji Rao Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  |  |  | 0.21 | 0.17 |
| Commission |  |  |  |  |  |  |  |  | -0.44 | 0.58 |
| Bachhraj Factories Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 0.14 | 0.22 |
| Divdend paid |  |  |  |  |  |  |  | 0.07 |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.01 | 0.01 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.01 |  |  |
| Allianz Insurance Lanka Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claims paid on reinsurance accepted |  | 0.23 |  |  |  |  |  |  |  |  |
| Reinsurance premium received/receivable | 0.08 | -0.07 | 0.09 |  |  |  |  |  |  |  |
| Commission on reinsurance paid/payable | 0.02 |  | 0.02 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Netherlands Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.22 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.10 |  |  |  |  |  |  |  |  |  |
| Hind Lamps Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.15 | 0.15 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.04 |  |  |  |
| Balance - Unallocated premium |  |  |  | -0.05 |  |  |  |  |  |  |
| IDS Gmbh Associate |  |  |  |  |  |  |  |  |  |  |
| Legal and professional charges | 0.31 | 0.04 |  |  |  |  |  |  |  |  |
| Balance - Legal and professional charges | -0.07 |  |  |  |  |  |  |  |  |  |
| Allianz Australia Insurance Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.14 | 0.07 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.03 | 0.02 |  |  |  |  |  |  |  |
| Jamnalal Sons Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Security deposit |  |  |  |  |  |  | 0.29 |  |  |  |
| Rent and other expenses |  |  |  |  |  |  | -0.02 |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.03 |  |  |  |
| Allianz Global Corporate & Speciality SE, Netherlands Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.08 | 0.09 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  | 0.04 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.01 | 0.04 |  |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE France Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | 0.82 |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  |  |  | -0.61 |  |  |  |  |  |  |
| Centre for Technology Innovation and Economic Research |  |  |  |  |  |  |  |  |  |  |
| Corporate social responsibility expenses |  |  |  |  |  |  | 0.20 |  |  |  |
| Allianz Managed Operations and Services SE India Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 0.15 |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.06 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.06 |  |  |  |  |  |  |  |  |  |
| Lila Poonawala (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 | 0.07 |  |  |  |  |  |  |  |
| Sanjali Bajaj Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.09 |  |  |
| Allianz Insurance Management Asia Pacific Pte. JV |  |  |  |  |  |  |  |  |  |  |
| Paid towards revenue expenditure | 0.06 | 0.02 | 0.01 |  | 0.01 |  |  |  |  |  |
| Billable expenses incurred reversed |  |  |  |  |  |  | 0.04 |  |  |  |
| Reimbursement received of revenue expenditure |  | 0.01 | 0.03 |  |  |  |  |  |  |  |
| Billable expenses recovered on behalf |  | 0.01 |  |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred | -0.01 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred | 0.01 | 0.01 | -0.03 |  | -0.04 | -0.04 |  |  |  |  |
| Allianz Marine and Aviation Versicherungs AG Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.04 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.04 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE, Italy JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.14 | 0.11 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 0.06 | 0.03 |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  | 0.01 | 0.01 |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.06 |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.01 | -0.01 | -0.06 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.06 | -0.08 |  |  |  |  |
| Allianz Global Corporate & Speciality SE, Denmark - Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.21 | 0.14 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.26 | -0.01 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality AG, Spain Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.09 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.02 |  |  |  |  |  |  |  |  |  |
| Lila Poonawala Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  | 0.07 |  |  |  |
| Sanjay Asher (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 | 0.03 |  |  |  |  |  |  |  |
| Nanoo Pamnani (Vice Chairman - BFL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees and expenses |  | 0.01 | 0.06 |  |  |  |  |  |  |  |
| S Rs. Khan Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.07 |  |  |  |  |  |  |  |  |  |
| Suraj Mehta (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Manu Tandon (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.03 | 0.01 |  |  |  |  |  |  |  |
| Late S H Khan (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 |  |  |  |  |  |  |  |  |
| Sanjay Asher Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Insurance Joint Stock Company Allianz Russia Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.02 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Allianz Hongkong Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.02 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Manu Tandon Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.03 |  |  |  |  |  |  |  |  |  |
| Suraj Mehta Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.02 |  |  |  |  |  |  |  |  |  |
| Hindustan Housing Co. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  |  | 0.01 |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.01 | 0.01 |
| Mukand Engineers Ltd |  |  |  |  |  |  |  |  |  |  |
| Unallocated premium |  |  |  | 0.01 |  |  |  |  |  |  |
| Allianz Global Assistance Australia Associate |  |  |  |  |  |  |  |  |  |  |
| Billable expenses recovered on behalf |  | 0.01 |  |  |  |  |  |  |  |  |
| Allianz Managed Operations & Services SE India Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  | 0.06 | 0.03 |  |  |  |  |  |  |  |
| Insurance claims paid |  | 0.01 |  |  |  |  |  |  |  |  |
| Unallocated premium |  | -0.07 | -0.03 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE - Malaysia Associate |  |  |  |  |  |  |  |  |  |  |
| Billabale expenses | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Billabale expenses | -0.01 |  |  |  |  |  |  |  |  |  |
| Bachhraj Factories Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.01 |  |  |  |
| Denmark Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.01 |  |  |  |  |  |  |
| Baroda Industries Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.02 |  |  |  |
| Allianz Global Corporate and Speciality SE, Switzerland Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.27 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.11 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.40 |  |  |  |  |  |  |  |  |  |
| M/s. Allianz Risk Transfer AG Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.04 |  |  |  |  |  |  |
| Devang Mody Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | -0.05 |  |  |  |
| Allianz Insurance Management Asia Associate |  |  |  |  |  |  |  |  |  |  |
| Paid towards revenue expenditure |  |  |  | 0.01 |  |  |  |  |  |  |
| Balance - Paid towards revenue expenditure |  |  |  | 0.01 |  |  |  |  |  |  |
| Billable expenses incurred |  |  |  | -0.04 |  |  |  |  |  |  |
| Balance - Billable expenses incurred |  |  |  | -0.04 |  |  |  |  |  |  |
| Rajiv Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.06 | 0.06 |  | 0.07 | 0.10 | 0.11 | 0.10 | 0.12 | 0.12 |
| Sitting Fees | 0.06 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.06 |  |  | -0.08 |  |  |  |  |  |  |
| Commission | 0.06 | -0.08 | -0.09 | -0.09 | -0.09 | -0.18 | -0.19 | -0.21 | -0.26 | 0.40 |
| Naushad Forbes Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.03 |  |  |  |  |  |  |
| Commission |  |  |  | -0.05 |  |  |  |  |  |  |
| Late Naresh Chandra Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.08 |  |  |  |  |  |  |
| Allianz Cornhill Information Services Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.01 | 0.05 | 0.03 |  |  |  |  |  |  |  |
| Unallocated premium |  |  | -0.17 |  |  |  |  |  |  |  |
| Rajeev Jain (CEO - BFL) Key Person |  |  |  |  |  |  |  |  |  |  |
| ESOPs exercised |  | 7.10 |  |  |  |  |  |  |  |  |
| Medical reimbursement |  | 0.22 |  |  |  |  |  |  |  |  |
| Remuneration |  | -3.03 | -4.37 |  |  |  |  |  |  |  |
| Dr. Omkar Goswami Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  | 0.21 |  |  |  |
| Commission |  |  |  |  |  |  | -0.31 |  |  |  |
| Rahul Bajaj (Chairman) Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.11 | 0.08 |  |  |  |  |  |  |  |
| Commission |  | -0.17 | -0.13 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Italy Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.11 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.10 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.34 |  |  |  |  |  |  |  |  |  |
| Ashwin Vijaykumar Jain Relative |  |  |  |  |  |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | -0.15 |  |  |  |
| Rajendra Lakhotia Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.10 |  |  |  |  |  |  |
| Commission |  |  |  | -0.08 | -0.08 |  |  |  |  |  |
| Madhur Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.07 | 0.07 |  | 0.07 | 0.08 | 0.12 | 0.13 | 0.08 | 0.07 |
| Sitting Fees | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.07 |  |  | -0.11 |  |  |  |  |  |  |
| Commission | 0.07 | -0.11 | -0.10 | -0.10 | -0.10 | -0.14 | -0.20 | -0.27 | -0.17 | 0.21 |
| Dipak Poddar |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 | 0.03 | 0.10 |  |  |  |
| Balance - Commission |  |  |  | -0.09 |  |  |  |  |  |  |
| Commission |  |  |  | -0.09 | -0.09 | -0.06 | -0.19 |  |  |  |
| Rahul Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.10 | 0.11 | 0.06 | 0.01 |  |  |
| Sitting Fees | 0.10 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.10 |  |  | -0.17 |  |  |  |  |  |  |
| Commission | 0.10 |  |  | -0.13 | -0.13 | -0.21 | -0.11 | -0.02 |  |  |
| Omkar Goswami Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.06 | 0.12 |  |  |  |  |
| Balance - Commission |  |  |  | -0.12 |  |  |  |  |  |  |
| Commission |  |  |  | -0.11 | -0.11 | -0.24 |  |  |  |  |
| Ranjan Sanghi |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.07 | 0.14 | 0.14 |  |  |  |
| Balance - Commission |  |  |  | -0.15 |  |  |  |  |  |  |
| Commission |  |  |  | -0.12 | -0.12 | -0.26 | -0.26 |  |  |  |
| Rakesh Bhatt Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | -0.74 |  |  |  |
| D J Balaji Rao Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.12 | 0.18 | 0.19 | 0.22 |  |  |
| Balance - Commission |  |  |  | -0.12 |  |  |  |  |  |  |
| Commission |  |  |  | -0.15 | -0.15 | -0.31 | -0.31 | -0.44 |  |  |
| Dr. Gita Piramal Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.13 | 0.21 | 0.21 | 0.20 |  |  |
| Balance - Commission |  |  |  | -0.14 |  |  |  |  |  |  |
| Commission |  |  |  | -0.16 | -0.16 | -0.36 | -0.34 | -0.40 |  |  |
| Radhika Singh Relative |  |  |  |  |  |  |  |  |  |  |
| Fixed deposit interest accrued |  |  |  |  |  | -0.01 | 0.16 |  |  |  |
| Fixed deposit accepted |  |  |  |  |  | 2 | 2 |  |  |  |
| Bajaj Auto Holdings Ltd. |  |  |  |  |  |  |  |  |  |  |
| Non convertible debentures redeemed |  |  | 5 |  |  |  |  |  |  |  |
| Dividend paid |  | 0.07 |  |  | 0.04 | 0.16 |  | 0.06 | 0.08 | 0.17 |
| Purchase of shares by BAHL | 0.10 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.21 | 0.21 |
| Interest on non convertible debentures issued |  | -0.48 | 0.48 |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  |  | -0.10 |  |  |
| Purchase of shares by |  |  |  | -0.10 |  |  |  |  |  |  |
| Balance - Purchase of shares by |  |  |  | -0.10 |  |  |  |  |  |  |
| Balance - Purchase of shares by BAHL | -0.10 |  |  |  |  |  |  |  |  |  |
| Purchase of shares by BAHL (209,005 shares of H 5 each) |  | -0.10 | -0.10 |  |  |  |  |  |  |  |
| Shares of BFS held by BAHL |  |  |  |  | -0.10 | -0.10 | -0.10 |  |  |  |
| Non convertible debentures issued |  | 5 |  |  |  |  |  |  |  |  |
| Balance - Non-convertible debentures issued | 5 |  |  |  |  |  |  |  |  |  |
| Nanoo Pamnani Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.18 | 0.32 |  |  |  |  |
| Sitting fees and expenses | 0.09 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.89 |  |  | -1.21 |  |  |  |  |  |  |
| Commission | 0.89 |  |  | -2.24 | -2.24 | -2.46 |  |  |  |  |
| Allianz Managed Operations & Services SE Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  | 0.23 | 0.22 |  |  |  |  |  |  |  |
| E-learning service fees |  | 0.34 |  |  |  |  |  |  |  |  |
| Benefits paid |  | 0.02 | 0.01 |  |  |  |  |  |  |  |
| License and Maintenance fees paid |  | 0.93 | -0.95 |  |  |  |  |  |  |  |
| Unallocated premium |  | -0.06 | -0.08 |  |  |  |  |  |  |  |
| SAS license fees |  | -4.07 |  |  |  |  |  |  |  |  |
| Paid towards opus revenue expenditure |  | -4.97 | -2.29 |  |  |  |  |  |  |  |
| Allianz Fire and Marine Insurance Japan Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  | 1.80 |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  |  | 0.01 |  |  |  |  |
| Reinsurance premium paid |  |  |  |  |  | -15 |  |  |  |  |
| D.S.Mehta Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | 0.10 |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 |  |  |  |  |  |
| Commission |  |  |  | -0.09 | -0.09 |  |  |  |  |  |
| Balance - Fixed deposit interest accrued |  |  |  | -0.21 |  |  |  |  |  |  |
| Fixed deposit interest accrued |  |  |  | -0.87 | -0.87 |  |  |  |  |  |
| Balance - Fixed deposit accepted |  |  |  | -5.33 |  |  |  |  |  |  |
| Fixed deposit accepted |  |  |  | -8.28 | -8.28 |  |  |  |  |  |
| Allianz Technology SE JV |  |  |  |  |  |  |  |  |  |  |
| Billable expenses recovery |  |  |  |  |  | 0.49 | 0.25 |  |  |  |
| Balance - Unallocated premium |  |  |  | 0.06 |  |  |  |  |  |  |
| Benefits paid |  |  |  |  | 0.01 |  |  |  |  |  |
| Balance - License and maintenance fees paid |  |  |  | -1.16 |  |  |  |  |  |  |
| Information technology expenditure |  |  |  |  |  |  | -2.90 |  |  |  |
| Balance - Paid towards opus revenue expenditure |  |  |  | -5.17 |  |  |  |  |  |  |
| Paid towards opus revenue expenditure |  |  |  | -2.60 | -2.60 | -5.56 |  |  |  |  |
| License and maintenance fees paid |  |  |  | -1.93 | -1.93 | -3.66 | -5.86 |  |  |  |
| Allianz Fire and Marine Insurance Japan Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  |  | 22 |  |  |  |
| Claims recovery on reinsurance |  |  |  |  |  |  | 1.46 |  |  |  |
| Reinsurance premium paid |  |  |  |  |  |  | -71 |  |  |  |
| Group Gratuity Cum Life Assurance Trust |  |  |  |  |  |  |  |  |  |  |
| Benefits paid |  |  |  |  | 5.66 | 5.39 | 3.61 | 3.57 |  |  |
| Fund reserve |  |  |  |  | 1.96 | 2.90 | 1.96 | 2.03 |  |  |
| Provision for linked liabilities |  |  |  |  |  |  | -39 | -52 |  |  |
| Bajaj Auto Ltd. Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Interest paid on non convertible debentures |  |  |  |  | 4.92 | 4.91 | 4.92 |  | 4.34 | 3.35 |
| Unsecured non convertible debentures redemption |  |  |  |  |  |  | 6 |  | 10 |  |
| Interest paid on non-convertible debentures |  |  |  |  |  |  |  | 4.35 |  |  |
| Balance - Providend fund contribution (Employer's share) |  |  |  | -4.85 |  |  |  |  |  |  |
| Provident fund contribution (Employer's share) |  |  |  |  |  |  | -11 | 1.44 |  |  |
| Providend fund contribution (Employer's share) |  |  |  | -5.82 | -5.82 | -10 |  |  |  |  |
| Unsecured non-convertible debentures issued |  |  |  |  |  |  |  | 46 |  |  |
| Balance - Unsecured non convertible debentures issued |  |  |  | 52 |  |  |  |  |  |  |
| Unsecured non convertible debentures issued |  |  |  | 52 | 52 | -55 | 46 |  | 36 | 36 |
| Bajaj Holdings & Investment Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  | 150 | 150 |  |
| Dividend paid | 11 | 22 |  |  | 11 | 47 |  | 19 | 25 | 50 |
| Interest paid on non convertible debentures |  |  |  |  |  |  | 23 | 23 | 13 |  |
| Business support services received | 2.66 | 2.60 | 2.61 |  |  |  |  | -0.05 | 19 | 25 |
| Sale of investments | 35 |  |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | 0.38 | 0.51 | 16 |  |  |  |
| Business support services rendered | 1.95 | 0.20 | 0.26 |  |  |  | 0.87 | 0.76 | 1.43 | 1.03 |
| Billable expenses reimbursed on behalf |  |  |  |  | 0.06 | 0.52 | 0.58 | 0.10 | 1 | 2.03 |
| Other payments |  |  |  |  | 0.03 | 0.04 | 0.04 | 0.05 | 0.10 | 3.90 |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.65 |  | 1 | 1.32 |
| Billable expenses reimbursement received |  |  |  |  |  |  |  |  | 0.44 | 1.01 |
| Rent paid |  |  |  |  |  |  |  |  |  | 1.17 |
| Insurance premium received | 0.05 | 0.06 | 0.06 |  |  |  |  | 1 |  |  |
| Security deposit |  |  |  |  |  |  |  |  |  | 0.70 |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 0.01 | 0.46 |  |  |  |  |
| Employee car transfer |  |  |  |  |  |  |  | 0.06 |  |  |
| Other receipts |  |  |  |  | 0.01 |  |  |  |  |  |
| Balance - Unallocated premium | -0.07 |  |  | -0.02 |  |  |  |  |  |  |
| Unallocated premium |  |  | -0.04 | -0.57 |  |  | -1.17 | -1.25 | 0.04 | 1.70 |
| Superannuation contribution |  |  |  |  | -0.57 | -0.89 |  |  |  |  |
| Purchase of shares by |  |  |  | -31 |  |  |  |  |  |  |
| Balance - Purchase of shares by |  |  |  | -31 |  |  |  |  |  |  |
| Balance - Purchase of shares by BHIL | -31 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -31 | -31 |  |  | -62 | 62 |
| Contribution to Equity |  |  |  |  |  |  | -31 | -31 |  |  |
| Purchase of shares by BHIL (62,314,214 shares of H 5 each) |  | -31 | -31 |  |  |  |  |  |  |  |
| Secured non convertible debentures issued |  |  |  |  |  | -312 | 300 | 150 |  |  |
| Maharashtra Scooters Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  | 5 |  | 85 | 100 |
| Dividend paid | 3.69 |  |  |  | 8.24 | 33 |  | 20 | 39 | 60 |
| Secured non-convertible debentures redemption |  |  |  |  | 5 | 110 |  |  |  |  |
| Interest on non-convertible debentures issued |  | 7.25 | 7.20 |  | 10 | 11 | 7.51 | 13 | 17 | 9.94 |
| Business support charges received |  |  |  |  | 1.86 | 0.14 | 0.16 | 0.14 | 0.15 | 0.18 |
| Business support services rendered | 0.08 | 0.02 | 0.03 | 1.86 |  |  |  |  |  |  |
| Balance - Business support services rendered |  |  |  | 1.86 |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  |  | -1.86 |  |  |
| Balance - Contribution to equity of BFS |  |  |  | -1.86 |  |  |  |  |  |  |
| Balance - Contribution to Equity | -1.90 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -1.86 | -1.86 |  |  | -3.79 | 3.79 |
| Contribution to equity of BFS |  |  |  | -1.86 |  |  | -1.86 |  |  |  |
| Contribution to equity of BFS (3,725,740 shares of H 5 each) |  | -1.86 | -1.86 |  |  |  |  |  |  |  |
| Balance - Contribution to equity of BFL |  |  |  | -3.79 |  |  |  |  |  |  |
| Contribution to equity of BFL (18,974,660 shares of H 2 each) |  | -1.90 | -3.79 |  |  |  |  |  |  |  |
| Contribution to equity of BFL |  |  |  | -3.79 |  |  | -3.79 |  | -3.79 | 3.79 |
| Balance - Non-convertible debentures issued | 80 |  |  | 80 |  |  |  |  |  |  |
| Non convertible debentures issued |  |  |  |  | 140 | -96 |  |  |  |  |
| Non-convertible debentures issued |  | 80 | 80 | 140 |  |  | 185 | 260 | 175 | 225 |
| Allianz SE JV |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  | 56 | 56 | 82 |  |  |  |
| Billable expenses recovered on behalf |  | 0.72 | 0.02 |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.03 | 0.51 | 0.08 |  |  | 0.04 |  |  |  |  |
| Receipt of award |  | 0.15 |  |  |  |  |  |  |  |  |
| Reimbursement of revenue expenses received | 0.02 | 0.01 | 0.03 |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.03 |  |  |  |  |  |  |
| Balance - Contribution to equity of BAGICL including premium |  |  |  | -195 |  |  |  |  |  |  |
| Balance - Contribution to Equity | -195 |  |  |  |  |  |  |  |  |  |
| Contribution to equity of BAGICL including premium |  | -195 | -195 | -195 |  |  |  |  |  |  |
| Contribution to equity of BAGIC including premium |  |  |  |  |  |  | -1,099 |  |  |  |
| Balance - Contribution to equity of BALICL including premium |  |  |  | -1,099 |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -1,099 | -1,099 |  |  |  |  |
| Contribution to equity of BALICL including premium |  | -1,099 | -1,099 | -1,099 |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,055 | 6,023 | 11,335 | 20,533 | 24,507 | 32,862 | 42,605 | 54,351 | 60,592 | 68,406 | 82,072 | 110,382 | 118,582 |
| Expenses + | 4,124 | 1,531 | 5,823 | 13,795 | 15,794 | 22,074 | 27,569 | 36,094 | 40,950 | 46,951 | 52,204 | 69,497 | 75,437 |
| Operating Profit | 3,931 | 4,491 | 5,511 | 6,739 | 8,713 | 10,788 | 15,037 | 18,258 | 19,641 | 21,455 | 29,868 | 40,886 | 43,145 |
| OPM % | 49% | 75% | 49% | 33% | 36% | 33% | 35% | 34% | 32% | 31% | 36% | 37% | 36% |
| Other Income + | 2 | 3 | 8 | 0 | 0 | 1 | 2 | 0 | -7 | 8 | 1 | -4 | 9 |
| Interest | 1,204 | 1,562 | 2,230 | 2,877 | 3,716 | 4,531 | 6,657 | 9,500 | 9,274 | 9,629 | 12,380 | 18,607 | 19,971 |
| Depreciation | 22 | 31 | 38 | 58 | 73 | 160 | 226 | 457 | 498 | 563 | 678 | 900 | 965 |
| Profit before tax | 2,708 | 2,902 | 3,251 | 3,804 | 4,925 | 6,099 | 8,155 | 8,302 | 9,862 | 11,271 | 16,811 | 21,375 | 22,218 |
| Tax % | 18% | 24% | 26% | 27% | 30% | 32% | 34% | 28% | 25% | 26% | 27% | 27% |  |
| Net Profit + | 2,214 | 2,191 | 2,409 | 2,775 | 3,450 | 4,176 | 5,374 | 5,994 | 7,367 | 8,314 | 12,210 | 15,595 | 16,095 |
| EPS in Rs | 9.89 | 9.71 | 10.62 | 11.71 | 14.21 | 16.65 | 20.23 | 21.17 | 28.09 | 28.63 | 40.29 | 51.07 | 52.28 |
| Dividend Payout % | 2% | 2% | 2% | 1% | 1% | 1% | 1% | 2% | 1% | 1% | 2% | 2% |  |
| 10 Years: | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -6,922 | -9,807 | -10,731 | -9,795 | -10,922 | -19,580 | -27,076 | -23,369 | 4,547 | -33,670 | -39,480 | -68,674 |
| Cash from Investing Activity + | 2,953 | 3,764 | 3,709 | -886 | 151 | -922 | -6,903 | -9,948 | -3,684 | 1,445 | -13,945 | -10,960 |
| Cash from Financing Activity + | 4,592 | 6,521 | 6,839 | 11,602 | 12,513 | 19,590 | 34,535 | 34,479 | 1,687 | 32,326 | 51,016 | 82,709 |
| Net Cash Flow | 623 | 478 | -183 | 921 | 1,742 | -911 | 555 | 1,162 | 2,551 | 101 | -2,409 | 3,075 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 16 | 22 | 17 | 12 | 19 | 19 | 19 | 18 | 17 | 16 | 15 | 20 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 16 | 22 | 17 | 12 | 19 | 19 | 19 | 18 | 17 | 16 | 15 | 20 |
| Working Capital Days | -1,204 | -1,338 | -603 | -243 | -169 | -675 | -537 | -417 | -490 | -493 | -444 | -400 |
| ROCE % | 19% | 16% | 15% | 14% | 14% | 13% | 13% | 11% | 10% | 10% | 11% | 12% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 60.80% | 60.80% | 60.77% | 60.80% | 60.75% | 60.75% | 60.78% | 60.79% | 60.69% | 60.69% | 60.69% | 60.64% |
| FIIs + | 8.92% | 8.78% | 8.50% | 7.38% | 7.48% | 7.81% | 7.03% | 7.17% | 7.66% | 7.91% | 8.42% | 8.39% |
| DIIs + | 6.65% | 6.75% | 6.97% | 7.70% | 7.01% | 6.91% | 7.10% | 7.30% | 7.09% | 7.48% | 7.33% | 7.60% |
| Public + | 23.50% | 23.55% | 23.65% | 24.03% | 24.60% | 24.39% | 24.95% | 24.66% | 24.31% | 23.70% | 23.38% | 23.18% |
| Others + | 0.13% | 0.12% | 0.11% | 0.09% | 0.16% | 0.14% | 0.13% | 0.10% | 0.25% | 0.21% | 0.18% | 0.19% |
| No. of Shareholders | 2,02,188 | 2,27,973 | 2,43,853 | 2,99,380 | 5,63,432 | 6,31,436 | 7,36,596 | 6,91,234 | 6,60,295 | 5,85,220 | 5,67,041 | 7,08,432 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 58.35% | 58.35% | 58.37% | 60.80% | 60.80% | 60.77% | 60.78% | 60.69% | 60.64% |
| FIIs + | 8.22% | 7.82% | 8.30% | 8.62% | 9.07% | 8.50% | 7.03% | 8.42% | 8.39% |
| DIIs + | 6.39% | 7.03% | 6.50% | 6.24% | 6.09% | 6.97% | 7.10% | 7.33% | 7.60% |
| Public + | 27.04% | 26.80% | 26.81% | 24.15% | 23.87% | 23.65% | 24.95% | 23.38% | 23.18% |
| Others + | 0.00% | 0.00% | 0.03% | 0.19% | 0.18% | 0.11% | 0.13% | 0.18% | 0.19% |
| No. of Shareholders | 67,348 | 94,270 | 99,512 | 1,71,188 | 1,94,174 | 2,43,853 | 7,36,596 | 5,67,041 | 7,08,432 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/bajaj-finserv-ltd/bajajfinsv/532978/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Outcome
15h - Link of audio recording of investors conference call held on 25 July 2024.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=494b4da3-926a-4ee7-ad02-140b5c060c39.pdf)
- [Shareholder Meeting / Postal Ballot-Scrutinizer''s Report 16h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a5b44cb9-e074-4d00-9bd5-8ed7182fcb97.pdf)
- [Announcement under Regulation 30 (LODR)-Investor Presentation
1d - Investors presentation on unaudited financial results for the quarter ended 30 June 2024.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9215ac47-637c-40e4-afe7-8b1d317d8a7a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bf83e73e-a98d-419d-ba73-b90866e6f4ef.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=21c4ff32-a018-47b0-b716-5dd1a768c444.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a5a72b88-dcc6-45a3-8a32-ae88079475ff.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\641ff85b-b60c-4c73-93e9-52963d7d50ac.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/532978/73489532978.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/532978/68643532978.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_BAJAJFINSV_2010_2011_11102011031414.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/532978/5329780311.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/sep-2012/bajaj-finserv-limited_23387.html)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9215ac47-637c-40e4-afe7-8b1d317d8a7a.pdf)
- [Transcript](https://www.aboutbajajfinserv.com/content/dam/bajajfinserv/web/in/en/global/document/corporate/bfs-new/bfs-investor-relations/investor-presentation/conference-call-transcript-fy-23-24/earnings-call-transcript-q4-fy24.docx)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c740d1aa-75ed-45b0-bcfa-33ff270adfef.pdf)
- [REC](https://www.aboutbajajfinserv.com/content/dam/bajajfinserv/web/in/en/global/document/corporate/bfs-new/bfs-investor-relations/investor-presentation/conference-call-transcripts-fy23/bajaj-finserv-q4-conference-call-audio-playback-file.mp3)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e5c87fa8-62c3-4936-8bfc-a27cd16c0e8b.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b395f74f-9678-41a1-8aaf-7c87c043e123.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfc07df5-af11-4de3-b542-fe9100de50f7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3cee5fef-036c-4cad-a704-ba3d60595451.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=eff59682-9fcb-4d0d-86ea-e652fadd09fa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9ebad4b0-51d3-43a0-bf9a-ff3eff6d43fb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b171128-3f7f-4460-b4f9-94aacb589792.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=16338c28-de5a-4e36-9529-8e15d152d5a0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=74f70c49-f576-4cd5-8374-7a70a046ea93.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e942b409-f300-458e-b6c8-d8c57ec0e1c4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=54b10e3a-be75-4563-a3e8-d178e265033a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=171f5888-4d2a-4300-b674-bd5187567472.pdf)
- [](https://www.bajajfinserv.in/fy-bajaj-finance-group-investor-call-organised-by-clsa-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=17f56977-a112-4cd5-b090-acff6a4586a4.pdf)
- [](https://www.bajajfinserv.in/bajaj-finserv-q1-conference-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=66997866-1a7c-4585-b1a6-66debef7e96e.pdf)
- [](https://www.bajajfinserv.in/q4-fy21_bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d389c417-7580-448f-8f25-d04f4ba0e9fe.pdf)
- [](https://www.bajajfinserv.in/q3-fy21_bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fc1b88df-5880-4f72-8b23-d2569f301f79.pdf)
- [](https://www.bajajfinserv.in/q2-fy21_bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ee814cc9-8cf4-4a96-847b-4acb8f98c706.pdf)
- [](https://www.bajajfinserv.in/q1-fy21-bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ece3647e-bc9a-4df0-9dfa-e0ceabbb3936.pdf)
- [](https://www.bajajfinserv.in/q4-fy20-bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6807ce9e-e25a-47ef-b7ee-072173cfc2ce.pdf)
- [](https://www.bajajfinserv.in/q3-fy20_bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6f45d33f-70c6-499b-b0b9-4a005233ca99.pdf)
- [](https://www.bajajfinserv.in/q2-fy20_bfs-call-transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=041fd101-7f25-4296-a209-eceba1e6ecd9.pdf)
- [](https://www.bajajfinserv.in/bfs-q1-fy-20-concall-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=62017e8f-dab0-4460-9cfb-0ff824735a1c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ab243316-ab0d-4427-9f04-89f0fc6843e4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf0dabf7-530b-4ea0-8b05-291de271b9d6.pdf)
- [](https://www.bajajfinserv.in/q3-fy19-analyst-call-opening-qna.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9813b36b-60ad-49de-baff-6312bf79f75c.pdf)
- [](https://www.bajajfinserv.in/q2-fy19-analyst-call-%E2%80%93-qna.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1ffdd7bc-c9f8-4c20-a221-c4225d1fb694.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f8a49769-1cb2-4397-84e0-0584b27f5800.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8401b630-5f26-485a-a67d-b7b6bb93b28a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b530b838-1ad6-4418-8457-f9dc5d224679.pdf)
- [](https://www.bajajfinserv.in/concall-transcript-%E2%80%93-q4-fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d12e8632-4c1b-4e97-9c29-471a9d9cbd16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49343922-27f9-42d7-81b8-09e4234d5255.pdf)
- [](https://www.bajajfinserv.in/concall-transcript-%E2%80%93-q3-fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7d8d6a79-0311-4517-8c38-db95c8548104.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/concall-transcript-q2-fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=15efd9ef-6472-4833-a5b9-9b97d90bf9c8.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/4qfy17-bajajfinserv-transcript-new.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5d54bc06-ad25-4124-9b16-d2b1c99f9ddd.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/3qfy17-bajajfinserv-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=97B71D6A_8206_4627_9CD5_3B62F4CBCFBF_155655.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/2qfy17-bajajfinserv-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=66835B18_963C_4266_960B_4E96D3954C52_163003.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/concall-transcript-q1-fy17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=DE3BEA9B_66DC_4146_B44E_2C59111991CD_191221.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=A70CCC9F_BA11_46A3_9CDD_848DAF512C70_151937.pdf)
- [](https://www.bajajfinserv.in/media/corporate/downloads/concall-transcript-q4-fy16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=75A4B8CB_4FE5_40BE_A350_4C8BABFA0C01_104537.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6AE9D35A_BAA6_49B5_8984_B2F4D0C9E31C_110816.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Bajaj Finance | 6796.50 | 420700.87 | 28.09 | 5.62 | 7.18 | -8.17 | 17.13 | 15.28 | 0.54 | 11.93 | 4.44 | 22.12 | 0.17 | 3.84 | 1.99 | 4.26 | 58566.70 | 70.06 | 14926.26 | 16098.67 | 3911.98 | 28.81 | 13.82 | 242.47 | 293345.83 | 54.70 | 0.01 | 5.81 | 23.88 | 0.00 | 31.26 | 20.88 | 703422.69 | 2.50 | 0.96 | -1.24 | -6.18 | 2.18 | -8.74 | 21.34 | 19.83 | 29.35 | 48.40 | 24.35 | 27.26 | 23.48 | 11.77 | 2.50 | 233.46 | 27.59 | 44.54 | 39.48 | 48.90 | 11.51 | 60.54 |
| 2. | Bajaj Finserv | 1582.30 | 252639.88 | 30.28 | 4.23 | 2.13 | -5.23 | 12.26 | 16.79 | 0.06 | 11.72 | 3.31 | 15.28 | 0.23 | 4.79 | 2.11 | 7.81 | 118581.86 | 36.38 | 8342.86 | 31479.93 | 2137.70 | 35.22 | 10.04 | 52.28 | 288932.62 | 60.65 | -0.04 | 8.00 | 23.88 | 0.01 | 32.55 | 18.33 | 529185.84 | 0.25 | 1.48 | -1.59 | -3.57 | 4.42 | -2.64 | 14.19 | 13.77 | 20.42 | 22.15 | 20.97 | 22.13 | 14.81 | 11.28 | 0.25 | 51.07 | 20.36 | 38.57 | 40.05 | 36.56 | 19.75 | 159.28 |
| 3. | Jio Financial | 331.75 | 210770.18 | 132.95 | 1.50 | 113.47 |  | 102.44 |  | 0.00 | 1.55 | 1.24 | 1.27 | 0.01 | 0.00 |  | 0.93 | 1857.57 | 82.17 | 1585.26 | 417.82 | 312.63 | 0.89 | -5.81 | 2.50 | 0.00 | 47.12 | 0.00 | 0.97 | 23.88 | 0.00 | 4034.43 | 6282.46 | 199810.41 | 98.41 |  | -13.77 | 37.25 |  |  |  |  |  |  |  |  |  |  | 98.41 | 2.53 |  | 140.40 | 140.40 | 140.40 | 2.75 |  |
| 4. | Cholaman.Inv.&Fn | 1416.00 | 118978.08 | 34.76 | 6.09 | 6.21 | -5.12 | 17.75 | 40.91 | 0.15 | 10.41 | 2.53 | 20.16 | 0.14 | 6.86 | 1.50 | 6.90 | 19163.44 | 71.90 | 3420.82 | 5427.56 | 1065.23 | 45.08 | 24.56 | 40.72 | 134474.88 | 50.33 | -0.02 | 5.66 | 23.88 | 0.00 | 48.73 | 28.34 | 249059.23 | 2.27 | 1.49 | 16.38 | 9.56 | 41.28 | 20.04 | 20.24 | 19.03 | 23.38 | 31.01 | 21.94 | 25.99 | 20.41 | 9.72 | 2.27 | 40.72 | 21.62 | 27.29 | 30.33 | 25.19 | 4.08 | 82.19 |
| 5. | Shriram Finance | 2932.00 | 110169.53 | 14.56 | 2.23 | 2.96 | -5.69 | 11.06 | 25.28 | 1.53 | 11.27 | 3.22 | 15.93 | 0.16 | 3.99 | 1.65 | 4.69 | 37273.15 | 71.38 | 7563.25 | 9604.98 | 1974.11 | 20.02 | 18.23 | 204.54 | 195496.08 | 25.41 | -0.01 | 8.84 | 23.88 | 0.00 | 18.90 | 19.48 | 294492.81 | 4.30 | 0.62 | 17.47 | 27.21 | 29.05 | 62.01 | 15.34 | 14.87 | 23.38 | 43.37 | 18.56 | 27.83 | 17.27 | 12.15 | 4.30 | 196.02 | 14.00 | 10.87 | 11.69 | 11.78 | 0.52 | 37.44 |
| 6. | Bajaj Holdings | 9488.30 | 105595.30 | 14.13 | 1.92 | 62.92 | 60.06 | 13.69 | 22.69 | 1.39 | 13.07 | 12.45 | 14.77 | 0.01 | 0.00 | 3858.65 | 1.09 | 1678.38 | 90.15 | 7462.17 | 133.76 | 1610.46 | 28.53 | 13.77 | 670.49 | 62.57 | 51.46 | 0.00 | 7.33 | 23.88 | 0.00 | 252.03 | 40.88 | 105603.91 | 2.05 | 0.74 | 15.51 | 14.83 | 34.09 | 24.63 | 12.18 | 11.85 | 18.98 | 25.81 | 6.50 | 8.93 | 11.15 | 9.71 | 2.01 | 652.98 | 18.98 | 13.53 | 14.81 | 12.70 | 1.09 | 11.13 |
| 7. | HDFC AMC | 4090.00 | 87353.70 | 42.16 | 12.35 | 31.36 | 65.84 | 32.10 | 13.08 | 1.69 | 37.72 | 27.61 | 29.51 | 0.45 | 0.00 | 294.52 | 1.00 | 2785.07 | 76.40 | 2072.35 | 775.24 | 603.98 | 34.93 | 26.49 | 97.06 | 0.00 | 52.52 | -0.03 | 3.08 | 23.88 | 0.00 | 25.47 | 30.56 | 87342.53 | 0.59 | 2.65 | 9.17 | 18.37 | 12.32 | 65.88 | 27.11 | 28.81 | 15.89 | 13.65 | 8.77 | 12.92 | 24.47 | 32.31 | 0.59 | 91.15 | 15.79 | 40.70 | 34.65 | 40.92 | 10.78 | 21.34 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | Sales | ₹ 1,18,582 Cr. |
| BAJAJFINSV | OPM | 36.4 % |
| BAJAJFINSV | Profit after tax | ₹ 8,343 Cr. |
| BAJAJFINSV | Mar Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Sales Qtr | ₹ 31,480 Cr. |
| BAJAJFINSV | PAT Qtr | ₹ 2,138 Cr. |
| BAJAJFINSV | Qtr Sales Var | 35.2 % |
| BAJAJFINSV | Qtr Profit Var | 10.0 % |
| BAJAJFINSV | Price to Earning | 30.3 |
| BAJAJFINSV | Dividend yield | 0.06 % |
| BAJAJFINSV | Price to book value | 4.23 |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | Return on assets | 3.31 % |
| BAJAJFINSV | Debt to equity | 4.79 |
| BAJAJFINSV | Return on equity | 15.3 % |
| BAJAJFINSV | EPS | ₹ 52.3 |
| BAJAJFINSV | Debt | ₹ 2,88,933 Cr. |
| BAJAJFINSV | Promoter holding | 60.6 % |
| BAJAJFINSV | Change in Prom Hold | -0.04 % |
| BAJAJFINSV | Earnings yield | 8.00 % |
| BAJAJFINSV | Pledged percentage | 0.01 % |
| BAJAJFINSV | Industry PE | 23.9 |
| BAJAJFINSV | Sales growth | 32.6 % |
| BAJAJFINSV | Profit growth | 18.3 % |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | Price to Sales | 2.13 |
| BAJAJFINSV | CMP / FCF | -5.23 |
| BAJAJFINSV | EVEBITDA | 12.3 |
| BAJAJFINSV | Enterprise Value | ₹ 5,29,186 Cr. |
| BAJAJFINSV | Current ratio | 0.25 |
| BAJAJFINSV | Int Coverage | 2.11 |
| BAJAJFINSV | PEG Ratio | 1.48 |
| BAJAJFINSV | Return over 3months | -1.59 % |
| BAJAJFINSV | Return over 6months | -3.57 % |
| BAJAJFINSV | No. Eq. Shares | 160 |
| BAJAJFINSV | Sales growth 3Years | 22.1 % |
| BAJAJFINSV | Sales growth 5Years | 21.0 % |
| BAJAJFINSV | Profit Var 3Yrs | 22.2 % |
| BAJAJFINSV | Profit Var 5Yrs | 20.4 % |
| BAJAJFINSV | ROE 5Yr | 13.8 % |
| BAJAJFINSV | ROE 3Yr | 14.2 % |
| BAJAJFINSV | Return over 1year | -2.64 % |
| BAJAJFINSV | Return over 3years | 4.42 % |
| BAJAJFINSV | Return over 5years | 16.8 % |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | Sales last year | ₹ 1,10,382 Cr. |
| BAJAJFINSV | OP Ann | ₹ 40,886 Cr. |
| BAJAJFINSV | Other Inc Ann | ₹ -3.86 Cr. |
| BAJAJFINSV | EBIDT last year | ₹ 40,894 Cr. |
| BAJAJFINSV | Dep Ann | ₹ 900 Cr. |
| BAJAJFINSV | EBIT last year | ₹ 39,994 Cr. |
| BAJAJFINSV | Interest last year | ₹ 18,607 Cr. |
| BAJAJFINSV | PBT Ann | ₹ 21,375 Cr. |
| BAJAJFINSV | Tax last year | ₹ 5,780 Cr. |
| BAJAJFINSV | PAT Ann | ₹ 8,153 Cr. |
| BAJAJFINSV | Extra Ord Item Ann | ₹ -12.4 Cr. |
| BAJAJFINSV | NP Ann | ₹ 15,595 Cr. |
| BAJAJFINSV | Dividend last year | ₹ 159 Cr. |
| BAJAJFINSV | Raw Material | 0.00 % |
| BAJAJFINSV | Employee cost | ₹ 10,380 Cr. |
| BAJAJFINSV | OPM last year | 37.0 % |
| BAJAJFINSV | NPM last year | 14.1 % |
| BAJAJFINSV | Operating profit | ₹ 43,145 Cr. |
| BAJAJFINSV | Interest | ₹ 19,971 Cr. |
| BAJAJFINSV | Depreciation | ₹ 965 Cr. |
| BAJAJFINSV | EPS last year | ₹ 51.1 |
| BAJAJFINSV | EBIT | ₹ 42,189 Cr. |
| BAJAJFINSV | Net profit | ₹ 16,095 Cr. |
| BAJAJFINSV | Current Tax | ₹ 6,209 Cr. |
| BAJAJFINSV | Tax | ₹ 6,123 Cr. |
| BAJAJFINSV | Other income | ₹ 9.00 Cr. |
| BAJAJFINSV | Ann Date | 2,02,403 |
| BAJAJFINSV | Sales Prev Ann | ₹ 82,072 Cr. |
| BAJAJFINSV | OP Prev Ann | ₹ 29,868 Cr. |
| BAJAJFINSV | Other Inc Prev Ann | ₹ 1.46 Cr. |
| BAJAJFINSV | EBIDT Prev Ann | ₹ 29,869 Cr. |
| BAJAJFINSV | Dep Prev Ann | ₹ 678 Cr. |
| BAJAJFINSV | EBIT preceding year | ₹ 29,191 Cr. |
| BAJAJFINSV | Interest Prev Ann | ₹ 12,380 Cr. |
| BAJAJFINSV | PBT Prev Ann | ₹ 16,811 Cr. |
| BAJAJFINSV | Tax preceding year | ₹ 4,602 Cr. |
| BAJAJFINSV | PAT Prev Ann | ₹ 6,417 Cr. |
| BAJAJFINSV | Extra Ord Prev Ann | ₹ 0.02 Cr. |
| BAJAJFINSV | NP Prev Ann | ₹ 12,210 Cr. |
| BAJAJFINSV | Dividend Prev Ann | ₹ 127 Cr. |
| BAJAJFINSV | OPM preceding year | 36.4 % |
| BAJAJFINSV | NPM preceding year | 14.9 % |
| BAJAJFINSV | EPS preceding year | ₹ 40.3 |
| BAJAJFINSV | Sales Prev 12M | ₹ 1,10,382 Cr. |
| BAJAJFINSV | Profit Prev 12M | ₹ 15,595 Cr. |
| BAJAJFINSV | Med Sales Gwth 10Yrs | 27.6 % |
| BAJAJFINSV | Med Sales Gwth 5Yrs | 20.0 % |
| BAJAJFINSV | Sales growth 7Years | 24.0 % |
| BAJAJFINSV | Sales Var 10Yrs | 33.8 % |
| BAJAJFINSV | EBIDT growth 3Years | 27.7 % |
| BAJAJFINSV | EBIDT growth 5Years | 22.2 % |
| BAJAJFINSV | EBIDT growth 7Years | 24.7 % |
| BAJAJFINSV | EBIDT Var 10Yrs | 24.7 % |
| BAJAJFINSV | EPS growth 3Years | 22.0 % |
| BAJAJFINSV | EPS growth 5Years | 20.4 % |
| BAJAJFINSV | EPS growth 7Years | 20.1 % |
| BAJAJFINSV | EPS growth 10Years | 18.1 % |
| BAJAJFINSV | Profit Var 7Yrs | 20.1 % |
| BAJAJFINSV | Profit Var 10Yrs | 18.1 % |
| BAJAJFINSV | Chg in Prom Hold 3Yr | -0.15 % |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | OP Qtr | ₹ 11,825 Cr. |
| BAJAJFINSV | Other Inc Qtr | ₹ 2.62 Cr. |
| BAJAJFINSV | EBIDT Qtr | ₹ 11,827 Cr. |
| BAJAJFINSV | Dep Qtr | ₹ 267 Cr. |
| BAJAJFINSV | EBIT latest quarter | ₹ 11,560 Cr. |
| BAJAJFINSV | Interest Qtr | ₹ 5,592 Cr. |
| BAJAJFINSV | PBT Qtr | ₹ 5,968 Cr. |
| BAJAJFINSV | Tax latest quarter | ₹ 1,759 Cr. |
| BAJAJFINSV | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| BAJAJFINSV | NP Qtr | ₹ 4,209 Cr. |
| BAJAJFINSV | GPM latest quarter | 100 % |
| BAJAJFINSV | OPM latest quarter | 37.6 % |
| BAJAJFINSV | NPM latest quarter | 13.4 % |
| BAJAJFINSV | Eq Cap Qtr | ₹ 160 Cr. |
| BAJAJFINSV | EPS latest quarter | ₹ 13.4 |
| BAJAJFINSV | OP 2Qtr Bk | ₹ 10,438 Cr. |
| BAJAJFINSV | OP 3Qtr Bk | ₹ 9,950 Cr. |
| BAJAJFINSV | Sales 2Qtr Bk | ₹ 29,038 Cr. |
| BAJAJFINSV | Sales 3Qtr Bk | ₹ 26,023 Cr. |
| BAJAJFINSV | NP 2Qtr Bk | ₹ 4,045 Cr. |
| BAJAJFINSV | NP 3Qtr Bk | ₹ 3,756 Cr. |
| BAJAJFINSV | Opert Prft Gwth | 31.9 % |
| BAJAJFINSV | Last result date | 2,02,406 |
| BAJAJFINSV | Exp Qtr Sales Var | 32.7 % |
| BAJAJFINSV | Exp Qtr Sales | ₹ 34,527 Cr. |
| BAJAJFINSV | Exp Qtr OP | ₹ 12,794 Cr. |
| BAJAJFINSV | Exp Qtr NP | ₹ 6,902 Cr. |
| BAJAJFINSV | Exp Qtr EPS | ₹ 22.0 |
| BAJAJFINSV | Sales Prev Qtr | ₹ 32,041 Cr. |
| BAJAJFINSV | OP Prev Qtr | ₹ 10,933 Cr. |
| BAJAJFINSV | Other Inc Prev Qtr | ₹ 4.42 Cr. |
| BAJAJFINSV | EBIDT Prev Qtr | ₹ 10,937 Cr. |
| BAJAJFINSV | Dep Prev Qtr | ₹ 257 Cr. |
| BAJAJFINSV | EBIT Prev Qtr | ₹ 10,680 Cr. |
| BAJAJFINSV | Interest Prev Qtr | ₹ 5,154 Cr. |
| BAJAJFINSV | PBT Prev Qtr | ₹ 5,527 Cr. |
| BAJAJFINSV | Tax Prev Qtr | ₹ 1,442 Cr. |
| BAJAJFINSV | PAT Prev Qtr | ₹ 2,119 Cr. |
| BAJAJFINSV | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| BAJAJFINSV | NP Prev Qtr | ₹ 4,085 Cr. |
| BAJAJFINSV | OPM Prev Qtr | 34.1 % |
| BAJAJFINSV | NPM Prev Qtr | 12.8 % |
| BAJAJFINSV | Eq Cap Prev Qtr | ₹ 159 Cr. |
| BAJAJFINSV | EPS Prev Qtr | ₹ 13.3 |
| BAJAJFINSV | Sales PY Qtr | ₹ 23,280 Cr. |
| BAJAJFINSV | OP PY Qtr | ₹ 9,345 Cr. |
| BAJAJFINSV | Other Inc PY Qtr | ₹ 2.80 Cr. |
| BAJAJFINSV | EBIDT PY Qtr | ₹ 9,348 Cr. |
| BAJAJFINSV | Dep PY Qtr | ₹ 202 Cr. |
| BAJAJFINSV | EBIT PY Qtr | ₹ 9,146 Cr. |
| BAJAJFINSV | Interest PY Qtr | ₹ 4,020 Cr. |
| BAJAJFINSV | PBT PY Qtr | ₹ 5,125 Cr. |
| BAJAJFINSV | Tax PY Qtr | ₹ 1,416 Cr. |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | Equity capital | ₹ 159 Cr. |
| BAJAJFINSV | Preference capital | ₹ 0.00 Cr. |
| BAJAJFINSV | Reserves | ₹ 60,169 Cr. |
| BAJAJFINSV | Secured loan | ₹ 1,90,767 Cr. |
| BAJAJFINSV | Unsecured loan | ₹ 98,166 Cr. |
| BAJAJFINSV | Balance sheet total | ₹ 5,37,415 Cr. |
| BAJAJFINSV | Gross block | ₹ 8,837 Cr. |
| BAJAJFINSV | Revaluation reserve | ₹ 0.00 Cr. |
| BAJAJFINSV | Accum Dep | ₹ 3,381 Cr. |
| BAJAJFINSV | Net block | ₹ 5,455 Cr. |
| BAJAJFINSV | CWIP | ₹ 220 Cr. |
| BAJAJFINSV | Investments | ₹ 1,68,385 Cr. |
| BAJAJFINSV | Current assets | ₹ 36,099 Cr. |
| BAJAJFINSV | Current liabilities | ₹ 1,44,707 Cr. |
| BAJAJFINSV | BV Unq Invest | ₹ 1,68,386 Cr. |
| BAJAJFINSV | MV Quoted Inv | ₹ 0.00 Cr. |
| BAJAJFINSV | Cont Liab | ₹ 3,647 Cr. |
| BAJAJFINSV | Total Assets | ₹ 5,37,415 Cr. |
| BAJAJFINSV | Working capital | ₹ -1,08,607 Cr. |
| BAJAJFINSV | Lease liabilities | ₹ 0.00 Cr. |
| BAJAJFINSV | Inventory | ₹ 0.00 Cr. |
| BAJAJFINSV | Trade receivables | ₹ 5,974 Cr. |
| BAJAJFINSV | Face value | ₹ 1.00 |
| BAJAJFINSV | Cash Equivalents | ₹ 12,387 Cr. |
| BAJAJFINSV | Adv Cust | ₹ 0.00 Cr. |
| BAJAJFINSV | Trade Payables | ₹ 6,277 Cr. |
| BAJAJFINSV | No. Eq. Shares PY | 159 |
| BAJAJFINSV | Debt preceding year | ₹ 2,12,265 Cr. |
| BAJAJFINSV | Work Cap PY | ₹ -94,505 Cr. |
| BAJAJFINSV | Net Block PY | ₹ 4,336 Cr. |
| BAJAJFINSV | Gross Block PY | ₹ 7,048 Cr. |
| BAJAJFINSV | CWIP PY | ₹ 191 Cr. |
| BAJAJFINSV | Work Cap 3Yr | ₹ -77,937 Cr. |
| BAJAJFINSV | Work Cap 5Yr | ₹ -61,072 Cr. |
| BAJAJFINSV | Work Cap 7Yr | ₹ -9,827 Cr. |
| BAJAJFINSV | Work Cap 10Yr | ₹ -20,009 Cr. |
| BAJAJFINSV | Debt 3Years back | ₹ 1,28,461 Cr. |
| BAJAJFINSV | Debt 5Years back | ₹ 99,754 Cr. |
| BAJAJFINSV | Debt 7Years back | ₹ 48,282 Cr. |
| BAJAJFINSV | Debt 10Years back | ₹ 19,507 Cr. |
| BAJAJFINSV | Net Block 3Yrs Back | ₹ 3,182 Cr. |
| BAJAJFINSV | Net Block 5Yrs Back | ₹ 2,097 Cr. |
| BAJAJFINSV | Net Block 7Yrs Back | ₹ 1,645 Cr. |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | CF Operations | ₹ -68,674 Cr. |
| BAJAJFINSV | Free Cash Flow | ₹ -69,986 Cr. |
| BAJAJFINSV | CF Investing | ₹ -10,960 Cr. |
| BAJAJFINSV | CF Financing | ₹ 82,709 Cr. |
| BAJAJFINSV | Net CF | ₹ 3,075 Cr. |
| BAJAJFINSV | Cash Beginning | ₹ 5,504 Cr. |
| BAJAJFINSV | Cash End | ₹ 12,387 Cr. |
| BAJAJFINSV | FCF Prev Ann | ₹ -40,603 Cr. |
| BAJAJFINSV | CF Operations PY | ₹ -39,480 Cr. |
| BAJAJFINSV | CF Investing PY | ₹ -13,945 Cr. |
| BAJAJFINSV | CF Financing PY | ₹ 51,016 Cr. |
| BAJAJFINSV | Net CF PY | ₹ -2,409 Cr. |
| BAJAJFINSV | Cash Beginning PY | ₹ 7,913 Cr. |
| BAJAJFINSV | Cash End PY | ₹ 5,377 Cr. |
| BAJAJFINSV | Free Cash Flow 3Yrs | ₹ -1,45,009 Cr. |
| BAJAJFINSV | Free Cash Flow 5Yrs | ₹ -1,65,152 Cr. |
| BAJAJFINSV | Free Cash Flow 7Yrs | ₹ -2,12,681 Cr. |
| BAJAJFINSV | Free Cash Flow 10Yrs | ₹ -2,44,130 Cr. |
| BAJAJFINSV | CF Opr 3Yrs | ₹ -1,41,824 Cr. |
| BAJAJFINSV | CF Opr 5Yrs | ₹ -1,60,645 Cr. |
| BAJAJFINSV | CF Opr 7Yrs | ₹ -2,07,302 Cr. |
| BAJAJFINSV | CF Opr 10Yrs | ₹ -2,38,750 Cr. |
| BAJAJFINSV | CF Inv 10Yrs | ₹ -41,941 Cr. |
| BAJAJFINSV | CF Inv 7Yrs | ₹ -44,916 Cr. |
| BAJAJFINSV | CF Inv 5Yrs | ₹ -37,091 Cr. |
| BAJAJFINSV | CF Inv 3Yrs | ₹ -23,459 Cr. |
| BAJAJFINSV | Cash 3Years back | ₹ 3,410 Cr. |
| BAJAJFINSV | Cash 5Years back | ₹ 1,589 Cr. |
| BAJAJFINSV | Cash 7Years back | ₹ 1,499 Cr. |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | No. Eq. Shares | 160 |
| BAJAJFINSV | Book value | ₹ 378 |
| BAJAJFINSV | Inven TO |  |
| BAJAJFINSV | Quick ratio | 0.25 |
| BAJAJFINSV | Exports percentage | 0.00 % |
| BAJAJFINSV | Piotroski score | 5.00 |
| BAJAJFINSV | G Factor | 4.00 |
| BAJAJFINSV | Asset Turnover | 0.23 |
| BAJAJFINSV | Financial leverage | 7.81 |
| BAJAJFINSV | No. of Share Holders | 7,08,432 |
| BAJAJFINSV | Unpledged Prom Hold | 60.6 % |
| BAJAJFINSV | ROIC | 11.7 % |
| BAJAJFINSV | Debtor days | 19.8 |
| BAJAJFINSV | Industry PBV | 1.79 |
| BAJAJFINSV | Credit rating |  |
| BAJAJFINSV | WC Days | -400 |
| BAJAJFINSV | Earning Power | 7.85 % |
| BAJAJFINSV | Graham Number | ₹ 667 |
| BAJAJFINSV | Cash Cycle | 19.8 |
| BAJAJFINSV | Days Payable |  |
| BAJAJFINSV | Days Receivable | 19.8 |
| BAJAJFINSV | Inventory Days |  |
| BAJAJFINSV | Public holding | 23.2 % |
| BAJAJFINSV | FII holding | 8.39 % |
| BAJAJFINSV | Chg in FII Hold | -0.03 % |
| BAJAJFINSV | DII holding | 7.60 % |
| BAJAJFINSV | Chg in DII Hold | 0.27 % |
| BAJAJFINSV | B.V. Prev Ann | ₹ 291 |
| BAJAJFINSV | ROCE Prev Yr | 11.3 % |
| BAJAJFINSV | ROA Prev Yr | 3.31 % |
| BAJAJFINSV | ROE Prev Ann | 14.8 % |
| BAJAJFINSV | No. of Share Holders Prev Qtr | 5,67,041 |
| BAJAJFINSV | No. Eq. Shares 10 Yrs | 159 |
| BAJAJFINSV | BV 3yrs back | ₹ 225 |
| BAJAJFINSV | BV 5yrs back | ₹ 197 |
| BAJAJFINSV | BV 10yrs back | ₹ 69.7 |
| BAJAJFINSV | Inven TO 3Yr |  |
| BAJAJFINSV | Inven TO 5Yr |  |
| BAJAJFINSV | Inven TO 7Yr |  |
| BAJAJFINSV | Inven TO 10Yr |  |
| BAJAJFINSV | Export 3Yr | 0.00 % |
| BAJAJFINSV | Export 5Yr | 0.00 % |
| BAJAJFINSV | Div 5Yrs | ₹ 95.6 Cr. |
| BAJAJFINSV | ROCE 3Yr | 11.0 % |
| BAJAJFINSV | ROCE 5Yr | 11.0 % |
| BAJAJFINSV | ROCE 7Yr | 11.5 % |
| BAJAJFINSV | ROCE 10Yr | 12.2 % |
| BAJAJFINSV | ROE 10Yr | 14.1 % |
| BAJAJFINSV | ROE 7Yr | 13.9 % |
| BAJAJFINSV | ROE 5Yr Var | 0.97 % |
| BAJAJFINSV | OPM 5Year | 34.6 % |
| BAJAJFINSV | OPM 10Year | 34.8 % |
| BAJAJFINSV | No. of Share Holders 1Yr | 6,91,234 |
| BAJAJFINSV | Avg Div Payout 3Yrs | 1.78 % |
| BAJAJFINSV | Debtor days 3yrs | 17.1 |
| BAJAJFINSV | Debtor days 3yrs back | 16.6 |
| BAJAJFINSV | Debtor days 5yrs back | 19.5 |
| BAJAJFINSV | ROA 5Yr | 2.94 % |
| BAJAJFINSV | ROA 3Yr | 3.11 % |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | Avg Vol 1Mth | 19,30,050 |
| BAJAJFINSV | Avg Vol 1Wk | 22,82,842 |
| BAJAJFINSV | Volume | 17,60,753 |
| BAJAJFINSV | High price | ₹ 1,742 |
| BAJAJFINSV | Low price | ₹ 1,419 |
| BAJAJFINSV | High price all time | ₹ 1,933 |
| BAJAJFINSV | Low price all time | ₹ 8.67 |
| BAJAJFINSV | Return over 1day | 0.66 % |
| BAJAJFINSV | Return over 1week | -4.16 % |
| BAJAJFINSV | Return over 1month | -1.77 % |
| BAJAJFINSV | DMA 50 | ₹ 1,594 |
| BAJAJFINSV | DMA 200 | ₹ 1,590 |
| BAJAJFINSV | DMA 50 previous day | ₹ 1,595 |
| BAJAJFINSV | 200 DMA prev. | ₹ 1,590 |
| BAJAJFINSV | RSI | 43.0 |
| BAJAJFINSV | MACD | 5.24 |
| BAJAJFINSV | MACD Previous Day | 8.66 |
| BAJAJFINSV | MACD Signal | 7.35 |
| BAJAJFINSV | MACD Signal Prev | 7.88 |
| BAJAJFINSV | Avg Vol 1Yr | 15,28,072 |
| BAJAJFINSV | Return over 7years | 18.0 % |
| BAJAJFINSV | Return over 10years | 32.6 % |
| BAJAJFINSV | Market Cap | ₹ 2,52,640 Cr. |
| BAJAJFINSV | Current Price | ₹ 1,582 |
| BAJAJFINSV | High / Low | ₹ 1,742 / 1,419 |
| BAJAJFINSV | Stock P/E | 30.3 |
| BAJAJFINSV | Book Value | ₹ 378 |
| BAJAJFINSV | Dividend Yield | 0.06 % |
| BAJAJFINSV | ROCE | 11.7 % |
| BAJAJFINSV | ROE | 15.3 % |
| BAJAJFINSV | Face Value | ₹ 1.00 |
| BAJAJFINSV | WC to Sales | -91.6 % |
| BAJAJFINSV | QoQ Profits | 3.04 % |
| BAJAJFINSV | QoQ Sales | -1.75 % |
| BAJAJFINSV | Net worth | ₹ 60,329 Cr. |
| BAJAJFINSV | Market Cap to Sales | 2.13 |
| BAJAJFINSV | Interest Coverage | 2.11 |
| BAJAJFINSV | EV / EBIT | 12.5 |
| BAJAJFINSV | Debt Capacity | -0.82 |
| BAJAJFINSV | Debt To Profit | 18.5 |
| BAJAJFINSV | Capital Employed | ₹ -1,02,932 Cr. |
| BAJAJFINSV | CROIC | -14.2 % |
| BAJAJFINSV | debtplus | 4.85 |
| BAJAJFINSV | Leverage | ₹ 7.81 |
| BAJAJFINSV | Dividend Payout | 1.96 % |
| BAJAJFINSV | Intrinsic Value | ₹ 902 |
| BAJAJFINSV | CDL | -111 % |
| BAJAJFINSV | Cash by market cap | 0.04 |
| BAJAJFINSV | 52w Index | 50.6 % |
| BAJAJFINSV | Down from 52w high | 9.16 % |
| BAJAJFINSV | Up from 52w low | 11.5 % |
| BAJAJFINSV | From 52w high | 0.91 |
| BAJAJFINSV | Mkt Cap To Debt Cap | -0.63 |
| BAJAJFINSV | Dividend Payout | 1.96 % |
| BAJAJFINSV | Graham | ₹ 667 |
| BAJAJFINSV | Price to Cash Flow | -3.68 |
| BAJAJFINSV | ROCE3yr avg | 11.0 % |
| BAJAJFINSV | PB X PE | 128 |
| BAJAJFINSV | NCAVPS | ₹ -680 |
| BAJAJFINSV | Mar Cap to CF | -3.68 |
| BAJAJFINSV | Altman Z Score | 1.15 |
| BAJAJFINSV | M.Cap / Qtr Profit | 118 |