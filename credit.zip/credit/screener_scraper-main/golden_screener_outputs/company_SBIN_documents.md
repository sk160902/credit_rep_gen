# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/state-bank-of-india/sbin/500112/corp-announcements/)
- [Signing Of Non-Binding Mou With FCDO 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c94cc8c0-d64b-4392-a4b5-3762dc400c40.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f880f8fd-b1d3-4cae-852d-39b9df3c6fba.pdf)
- [Board Meeting Intimation for Financial Results For The Quarter Ended 30.06.2024 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6d100feb-650a-44bf-983c-5a9eb3875b79.pdf)
- [GRI Certified Sustainability Report FY 2023-24 20 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8961d534-00fe-433d-9035-99540825c310.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06d1c5f0-fa3d-4ef6-8f69-8b4c9ca837c3.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e236470-9427-43c7-93e9-c8eb61bb1f72.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\22d33d1d-af2a-4d2d-98c0-eff16cd73cb5.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500112/73059500112.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500112/68518500112.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120311.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120310.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/feb-2008/state-bank-of-india-fast-track-issue_6259.html)

## Credit Ratings
- [Rating update
5 Jul from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/StateBankofIndia_July%2005_%202024_RR_348098.html)
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407150707_State_Bank_of_India.pdf)
- [Rating update
21 Jun from fitch](https://www.indiaratings.co.in/pressrelease/70546)
- [Rating update
21 Jun from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128229)
- [Rating update
6 Nov 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202311121133_State_Bank_of_India.pdf)
- [](https://www.indiaratings.co.in/pressrelease/66783)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=68b86c74-1a02-41cf-9daf-d040d60cd34d.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d7eaa420-b619-4865-b196-519921e57cbc.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=595ee5f3-1722-4ee7-974e-6b537cb498ad.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0de1b244-29ba-40d3-8de7-aa64249297d7.pdf)
- [REC](https://sbi.co.in/documents/17836/41362884/030224-SBI+Analyst+Meet_3rd_Feb_24.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a58f0d8-f71e-4d4d-8dab-6e3e21d65281.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=501d3fc4-a24b-48ee-815a-87c711a08e9e.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d1a1746d-fa6e-48c4-bbab-c5b2e05ec4e7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2698e2ad-5bf3-42e4-9ce0-15ea315461da.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c0592b75-f3d7-4e58-b582-060c9cff3bda.pdf)
- [PPT](https://www.sbi.co.in/documents/17836/1275616/180523-SBI+Analyst+Presentation+Q4FY23.pdf/254aa07d-32bc-37c0-048d-c6666d1e1619?t=1684399592252)
- [REC](https://sbi.co.in/documents/17836/30252825/180523-SBI_AnalystMeet+Audio+Recording_18.05.2023.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=98f6f60a-be7b-47bd-b961-71e79984bd2c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c433f9bf-fb1a-4d77-a804-c9908bdc8f25.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d4197c79-9542-46a6-8389-eab7b17f0b9d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=65e56f27-ce21-495d-91f2-9db0baa3cea3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a89aeb98-b09e-4199-8993-da23e76f118f.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_13052022134116_BSENSEPRAnalystPPTMarch202213052022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9a7dbf75-41cf-4806-b4a7-ae3a976c42fd.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_05022022134234_BSENSEAnalystPresentationDec202105022022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4fd42357-9d95-4e4c-b5d7-4e169643b94c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b52b4b6e-71cf-494d-893b-be3b2554c608.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23225b11-e337-4259-9751-569175a984ad.pdf)
- [](https://sbi.co.in/documents/17836/4840865/02082020_SBI+Q1FY21+ANALYST+CONFERENCE+CALL+TRANSCRIPT.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5eac345a-7d35-4966-9803-a5085bc0a0da.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c96c47e9-4664-4e89-bb47-a6ede7fe014e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=38d64302-c438-4e34-b1a1-9f23f485cd59.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a76d3e75-5933-4d0d-b126-b0e86f1afee9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa1bb923-f000-4f8e-ab4c-807d8da063cb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=36efc9c3-a3b0-4a4c-bcc4-ae975db87cca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a1290736-7b9a-40b8-b458-43d6fc5098b3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b2142dd5-5684-4074-b7fb-8e69c0197ec1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4b2f1f50-a691-49ac-8cc7-c6a84ae95a7b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4075b384-c809-4c23-806f-450cfc827674.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=121b5497-6d06-43dc-8c97-2e9be85833a3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=db2b5d52-5628-41c1-ba88-7b014a999ff2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f2783451-2853-442c-831d-c8c8788a01fc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c9a219a8-e851-4368-819b-6a4cbc1a425d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95659481-cfcf-46c8-a820-b868ebe0d855.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2EF979D4_937A_4020_9E9B_E41807ACD41B_160702.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B1C5608A_FE04_4F34_AE03_A6777062FA78_165011.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3754D016_CCCE_4034_8C4D_A38777A79E58_142755.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_03112021135346_BSENSEAnalystAnnounce03112021.pdf)

