import json
import re
from jinja2 import Environment, FileSystemLoader

# Function to escape LaTeX special characters and replace underscores with spaces
def escape_latex(text):
    """
    Escapes LaTeX special characters in the given text and replaces underscores with spaces.
    """
    if not isinstance(text, str):
        return text
    replacements = {
        '&': r'\&',   # Use raw string to correctly handle backslashes
        '%': r'\%',   # Same here
        '$': r'\$',   # And here
        '#': r'\#',   # And here
        '_': r'\_',   # And here
        '{': r'\{',   # And here
        '}': r'\}',   # And here
        '~': r'\textasciitilde{}',  # Correct replacement for tilde
        '^': r'\textasciicircum{}',  # Correct replacement for caret
        '\n': ' ',    # Replaces new lines with a space
    }
    for key, value in replacements.items():
        text = text.replace(key, value)
    #print("Escaped Text:", text)
    return text

escaped_text = escape_latex("Mr. Jayanti Patel: 47 yrs of experience in Overseas corporate affairs & finance.")
#print(escaped_text)
# File paths
json_file_path = '/Users/Shreyas2/Desktop/Onfinance/credit/credit_reports-main/report_data.json'
latex_template_path = 'combined.tex'
output_file_path = 'credit_appraisal_output7.tex'

# Open and read the JSON file
with open(json_file_path, 'r') as file:
    data = json.load(file)

leverage_ratio_data = data["leverage_ratio"]
#leverage_ratio_graphs = [{"name": key, "url": value["url"]} for key, value in leverage_ratio_data["graphs"].items()]
leverage_ratio_commentary = [escape_latex(comment) for comment in leverage_ratio_data["commentary"]]
leverage_ratio_graphs = [{"name": key, "url": value} for key, value in leverage_ratio_data["graphs"].items()]
print(leverage_ratio_graphs)
#leverage_ratio_commentary = leverage_ratio_data.commentary

# Extracting performance ratios data
performance_ratios_data = data["performance_ratios"]
#performance_ratio_graphs = [{"name": key, "url": value["url"]} for key, value in performance_ratios_data["graphs"].items()]
performance_ratio_commentary = [escape_latex(comment) for comment in performance_ratios_data["commentary"]]
performance_ratio_graphs = [{"name": key, "url": value} for key, value in performance_ratios_data["graphs"].items()]
#performance_ratio_commentary = leverage_ratio_data.commentary
# Extracting activity ratios data
activity_ratios_data = data["activity_ratio"]
#activity_ratio_graphs = [{"name": key, "url": value["url"]} for key, value in activity_ratios_data["graphs"].items()]
activity_ratio_commentary = [escape_latex(comment) for comment in activity_ratios_data["commentary"]]
activity_ratio_graphs = [{"name": key, "url": value} for key, value in activity_ratios_data["graphs"].items()]
print(activity_ratio_graphs)
#activity_ratio_commentary = activity_ratios_data.commentary
# Extracting valuation ratios data
# valuation_ratios_data = data["valuation_ratios"]
# valuation_ratio_graphs = [{"name": key, "url": value["url"]} for key, value in valuation_ratios_data["graphs"].items()]
# valuation_ratio_commentary = [escape_latex(comment) for comment in valuation_ratios_data["commentary"]]

# Setup Jinja2 environment and load template file
ownership_structure_data = data["ownership_structure"]
ownership_structure_graphs = [{"name": key, "url": value["url"]} for key, value in ownership_structure_data["graphs"].items()]
ownership_structure_commentary = [escape_latex(comment) for comment in ownership_structure_data["commentary"]]
