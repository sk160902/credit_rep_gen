# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,279 | 10,173 | 11,345 | 13,790 | 14,394 | 15,156 | 16,362 | 17,132 | 19,160 | 21,763 | 22,753 | 25,774 |
| Expenses + | 6,065 | 8,026 | 9,183 | 11,310 | 11,898 | 12,329 | 13,265 | 13,926 | 14,907 | 17,211 | 17,726 | 19,483 |
| Operating Profit | 2,214 | 2,147 | 2,163 | 2,480 | 2,496 | 2,826 | 3,097 | 3,206 | 4,252 | 4,553 | 5,027 | 6,291 |
| OPM % | 27% | 21% | 19% | 18% | 17% | 19% | 19% | 19% | 22% | 21% | 22% | 24% |
| Other Income + | 245 | 251 | 164 | 208 | 208 | 280 | 477 | 344 | 266 | 99 | 293 | 552 |
| Interest | 34 | 146 | 168 | 207 | 159 | 114 | 168 | 197 | 161 | 106 | 110 | 90 |
| Depreciation | 330 | 373 | 505 | 754 | 1,323 | 1,323 | 1,326 | 1,175 | 1,068 | 1,052 | 1,172 | 1,051 |
| Profit before tax | 2,095 | 1,880 | 1,654 | 1,727 | 1,222 | 1,669 | 2,079 | 2,178 | 3,290 | 3,493 | 4,038 | 5,702 |
| Tax % | 26% | 25% | 24% | 19% | 15% | 15% | 27% | 29% | 27% | 27% | 30% | 27% |
| Net Profit + | 1,545 | 1,404 | 1,229 | 1,383 | 1,035 | 1,417 | 1,492 | 1,500 | 2,389 | 2,547 | 2,833 | 4,154 |
| EPS in Rs | 19.24 | 17.29 | 14.71 | 16.93 | 12.51 | 17.52 | 18.96 | 19.18 | 29.82 | 31.19 | 34.71 | 51.05 |
| Dividend Payout % | 10% | 12% | 14% | 12% | 16% | 17% | 16% | 21% | 17% | 16% | 24% | 25% |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 50% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cipla Limited Employees Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  | 42 | 42 | 41 | 40 | 39 | 43 |
| Contribution payable to provident/gratuity fund |  |  |  |  | 9.64 | 10 |  |  |  |
| Avenue Therapeutics, Inc. Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  | 242 |  |  |  |  |
| Cipla foundation |  |  |  |  |  |  |  |  |  |
| Donations given |  |  |  |  | 29 | 38 | 33 | 56 | 63 |
| Dr. Y. K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 50 | 115 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.02 | 2.03 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Remuneration |  |  | 2.02 |  |  |  |  |  |  |
| Cipla Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  | 28 | 15 | 15 | 28 | 20 | 24 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  | 28 |  |  |  |
| Advances receivable from gratuity trust |  |  |  |  | 9.51 |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  | 3.92 |  |  |  |  |  |
| GoApptiv Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Service Charges and reimbursement paid |  |  |  |  |  |  | 15 | 38 | 34 |
| Payable to |  |  |  |  |  |  |  | 24 | 3.34 |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  | 7.20 |  | 18 |
| Investment in equity shares of Associates |  |  |  |  |  |  | 1.80 |  | 8.25 |
| Reimbursement of operating/other expenses |  |  |  |  |  |  | 0.65 |  |  |
| Payable to associates and others |  |  |  |  |  |  | 0.29 |  |  |
| Mr. Umang Vohra Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 15 | 17 | 15 |  |  |  |
| Remuneration |  | 4.74 | 14 |  |  |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 5.50 | 4 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 4 |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 0.04 | 0.16 |  |  |  |
| Cipla Foundation |  |  |  |  |  |  |  |  |  |
| Donations given | 9.28 | 12 |  | 31 |  |  |  |  |  |
| Donations Given |  |  | 16 |  |  |  |  |  |  |
| Payable to |  |  |  |  |  |  |  | 0.33 |  |
| Outstanding receivables |  |  |  |  |  |  |  |  | 0.07 |
| Mr. Subhanu Saxena Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 13 | 12 | 25 |  |  |  |  |  |  |
| Mr. M. K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 10 | 24 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.07 | 2.08 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Remuneration |  | 0.11 | 2.09 |  |  |  |  |  |  |
| AMPSolar Power Systems Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electricity charges paid |  |  |  |  |  |  | 2.42 | 16 | 14 |
| Investment in Compulsory Convertible Debentures |  |  |  |  |  | 8.91 |  |  |  |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  |  | 1.16 |  |
| Investment in equity shares |  |  |  |  |  | 0.09 |  | 0.01 |  |
| Stempeutics Research Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investment in Equity | 20 | 13 |  |  |  |  |  |  |  |
| Loan repaid | 2.94 |  |  |  |  |  |  |  |  |
| Purchase of Goods |  | 2.01 |  |  |  |  |  |  |  |
| Outstanding payables | 0.02 | 1 |  |  |  |  |  |  |  |
| Dr. Y.K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 33 |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 2.03 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Ms. Samina Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 5.37 | 13 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 7.27 | 6.74 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2.30 | 2.30 |  |  |  |
| Cipla Limited Employees Provident fund |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 11 | 12 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 11 |  |  |
| Brandmed (Pty) Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  |  | 32 |  |  |  |
| Brandmed (Pty) Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding receivables |  |  |  |  |  |  |  | 2.61 | 7.27 |
| Loan given |  |  |  |  |  |  |  | 2.61 | 4.72 |
| Purchase of goods |  |  |  |  |  |  | 4.99 | 0.77 |  |
| Payable towards acquisition of stake in associate |  |  |  |  |  |  | 2.47 |  |  |
| Interest Income |  |  |  |  |  |  |  | 0.02 | 0.33 |
| Achira Labs Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  |  |  | 23 |
| Investment in equity shares of Associates |  |  |  |  |  |  |  |  | 2 |
| Stempeutics Research Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  | 3 |  | 2 |  |  |
| Purchase of goods |  |  |  | 1.10 | 0.16 |  |  | 0.46 | 2.33 |
| Testing and analysis charges paid |  |  |  |  | 1.79 | 2.06 |  |  |  |
| Service Charges and reimbursement paid |  |  |  |  |  |  | 1.16 | 1.05 | 1.26 |
| Purchase of Fixed Assets |  |  |  |  |  |  |  |  | 2 |
| Payable to |  |  |  |  |  |  |  | 0.52 | 1.25 |
| Reimbursement of operating/other expenses |  |  |  |  | 0.18 | 0.31 |  |  |  |
| Freight charges paid |  |  |  |  |  | 0.02 |  | 0.02 |  |
| Mr. S. Radhakrishnan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 3.69 | 3.37 | 4.06 |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.09 | 2.10 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Dividend Paid |  |  |  |  | 0.01 | 0.11 |  |  |  |
| Mr. Kedar Upadhye Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 3.31 | 3.85 | 3.84 |  |  |  |
| Remuneration |  |  | 3.13 |  |  |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.91 | 0.90 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.70 |  |  |  |  |  |
| Dividend Paid |  |  |  |  |  | 0.03 |  |  |  |
| Mr. Rajesh Garg Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 4.98 | 11 |  |  |  |  |  |  |  |
| Ms. Samina Vaziralli Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 2.47 | 3.90 |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 4.83 |  |  |  |  |  |
| Dividend paid |  |  |  | 3.58 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 1.14 |  |  |  |  |  |
| Cipla Limited Employees Gratuity fund |  |  |  |  |  |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  |  | 9.30 |  |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 4.26 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  |  | 0.32 |
| Clean Max Auriga Power LLP Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  |  |  |  | 6.75 |  |
| Electricity charges paid |  |  |  |  |  |  |  |  | 5.19 |
| Payable to |  |  |  |  |  |  |  |  | 0.84 |
| AMP Energy Green Eleven Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Investment in Compulsory Convertible Debentures of Associates |  |  |  |  |  |  |  | 6.75 |  |
| Electricity charges paid |  |  |  |  |  |  |  |  | 3.67 |
| Investment in equity shares |  |  |  |  |  |  |  | 0.75 |  |
| Payable to |  |  |  |  |  |  |  |  | 0.40 |
| The Cipla Foundation (SA) |  |  |  |  |  |  |  |  |  |
| Donations given |  |  |  |  |  |  |  |  | 9.19 |
| Outstanding receivables |  |  |  |  |  |  |  | 1.68 | 0.49 |
| Hamied Foundation |  |  |  |  |  |  |  |  |  |
| Service charges paid |  | 1.76 |  | 4.87 |  |  |  |  |  |
| Service Charges Paid |  |  | 2.49 |  |  |  |  |  |  |
| Donations Given |  |  | 1.64 |  |  |  |  |  |  |
| Donations given |  | 0.36 |  |  |  |  |  |  |  |
| Mr. M.K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 6.33 |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 2.10 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Dr. Raghunathan Ananthanarayanan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 8.85 | -0.47 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 1.78 |  |  |  |  |
| Mr. S.Radhakrishnan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 4.03 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Chest Research Foundation |  |  |  |  |  |  |  |  |  |
| Service charges paid |  |  |  |  | 2.22 |  |  |  |  |
| Donations given |  |  |  |  |  | 2 |  |  |  |
| Sitec Labs Private Limited Employees Group Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.98 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 1.11 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.13 | 0.85 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.08 |  |  |
| Cipla Limited Employee Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident fund |  |  |  | 3.53 |  |  |  |  |  |
| Dr. Peter Mugyenyi Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.43 | 0.43 | 0.66 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.41 |  |  |  |
| Remuneration |  |  | 0.42 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Stempeutics Research Pvt. Ltd Associate |  |  |  |  |  |  |  |  |  |
| Investment - Equity |  |  | 2.57 |  |  |  |  |  |  |
| Purchase of Goods |  |  | 0.57 |  |  |  |  |  |  |
| Mr. Ashok Sinha Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.47 | 0.46 | 0.48 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.40 |  |  |  |
| Remuneration |  |  | 0.51 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Cipla Health Limited Employees Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.96 | 1.50 |
| Contribution to provident fund and other fund |  |  |  |  |  |  |  | 0.38 | 0.08 |
| Ms. Naina Lal Kidwai Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.40 | 0.43 | 0.45 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.35 | 0.35 |  |  |  |
| Remuneration |  |  | 0.43 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.35 |  |  |  |  |  |
| Mr. Adil Zainulbhai Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.36 | 0.38 | 0.47 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.32 | 0.36 |  |  |  |
| Remuneration |  |  | 0.42 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.32 |  |  |  |  |  |
| Ms. Punita Lal Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.39 | 0.41 | 0.40 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.35 | 0.35 |  |  |  |
| Remuneration |  |  | 0.38 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.33 |  |  |  |  |  |
| Medispray Laboratories Private Limited Employees Comprehensive Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.53 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.10 | 0.38 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.22 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.12 |  |  |
| Mr. Peter Lankau Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.44 | 0.73 | 0.17 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.10 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Remuneration |  |  | 0.11 |  |  |  |  |  |  |
| Meditab Specialities Limited Employees Comprehensive Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.20 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.22 | 0.52 |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.01 |  |  |
| Ms. Ireena Vittal Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.41 | 0.41 |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.36 |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.36 |  |  |  |  |  |
| Remuneration |  |  | 0.14 |  |  |  |  |  |  |
| Goldencross Pharma Private Limited Employees Group Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 0.80 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.21 | 0.46 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.12 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.04 |  |  |
| Cipla Health Limited Employees Gratuity scheme |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.95 |  |  |
| Mr. Kamil Hamied Relative |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 0.38 |  |  |  |  |  |  |  |
| Cipla Biotec Private Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.01 | 0.01 | 0.01 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,279 | 10,173 | 11,345 | 13,790 | 14,394 | 15,156 | 16,362 | 17,132 | 19,160 | 21,763 | 22,753 | 25,774 |
| Expenses + | 6,065 | 8,026 | 9,183 | 11,310 | 11,898 | 12,329 | 13,265 | 13,926 | 14,907 | 17,211 | 17,726 | 19,483 |
| Operating Profit | 2,214 | 2,147 | 2,163 | 2,480 | 2,496 | 2,826 | 3,097 | 3,206 | 4,252 | 4,553 | 5,027 | 6,291 |
| OPM % | 27% | 21% | 19% | 18% | 17% | 19% | 19% | 19% | 22% | 21% | 22% | 24% |
| Other Income + | 245 | 251 | 164 | 208 | 208 | 280 | 477 | 344 | 266 | 99 | 293 | 552 |
| Interest | 34 | 146 | 168 | 207 | 159 | 114 | 168 | 197 | 161 | 106 | 110 | 90 |
| Depreciation | 330 | 373 | 505 | 754 | 1,323 | 1,323 | 1,326 | 1,175 | 1,068 | 1,052 | 1,172 | 1,051 |
| Profit before tax | 2,095 | 1,880 | 1,654 | 1,727 | 1,222 | 1,669 | 2,079 | 2,178 | 3,290 | 3,493 | 4,038 | 5,702 |
| Tax % | 26% | 25% | 24% | 19% | 15% | 15% | 27% | 29% | 27% | 27% | 30% | 27% |
| Net Profit + | 1,545 | 1,404 | 1,229 | 1,383 | 1,035 | 1,417 | 1,492 | 1,500 | 2,389 | 2,547 | 2,833 | 4,154 |
| EPS in Rs | 19.24 | 17.29 | 14.71 | 16.93 | 12.51 | 17.52 | 18.96 | 19.18 | 29.82 | 31.19 | 34.71 | 51.05 |
| Dividend Payout % | 10% | 12% | 14% | 12% | 16% | 17% | 16% | 21% | 17% | 16% | 24% | 25% |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 50% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |

