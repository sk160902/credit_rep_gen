# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/asian-paints-ltd/asianpaint/500820/corp-announcements/)
- [Minutes Of The 78Th Annual General Meeting Of The Company
2m - Minutes of the 78th Annual General Meeting of the Company held on Tuesday, 25th June 2024 through video conference.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1ae7ec65-2a4e-4c98-9153-24cbfc8c7d7d.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b0a30efb-336e-4d66-8dcc-1072f2086e8d.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
22 Jul - Transcript of the Investor Conference held on Wednesday, 17th July 2024, with regard to the business and financial performance of the Company for the quarter …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b275848-7e65-4cf0-acbc-33cc7acb975c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8aed4d0c-d3fa-46b2-ba02-a508887506d9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa64a601-c78f-4fca-ad0f-e3487d2f2c20.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=218b2e64-6a82-4ecf-8d19-f92bd77518c7.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\e874970f-8a7b-41de-88f2-40928e65f3e7.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/73104500820.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/68521500820.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ASIANPAINT_2011_2012_12062012100812.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200311.pdf)

## Credit Ratings
- [Rating update
29 Dec 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_December%2029,%202023_RR_333603.html)
- [Rating update
15 Mar 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_March%2015,%202023_RR_314716.html)
- [Rating update
12 Jan 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_January%2012,%202023_RR_308786.html)
- [Rating update
17 Feb 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_February%2017,%202022_RR_288245.html)
- [Rating update
12 Jan 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_January%2012,%202022_RR_282669.html)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_April%2027,%202021_RR_269705.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b275848-7e65-4cf0-acbc-33cc7acb975c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa64a601-c78f-4fca-ad0f-e3487d2f2c20.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac9fe29f-3099-4479-b4f2-fdf0fa79e540.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=63a2696f-f94d-4133-a636-a33645aaa4f3.pdf)
- [REC](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2023-2024/Q4/Asian%20Paints_Q4FY24_Investor_Meet_Audio.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c705fd48-5088-4c70-afcc-6682ec00599c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a5eaa80-a911-4359-bcb0-751cc13df837.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1065d24c-707c-4f1a-b20b-b3fc7a34c21c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=87247a2b-5033-467c-a324-39a5e9078c96.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fe292159-09dd-40b9-bffa-99741a5afe41.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bbae2dec-20ce-4c3c-bc4b-b0f3ed44eefd.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0aed4336-c50d-41f6-9b03-b0a9a8782f52.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b118116-bed8-4b48-949a-c971c4193498.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6c84bd13-b939-4a77-be76-b3e928f26fd8.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/2022-2023/InvestorconferencepresentationQ3FY2023.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1f4a1b3b-0856-4953-b0f5-d4f2d34a893d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=156f8864-8ba9-4478-ad02-53bbb64d5f75.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4dfd9d49-2613-4f74-b98f-ea894035b797.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=38584fe3-d8fb-437a-934b-3d817f9d6d32.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3efac0b-aa64-499a-8995-169c380ff169.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3afe6ef-9fd6-483a-8a3e-3e6688186001.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9831cb5d-0b3f-46cb-af1e-2a67e454b670.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8f9c8791-eb61-48c1-962e-3a40aa25291d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a8d58ecd-a454-41b4-817c-c47031eb51a4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5f9dad5-bea9-458d-bfdf-2a87f5e1923a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e44ccf37-a913-4a69-bdb2-6adc0ee6ce26.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf03acdc-e12b-4034-84cc-761add1d66fa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7d68aa83-491b-4115-873c-f13d94ae4474.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f6909a8-5fff-44e6-80c3-434071aeddad.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=18b3d1ed-eede-4646-9ae4-e92369037d59.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bc8c670-ab6e-47a9-b3cf-bbb04de5f611.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9087e9e2-2c0c-4aa7-be5a-0be45259b3ee.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Conference%20call%20transcript%20-%20Q3FY21%20results.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0d8ef75-f7f7-4246-98ff-7f2a8bf042fd.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Q2-FY21%20results%20Investor%20call%20transcript%20(1).pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c50ac146-5f10-420f-9500-8a3653e07f3b.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Q1FY21%20results%20-%20Earnings%20call%20transcript.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Q2FY20%20Investor%20call%20transcript.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Motilal%20Oswal%20conference%20presentation.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Citi%20conference%20presentation.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94090c14-b57f-45bd-8c24-b9dc9b8c6eb8.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Investor%20call%20transcript%20-%20Q3FY19%20results..pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Q3FY18%20results%20-%20Investor%20conference%20call.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a72e312f-754d-4f71-ae33-da718f992bcb.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2017-2018/Asian%20Paints%20Q2%20FY%202018%20Result.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/UBS%20conference%20presentation%20-%20Nov%202017.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Investor%20conference%20call%20Q2-FY18%20results.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1695b666-469d-40b5-874c-543f846661e9.pdf)

