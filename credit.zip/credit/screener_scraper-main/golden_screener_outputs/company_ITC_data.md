About
[
edit
]
Established in 1910, ITC is the largest cigarette manufacturer and seller in the country. ITC operates in five business segments at present — FMCG Cigarettes, FMCG Others, Hotels, Paperboards, Paper and Packaging, and Agri Business.
[1]
Key Points
[
edit
]
Geographical Distribution
For FY22, India accounted for 78% of ITC's revenue while rest was from exports
[1]
FMCG - Cigarettes
ITC is the leader in the organised domestic cigarette market with a market share of over 80%
[2]
. It's wide range of brands include Insignia, India Kings, Classic, Gold Flake, American Club, Wills Navy Cut, Players, Scissors, Capstan, Berkeley, Bristol, Flake, Silk Cut, Duke & Royal.
[3]
Despite this vertical contributing only 40% to the revenues, it is the
most profitable business of the company with 81% contribution towards PBIT.
[4]
Industry:
India is the 4th largest market for illegal cigarettes. While the consumption rate of legal cigarettes is only 1/10th in the tobacco industry, It accounts for 4/5th Tax revenue share. Legal cigarette industry remains under pressure due to growth in illicit duty-evaded cigarette consumption.
[5]
FMCG - Others
ITC has 25 mother brands spread across multiple FMCG sectors
[6]
. Popular brands include:
- Packaged foods: Aashirvaad, Sunfeast, Bingo, Yippee noodles, Candyman and mint-o
- Personal Care: Savlon, Fiama, Vivel and Superia
- Stationary: Classmate and Paperkraft
- Apparels: WLS
- Agarbattis: Mangaldeep and AIM (matches)
‘ITC e-Store’, the Company’s exclusive D2C platform, is operational in 24,000+ pin-codes.
[7]
Hotels Business
Launched in 1975, ITC Hotels is one of the fastest growing hospitality chains in India. It is the second-largest hotel chain in India, with 108 hotels at 70 locations in the country, operating across multiple market segments. It possess a room inventory of ~290,000 rooms.
[8]
It's hotels are classified under 4 distinctive brands.
- ITC Hotels: which has an exclusive tie up with Marriott International Inc's 'The Luxury Collection'.
- Welcomhotels: which offers 5-star hospitality for the discerning business & leisure traveller.
- Fortune Hotels: which operates in mid-market to upscale properties hotel segment all over India.
- WelcomHeritage: which brings together a chain of palaces, forts, havelis & resorts that offer unique experience.
[9]
In H1FY24, they added 3 new properties to the Group portfolio including ‘WelcomHeritage Santa Roza, Kasauli’, ‘Fortune Park Hoshiarpur’ and ‘Fortune Ranjit Vihar, Amritsar.
[10]
Agri. Business
ITC is the second largest exporter of agri products from the country. It trades in feed ingredients, food grains, marine products, processed fruits, coffee etc
[11]
.
It also exports leaf tobacco under this vertical. ITC is India's largest and world's 5th largest leaf tobacco exporter
[12]
.
In H1FY24, ITC IndiVision Limited (IIVL), (WOS) received requisite regulatory approvals for its facility to manufacture Nicotine & Nicotine Derivative products conforming to US &
EU pharmacopoeia standards.
[13]
Paperboards, Paper & Packaging
ITC is the market leader in value added paperboards segment. It is also India’s largest converter of paperboard into high quality packaging.
[14]
ITC manufactures the entire spectrum of paperboards - from 100% virgin, food-grade boards which are made from renewable and sustainable sources to 100% recycled boards.
[15]
Revenue Split FY23
[2]
Cigarettes : 37% (vs ~57% in FY17)
FMCG : 23%
Hotels  : 3%
Paperboards & Packaging :11%
Agri : 23%
Demerger of Hotel Business
[2]
In Aug,23, the company has approved to dmerge its hotels  business into  a  new  entity
ITC  Hotels  Limited
.  ITC  will  continue  to have  a 40%  shareholding  in  the  new  entity  and  the balance 60% will be held by ITC’s existing shareholders in the proportion of their shareholding in ITC.
Last edited 6 months, 4 weeks ago
Request an update
© Protected by Copyright
