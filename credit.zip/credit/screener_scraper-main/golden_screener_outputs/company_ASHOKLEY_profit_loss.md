# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 11,859 | 15,708 | 21,260 | 22,871 | 29,636 | 33,197 | 21,951 | 19,454 | 26,237 | 41,673 | 45,791 | 46,824 |
| Expenses + | 11,437 | 14,191 | 18,281 | 19,826 | 25,387 | 28,287 | 18,718 | 16,992 | 23,472 | 36,580 | 37,848 | 38,521 |
| Operating Profit | 422 | 1,517 | 2,979 | 3,045 | 4,248 | 4,910 | 3,233 | 2,462 | 2,765 | 5,093 | 7,943 | 8,303 |
| OPM % | 4% | 10% | 14% | 13% | 14% | 15% | 15% | 13% | 11% | 12% | 17% | 18% |
| Other Income + | 613 | -106 | -321 | 406 | 190 | 139 | 57 | 207 | -230 | 166 | 73 | 56 |
| Interest | 805 | 872 | 925 | 1,049 | 1,227 | 1,502 | 1,802 | 1,901 | 1,869 | 2,094 | 2,982 | 3,231 |
| Depreciation | 530 | 580 | 524 | 573 | 646 | 676 | 750 | 836 | 866 | 900 | 927 | 936 |
| Profit before tax | -300 | -42 | 1,209 | 1,829 | 2,565 | 2,872 | 739 | -67 | -200 | 2,265 | 4,106 | 4,192 |
| Tax % | -23% | 415% | 41% | 11% | 29% | 24% | 38% | 4% | 43% | 40% | 34% |  |
| Net Profit + | -222 | -205 | 712 | 1,633 | 1,814 | 2,195 | 460 | -70 | -285 | 1,359 | 2,696 | 2,662 |
| EPS in Rs | -0.62 | 0.47 | 2.40 | 5.58 | 6.01 | 7.08 | 1.15 | -0.56 | -1.22 | 4.22 | 8.46 | 8.34 |
| Dividend Payout % | 0% | 96% | 40% | 28% | 40% | 44% | 44% | -107% | -82% | 62% | 59% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 206% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ashok Leyland Vehicles Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  | 1,026 | 764 |  |  |  |  |  |  |  |
| Other operatingincome |  | 75 | 59 |  |  |  |  |  |  |  |
| Sales and services |  | 34 | 34 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 35 | 23 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | -0.46 | 15 |  |  |  |  |  |  |  |
| Lanka Ashok Leyland, PLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and services |  | 331 | 336 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | -11 | 1.23 |  |  |  |  |  |  |  |
| Ashok Leyland (UAE) LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and Services (net of taxes) | 363 |  |  |  |  |  |  |  |  |  |
| Disposal of Investments to | 1.87 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.52 |  |  |  |  |  |  |  |  |  |
| Lanka Ashok Leyland PLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and Services (net of taxes) | 285 |  |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 1.40 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | -10 |  |  |  |  |  |  |  |  |  |
| Gulf Oil Lubricants India Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  | 87 | 109 |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 62 |  |  |  |  |  |  |  |  |  |
| Hinduja Automotive Limited, United Kingdom Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Dividend payment |  | 65 | 136 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 0.69 | 3.37 |  |  |  |  |  |  |  |
| Nisssan Ashok Leyland Powertrain Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 110 |  |  |  |  |  |  |  |  |  |
| Hinduja Foundries Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  |  | 109 |  |  |  |  |  |  |  |
| Sale of assets |  |  | 0.09 |  |  |  |  |  |  |  |
| Ashok Leyland John Deere Construction Equipment Company Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of |  | 46 | 25 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 1.27 | -0.73 |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.24 |  |  |  |  |  |  |  |  |  |
| Avia Ashok Leyland Motors s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Loans / Advance repaid | 66 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 1.88 |  |  |  |  |  |  |  |  |  |
| Purchase of assets | 0.39 |  |  |  |  |  |  |  |  |  |
| Ashley Powertrain Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other operatingincome |  | 26 | 22 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | 0.37 | 2.40 |  |  |  |  |  |  |  |
| Nissan Ashok Leyland Technologies Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 39 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 9.22 |  |  |  |  |  |  |  |  |  |
| Albonair GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of | 26 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.05 |  |  |  |  |  |  |  |  |  |
| Hinduja Tech Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 8.44 | 15 |  |  |  |  |  |  |  |
| Purchase of assets |  | 0.20 | 0.13 |  |  |  |  |  |  |  |
| Ashley Alteams India Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 20 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 0.11 |  |  |  |  |  |  |  |  |  |
| Ashok Leyland Defence Systems Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of |  |  | 6.47 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 1.47 | 3.93 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | 2.29 |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 0.60 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.55 |  |  |  |  |  |  |  |  |  |
| Nissan Ashok Leyland Powertrain Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other Operating Income | 12 |  |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 0.04 |  |  |  |  |  |  |  |  |  |
| Ashley Aviation Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Interest and other income | 2.25 | 2.25 | 2.25 |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.58 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 11,859 | 15,708 | 21,260 | 22,871 | 29,636 | 33,197 | 21,951 | 19,454 | 26,237 | 41,673 | 45,791 | 46,824 |
| Expenses + | 11,437 | 14,191 | 18,281 | 19,826 | 25,387 | 28,287 | 18,718 | 16,992 | 23,472 | 36,580 | 37,848 | 38,521 |
| Operating Profit | 422 | 1,517 | 2,979 | 3,045 | 4,248 | 4,910 | 3,233 | 2,462 | 2,765 | 5,093 | 7,943 | 8,303 |
| OPM % | 4% | 10% | 14% | 13% | 14% | 15% | 15% | 13% | 11% | 12% | 17% | 18% |
| Other Income + | 613 | -106 | -321 | 406 | 190 | 139 | 57 | 207 | -230 | 166 | 73 | 56 |
| Interest | 805 | 872 | 925 | 1,049 | 1,227 | 1,502 | 1,802 | 1,901 | 1,869 | 2,094 | 2,982 | 3,231 |
| Depreciation | 530 | 580 | 524 | 573 | 646 | 676 | 750 | 836 | 866 | 900 | 927 | 936 |
| Profit before tax | -300 | -42 | 1,209 | 1,829 | 2,565 | 2,872 | 739 | -67 | -200 | 2,265 | 4,106 | 4,192 |
| Tax % | -23% | 415% | 41% | 11% | 29% | 24% | 38% | 4% | 43% | 40% | 34% |  |
| Net Profit + | -222 | -205 | 712 | 1,633 | 1,814 | 2,195 | 460 | -70 | -285 | 1,359 | 2,696 | 2,662 |
| EPS in Rs | -0.62 | 0.47 | 2.40 | 5.58 | 6.01 | 7.08 | 1.15 | -0.56 | -1.22 | 4.22 | 8.46 | 8.34 |
| Dividend Payout % | 0% | 96% | 40% | 28% | 40% | 44% | 44% | -107% | -82% | 62% | 59% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 206% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |

