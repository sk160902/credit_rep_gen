# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 27,202 | 30,736 | 35,727 | 41,409 | 45,175 | 46,614 | 56,044 | 63,716 | 64,397 | 68,846 | 87,448 | 112,759 | 117,672 |
| Interest | 17,513 | 18,703 | 21,341 | 24,344 | 26,789 | 27,604 | 33,883 | 37,996 | 34,627 | 34,923 | 43,389 | 61,391 | 64,680 |
| Expenses + | 8,538 | 9,944 | 11,521 | 13,869 | 24,327 | 29,717 | 28,020 | 35,976 | 32,621 | 31,216 | 30,641 | 40,032 | 43,581 |
| Financing Profit | 1,151 | 2,089 | 2,865 | 3,196 | -5,941 | -10,706 | -5,860 | -10,256 | -2,851 | 2,707 | 13,418 | 11,336 | 9,411 |
| Financing Margin % | 4% | 7% | 8% | 8% | -13% | -23% | -10% | -16% | -4% | 4% | 15% | 10% | 8% |
| Other Income + | 6,833 | 7,766 | 8,838 | 9,955 | 12,422 | 11,863 | 14,189 | 16,342 | 13,577 | 17,268 | 18,349 | 25,230 | 26,219 |
| Depreciation | 359 | 375 | 420 | 461 | 527 | 591 | 737 | 806 | 976 | 1,046 | 13,146 | 1,388 | 0 |
| Profit before tax | 7,625 | 9,479 | 11,283 | 12,690 | 5,954 | 566 | 7,592 | 5,280 | 9,750 | 18,929 | 18,621 | 35,178 | 35,630 |
| Tax % | 31% | 33% | 34% | 34% | 33% | 18% | 34% | 64% | 26% | 25% | 42% | 25% |  |
| Net Profit + | 5,235 | 6,311 | 7,450 | 8,358 | 3,967 | 464 | 5,047 | 1,879 | 7,252 | 14,207 | 10,919 | 26,492 | 26,846 |
| EPS in Rs | 22.37 | 26.86 | 31.42 | 35.04 | 16.51 | 1.78 | 19.59 | 6.57 | 23.49 | 45.99 | 35.16 | 85.49 | 86.63 |
| Dividend Payout % | 16% | 15% | 15% | 14% | 30% | 0% | 5% | 0% | 0% | 2% | 3% | 1% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transactions |  |  |  |  |  |  |  |  |  |  |
| Dividend paid | 276 | 300 | 355 | 345 |  | 46 |  |  | 29 | 25 |
| Interest paid | 811 | 645 | 667 | 546 | 555 | 553 | 326 | 174 | 165 | 400 |
| Interest received | 0.17 | 0.41 | 2.16 | 0.79 | 1.22 | 0.45 | 0.26 | 0.33 | 0.09 | 0.04 |
| Investment of related party in the Bank | 139 | 144 | 142 | 138 | 136 | 94 | 89 | 81 | 49 | 0.14 |
| Remuneration paid |  |  |  | 12 | 18 | 16 | 13 | 14 | 15 | 18 |
| Contribution to employee benefit fund | 16 | 16 | 16 | 16 | 17 | 15 | 14 | 14 | 14 | 16 |
| Advance repaid | 0.23 | 0.66 | 0.20 | 6.54 | 7.83 | 11 | 0.94 | 3.10 | 7.65 | 0.42 |
| Receiving of services | 78 | 79 | 101 | 110 | 129 | 207 | 264 | 402 | 114 | 97 |
| Rendering of services | 2.18 | 2.79 | 2.48 | 33 | 28 | 30 | 52 | 47 | 54 | 91 |
| Sale/ Purchase of foreign exchange currency to/from related party |  |  |  |  |  |  | 0.51 |  | 2.79 | 0.22 |
| Other reimbursements to related party | 0.37 | 0.40 | 0.41 |  | 0.66 | 0.19 | 0.25 | 0.25 | 0.08 | 1.14 |
| Deposits with the Bank | 13,960 | 12,123 | 9,018 | 10,176 | 17,107 | 16,680 | 11,730 | 15,179 | 9,803 | 16 |
| Advances | 52 | 21 | 36 | 35 | 175 | 23 | 14 | 91 | 9.56 | 1.04 |
| Redemptionof Hybrid capital/Bonds of the Bank |  |  |  |  |  |  |  |  | 958 |  |
| Placement of deposits | 0.30 | 0.41 | 0.38 |  |  |  |  |  | 0.22 |  |
| Other reimbursements from related party |  |  |  |  | 0.10 |  | 0.06 |  | 43 |  |
| Placement of security deposits |  |  |  | 0.43 | 0.43 | 0.31 | 1.90 | 1.90 | 2.11 |  |
| Non-funded commitments | 3.13 | 3.19 | 3.21 |  | 3.35 | 3.33 |  | 3.32 | 3.25 |  |
| Investment of related party in Hybrid capital/ Bonds of the Bank |  |  | 4,300 |  | 2,790 | 2,760 | 2,760 |  | 500 |  |
| Other receivables (net) |  |  |  | 0.25 | 0.03 | 0.32 | 0.04 | 0.02 | 16 |  |
| Other payables (net) |  |  |  |  |  |  |  |  | 1.32 |  |
| Investment of related party in Hybrid capital/Bonds of the Bank |  |  | 1,050 |  | 4,300 | 2,815 | 2,760 | 2,760 | 1,458 |  |
| Sale of investments | 659 | 325 | 762 | 870 | 857 | 1,318 | 2,228 | 585 |  |  |
| Repayment of deposit |  |  |  |  |  |  |  | 0.01 |  |  |
| Advance granted (net) | 0.04 | 1.05 | 0.67 | 7.99 |  |  | 0.90 | 7.25 |  |  |
| Sale/Purchase of foreign exchange currency to/from related party |  |  |  |  |  |  |  | 1.11 |  |  |
| Investment in non-equity instrument of related party |  |  | 110 |  | 341 | 290 |  | 0.02 |  |  |
| Investment in non |  |  |  |  |  |  | 0.02 |  |  |  |
| Non-funded commitment |  |  |  |  |  |  | 3.32 |  |  |  |
| Redemption of Hybrid capital/Bonds of the Bank |  |  | 70 |  | 1,510 | 55 |  |  |  |  |
| Sale of foreign exchange currency to related party |  |  |  |  | 1.36 | 1.51 |  |  |  |  |
| Investment in non-equity instruments of related party |  |  | 56 |  | 290 | 0.02 |  |  |  |  |
| Purchase of investments |  |  |  | 189 | 205 |  |  |  |  |  |
| Repayment of security deposits by related party |  |  |  |  | 0.12 |  |  |  |  |  |
| Payable under management contracts | 0.90 | 1.64 | 1.37 | 3.70 | 3.70 |  |  |  |  |  |
| Investment in nonequity instrument of |  |  |  | 393 |  |  |  |  |  |  |
| Nonfunded commitments (issued) |  |  |  | 0.20 |  |  |  |  |  |  |
| Sale of foreign exchange currency to |  |  |  | 1.29 |  |  |  |  |  |  |
| Other reimbursements from |  |  |  | 6.09 |  |  |  |  |  |  |
| Other reimbursements to |  |  |  | 0.75 |  |  |  |  |  |  |
| Investment in nonequity instruments of related party |  |  |  | 206 |  |  |  |  |  |  |
| Nonfunded commitments |  |  |  | 3.39 |  |  |  |  |  |  |
| Investment of related party in Hybrid capital/ Bonds of the |  |  |  | 4,300 |  |  |  |  |  |  |
| Investment in nonequity instrument of the Bank |  |  |  | 393 |  |  |  |  |  |  |
| Investment of related party in Hybrid capital/Bonds |  |  |  | 4,300 |  |  |  |  |  |  |
| Management contracts | 12 | 13 | 11 |  |  |  |  |  |  |  |
| Non-funded commitments (issued) |  |  | 0.05 |  |  |  |  |  |  |  |
| Investment in non-equity instrument of the Bank |  |  | 110 |  |  |  |  |  |  |  |
| Investment of related party in Hybrid Capital/Bonds of the Bank |  |  | 4,355 |  |  |  |  |  |  |  |
| Redemption of Subordinated Debt |  | 50 |  |  |  |  |  |  |  |  |
| Non-funded commitments (net) | 0.08 | 0.05 |  |  |  |  |  |  |  |  |
| Investment of related party in Subordinated Debt/Hybrid Capital/Bonds of the Bank | 3,370 | 3,370 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 27,202 | 30,736 | 35,727 | 41,409 | 45,175 | 46,614 | 56,044 | 63,716 | 64,397 | 68,846 | 87,448 | 112,759 | 117,672 |
| Interest | 17,513 | 18,703 | 21,341 | 24,344 | 26,789 | 27,604 | 33,883 | 37,996 | 34,627 | 34,923 | 43,389 | 61,391 | 64,680 |
| Expenses + | 8,538 | 9,944 | 11,521 | 13,869 | 24,327 | 29,717 | 28,020 | 35,976 | 32,621 | 31,216 | 30,641 | 40,032 | 43,581 |
| Financing Profit | 1,151 | 2,089 | 2,865 | 3,196 | -5,941 | -10,706 | -5,860 | -10,256 | -2,851 | 2,707 | 13,418 | 11,336 | 9,411 |
| Financing Margin % | 4% | 7% | 8% | 8% | -13% | -23% | -10% | -16% | -4% | 4% | 15% | 10% | 8% |
| Other Income + | 6,833 | 7,766 | 8,838 | 9,955 | 12,422 | 11,863 | 14,189 | 16,342 | 13,577 | 17,268 | 18,349 | 25,230 | 26,219 |
| Depreciation | 359 | 375 | 420 | 461 | 527 | 591 | 737 | 806 | 976 | 1,046 | 13,146 | 1,388 | 0 |
| Profit before tax | 7,625 | 9,479 | 11,283 | 12,690 | 5,954 | 566 | 7,592 | 5,280 | 9,750 | 18,929 | 18,621 | 35,178 | 35,630 |
| Tax % | 31% | 33% | 34% | 34% | 33% | 18% | 34% | 64% | 26% | 25% | 42% | 25% |  |
| Net Profit + | 5,235 | 6,311 | 7,450 | 8,358 | 3,967 | 464 | 5,047 | 1,879 | 7,252 | 14,207 | 10,919 | 26,492 | 26,846 |
| EPS in Rs | 22.37 | 26.86 | 31.42 | 35.04 | 16.51 | 1.78 | 19.59 | 6.57 | 23.49 | 45.99 | 35.16 | 85.49 | 86.63 |
| Dividend Payout % | 16% | 15% | 15% | 14% | 30% | 0% | 5% | 0% | 0% | 2% | 3% | 1% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |

