About
[
edit
]
Asian Paints is the
largest
home decor company in India. The 80+yyr old company has major brands like Asian Paints, Berger, Apco, etc under its umbrella. The co. is into wall paints, wall coverings, waterproofing, texture painting, wall stickers, mechanized tools, adhesives, modular kitchens, sanitaryware, lightings, soft furnishings, and uPVC windows.
Key Points
[
edit
]
Brand
[1]
The Asian Paints group has some of the leading brands under its umbrella like Asian Paints, Sleek, Berger, Weather Seal, Apco, Taubman, Kadisco, Scib etc. In FY23, 25 patents were filed and 10 were granted. 22 new products were launched in FY23.
[2]
The company has total 49 patents in its name till FY23.
[3]
Revenue Breakup FY23
[4]
Decorative Business - 84%
Home Decor Business - 4%
Industrial Coatings - 3%
International Operations - 9%
Geographical Revenue FY23
[5]
Asia : 44%
Middle East : 29%
Africa : 22%
South pacific: 4%
Leadership
[1]
<h1>1 paint company in India</h1>
<h1>2 paint company in Asia</h1>
<h1>7 paint company in the world.</h1>
50+ Years of Market Leadership in India.
Leading wallpaper manufacturer under the brand NILAYA.
3x of the nearest Competitor in India.
Business Segments
[4]
Decorative Business
Asian Paints is India's leading paint and décor company, with the largest of its kind painting
service in the world, available in 600+ towns. This includes Interior wall finishes, Exterior wall finishes, Waterproofing, Wood finishes,  Enamels, Adhesives, Tools, Undercoats
Home Decor Business
Under this segment, the company tries to provide a complete one-stop home décor solution to customers. This includes Modular Kitchens, Sanitaryware, lighting, uPVC windows, Wall coverings, Furniture, soft Furnishing
Industrial Business
In this segment, the company provides high-quality custom formulated products for the automotive and industrial coatings business in India. This includes Automotive, Marine, and Packaging Coatings, Industrial Protective
coatings, Powder coatings, Floor coatings
and Road markings.
Sales & Distribution
The company has 150,000+ retail touchpoints in India. It has 42 Beautiful Home stores. It serves 60+ countries.
[1]
The company has 240,000+ Business influencers
and 20,000+ Supplier base.
[2]
Manufacturing Facilities **
The company has total
11 manufacturing facilities in India and 17 outside India
.
[5]
The company's Ankleshwar plant reached BBS
Generative Stage (First in the world in coatings sector)
[6]
The company also has
27 outsourced processing centres**.
[2]
Capex
[7]
The company has planned investments of ₹ 8,750 Crores over the next 3 years on various capacity enhancements as well as a few critical backward integration projects.
1. The company plans to set up a manufacturing facility for VAE (Vinyl Acetate Ethylene Emulsion) and VAM (Vinyl Acetate Monomer) in India for a proposed investment of approx ₹ 2,100 Crores over a period of 3 years. The installed capacity of the manufacturing facility would be 1 Lakhs TPA for VAM and 1.5 Lakhs TPA for VAE. VAE is the Next-Gen environment-friendly emulsion, based on a unique VAM technology, which will provide a robust competitive edge to Asian Paints in the coatings business.
2. The company has entered into a JV to establish a 2.65 Lakhs MTPA manufacturing facility of white cement in Fujairah, UAE. In addition, clinker grinding units would be set up in India as well. The overall investment would be approximately ₹ 550 Crores, to be invested over the next 2 years.
3. Brownfield expansions at the existing decorative paint plants at Kasna, Khandala, Ankleshwar, and Mysuru, along with other regular capex will entail an outflow of ₹ 3,400
Crs supporting the growth plan over the next 3 years which will add 5.40 Lakhs KL per annum to the existing capacity.
4. The company has plans to set up a new water-based paint manufacturing facility with a capacity of 4 Lakhs KLPA at an approximate investment of ₹ 2,000 Crores. This facility is expected to commission 3 years after the acquisition of the land.
5. The company has signed a definitive agreement to acquire a majority stake in a specialty chemical and next-generation nanotechnology player, which will enhance the company's technological capabilities across all the products.
Associates / Subsidiaries
1. PPG Asian Paints Private Limited :
50% stake held
[8]
2. Obgenix Software Private Limited : 49% stake held.
3. The company has 24 subsidiaries in total.
[9]
Focus
The company is in the process of reinventing itself by strategically shifting its focus from ‘share of surface’ to ‘share of space’. This strategic shift is part of its plan to transform into a premier décor consultant and service provider.
[10]
Last edited 1 year ago
Request an update
© Protected by Copyright
