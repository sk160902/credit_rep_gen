About
[
edit
]
Cipla is engaged in the Business of Pharmaceuticals.(Source : 202003 Annual Report Page No:157)
Key Points
[
edit
]
Market Leadership
[1]
#
3rd largest in the India domestic Rx market
#
Leadership in Gx
#
1st rank in Respiratory
#
Top 5 in Urology and Anti-infectives.
#
Over 5 Lac+ no of downloads - Digital Breathe free
#
7,500+ field force detailing to HCPs across the country – 85% of physicians prescribe at least one Cipla product.
#
3rd largest player in private Rx market in SAGA
#
Fastest growing generic player in North America.
Diversified Product portfolio
Co. has a diversified product portfolio of 1,500+ products in 50+ dosage forms and 65 therapeutic categories.
[2]
In FY22, it launched 93 products across the globe.
[3]
Consumer Brands
[4]
India - Nicotex, Cofsils, Cipladine, ORS, Omnigel
South Africa - Cipla Actin, Broncol, Flomist, Asthavent, coryx.
Therapy – Market share – Market Rank
Overall - 5.2% - 3
Chronic - 7.9% - 2
Acute - 3.7% - 7
Respiratory - 22.2% - 1
Urology - 14.2% - 1
Anti-infective - 6.9% - 4
Cardiac - 5.3% - 5
Gastro-Intestinal - 2.9% - 9
Anti-diabetics - 0.8% - 27
[5]
Therapy – FY22 Revenue Contribution
Respiratory – 37%
Anti Infectives – 16%
Cardiac – 12%
Antiviral – 5%
Gastrointestinal – 6%
Urology – 5%
Derma – 3%
CNS – 3%
Pain – 3%
Opthimal - 3%
Others – 7%
[5]
API Business
The Co. has produced 200+ generics and complex APIs that are supplied to 62 countries worldwide. It continues to be a preferred partner to many large generic pharmaceutical co.s. The API business has also made efforts to de-risking the supply chain for Cipla’s focus APIs, by shifting to indigenous suppliers for key starting materials (KSM) and intermediates. It has a robust pipeline of over 75+ APIs across regulated markets in various stages of development.
[6]
Geographical Split FY23
[1]
India - 43%
North America - 26%
South Africa, Sub-Saharan Africa, and Cipla Global Access (SAGA) - 14%
EMEU - 13%
Others - 4%
Manufacturing Facilities
The product pipeline of the Co. is driven by 47 state-of-the-art manufacturing facilities across six countries.
[7]
Strategic Partnerships
[8]
On March 24th, the company established a partnership with Sanofi India Ltd. to distribute and promote Sanofi India’s Central Nervous System (CNS) product range in India. Under this agreement, Cipla will manage the distribution of six CNS brands from Sanofi India, which includes Frisium®, a prominent brand in the anti-epileptic medication segment.
Acquisitions
In FY22, Cipla entered into definitive agreements for the acquisition of a 33% partnership interest in Clean Max Auriga Power LLP and a 32.49% stake in AMP Energy Green Eleven Private Limited for setting up renewable power generation plants in Karnataka and Maharashtra, respectively.
[9]
Joint Venture
The Co. entered into a joint venture agreement with ‘Kemwell Biopharma Private Limited for undertaking the business of developing, manufacturing, and other allied activities relating to biologic products.
[9]
Subsidiaries
Two wholly-owned step-down subsidiaries were voluntarily deregistered/dissolved as these were operationally inactive and not required, namely - Cipla Biotec South Africa (Pty) Limited with effect from 3rd February 2022 and Inyanga Trading 386 (Pty) Limited with effect from 10th December 2021.
[10]
POC Model
[11]
The company plans to enter the POC model by Leveraging Cipla’s reach with doctors, clinics, and nursing homes. For this, they launched Cippoint on Jan,23, Achira (In-development) and Neodocs.
** R&D Capabilities**
[12]
The Co. has 5 R&D facilities that are located in New York, Maharashtra, and Karnataka and a total team of 1650 scientists. In FY23, the company spent Rs. 1343 crs. (6% of revenue) on R&D. last 5 yrs avg. spend is Rs. 1140 crs.
[13]
New Products
- the company has launched 78 new products in FY23. (vs 93 in FY22 and 81 in FY21). Out of these 78, 27 were launched in Emerging Markets, 20 in Europe, and 12 in India.
303 patents are granted to Cipla till FY23
. The company launched 30 new products in 9MFY24.
[14]
**Consumer Business **
In FY22, the consumer business continued to drive the illness-to-wellness theme led by brand-building initiatives, deepening distribution and category innovations.
Consumers Reached -
Retailers - 500k
Grocers and others - 40K+
Modern Trade - 700+
E-commerce - 9
The Co’s anchor brands Nicotex and Cofsils continued to maintain a strong market position in their respective categories in FY22.
[15]
New Streams
[16]
The company is working on Cell & Gene therapy (Genomics), Oligonucleotides, mRNAs, and Stem cells.
Focus
The company is expecting a growth of ~20% till 2030.
[17]
and aims to be the 2nd Largest Pharma company in Rx Market in India. It aims to be the largest in SAGA and the 2nd largest in North America.
[18]
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright
