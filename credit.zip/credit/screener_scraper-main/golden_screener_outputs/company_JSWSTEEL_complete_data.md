# Complete Company Data

## Modal Content
About
[
edit
]
JSW Steel is primarily engaged in the business of manufacture and sale of Iron and Steel Products.
[1]
It is the flagship business of the diversified, US$ 23 billion JSW Group.The Group has interests in energy, infrastructure, cement, paints, sports, and venture capital.
[2]
Key Points
[
edit
]
Product Portfolio
The company's diversified portfolio comprises products under hot-rolled, cold-rolled, galvanneal, galvanised/galvalume, pre-painted, tinplate, electrical steel, TMT bar, wire rod, special steel bar, round and bloom categories.
[1]
Revenue Breakup- Client wise Q3FY24
[2]
Retail: 33%
Auto: 14%
Industrial: 16%
Construction & Infra: 37%
Geography Wise
[3]
Domestic - 93%
Exports - 7%
Share of Revenue from Value Added Steel Products
[2]
The revenue share from VASP was 35% in FY16 which has increased to 60% in Q3FY24.
The company aims to maintain this by >50% in future years.
Capacity Utilization
[4]
Average India capacity utilization: 94%
Distribution Network Q3FY24
[5]
The company is present in ~ 17,500 retail stores across more than 530 districts in India. It has a strong distribution channel of 2,475 points including 450 distributors and 2,025 Branded Stores, 706 JSW Shoppe spread across urban areas, and 1,319 JSW Shoppe Connect in semi-urban and rural areas. It has enrolled 82,000+ partners in JSW Privilege Club and 14 Experience Centres across India.
Manufacturing Capabilities
[6]
As of Q3FY24, the company has a total capacity of 28.2mt.
Vijaynagar Works - 23.5 MnTPA
BPSL - 3.5 MnTPA
JISPL - 1.2 MnTPA
Expansion
[6]
The company has plans to expand capacity to 37mt by FY25- 26 and eventually to 50mt vy FY30 through :
1) Brownfield expansion of ~5mt at each of Vijayanagar, Dolvi and BPSL
2) 4mt Green Steel in 2 phases
3) Greenfield growth in Odisha (13mt)
4) Greenfield EAF at Kadapa, Andhra Pradesh.
Approvals
[7]
12 products got approved/graded in Q3FY24. These include Solar Module, Magsure, Seamless Tubes etc.
JSW One
[8]
The company launched JSW One TMT private brand in Nov’23. It is one of India’s leading integrated B2B commerce platforms catering to the buying needs of MSMEs. JSW Steel has a shareholding of 69.01%; Mitsui and Co. have acquired an 8.2% stake in JSW One. As of Q3FY24, the company has ~43,000 registered users, ~155,000 visits on the platform and the repeat customer rate is ~68%. annual GMV is 6,800 crs+.
NCDs
[9]
On Jan,24, the company decided to issue Secured/Un-secured, Redeemable, Non-Convertible Debentures for ~Rs. 2,000 crores, by way of private placement and/or by way of public issuance, in one or more tranches.
Focus
[6]
The company aims to take JSW Steel India's capacity to 37mt and up to 50mt by FY30.
Last edited 5 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 38,210 | 51,220 | 52,972 | 41,546 | 55,604 | 71,933 | 84,757 | 73,326 | 79,839 | 146,371 | 165,960 | 175,006 | 175,736 |
| Expenses + | 31,698 | 42,051 | 43,608 | 35,124 | 43,296 | 57,017 | 65,827 | 61,513 | 59,661 | 107,257 | 147,490 | 146,849 | 149,186 |
| Operating Profit | 6,512 | 9,169 | 9,364 | 6,422 | 12,308 | 14,916 | 18,930 | 11,813 | 20,178 | 39,114 | 18,470 | 28,157 | 26,550 |
| OPM % | 17% | 18% | 18% | 15% | 22% | 21% | 22% | 16% | 25% | 27% | 11% | 16% | 15% |
| Other Income + | -307 | -1,630 | 103 | -1,966 | 18 | -177 | 196 | -289 | 473 | 1,600 | 1,561 | 1,500 | 1,426 |
| Interest | 1,967 | 3,048 | 3,493 | 3,601 | 3,768 | 3,701 | 3,917 | 4,265 | 3,957 | 4,968 | 6,902 | 8,105 | 8,215 |
| Depreciation | 2,237 | 3,183 | 3,434 | 3,323 | 3,430 | 3,387 | 4,041 | 4,246 | 4,679 | 6,001 | 7,474 | 8,172 | 8,481 |
| Profit before tax | 1,999 | 1,308 | 2,539 | -2,468 | 5,128 | 7,651 | 11,168 | 3,013 | 12,015 | 29,745 | 5,655 | 13,380 | 11,280 |
| Tax % | 42% | 70% | 32% | -80% | 33% | 20% | 33% | -30% | 34% | 30% | 27% | 33% |  |
| Net Profit + | 929 | 402 | 1,722 | -481 | 3,467 | 6,113 | 7,524 | 3,919 | 7,873 | 20,938 | 4,139 | 8,973 | 7,412 |
| EPS in Rs | 4.32 | 1.87 | 7.43 | -1.39 | 14.57 | 25.71 | 31.60 | 16.67 | 32.73 | 85.49 | 17.14 | 36.03 | 29.94 |
| Dividend Payout % | 30% | 74% | 19% | -67% | 19% | 16% | 16% | 15% | 25% | 25% | 25% | 25% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 36% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| JSW International Tradecorp PTE Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 12,146 | 35,907 |  |  |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 18,418 | 15,478 |  |  |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 17,972 |  |  |  |  |  |  |
| Purchase of goods / power and fuel / services |  | 3,480 | 6,659 |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 2,995 | 158 |
| Others Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 6,093 | 6,986 |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 2,812 | 6,603 |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 458 |  | 3,023 | 3,371 |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 2,146 | 2,250 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 3,141 |  |  |
| Purchase of goods / power and fuel / services |  | 1,340 | 1,560 |  |  |  |  |  |  |  |
| Trade payables |  | 82 | 124 |  | 311 | 647 | 555 | 923 |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 1,932 |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 869 | 662 |  |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 1,213 |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 340 | 454 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 540 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 530 |  |  |  |  |  |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 176 | 239 | 3 | 5 |
| Dividend paid |  |  |  | 53 | 76 | 99 | 48 | 121 |  |  |
| Purchase of assets |  | 5.11 | 3.38 |  | 50 | 136 | 4 | 2 | 52 | 114 |
| Investments held by the group |  | 169 | 167 |  |  |  |  |  |  |  |
| Finance lease obligation |  |  | 177 |  |  |  |  |  |  |  |
| Trade receivables |  | 19 | 18 |  | 48 | 6 | 43 | 37 |  |  |
| Recovery of expenses incurred by us on their behalf |  | 7.44 | 5.45 |  | 23 | 33 | 41 |  |  |  |
| TRADE PAYABLES | 100 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 95 |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 44 | 49 |  |  |
| Capital / revenue advance |  | 22 | 71 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 34 | 49 |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 10 | 67 |
| Lease interest cost |  |  |  |  |  | 17 | 17 | 17 | 3 | 8 |
| Loan and advances given |  | 0.01 | 0.13 |  | 20 | 19 | 16 | 4 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 45 | 11 |
| Other income/ Interest income/ Dividend income |  |  |  |  | 13 | 25 | 18 |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 46 |  |  |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  | 8 | 26 | 11 |  |  |  |
| TRADE RECEIVABLES | 45 |  |  |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 42 |  |  |
| Capital / revenue advances aiven |  |  |  |  | 1 | 39 |  |  |  |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 35 |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 12 | 15 |  |  |  |  |  |  |  |
| PURCHASE OF ASSETS | 25 |  |  |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 12 | 13 |  |  |
| Lease & other deposit received |  |  |  |  | 12 | 12 |  |  |  |  |
| Security deposits given |  |  |  |  |  |  |  |  | 21 | 1 |
| Capital / Revenue advance |  |  |  |  | 7 | 14 |  |  |  |  |
| Loan given received back |  |  |  |  |  |  | 3 | 10 | 2 |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 12 |  |  |  |  |  |  |
| Advance received from customers |  | 0.10 |  |  |  |  | 7 | 4 |  |  |
| Interest receivable |  |  |  |  |  | 1 | 8 | 1 |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 7.86 |  |  |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 7 |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 2 | 4 |
| Loan given |  |  |  |  | 5 | 1 |  |  |  |  |
| Purchase of Assets |  |  |  | 6 |  |  |  |  |  |  |
| Advance Given/(Received Back) |  |  |  | 4 |  |  |  |  |  |  |
| Finance lease obligation repayment |  |  |  | 4 |  |  |  |  |  |  |
| Lease and other deposit received |  | 1.24 | 1.36 |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 2.07 |  |  |  |  |  |  |  |  |  |
| Lease and other deposit received back |  |  |  |  | 1 | 1 |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 2 |  |  |  |  |  |  |  |  |  |
| Interest expenses |  | 1.18 |  |  |  |  |  |  |  |  |
| Investments / share application money given during the year |  | 0.43 | 0.73 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 1 |  |  |  |  |  |
| Share application money given |  | 0.37 | 0.42 |  |  |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  | 0.29 | 0.44 |  |  |  |  |  |  |  |
| Advance given/(received back) |  |  | 0.27 |  |  |  |  |  |  |  |
| REIMBURSEMENT OF EXPENSES INCURRED ON BEHALF OF THE GROUP | 0.27 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS/SHARE APPLICATION MONEY GIVEN DURING THE YEAR | 0.27 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.26 |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.20 |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 0.04 |  |  |  |  |  |  |  |  |  |
| JSW Energy Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 2,944 | 2,489 |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 3,189 | 1,695 |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 1,811 | 2,418 |  |  |
| Purchase of goods / power and fuel / services |  | 1,203 | 2,182 |  |  |  |  |  |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 2,269 |  |  |  |  |  |  |
| Trade payables |  | 158 | 355 |  | 245 | 377 | 8 | 384 |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 1,491 |  |  |  |  |  |  |  |  |  |
| Investments held by the group |  | 707 | 637 |  |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 525 | 404 |  |  |  |  |
| Sales of goods / power and fuel |  | 153 | 380 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 464 |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 412 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 347 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 252 |  |  |  |  |  |  |  |  |  |
| Trade receivables |  |  |  |  |  |  | 148 |  |  |  |
| Capital / revenue advances given |  |  |  |  |  |  | 81 |  |  |  |
| TRADE PAYABLES | 80 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 27 | 24 |
| Other income/ interest income/ dividend income |  | 26 | 24 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 2.22 | 1.83 |  | 19 | 9 |  |  |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 28 |  |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 21 | 4 |
| Lease & other deposits received |  |  |  |  |  |  | 11 | 11 |  |  |
| Lease & other deposit received |  |  |  |  | 11 | 11 |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 21 |  |  |
| Lease and other deposit received |  | 10 | 10 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 17 |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  | 3 |  |  |  | 4 | 3 | 3 |
| Other income/ Interest income/ Dividend income |  |  |  |  | 2 | 11 |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  | 2.16 | 2.07 |  | 3 | 3 | 1 |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 10 |  |  |  |  |  |  |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 6 |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 3 |  |  |  |  |  |  |
| INTEREST EXPENSES | 2.98 |  |  |  |  |  |  |  |  |  |
| REIMBURSEMENT OF EXPENSES INCURRED ON BEHALF OF THE GROUP | 2.66 |  |  |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 1.18 |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  | 1 |  |  |  |  |  |
| Lease and other deposit given |  | 0.29 | 0.29 |  |  |  |  |  |  |  |
| JSW Projects Limited |  |  |  |  |  |  |  |  |  |  |
| Finance lease obligation |  | 1,842 | 1,666 |  |  |  |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  | 1,280 | 1,052 |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 797 | 512 | 318 |  |
| Loan and advances given |  |  |  |  | 300 | 415 | 315 | 225 |  |  |
| Loan given |  |  |  | 300 | 300 | 130 | 200 |  |  |  |
| Purchase of assets |  |  |  |  |  |  |  |  |  | 858 |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  | 204 | 228 | 255 |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 614 |  |  |  |  |  |  |  |  |  |
| Finance lease interest cost |  | 195 | 197 | 177 |  |  |  |  |  |  |
| Finance lease obligation repayment |  | 169 | 176 | 183 |  |  |  |  |  |  |
| Loan given received back |  |  |  |  |  | 15 | 300 | 90 | 105 |  |
| Lease interest cost |  |  |  |  | 156 | 132 | 105 | 75 | 41 |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 500 |  |  |  |  |  |  |  |  |  |
| Loan given Received back |  |  |  | 300 |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 50 | 49 |  |  |  |  |
| Capital / revenue advance |  | 49 | 49 |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 49 | 49 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 2 | 40 | 36 |  |  |  |
| TRADE PAYABLES | 75 |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 36 |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 20 | 12 |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 26 |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 15 |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 5.43 | 6.38 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Jindal Saw Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 1,128 |  | 3,249 | 3,194 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 1,198 | 1,165 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 1,534 |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 792 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 658 |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 485 | 71 |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  |  |  | 55 | 94 | 90 | 139 |
| Trade receivables |  |  | 0.01 |  | 34 | 34 |  | 74 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  |  | 55 |
| Lease & other deposit received |  |  |  |  | 5 | 5 |  |  |  |  |
| Lease and other deposit received |  | 4.13 | 4.55 |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 5 |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 5 |  |  |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Advance received from customers |  | 0.08 |  |  |  | 1 | 1 |  |  |  |
| Notes payable |  |  | 0.40 |  |  |  |  |  |  |  |
| Bhushan power & Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Guarantees and collaterals provided by |  |  |  |  |  |  | 10,800 |  |  |  |
| JSW International Trade Corp PTE Limited |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 370 | 546 |  | 1,398 | 1,499 |  | 5,434 |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 149 |  |  |
| TRADE PAYABLES | 27 |  |  |  |  |  |  |  |  |  |
| Epsilon Carbon Private Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 345 |  | 1,035 | 864 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 543 | 530 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 846 |  |  |
| Trade receivables |  | 55 | 64 |  | 124 | 109 | 106 | 124 |  |  |
| Sales of goods / power and fuel |  | 276 | 246 |  |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 345 |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 319 |  |  |  |  |  |  |
| TRADE RECEIVABLES | 44 |  |  |  |  |  |  |  |  |  |
| JSW International Tradecorp Pte Limited |  |  |  |  |  |  |  |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 3,629 |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  |  |  |  | 1,192 |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  |  | 119 | 68 |  |  |  |
| Jindal Industries Private Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 214 |  | 831 | 1,127 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 646 | 374 |  |  |  |  |
| Sales of goods / power and fuel |  | 609 | 287 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 458 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 356 |  |  |  |  |  |  |  |  |  |
| Trade receivables |  | 23 |  |  | 24 | 8 |  |  |  |  |
| TRADE RECEIVABLES | 31 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.18 |  |  |  |  |  |  |  |
| JSW Techno Projects Management Limited |  |  |  |  |  |  |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 997 | 946 | 57 | 78 |
| Lease liabilities / Finance lease obligation |  |  |  |  | 567 | 550 |  |  |  |  |
| Lease interest cost |  |  |  |  | 54 | 84 | 95 | 118 | 112 | 119 |
| Dividend paid |  |  |  | 52 | 74 | 101 | 51 | 172 |  |  |
| Loan given |  |  |  | 447 |  |  |  |  |  |  |
| Loan given received back |  |  |  |  |  | 96 |  |  |  |  |
| Finance lease interest cost |  |  | 13 | 25 |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 11 | 8 |  |  |  |  |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  |  |  | 17 |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 13 |  |  |  |  |  |  |
| Interest expenses |  |  |  |  |  | 2 |  | 4 | 4 |  |
| Interest receivable |  |  |  |  |  | 9 |  |  |  |  |
| Loan refunded |  |  |  |  |  | 6 |  |  |  |  |
| Finance lease obligation repayment |  |  | 2.41 |  |  |  |  |  |  |  |
| ADVANCE GIVEN | 0.03 |  |  |  |  |  |  |  |  |  |
| JSW Ispat Special Products Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 711 |  | 1,166 | 443 |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 968 |  |  |
| Loan and advances given |  |  |  |  |  |  | 215 | 215 |  |  |
| Trade receivables |  |  |  |  |  |  | 13 | 192 |  |  |
| Interest receivable |  |  |  |  |  |  | 45 | 68 |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 48 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 27 | 9 |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 26 |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  | 1 |  |  |
| JSW Severfield Structures Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  | 416 | 762 | 228 | 141 | 530 | 499 |
| Purchase of Assets |  |  |  | 136 |  |  |  |  |  |  |
| Investments / Share Application Money given during the year |  |  |  | 45 |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 42 |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  | 38 |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 13 | 13 |  |  |
| Lease & other deposit received |  |  |  |  | 13 | 13 |  |  |  |  |
| JSW Paints Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 780 | 908 |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 200 | 250 |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 300 |  |  |
| Capital / revenue advances received back |  |  |  |  |  |  | 10 | 70 |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 70 |  |  |  |
| Capital / revenue advances given |  |  |  |  |  |  | 45 |  |  |  |
| Lease deposit received |  |  | 4.19 |  |  |  |  |  |  |  |
| Lease and other deposit received |  |  | 4.19 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  | 3.35 |  |  |  |  |  |  |  |
| JSW Cement Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  | 4.14 | 25 |  | 148 | 243 | 157 | 258 | 275 | 139 |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 110 | 121 |
| Recovery of expenses incurred by us on their behalf |  | 7.03 | 8.89 |  | 43 | 45 | 71 |  |  |  |
| Capital / revenue advance |  | 72 | 73 |  |  |  |  |  |  |  |
| SALE OF FIXED ASSETS | 118 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 96 |  |  |
| Security and other deposits taken |  |  |  |  |  |  |  | 92 |  |  |
| Security deposits given |  |  |  |  |  |  |  | 90 |  |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 70 |  |  |  |  |  |  |  |  |  |
| Purchase of Assets |  |  |  | 51 |  |  |  |  |  |  |
| Security deposits taken |  |  |  |  |  |  |  |  | 33 | 8 |
| TRADE RECEIVABLES | 27 |  |  |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 11 | 11 |  |  |
| Lease & other deposit received |  |  |  |  | 11 | 11 |  |  |  |  |
| Trade receivables |  | 6.64 | 13 |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 17 |  |  |  |  |  |  |
| Lease deposit received |  |  |  |  | 11 |  |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  | 5 |  |  |  |  |  |
| Lease and other deposit received back |  |  |  |  |  |  | 1 |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.53 |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  | 0.25 |  |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.10 |  |  |  |  |  |  |  |  |  |
| JSW Ml Steel Service Centre Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  |  |  | 854 | 1,039 |
| Sale of assets |  |  |  |  |  |  |  |  |  | 36 |
| JSW Shipping and Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Lease and other deposits given |  |  |  |  | 59 | 175 | 247 | 300 |  |  |
| Lease liabilities |  |  |  |  |  |  | 137 | 298 | 32 | 35 |
| Security deposit given |  |  |  |  | 59 | 116 |  |  |  |  |
| Security deposits given |  |  |  |  |  |  | 71 | 53 |  |  |
| Loan and advances given |  |  |  |  | 105 |  |  |  |  |  |
| Lease interest cost |  |  |  |  |  |  | 2 | 27 | 27 | 24 |
| Interest receivable |  |  |  |  |  |  | 28 | 27 |  |  |
| Bhushan Power and Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 1,296 |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 11 |  |  |  |
| JSW Vallabh Tin Plate Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 431 | 312 |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 332 |  |  |  |  |  |  |
| Trade receivables |  | 25 | 68 |  | 83 |  |  |  |  |  |
| India Flysafe Aviation Limited |  |  |  |  |  |  |  |  |  |  |
| Lease and other deposits given |  |  |  |  | 203 | 193 | 183 | 171 |  |  |
| Advance Given/(Received Back) |  |  |  | 214 |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 21 | 20 | 20 |  |  |  |
| Lease and other deposit received back |  |  |  |  | 10 | 10 | 10 | 11 | 7 | 6 |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 12 | 10 |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 14 |  |  |  |  |  |  |
| JSW Foundation |  |  |  |  |  |  |  |  |  |  |
| Donation/CSR expenses |  |  |  |  |  |  |  |  | 321 | 326 |
| Donation/ CSR expenses |  | 3.60 | 3.02 |  | 26 | 75 | 83 | 264 |  |  |
| Donation/ CSR Expenses |  |  |  | 11 |  |  |  |  |  |  |
| DONATION/ CSR EXPENSES | 1.83 |  |  |  |  |  |  |  |  |  |
| JSW Dharamatar Port Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 200 | 200 |  |  |
| Capital/revenue advances received back |  |  |  |  |  |  |  |  | 200 |  |
| Capital / Revenue advance |  |  |  |  |  | 200 |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  |  | 138 |  |  |  |  |
| Lease interest cost |  |  |  |  |  |  |  |  | 12 | 20 |
| Lease liabilities |  |  |  |  |  |  |  |  | 9 | 20 |
| Jindal Steel & Power Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  | 110 | 47 |  | 228 | 238 |  | 159 |  |  |
| PURCHASE OF ASSETS | 107 |  |  |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 33 |  |  |  |  |  |
| Purchase of Assets |  |  |  | 25 |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.91 |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  | 0.48 |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.10 |  |  |  |  |  |  |  |
| Sapphire Airlines Private Limited |  |  |  |  |  |  |  |  |  |  |
| Security deposits given |  |  |  |  |  |  |  | 147 | 191 | 193 |
| Lease and other deposits given |  |  |  |  |  |  |  | 147 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 22 | 44 |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 3 |  |  |
| Interest receivable |  |  |  |  |  |  |  | 2 |  |  |
| Jindal Steel S Power Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  |  |  | 87 |  | 374 | 217 |
| St. James Investment Limited |  |  |  |  |  |  |  |  |  |  |
| Notes payable |  | 285 | 22 |  |  |  |  |  |  |  |
| NOTES PAYABLE | 269 |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 79 |  |  |  |  |  |  |  |  |
| Interest expenses |  | 12 |  |  |  |  |  |  |  |  |
| INTEREST EXPENSES | 8.79 |  |  |  |  |  |  |  |  |  |
| JSW Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Loans/advances/deposits taken |  | 122 | 87 |  |  |  |  |  |  |  |
| LOANS AND ADVANCES TAKEN | 186 |  |  |  |  |  |  |  |  |  |
| Lease and other advances refunded |  | 37 | 47 |  | 53 |  |  |  |  |  |
| Lease and Other Advances refunded |  |  |  | 48 |  |  |  |  |  |  |
| ADVANCE TAKEN REFUNDED | 37 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 1.73 | 4.38 |  | 6 | 7 |  |  |  |  |
| Liabilities written back |  |  |  |  | 11 |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 6 |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.10 |  |  |  |  |  |  |  |  |  |
| Brahmani River Pellets Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 646 |  |  |  |
| Monnet Ispat & Energy Limited JV |  |  |  |  |  |  |  |  |  |  |
| Loan and advances given |  |  |  |  | 125 | 215 |  |  |  |  |
| Loan given |  |  |  |  | 125 | 90 |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 1 | 36 |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 7 | 16 |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  | 15 | 1 |  |  |  |  |
| JSW MI Steel Service Centre Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 433 |  |  |  |
| Trade receivables |  |  |  |  | 42 | 44 |  |  |  |  |
| Investments / share application money given during the year |  | 12 | 24 |  |  |  |  |  |  |  |
| Share application money given |  |  | 24 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  | 1 |  |  |  |  |  |
| JSW Vallabh Tinplate Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 250 | 273 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 2.99 | 3.32 |  |  |  |  |  |  |  |
| JSW Severeld Structures Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments held by the group |  | 115 | 115 |  |  |  |  |  |  |  |
| Purchase of assets |  | 138 | 45 |  |  |  |  |  |  |  |
| Lease and other deposit received |  | 11 | 12 |  |  |  |  |  |  |  |
| Trade receivables |  | 0.42 | 21 |  |  |  |  |  |  |  |
| Jindal Steel & power Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances aiven |  |  |  |  |  | 200 |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  |  | 200 |  |  |  |  |
| Creixent Special Steels Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  | 370 |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | 2 | 1 | 4 |  |
| JSW Holdings Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 40 | 57 | 73 | 36 | 118 |  |  |
| Piombino Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  |  |  | 137 |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 123 |  |  |
| Loan given |  |  |  |  |  |  |  | 4 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 3 |  |  |  |
| JSW Realty & Infrastructure Private Limited |  |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 199 |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 40 |  |  |  |  |  |  |  |  |  |
| JSW MI Steel Service Center Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Trade receivables |  |  |  |  |  |  | 50 | 71 |  |  |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 83 |  |  |
| Sahyog Holdings Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 25 | 35 | 46 | 22 | 73 |  |  |
| JSW Dharmatar Port Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances aiven |  |  |  |  |  | 200 |  |  |  |  |
| JSW One Platform Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 156 |  |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 8 |  |  |
| JSW Renewable Energy (Vijayanagar) Limited |  |  |  |  |  |  |  |  |  |  |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 77 | 76 |
| Bhushan Power & Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Loan and advances given |  |  |  |  |  |  | 134 |  |  |  |
| Interest expenses |  |  |  |  |  |  |  | 4 |  |  |
| Rohne Coal Company Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advance |  | 42 | 14 |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 19 | 22 |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  |  | 28 |  |  |
| SHARE APPLICATION MONEY | 3.93 |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  |  | 1 |  |  |  |  |
| Share application money given |  | 0.03 | 0.02 |  |  |  |  |  |  |  |
| JSW Ispat Special Steels Limited JV |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  |  |  |  |  | 119 |  |  |
| South West Port Limited |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 24 | 75 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| JSW Severfield Stuructures Limited JV |  |  |  |  |  |  |  |  |  |  |
| PURCHASE OF ASSETS | 99 |  |  |  |  |  |  |  |  |  |
| Dolvi Minerals & Metals Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| TRADE PAYABLES | 41 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS/SHARE APPLICATION MONEY GIVEN DURING THE YEAR | 40 |  |  |  |  |  |  |  |  |  |
| JSW Jaigarh Port Limited |  |  |  |  |  |  |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  |  | 46 |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  | 7 | 3 |  |  |  |  |
| Lease and other deposit received |  | 3.50 | 3.50 |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 5 |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  |  | 4 |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 3.50 |  |  |  |  |  |  |  |  |  |
| JSW Global Business Solutions Limited |  |  |  |  |  |  |  |  |  |  |
| Advance given/(received back) |  | 10 | 29 |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 6 | 6 |  |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 7 |  |  |  |  |  |  |
| Loan and advances given |  |  | 5.11 |  |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 1 | 3 |
| Reimbursement of expenses incurred on our behalf by |  |  | 2.81 |  |  |  | 1 |  |  |  |
| Loan refunded |  |  |  |  |  |  |  | 3 |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.64 |  |  |  |  |  |  |  |  |  |
| St .James Investment limited |  |  |  |  |  |  |  |  |  |  |
| TRADE PAYABLES | 63 |  |  |  |  |  |  |  |  |  |
| JSW Shipping S Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 25 | 35 |
| JSW Power Trading Company Limited |  |  |  |  |  |  |  |  |  |  |
| Trade receivables |  | 49 |  |  |  |  |  |  |  |  |
| TRADE RECEIVABLES | 1.64 |  |  |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.61 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.37 |  |  |  |  |  |  |  |
| JSW Shipping & Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 27 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 20 |  |  |  |
| JSW Praxair Oxygen Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 38 |  |  |  |  |  |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 3.83 |  |  |  |  |  |  |  |  |  |
| JSW Industrial Gases Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 15 | 11 |  |  |  |  |  |  |  |
| Lease and other deposit received |  | 3.83 |  |  |  |  |  |  |  |  |
| JSW IP Holdings Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 18 | 10 |  |  |  |  |
| Mr. Sajjan Jindal Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 26 |  |  |  |  |  |  |  |  |  |
| Dolvi Coke Projects Limited Associate |  |  |  |  |  |  |  |  |  |  |
| TRADE RECEIVABLES | 22 |  |  |  |  |  |  |  |  |  |
| JSW Steel EPF Trust |  |  |  |  |  |  |  |  |  |  |
| Contribution to post employment benefit entities |  |  |  |  |  |  | 21 |  |  |  |
| Brahmani River Pellet Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  | 13 | 7 |  |  |
| Geo Steel LLC JV |  |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 14 |  |  |  |  |  |  |  |  |  |
| AcciaItalia S.p.A. JV |  |  |  |  |  |  |  |  |  |  |
| Investments / share application money given during the year |  |  | 13 |  |  |  |  |  |  |  |
| JSW Global Business Solutions Private Limited |  |  |  |  |  |  |  |  |  |  |
| Loan given received back |  |  |  |  | 11 | 2 |  |  |  |  |
| JSW MI Steel Service Centre JV |  |  |  |  |  |  |  |  |  |  |
| Share application money given |  | 12 |  |  |  |  |  |  |  |  |
| JSW Cements Limited |  |  |  |  |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  | 2 | 4 |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  |  |  | 5 |  |  |  |
| JSW Steel Group Gratuity Trust |  |  |  |  |  |  |  |  |  |  |
| Contribution to post employment benefit entities |  |  |  |  |  |  | 7 | 3 |  |  |
| JSW Severfield structures limited JV |  |  |  |  |  |  |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 6.50 |  |  |  |  |  |  |  |  |  |
| JSW Energy (Kutehr) Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  |  | 5 |  |  |
| Mr. Seshagiri Rao M V S Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 4.14 |  |  |  |  |  |  |  |  |  |
| JSW One Platforms Limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  |  | 4 |  |  |
| Gourangdih Coal Limited JV |  |  |  |  |  |  |  |  |  |  |
| Share application money given |  |  |  |  |  | 1 | 1 | 1 |  |  |
| Loan and advances given |  | 0.38 | 0.38 |  |  |  |  |  |  |  |
| JSoft Solutions Limited |  |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  | 3.50 |  |  |  |  |  |  |  |
| Dr. Vinod Nowal Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 3.04 |  |  |  |  |  |  |  |  |  |
| Jindal Rail Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  | 3 |  |  |  |
| Mr. Jayant Acharya Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 2.63 |  |  |  |  |  |  |  |  |  |
| JSW Structural Metal Decking Limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  | 1 | 1 |  |  |  |
| Monnet ipat & Energy limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  | 2 |  |  |  |  |
| Mr. Rajeev Pai Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 1.27 |  |  |  |  |  |  |  |  |  |
| JSW Praxair Company Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| INTEREST EXPENSES | 1.17 |  |  |  |  |  |  |  |  |  |
| JSW Cement, FZE |  |  |  |  |  |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  |  | 1 |  |  |  |  |
| Mr. Lancy Varghese Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 0.46 |  |  |  |  |  |  |  |  |  |
| Jindal Saw USA LLC |  |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.25 |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.17 |  |  |  |  |  |  |  |  |  |
| Rohne Coal Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / share application money refunded during the year |  | 0.37 |  |  |  |  |  |  |  |  |
| O.P. Jindal Foundation |  |  |  |  |  |  |  |  |  |  |
| DONATION/ CSR EXPENSES | 0.17 |  |  |  |  |  |  |  |  |  |
| Mr. Parth Jindal Relative |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 0.07 |  |  |  |  |  |  |  |  |  |
| JSL Architecture Limited |  |  |  |  |  |  |  |  |  |  |
| ADVANCE GIVEN | 0.02 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 38,210 | 51,220 | 52,972 | 41,546 | 55,604 | 71,933 | 84,757 | 73,326 | 79,839 | 146,371 | 165,960 | 175,006 | 175,736 |
| Expenses + | 31,698 | 42,051 | 43,608 | 35,124 | 43,296 | 57,017 | 65,827 | 61,513 | 59,661 | 107,257 | 147,490 | 146,849 | 149,186 |
| Operating Profit | 6,512 | 9,169 | 9,364 | 6,422 | 12,308 | 14,916 | 18,930 | 11,813 | 20,178 | 39,114 | 18,470 | 28,157 | 26,550 |
| OPM % | 17% | 18% | 18% | 15% | 22% | 21% | 22% | 16% | 25% | 27% | 11% | 16% | 15% |
| Other Income + | -307 | -1,630 | 103 | -1,966 | 18 | -177 | 196 | -289 | 473 | 1,600 | 1,561 | 1,500 | 1,426 |
| Interest | 1,967 | 3,048 | 3,493 | 3,601 | 3,768 | 3,701 | 3,917 | 4,265 | 3,957 | 4,968 | 6,902 | 8,105 | 8,215 |
| Depreciation | 2,237 | 3,183 | 3,434 | 3,323 | 3,430 | 3,387 | 4,041 | 4,246 | 4,679 | 6,001 | 7,474 | 8,172 | 8,481 |
| Profit before tax | 1,999 | 1,308 | 2,539 | -2,468 | 5,128 | 7,651 | 11,168 | 3,013 | 12,015 | 29,745 | 5,655 | 13,380 | 11,280 |
| Tax % | 42% | 70% | 32% | -80% | 33% | 20% | 33% | -30% | 34% | 30% | 27% | 33% |  |
| Net Profit + | 929 | 402 | 1,722 | -481 | 3,467 | 6,113 | 7,524 | 3,919 | 7,873 | 20,938 | 4,139 | 8,973 | 7,412 |
| EPS in Rs | 4.32 | 1.87 | 7.43 | -1.39 | 14.57 | 25.71 | 31.60 | 16.67 | 32.73 | 85.49 | 17.14 | 36.03 | 29.94 |
| Dividend Payout % | 30% | 74% | 19% | -67% | 19% | 16% | 16% | 15% | 25% | 25% | 25% | 25% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 36% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 5,844 | 2,594 | 7,876 | 6,897 | 7,888 | 12,379 | 14,633 | 12,785 | 18,789 | 26,270 | 23,323 | 12,078 |
| Cash from Investing Activity + | -5,433 | -5,618 | -7,372 | -3,857 | -5,094 | -4,529 | -11,387 | -19,589 | -7,702 | -14,748 | -10,730 | -14,467 |
| Cash from Financing Activity + | -791 | 3,300 | -169 | -3,151 | -2,710 | -8,185 | 1,753 | 5,189 | -3,110 | -14,657 | -5,977 | -5,005 |
| Net Cash Flow | -380 | 276 | 334 | -111 | 84 | -335 | 4,999 | -1,615 | 7,977 | -3,135 | 6,616 | -7,394 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 20 | 16 | 17 | 24 | 27 | 24 | 31 | 22 | 21 | 19 | 16 | 16 |
| Inventory Days | 83 | 98 | 136 | 135 | 147 | 118 | 123 | 130 | 160 | 208 | 130 | 151 |
| Days Payable | 155 | 141 | 175 | 207 | 172 | 149 | 137 | 169 | 171 | 190 | 149 | 133 |
| Cash Conversion Cycle | -52 | -26 | -23 | -48 | 2 | -7 | 17 | -17 | 9 | 36 | -4 | 33 |
| Working Capital Days | -66 | -44 | -49 | -84 | -34 | -25 | -36 | -53 | -82 | 8 | -12 | 10 |
| ROCE % | 11% | 13% | 10% | 5% | 14% | 18% | 20% | 9% | 16% | 29% | 8% | 13% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 44.09% | 44.72% | 45.01% | 45.02% | 45.20% | 45.20% | 45.41% | 45.41% | 44.79% | 44.81% | 44.81% | 44.81% |
| FIIs + | 12.17% | 11.21% | 11.58% | 10.61% | 10.75% | 26.04% | 26.01% | 25.98% | 26.13% | 26.33% | 26.06% | 25.52% |
| DIIs + | 8.06% | 8.38% | 7.94% | 9.07% | 9.25% | 9.34% | 9.47% | 9.59% | 9.50% | 9.48% | 9.81% | 10.52% |
| Government + | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% |
| Public + | 34.80% | 34.85% | 34.65% | 34.14% | 33.70% | 18.35% | 18.07% | 17.99% | 18.64% | 18.47% | 18.44% | 18.30% |
| Others + | 0.37% | 0.33% | 0.31% | 0.65% | 0.60% | 0.57% | 0.53% | 0.51% | 0.43% | 0.41% | 0.37% | 0.34% |
| No. of Shareholders | 6,86,724 | 6,79,906 | 6,59,879 | 6,94,916 | 6,67,173 | 6,08,448 | 6,05,019 | 5,86,997 | 6,63,179 | 6,41,582 | 6,71,779 | 6,35,680 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 41.62% | 41.75% | 42.66% | 42.71% | 44.07% | 45.01% | 45.41% | 44.81% | 44.81% |
| FIIs + | 19.95% | 19.86% | 18.58% | 17.13% | 12.69% | 11.58% | 26.01% | 26.06% | 25.52% |
| DIIs + | 16.39% | 17.78% | 2.87% | 4.39% | 7.11% | 7.94% | 9.47% | 9.81% | 10.52% |
| Government + | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% | 0.51% |
| Public + | 20.93% | 19.65% | 34.74% | 34.65% | 35.15% | 34.65% | 18.07% | 18.44% | 18.30% |
| Others + | 0.59% | 0.45% | 0.64% | 0.61% | 0.47% | 0.31% | 0.53% | 0.37% | 0.34% |
| No. of Shareholders | 7,12,410 | 5,98,406 | 5,90,514 | 6,01,150 | 5,63,121 | 6,59,879 | 6,05,019 | 6,71,779 | 6,35,680 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/jsw-steel-ltd/jswsteel/500228/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
17h - Transcripts of the Q1FY2025 Earnings Conference Call conducted after the Board Meeting](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5644bf7f-daa7-4e61-a7bf-68700c116acc.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 21h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11be8be3-6fbb-4775-bfe6-c80184b0def4.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
2d - Newspaper publication of financial results for the quarter ended 30.06.2024.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d144b324-e9a3-4466-b274-4508ff2d1134.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bd05b0-a405-47ad-8194-e191fc868815.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c38180e4-8b40-4cc1-ba12-5e013ff0c6c1.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b5fea484-29c2-448d-9799-749e51d6527a.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\1a2804ad-bc66-444b-aa4a-ea2e604971f3.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/73336500228.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/68698500228.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_JSWSTEEL_2011_2012_06072012103029.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280311.pdf)

## Credit Ratings
- [Rating update
5 Jul from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128631)
- [Rating update
21 Jun from care](https://www.careratings.com/upload/CompanyFiles/PR/202406150658_JSW_Steel_Limited.pdf)
- [Rating update
7 Dec 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202312141221_JSW_Steel_Limited.pdf)
- [Rating update
9 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123418)
- [Rating update
20 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310131042_JSW_Steel_Limited.pdf)
- [](https://www.careratings.com/upload/CompanyFiles/PR/202307140740_JSW_Steel_Limited.pdf)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bd05b0-a405-47ad-8194-e191fc868815.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q4/Results-Conference-Call-4Q-FY24.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95118ad9-e338-403a-ae11-8796a9bcb326.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q3/JSWSteel-Earnings-transcript-Q3-FY24-250124.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d2bcd9d7-fc63-42de-b619-d2f234ff72f9.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q2/JSWSteel-call-transcript-2Q-2024.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4f51f2a9-2ebc-4641-805f-d3c0eb8e4029.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q1/Q1-FY24-Earnings-call-transcript-Jul21-2023VF-v2.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfa37a9a-c01b-478b-ba35-5f0092d10651.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=19a90277-2030-4455-86fa-5ca52ae6351b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88fce2df-adec-4819-8088-0a8f0fd278b7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd942300-61f5-48ec-9963-72d5ff5d7544.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=53617093-909f-461c-9ab8-db0be12f843b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f2f1279-31ed-4a41-88fa-67279b31dc1b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a92009cb-b092-4d4a-9d22-0119687a4b51.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c230e1ac-cc81-4547-9716-b94ffb48e92e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9553cea5-54cb-46ee-8e80-b3dda204cbab.pdf)
- [](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2021-22/Q1/JSW_Steel_Q1_FY22_Earnings_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=410f3a74-e00d-45be-8859-a6b108c97ef4.pdf)
- [](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q4/JSWSteel-Q4%20FY21%20Earnings%20call%20Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a7f1eda2-bc7e-43a6-aa24-8987cbfe1054.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q3/JSW_Steel_Q3FY21_Earnings_Call_transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7a301da2-2697-4719-96ff-a094702b2842.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q2/JSWSteel-Q2FY-21-Transcript-Oct23-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4af281fb-ed68-4ab8-b2e9-a014d26092f4.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q1/JSWSteel-Q1%20FY21%20results%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8cc028b8-c085-4d93-860e-be7bfad751b6.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/Q4/JSW%20Steel_Q4FY20%20Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=964fc7d8-501c-4c1b-808b-fbf4f24493c0.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q3/JSWSteel_Q3-FY20-Transcript-24Jan-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8ac81e89-504c-40f3-9745-2ffefbb69b50.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q2/JSWSteel-Q2-FY-20-Earnings-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d745393b-d1c8-4ef5-9ac9-d54d846326f9.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q1/Q1-FY2020_JSWSteel-26Jul-2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=14569a17-9e74-4bd8-be85-3fe9414e2aae.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q4/Transcript_Q4_19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7b029253-9070-425e-a9d5-e106c961eba1.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q3/JSWSteel-Q3-FY2019_Call_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3f730a25-9cbb-4c41-93bf-5a6afc736604.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q2/JSWSteel-Q2-FY-19-Earnings-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=72e93ab4-4b4c-43d1-a794-e796963e62a6.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q1/Q1_FY19_Transcript_25July_2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81aedef0-1789-4dbd-b4c7-cc21cc0b6aa7.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q4/Q4FY2018_Call_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a027f16f-0037-4f7f-8c7c-68bef962fd7e.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q3/JSW%20Steel%20Q3%20FY18%20results%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5fde30a-97bc-452e-b2e8-b56067c14b7b.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q2/JSW%20Steel%20Q2%20FY18%20results%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dbc7528b-a7c2-48da-8832-a7b717ca2cf3.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q1/JSW%20Steel%20-%201QFY18%20results%20conference%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c7f05343-3cca-4d14-afe4-ab83cb3221e8.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2016-17/Q4/JSW%20Steel%20-%204QFY17%20results%20conference%20call%20transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Corporate%20Announcement/JSW%20Steel_3QFY17%20results%20conference%20call%20transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/Transcript_JSW_Steel_-_2QFY17_Earning_Call_Transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2016-17/Q1/JSW%20Steel%20-%201QFY17%20Earning%20Call%20Transcript-040816.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=E3D3A6A0_0C96_41F9_BC87_AF976D312A52_150647.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2015-16/Q3%20Transcript%2016.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=D2AE770D_E2D2_4211_80A4_66EC8D6A465A_124112.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | JSW Steel | 900.30 | 220164.18 | 31.64 | 2.82 | 1.25 | 30.97 | 10.80 | 28.49 | 0.82 | 13.30 | 3.92 | 11.79 | 0.80 | 1.13 | 2.30 | 2.82 | 175736.00 | 15.11 | 6964.44 | 42943.00 | 845.00 | 1.73 | -63.86 | 29.93 | 87984.00 | 44.80 | -0.01 | 6.53 | 19.34 | 15.16 | 3.32 | 36.02 | 295800.18 | 0.98 | 13.41 | -1.44 | 7.21 | 7.16 | 10.17 | 17.14 | 16.83 | 2.36 | 2.06 | 15.60 | 29.90 | 5.64 | 8.33 | 0.40 | 36.03 | 2.13 | 19.77 | 19.74 | 16.51 | 33.46 | 241.72 |
| 2. | Tata Steel | 162.65 | 203044.64 | 31.80 | 2.18 | 0.89 | 13.58 | 12.32 | 28.71 | 2.23 | 7.02 | 2.55 | 6.55 | 0.83 | 0.95 | 1.73 | 3.01 | 229170.78 | 9.71 | 6390.28 | 58687.31 | 704.22 | -6.79 | -54.88 | -3.55 | 87082.12 | 33.19 | 0.00 | 4.72 | 19.34 | 0.00 | -5.83 | -19.24 | 281449.04 | 0.71 | -5.45 | -5.07 | 17.67 | 5.75 | 31.38 | 18.07 | 13.81 | -5.83 | -6.63 | 7.77 | 13.61 | 7.28 | 12.63 | 0.21 | -3.55 | -7.75 | 7.36 | 7.43 | 7.63 | 59.12 | 1222.15 |
| 3. | Tube Investments | 4164.70 | 80551.88 | 67.27 | 15.76 | 4.77 | 161.78 | 36.20 | 64.05 | 0.09 | 26.28 | 14.71 | 26.48 | 1.45 | 0.18 | 24.12 | 2.29 | 16890.33 | 11.66 | 1198.12 | 4490.11 | 192.47 | 18.86 | -13.56 | 62.08 | 896.33 | 45.04 | -0.06 | 2.26 | 19.34 | 0.01 | 12.87 | 26.55 | 80220.81 | 1.35 | 1.76 | 11.20 | 1.06 | 54.83 | 29.05 | 27.22 | 24.64 | 38.28 | 61.63 | 23.95 | 40.55 | 26.97 | 31.58 | 0.98 | 62.08 | 37.45 | 61.58 | 62.72 | 57.89 | 26.33 | 19.31 |
| 4. | Jindal Stain. | 764.70 | 62968.01 | 24.08 | 4.37 | 1.63 | 38.67 | 13.61 | 89.19 | 0.20 | 22.27 | 9.04 | 19.93 | 1.33 | 0.42 | 7.30 | 2.02 | 38562.47 | 12.20 | 2619.14 | 9454.02 | 501.83 | -3.19 | -29.94 | 32.95 | 6052.26 | 60.49 | 0.00 | 6.16 | 19.34 | 0.00 | 8.03 | 25.77 | 67032.16 | 1.47 | 0.30 | 6.80 | 39.10 | 68.89 | 96.50 | 25.48 | 22.70 | 79.09 | 94.36 | 23.25 | 46.80 | 19.14 | 20.77 | 0.68 | 32.95 | 60.72 | 10.80 | 8.53 | 11.35 | 40.59 | 82.34 |
| 5. | S A I L | 147.50 | 60925.28 | 16.44 | 1.06 | 0.58 | 10.48 | 7.63 | 25.83 | 1.02 | 8.24 | 2.73 | 6.62 | 0.78 | 0.64 | 2.98 | 2.38 | 105378.33 | 10.58 | 3701.50 | 27958.52 | 1518.04 | -4.02 | 27.78 | 7.42 | 36322.65 | 65.00 | 0.00 | 7.80 | 19.34 | 0.00 | 0.89 | 90.29 | 96574.98 | 0.90 | 2.34 | -15.40 | 19.72 | 3.20 | 54.15 | 11.34 | 10.22 | 7.02 | -3.61 | 9.49 | 15.10 | 3.57 | 5.89 | 0.29 | 7.42 | 7.02 | 10.77 | 7.82 | 10.57 | 145.71 | 413.05 |
| 6. | APL Apollo Tubes | 1485.60 | 41229.07 | 56.33 | 11.39 | 2.28 | 341.38 | 33.17 | 58.68 | 0.33 | 25.29 | 11.24 | 22.16 | 2.78 | 0.32 | 9.62 | 1.81 | 18118.80 | 6.58 | 732.44 | 4765.74 | 170.44 | 7.55 | -15.55 | 26.39 | 1144.25 | 28.33 | -1.11 | 2.64 | 19.34 | 0.00 | 12.08 | 13.99 | 42025.72 | 1.34 | 1.50 | -6.04 | -1.97 | 18.61 | -2.99 | 24.56 | 23.98 | 37.66 | 26.69 | 20.43 | 28.70 | 23.50 | 26.90 | 0.68 | 26.39 | 33.55 | 46.38 | 50.42 | 37.97 | -5.23 | 27.73 |
| 7. | Shyam Metalics | 693.00 | 19343.80 | 18.82 | 1.97 | 1.47 | 127.29 | 11.50 |  | 0.25 | 10.94 | 8.04 | 12.24 | 1.03 | 0.06 | 8.05 | 1.33 | 13195.22 | 11.90 | 1029.00 | 3606.20 | 216.54 | 5.20 | -14.72 | 37.07 | 596.91 | 74.59 | 0.00 | 5.46 | 19.34 | 0.00 | 4.64 | 21.51 | 19890.24 | 1.39 | 1.67 | 6.63 | 1.12 | 16.88 | 69.91 | 18.34 | 18.74 | 11.29 | 6.89 | 23.43 | 27.97 | 13.03 | 15.01 | 0.80 | 37.07 | 7.40 | 8.90 | 7.48 | 8.90 | 11.84 | 25.51 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | Sales | ₹ 1,75,736 Cr. |
| JSWSTEEL | OPM | 15.1 % |
| JSWSTEEL | Profit after tax | ₹ 6,964 Cr. |
| JSWSTEEL | Mar Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Sales Qtr | ₹ 42,943 Cr. |
| JSWSTEEL | PAT Qtr | ₹ 845 Cr. |
| JSWSTEEL | Qtr Sales Var | 1.73 % |
| JSWSTEEL | Qtr Profit Var | -63.9 % |
| JSWSTEEL | Price to Earning | 31.6 |
| JSWSTEEL | Dividend yield | 0.82 % |
| JSWSTEEL | Price to book value | 2.82 |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | Return on assets | 3.92 % |
| JSWSTEEL | Debt to equity | 1.13 |
| JSWSTEEL | Return on equity | 11.8 % |
| JSWSTEEL | EPS | ₹ 29.9 |
| JSWSTEEL | Debt | ₹ 87,984 Cr. |
| JSWSTEEL | Promoter holding | 44.8 % |
| JSWSTEEL | Change in Prom Hold | -0.01 % |
| JSWSTEEL | Earnings yield | 6.53 % |
| JSWSTEEL | Pledged percentage | 15.2 % |
| JSWSTEEL | Industry PE | 19.3 |
| JSWSTEEL | Sales growth | 3.32 % |
| JSWSTEEL | Profit growth | 36.0 % |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | Price to Sales | 1.25 |
| JSWSTEEL | CMP / FCF | 31.0 |
| JSWSTEEL | EVEBITDA | 10.8 |
| JSWSTEEL | Enterprise Value | ₹ 2,95,800 Cr. |
| JSWSTEEL | Current ratio | 0.98 |
| JSWSTEEL | Int Coverage | 2.30 |
| JSWSTEEL | PEG Ratio | 13.4 |
| JSWSTEEL | Return over 3months | -1.44 % |
| JSWSTEEL | Return over 6months | 7.21 % |
| JSWSTEEL | No. Eq. Shares | 245 |
| JSWSTEEL | Sales growth 3Years | 29.9 % |
| JSWSTEEL | Sales growth 5Years | 15.6 % |
| JSWSTEEL | Profit Var 3Yrs | 2.06 % |
| JSWSTEEL | Profit Var 5Yrs | 2.36 % |
| JSWSTEEL | ROE 5Yr | 16.8 % |
| JSWSTEEL | ROE 3Yr | 17.1 % |
| JSWSTEEL | Return over 1year | 10.2 % |
| JSWSTEEL | Return over 3years | 7.16 % |
| JSWSTEEL | Return over 5years | 28.5 % |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | Sales last year | ₹ 1,75,006 Cr. |
| JSWSTEEL | OP Ann | ₹ 28,157 Cr. |
| JSWSTEEL | Other Inc Ann | ₹ 1,500 Cr. |
| JSWSTEEL | EBIDT last year | ₹ 29,161 Cr. |
| JSWSTEEL | Dep Ann | ₹ 8,172 Cr. |
| JSWSTEEL | EBIT last year | ₹ 20,989 Cr. |
| JSWSTEEL | Interest last year | ₹ 8,105 Cr. |
| JSWSTEEL | PBT Ann | ₹ 13,380 Cr. |
| JSWSTEEL | Tax last year | ₹ 4,407 Cr. |
| JSWSTEEL | PAT Ann | ₹ 8,448 Cr. |
| JSWSTEEL | Extra Ord Item Ann | ₹ 496 Cr. |
| JSWSTEEL | NP Ann | ₹ 8,973 Cr. |
| JSWSTEEL | Dividend last year | ₹ 2,226 Cr. |
| JSWSTEEL | Raw Material | 52.4 % |
| JSWSTEEL | Employee cost | ₹ 4,591 Cr. |
| JSWSTEEL | OPM last year | 16.1 % |
| JSWSTEEL | NPM last year | 4.92 % |
| JSWSTEEL | Operating profit | ₹ 26,550 Cr. |
| JSWSTEEL | Interest | ₹ 8,215 Cr. |
| JSWSTEEL | Depreciation | ₹ 8,481 Cr. |
| JSWSTEEL | EPS last year | ₹ 36.0 |
| JSWSTEEL | EBIT | ₹ 18,906 Cr. |
| JSWSTEEL | Net profit | ₹ 7,412 Cr. |
| JSWSTEEL | Current Tax | ₹ 3,512 Cr. |
| JSWSTEEL | Tax | ₹ 3,868 Cr. |
| JSWSTEEL | Other income | ₹ 1,426 Cr. |
| JSWSTEEL | Ann Date | 2,02,403 |
| JSWSTEEL | Sales Prev Ann | ₹ 1,65,960 Cr. |
| JSWSTEEL | OP Prev Ann | ₹ 18,470 Cr. |
| JSWSTEEL | Other Inc Prev Ann | ₹ 1,561 Cr. |
| JSWSTEEL | EBIDT Prev Ann | ₹ 19,500 Cr. |
| JSWSTEEL | Dep Prev Ann | ₹ 7,474 Cr. |
| JSWSTEEL | EBIT preceding year | ₹ 12,026 Cr. |
| JSWSTEEL | Interest Prev Ann | ₹ 6,902 Cr. |
| JSWSTEEL | PBT Prev Ann | ₹ 5,655 Cr. |
| JSWSTEEL | Tax preceding year | ₹ 1,516 Cr. |
| JSWSTEEL | PAT Prev Ann | ₹ 3,750 Cr. |
| JSWSTEEL | Extra Ord Prev Ann | ₹ 531 Cr. |
| JSWSTEEL | NP Prev Ann | ₹ 4,139 Cr. |
| JSWSTEEL | Dividend Prev Ann | ₹ 1,023 Cr. |
| JSWSTEEL | OPM preceding year | 11.1 % |
| JSWSTEEL | NPM preceding year | 2.26 % |
| JSWSTEEL | EPS preceding year | ₹ 17.1 |
| JSWSTEEL | Sales Prev 12M | ₹ 1,75,006 Cr. |
| JSWSTEEL | Profit Prev 12M | ₹ 8,973 Cr. |
| JSWSTEEL | Med Sales Gwth 10Yrs | 8.88 % |
| JSWSTEEL | Med Sales Gwth 5Yrs | 8.88 % |
| JSWSTEEL | Sales growth 7Years | 17.8 % |
| JSWSTEEL | Sales Var 10Yrs | 13.1 % |
| JSWSTEEL | EBIDT growth 3Years | 12.0 % |
| JSWSTEEL | EBIDT growth 5Years | 8.81 % |
| JSWSTEEL | EBIDT growth 7Years | 12.9 % |
| JSWSTEEL | EBIDT Var 10Yrs | 12.2 % |
| JSWSTEEL | EPS growth 3Years | 1.66 % |
| JSWSTEEL | EPS growth 5Years | 2.13 % |
| JSWSTEEL | EPS growth 7Years | 13.0 % |
| JSWSTEEL | EPS growth 10Years | 37.4 % |
| JSWSTEEL | Profit Var 7Yrs | 13.2 % |
| JSWSTEEL | Profit Var 10Yrs | 37.5 % |
| JSWSTEEL | Chg in Prom Hold 3Yr | 0.73 % |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | OP Qtr | ₹ 5,498 Cr. |
| JSWSTEEL | Other Inc Qtr | ₹ 164 Cr. |
| JSWSTEEL | EBIDT Qtr | ₹ 5,662 Cr. |
| JSWSTEEL | Dep Qtr | ₹ 2,209 Cr. |
| JSWSTEEL | EBIT latest quarter | ₹ 3,453 Cr. |
| JSWSTEEL | Interest Qtr | ₹ 2,073 Cr. |
| JSWSTEEL | PBT Qtr | ₹ 1,380 Cr. |
| JSWSTEEL | Tax latest quarter | ₹ 513 Cr. |
| JSWSTEEL | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| JSWSTEEL | NP Qtr | ₹ 867 Cr. |
| JSWSTEEL | GPM latest quarter | 38.4 % |
| JSWSTEEL | OPM latest quarter | 12.8 % |
| JSWSTEEL | NPM latest quarter | 2.02 % |
| JSWSTEEL | Eq Cap Qtr | ₹ 244 Cr. |
| JSWSTEEL | EPS latest quarter | ₹ 3.46 |
| JSWSTEEL | OP 2Qtr Bk | ₹ 7,164 Cr. |
| JSWSTEEL | OP 3Qtr Bk | ₹ 7,862 Cr. |
| JSWSTEEL | Sales 2Qtr Bk | ₹ 41,940 Cr. |
| JSWSTEEL | Sales 3Qtr Bk | ₹ 44,584 Cr. |
| JSWSTEEL | NP 2Qtr Bk | ₹ 2,450 Cr. |
| JSWSTEEL | NP 3Qtr Bk | ₹ 2,773 Cr. |
| JSWSTEEL | Opert Prft Gwth | 25.6 % |
| JSWSTEEL | Last result date | 2,02,406 |
| JSWSTEEL | Exp Qtr Sales Var | 3.45 % |
| JSWSTEEL | Exp Qtr Sales | ₹ 46,122 Cr. |
| JSWSTEEL | Exp Qtr OP | ₹ 7,365 Cr. |
| JSWSTEEL | Exp Qtr NP | ₹ 3,053 Cr. |
| JSWSTEEL | Exp Qtr EPS | ₹ 12.2 |
| JSWSTEEL | Sales Prev Qtr | ₹ 46,269 Cr. |
| JSWSTEEL | OP Prev Qtr | ₹ 6,026 Cr. |
| JSWSTEEL | Other Inc Prev Qtr | ₹ 242 Cr. |
| JSWSTEEL | EBIDT Prev Qtr | ₹ 6,268 Cr. |
| JSWSTEEL | Dep Prev Qtr | ₹ 2,194 Cr. |
| JSWSTEEL | EBIT Prev Qtr | ₹ 4,074 Cr. |
| JSWSTEEL | Interest Prev Qtr | ₹ 2,062 Cr. |
| JSWSTEEL | PBT Prev Qtr | ₹ 2,012 Cr. |
| JSWSTEEL | Tax Prev Qtr | ₹ 690 Cr. |
| JSWSTEEL | PAT Prev Qtr | ₹ 1,299 Cr. |
| JSWSTEEL | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| JSWSTEEL | NP Prev Qtr | ₹ 1,322 Cr. |
| JSWSTEEL | OPM Prev Qtr | 13.0 % |
| JSWSTEEL | NPM Prev Qtr | 2.86 % |
| JSWSTEEL | Eq Cap Prev Qtr | ₹ 305 Cr. |
| JSWSTEEL | EPS Prev Qtr | ₹ 5.31 |
| JSWSTEEL | Sales PY Qtr | ₹ 42,213 Cr. |
| JSWSTEEL | OP PY Qtr | ₹ 7,012 Cr. |
| JSWSTEEL | Other Inc PY Qtr | ₹ 331 Cr. |
| JSWSTEEL | EBIDT PY Qtr | ₹ 7,343 Cr. |
| JSWSTEEL | Dep PY Qtr | ₹ 1,900 Cr. |
| JSWSTEEL | EBIT PY Qtr | ₹ 5,443 Cr. |
| JSWSTEEL | Interest PY Qtr | ₹ 1,963 Cr. |
| JSWSTEEL | PBT PY Qtr | ₹ 3,480 Cr. |
| JSWSTEEL | Tax PY Qtr | ₹ 1,052 Cr. |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | Equity capital | ₹ 305 Cr. |
| JSWSTEEL | Preference capital | ₹ 36.0 Cr. |
| JSWSTEEL | Reserves | ₹ 77,364 Cr. |
| JSWSTEEL | Secured loan | ₹ 34,081 Cr. |
| JSWSTEEL | Unsecured loan | ₹ 53,867 Cr. |
| JSWSTEEL | Balance sheet total | ₹ 2,27,898 Cr. |
| JSWSTEEL | Gross block | ₹ 1,54,695 Cr. |
| JSWSTEEL | Revaluation reserve | ₹ 0.00 Cr. |
| JSWSTEEL | Accum Dep | ₹ 42,234 Cr. |
| JSWSTEEL | Net block | ₹ 1,12,461 Cr. |
| JSWSTEEL | CWIP | ₹ 29,676 Cr. |
| JSWSTEEL | Investments | ₹ 7,246 Cr. |
| JSWSTEEL | Current assets | ₹ 64,531 Cr. |
| JSWSTEEL | Current liabilities | ₹ 66,065 Cr. |
| JSWSTEEL | BV Unq Invest | ₹ 0.00 Cr. |
| JSWSTEEL | MV Quoted Inv | ₹ 5,378 Cr. |
| JSWSTEEL | Cont Liab | ₹ 3,785 Cr. |
| JSWSTEEL | Total Assets | ₹ 2,27,898 Cr. |
| JSWSTEEL | Working capital | ₹ 17,036 Cr. |
| JSWSTEEL | Lease liabilities | ₹ 2,409 Cr. |
| JSWSTEEL | Inventory | ₹ 37,815 Cr. |
| JSWSTEEL | Trade receivables | ₹ 7,548 Cr. |
| JSWSTEEL | Face value | ₹ 1.00 |
| JSWSTEEL | Cash Equivalents | ₹ 12,348 Cr. |
| JSWSTEEL | Adv Cust | ₹ 1,005 Cr. |
| JSWSTEEL | Trade Payables | ₹ 33,365 Cr. |
| JSWSTEEL | No. Eq. Shares PY | 242 |
| JSWSTEEL | Debt preceding year | ₹ 80,853 Cr. |
| JSWSTEEL | Work Cap PY | ₹ 15,475 Cr. |
| JSWSTEEL | Net Block PY | ₹ 1,04,452 Cr. |
| JSWSTEEL | Gross Block PY | ₹ 1,39,236 Cr. |
| JSWSTEEL | CWIP PY | ₹ 22,166 Cr. |
| JSWSTEEL | Work Cap 3Yr | ₹ -5,051 Cr. |
| JSWSTEEL | Work Cap 5Yr | ₹ -2,202 Cr. |
| JSWSTEEL | Work Cap 7Yr | ₹ -3,703 Cr. |
| JSWSTEEL | Work Cap 10Yr | ₹ -5,470 Cr. |
| JSWSTEEL | Debt 3Years back | ₹ 62,392 Cr. |
| JSWSTEEL | Debt 5Years back | ₹ 47,396 Cr. |
| JSWSTEEL | Debt 7Years back | ₹ 43,334 Cr. |
| JSWSTEEL | Debt 10Years back | ₹ 35,527 Cr. |
| JSWSTEEL | Net Block 3Yrs Back | ₹ 64,917 Cr. |
| JSWSTEEL | Net Block 5Yrs Back | ₹ 62,644 Cr. |
| JSWSTEEL | Net Block 7Yrs Back | ₹ 58,730 Cr. |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | CF Operations | ₹ 12,078 Cr. |
| JSWSTEEL | Free Cash Flow | ₹ -3,469 Cr. |
| JSWSTEEL | CF Investing | ₹ -14,467 Cr. |
| JSWSTEEL | CF Financing | ₹ -5,005 Cr. |
| JSWSTEEL | Net CF | ₹ -7,394 Cr. |
| JSWSTEEL | Cash Beginning | ₹ 15,424 Cr. |
| JSWSTEEL | Cash End | ₹ 12,348 Cr. |
| JSWSTEEL | FCF Prev Ann | ₹ 8,574 Cr. |
| JSWSTEEL | CF Operations PY | ₹ 23,323 Cr. |
| JSWSTEEL | CF Investing PY | ₹ -10,730 Cr. |
| JSWSTEEL | CF Financing PY | ₹ -5,977 Cr. |
| JSWSTEEL | Net CF PY | ₹ 6,616 Cr. |
| JSWSTEEL | Cash Beginning PY | ₹ 8,808 Cr. |
| JSWSTEEL | Cash End PY | ₹ 20,714 Cr. |
| JSWSTEEL | Free Cash Flow 3Yrs | ₹ 21,327 Cr. |
| JSWSTEEL | Free Cash Flow 5Yrs | ₹ 30,927 Cr. |
| JSWSTEEL | Free Cash Flow 7Yrs | ₹ 43,101 Cr. |
| JSWSTEEL | Free Cash Flow 10Yrs | ₹ 49,697 Cr. |
| JSWSTEEL | CF Opr 3Yrs | ₹ 61,671 Cr. |
| JSWSTEEL | CF Opr 5Yrs | ₹ 93,245 Cr. |
| JSWSTEEL | CF Opr 7Yrs | ₹ 1,20,257 Cr. |
| JSWSTEEL | CF Opr 10Yrs | ₹ 1,42,918 Cr. |
| JSWSTEEL | CF Inv 10Yrs | ₹ -99,476 Cr. |
| JSWSTEEL | CF Inv 7Yrs | ₹ -83,152 Cr. |
| JSWSTEEL | CF Inv 5Yrs | ₹ -67,236 Cr. |
| JSWSTEEL | CF Inv 3Yrs | ₹ -39,945 Cr. |
| JSWSTEEL | Cash 3Years back | ₹ 12,813 Cr. |
| JSWSTEEL | Cash 5Years back | ₹ 6,187 Cr. |
| JSWSTEEL | Cash 7Years back | ₹ 1,485 Cr. |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | No. Eq. Shares | 245 |
| JSWSTEEL | Book value | ₹ 318 |
| JSWSTEEL | Inven TO | 3.01 |
| JSWSTEEL | Quick ratio | 0.40 |
| JSWSTEEL | Exports percentage | 0.00 % |
| JSWSTEEL | Piotroski score | 6.00 |
| JSWSTEEL | G Factor | 2.00 |
| JSWSTEEL | Asset Turnover | 0.80 |
| JSWSTEEL | Financial leverage | 2.82 |
| JSWSTEEL | No. of Share Holders | 6,35,680 |
| JSWSTEEL | Unpledged Prom Hold | 38.0 % |
| JSWSTEEL | ROIC | 10.9 % |
| JSWSTEEL | Debtor days | 15.7 |
| JSWSTEEL | Industry PBV | 2.75 |
| JSWSTEEL | Credit rating |  |
| JSWSTEEL | WC Days | 9.78 |
| JSWSTEEL | Earning Power | 8.30 % |
| JSWSTEEL | Graham Number | ₹ 462 |
| JSWSTEEL | Cash Cycle | 33.5 |
| JSWSTEEL | Days Payable | 133 |
| JSWSTEEL | Days Receivable | 15.7 |
| JSWSTEEL | Inventory Days | 151 |
| JSWSTEEL | Public holding | 18.3 % |
| JSWSTEEL | FII holding | 25.5 % |
| JSWSTEEL | Chg in FII Hold | -0.54 % |
| JSWSTEEL | DII holding | 10.5 % |
| JSWSTEEL | Chg in DII Hold | 0.71 % |
| JSWSTEEL | B.V. Prev Ann | ₹ 272 |
| JSWSTEEL | ROCE Prev Yr | 8.33 % |
| JSWSTEEL | ROA Prev Yr | 1.84 % |
| JSWSTEEL | ROE Prev Ann | 5.64 % |
| JSWSTEEL | No. of Share Holders Prev Qtr | 6,71,779 |
| JSWSTEEL | No. Eq. Shares 10 Yrs | 242 |
| JSWSTEEL | BV 3yrs back | ₹ 193 |
| JSWSTEEL | BV 5yrs back | ₹ 151 |
| JSWSTEEL | BV 10yrs back | ₹ 92.2 |
| JSWSTEEL | Inven TO 3Yr | 2.75 |
| JSWSTEEL | Inven TO 5Yr | 3.18 |
| JSWSTEEL | Inven TO 7Yr | 3.73 |
| JSWSTEEL | Inven TO 10Yr | 3.52 |
| JSWSTEEL | Export 3Yr | 0.00 % |
| JSWSTEEL | Export 5Yr | 0.00 % |
| JSWSTEEL | Div 5Yrs | ₹ 2,207 Cr. |
| JSWSTEEL | ROCE 3Yr | 16.7 % |
| JSWSTEEL | ROCE 5Yr | 15.0 % |
| JSWSTEEL | ROCE 7Yr | 16.1 % |
| JSWSTEEL | ROCE 10Yr | 14.3 % |
| JSWSTEEL | ROE 10Yr | 16.9 % |
| JSWSTEEL | ROE 7Yr | 18.2 % |
| JSWSTEEL | ROE 5Yr Var | -13.2 % |
| JSWSTEEL | OPM 5Year | 18.4 % |
| JSWSTEEL | OPM 10Year | 19.0 % |
| JSWSTEEL | No. of Share Holders 1Yr | 5,86,997 |
| JSWSTEEL | Avg Div Payout 3Yrs | 25.1 % |
| JSWSTEEL | Debtor days 3yrs | 16.7 |
| JSWSTEEL | Debtor days 3yrs back | 20.5 |
| JSWSTEEL | Debtor days 5yrs back | 30.8 |
| JSWSTEEL | ROA 5Yr | 5.51 % |
| JSWSTEEL | ROA 3Yr | 6.09 % |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | Avg Vol 1Mth | 20,56,415 |
| JSWSTEEL | Avg Vol 1Wk | 19,31,212 |
| JSWSTEEL | Volume | 16,91,159 |
| JSWSTEEL | High price | ₹ 959 |
| JSWSTEEL | Low price | ₹ 723 |
| JSWSTEEL | High price all time | ₹ 959 |
| JSWSTEEL | Low price all time | ₹ 16.0 |
| JSWSTEEL | Return over 1day | 2.95 % |
| JSWSTEEL | Return over 1week | -1.68 % |
| JSWSTEEL | Return over 1month | -4.86 % |
| JSWSTEEL | DMA 50 | ₹ 908 |
| JSWSTEEL | DMA 200 | ₹ 853 |
| JSWSTEEL | DMA 50 previous day | ₹ 909 |
| JSWSTEEL | 200 DMA prev. | ₹ 852 |
| JSWSTEEL | RSI | 34.8 |
| JSWSTEEL | MACD | -8.38 |
| JSWSTEEL | MACD Previous Day | -5.89 |
| JSWSTEEL | MACD Signal | -0.23 |
| JSWSTEEL | MACD Signal Prev | 1.81 |
| JSWSTEEL | Avg Vol 1Yr | 23,84,063 |
| JSWSTEEL | Return over 7years | 22.1 % |
| JSWSTEEL | Return over 10years | 22.0 % |
| JSWSTEEL | Market Cap | ₹ 2,20,164 Cr. |
| JSWSTEEL | Current Price | ₹ 900 |
| JSWSTEEL | High / Low | ₹ 959 / 723 |
| JSWSTEEL | Stock P/E | 31.6 |
| JSWSTEEL | Book Value | ₹ 318 |
| JSWSTEEL | Dividend Yield | 0.82 % |
| JSWSTEEL | ROCE | 13.3 % |
| JSWSTEEL | ROE | 11.8 % |
| JSWSTEEL | Face Value | ₹ 1.00 |
| JSWSTEEL | WC to Sales | 9.69 % |
| JSWSTEEL | QoQ Profits | -34.4 % |
| JSWSTEEL | QoQ Sales | -7.19 % |
| JSWSTEEL | Net worth | ₹ 77,669 Cr. |
| JSWSTEEL | Market Cap to Sales | 1.25 |
| JSWSTEEL | Interest Coverage | 2.30 |
| JSWSTEEL | EV / EBIT | 15.6 |
| JSWSTEEL | Debt Capacity | -0.05 |
| JSWSTEEL | Debt To Profit | 9.81 |
| JSWSTEEL | Capital Employed | ₹ 1,59,173 Cr. |
| JSWSTEEL | CROIC | 4.50 % |
| JSWSTEEL | debtplus | 1.18 |
| JSWSTEEL | Leverage | ₹ 2.82 |
| JSWSTEEL | Dividend Payout | 25.3 % |
| JSWSTEEL | Intrinsic Value | ₹ 487 |
| JSWSTEEL | CDL | -36.1 % |
| JSWSTEEL | Cash by market cap | 0.08 |
| JSWSTEEL | 52w Index | 75.0 % |
| JSWSTEEL | Down from 52w high | 6.16 % |
| JSWSTEEL | Up from 52w low | 24.5 % |
| JSWSTEEL | From 52w high | 0.94 |
| JSWSTEEL | Mkt Cap To Debt Cap | 0.94 |
| JSWSTEEL | Dividend Payout | 25.3 % |
| JSWSTEEL | Graham | ₹ 462 |
| JSWSTEEL | Price to Cash Flow | 18.2 |
| JSWSTEEL | ROCE3yr avg | 16.7 % |
| JSWSTEEL | PB X PE | 89.2 |
| JSWSTEEL | NCAVPS | ₹ 69.7 |
| JSWSTEEL | Mar Cap to CF | 18.2 |
| JSWSTEEL | Altman Z Score | 3.16 |
| JSWSTEEL | M.Cap / Qtr Profit | 261 |