About
[
edit
]
Incorporated  in  December  1993,  Axis  Bank  Limited  is  a  private  sector  bank.It  has  the  third-largest network of branches among private sector banks and an international presence through branches in DIFC (Dubai) and Singapore along with representative offices in Abu Dhabi, Sharjah, Dhaka and Dubai and an offshore banking unit in GIFT City.
[1]
Key Points
[
edit
]
Market Leadership
<h1>3rd largest private sector bank in India.
[1]
</h1>
<h1>4th largest issuer of credit cards
[2]
</h1>
<h1>19.8% market share in FY24.
[3]
</h1>
Ratios FY24
[4]
Capital Adequacy Ratio - 16.63%
Net Interest Margin - 4.07%
Gross NPA - 1.43 %
Net NPA - 0.31%
CASA Ratio - 43%
Branch Network
[5]
In FY24, Bank added 475 branches (125 in Q4FY24) to its network. At present, it has a total of 5377 branches, 16,026 ATMs and Cash recyclers. The region-wise breakup of branches is as follows:
[6]
Metro - 31%
Semi-urban - 29%
Urban - 23%
Rural - 17%
Revenue Mix FY24
[7]
Treasury: ~15%
Corporate/Wholesale Banking: ~22%
Retail Banking: ~61%
Other Banking Business: ~2%
Loan Book
[8]
Retail loans account for 60% of bank's loan book and corporate 29% & SME loans 11%.
[9]
Retail Book
Home loans account for 28% of retail book, followed by rural loans (16%), LAP(11%), Auto loans(10%), personal loans(12%) , small business banking (10%), credit cards (7%), Comm Equipment (2%) & others (4%).
[10]
Market Share FY24
Bank has 5.5% market share in assets, 5% in deposits & 5.9% in advances.
[1]
14% in credit cards circulation in India.
[11]
5.2% market share in personal loan.
[12]
. 8.4% RTGS, 30% NEFT, 38.9% IMPS Market share (by volume),20% Market share in BBPS. 11.4% Foreign LC Market Share.
[13]
8.4% market share of MSME credit.
[14]
Retail Fee Mix Q4FY24
Bank earns retail fees from various mediums. 74% of total fees. Retail cards account for 42% of fees, followed by third party products (27%), retail assets (17%), and the rest 14% fees come from retail liabilities and other mediums.
[15]
Digital Banking
96% of Digital transactions. 87% of Credit cards issued, 70% of new savings accounts, 74% of New MF SIP Volume, 53% of Personal loan disbursed were sourced digitally in FY24.
[16]
2. Axis Capital Ltd -
Provide focused and customized solutions in Investment Banking and Institutional Equities. 90 IB deals closed in FY24 that include 52 ECM and 7 M&A deals. 2nd rank in ECM deals
[17]
3. A.Treds Ltd (67% shareholding) -
It is engaged in the business of facilitating financing of trade receivables.
It is one of the three entities allowed by RBI to set up the Trade Receivables Discounting System (TReDS), an electronic platform for facilitating cash flows for MSMEs.
Its digital invoice discounting platform ‘Invoicemart’ has set a new benchmark by facilitating financing of MSME invoices of ~Rs. 1,04,000 Crs.
[18]
4. Axis Asset Management Co. Ltd (75% shareholding) -
PMS,AIF & Mutual Funds. 5% AUM market share. AUM:~Rs.2,74,265 Cr.
[17]
5. Axis Trustee Services Ltd -
It is registered with the SEBI and has been successfully executing various trusteeship activities including debenture trustee, security trustee, security agent, lenders’ agent, trustee for securitisation and escrow agent, among others. Assets under Trust: Rs. 39,04,153 Cr. 24% (AUM) market share in Debenture Trustee segment - 2nd Rank
[19]
6. Axis Securities Ltd -
3rd largest bank led retail brokerage in terms of customer base with customer base of 5.45 Mn.
[20]
7. Freecharge -
It is in the business of providing merchant acquiring services, payment aggregation services, payment support services, and business correspondent to a Bank / Financial Institution, distribution of Mutual Funds.
[18]
8. Axis Mutual Fund Trustee Ltd (75% shareholding) -
It acts as the trustee for the mutual fund business.
9. Axis Bank UK Ltd -
It is the banking subsidiary of the Bank in the UK and undertakes the activities of banking.
10. Max Life Insurance Co. Ltd.(16.22% shareholding)
[21]
Updates
1. During the Q3FY24 upon receipt of the final closing statement from Citibank N.A. and Citicorp Finance (India) Limited. The Bank has completed the settlement of the purchase price true up amount relating to the aforesaid acquisition. The final determined purchase price amounted to ~11,932.39 crores as against the estimated adjusted purchase price of ~11,949.08 crores recognised in FY23.
[22]
2.
Fund raising
Bank to consider fund raising through debt or equity.
[23]
3. Bank has subscribed 14,25,79,161 shares of Max Life @ Rs. 113.06 for ~Rs 1,612 Cr.
[21]
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright
