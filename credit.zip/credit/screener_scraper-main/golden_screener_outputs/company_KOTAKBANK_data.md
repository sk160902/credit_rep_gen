About
[
edit
]
Kotak Mahindra Bank is a diversified financial services group providing a wide range of banking and financial services including Retail Banking, Treasury and Corporate Banking, Investment Banking, Stock Broking, Vehicle Finance, Advisory services, Asset Management, Life Insurance and General Insurance.
[1]
Key Points
[
edit
]
Market Share
The company ranks
4th
in both deposit and gross advances market share. Its securities broking business held an
11.8% market share
in FY24, while the asset management business had a
6.5% market share.
[1]
Business Segments FY24
1) Insurance (~28%):
Offers Life insurance and General Insurance services. It has recorded a gross written premium of Rs 17,708 Cr in FY24 vs Rs 15,320 Cr in FY23.
[2]
2) Retail Banking (27%):
Offers Digital Banking, retail lending, deposit taking, etc.
3) Corporate & Wholesale Banking (22%):
Wholesale borrowings and lending and other related services to the corporate sector.
4) Treasury (~11%):
Engaged in the Money market, forex market, derivatives, investments,
and dealerships of government securities, etc.
5) Vehicle Financing (3%):
Offers loans for vehicle finance and wholesale trade finance to auto dealers through subsidiary Kotak Mahindra Prime Ltd.
6) Broking (3%):
Offers broking and distribution of financial products from subsidiary Kotak Securities Ltd. It has 1196 branches & franchises.
[3]
7) Asset Management (2%):
Bank manages funds and investments on behalf of clients and investment distribution through subsidiary KM Asset Management Company Ltd. Overall AUM as of FY24 stood at Rs. 3,46,589 Cr vs Rs. 2,87,058 Cr as of FY23. Domestic equity and debt account for 44% and 24% share in AUM for FY24 and alternative assets account for 8% of AUM.
[4]
[5]
8) Advisory and Other lendings (4%):
Financial advisory and transactional services such as M&A, advice, equity/ debt issue management services, etc, Securitisation, and other loan services.
[6]
[7]
[8]
Key Ratios
Capital Adequacy Ratio - ~20% in FY24 vs 22.7% in FY22
NIM - ~5.3% in FY24% vs 4.6% in FY22
Gross NPA - 1.39% in FY24 vs 2.34% in FY22
Net NPA - 0.3% in FY24 vs 0.6% in FY22
CASA Ratio - 45.5% in FY24 vs 60.7% in FY22
[9]
[10]
[11]
Branch Network
As of FY24, the bank operates 1,900+ branches, 3,200+ ATMs, and 11 currency chests in India vs ~1,700 branches and ~2,700 ATMs in FY23.
[12]
West: 31%
North: 31%
South: 30%
East: 8%
[13]
International Presence
It has a global presence through its subsidiaries in the UK, USA, Gulf Region, Singapore, and Mauritius. It opened its first international branch in 2019 in Dubai.
[14]
[15]
Customer Base
As of FY24, the bank has a customer base of 5 Cr customers vs 3.27 Cr customers in FY22.
[16]
[17]
Loan Book
As of FY24, total advances stood at Rs. ~3,91,000 Cr vs Rs. ~2,71,000 Cr in FY22.
Advances Mix:
Consumer: 45%
Commercial: 23%
Corporate Banking: 22%
SME: 7%
Others: 2%
[18]
[19]
Deposits
As of FY24, total deposits stood at Rs. ~4,49,000 Cr vs Rs. 2,88,000 Cr in FY22.
[20]
[17]
Divestment
The company has sold a 70% stake in Kotak Mahindra General Insurance Company to Zurich Insurance Company Ltd for Rs. 5,560 Cr on Jun 24.
[21]
Acquisition
On Oct 23, the company acquired a 100% stake in Sonata Finance Pvt Ltd, an NBFC- MFI for Rs.~ 537 Cr.
[22]
Digital Advancement
The company has been focusing on digitizing its banking operations. 98%+ Savings account transactions are done through digital or non-branch modes. Out of the total server base, 75% is handled virtually.
[23]
RBI Restrictions
On Apr 24, RBI directed the company to cease, onboarding new customers through its online and mobile banking channels and issuing fresh credit cards. These actions were taken based on concerns arising out of the Reserve Bank’s IT Examination of the bank for the years 2022 and 2023 and the failure on the part of the bank to address these concerns.
[24]
Bank’s Plan
The Bank will increase its investments to fortify its IT systems and will focus on accelerating the execution of the comprehensive plan for core banking resilience.
[25]
Last edited 1 week, 4 days ago
Request an update
© Protected by Copyright
