About
[
edit
]
HDFC Bank Limited (also known as HDFC) is an Indian banking and financial services company headquartered in Mumbai. It is India's largest private sector bank by assets and the world's tenth-largest bank by market capitalization as of May 2024.
As of April 2024, HDFC Bank has a market capitalization of $145 billion, making it the third-largest company on the Indian stock exchanges.
[1]
Key Points
[
edit
]
Key Ratios - FY22
[1]
Capital Adequacy Ratio - 18.9%
Net Interest Margin - 4.12%
Gross NPA - 1.17%
Net NPA - 0.32%
CASA Ratio - 48%
Cost to Income ratio – 38.3%
Segment revenue - FY22
[2]
Treasury – 14%
Retail banking – 46%
Wholesale banking – 27%
Other banking operations – 13%
Location-wise breakup
[3]
Domestic - 99%
International - 1%
International Footprints
[4]
The Bank has offices and branches in Bahrain, Hong Kong, UAE, and Kenya where they offer NRI clients Offshore Deposits, Bonds, Equity, Mutual Funds, Treasury, and Structured products offered by third parties from Bahrain Branch. As on March 31, 2022, Balance Sheet size of International Business was US$7.66 Billion.
PAN India Presence
[5]
The Bank's network includes 21,683 Banking outlets comprising Branches (6342) and Business Correspondents (15,431), ATMs/ Cash Deposits, and Withdrawal Machines (18,130) spread across India as of FY22.
Loan Mix - FY22
[6]
Retail – 39%
CRB – 35%
Wholesale – 26%
Sector-wise loan breakup
[7]
Agriculture and allied activities – 26%
Advances to industries eligible as priority sector lending – 33%
Services – 32%
Personal loans – 9%
Leadership in the Payments business
[8]
HDFC is a leading player in the Payments ecosystem in the country. Every third rupee spent on cards in India happens on an HDFC Bank’s issued instrument.
They have issued almost 3.21 Crore debit cards and 1.45 Crore credit cards.
On the acquiring side currently they have over 17 Lakh merchant acceptance points across India. They have a dominant market share, with approximately 50% of electronic card volumes.
Leadership
HDFC Bank is the second largest collector of direct taxes.
[9]
Number 1 in middle-market banking with 60% market share.
[10]
One of the largest banking networks in semi-urban and rural India.
[11]
HDFC Bank continues to be a leader in the auto loans segment with strong presence in passenger, commercial vehicle and two-wheeler financing.
[12]
Market leader in almost every asset category with best-in-class portfolio quality.
[13]
Market leader in cash management services.
[13]
Market share
[14]
Advances – 11.2%
Deposits – 9.5%
Acquiring volumes – 46%
Credit Cards – 23%
Reach
[14]
Customer Base – 70 Mn+
Banking Branches – 6.3K+
Banking Outlets  - 21K+
Balance sheet size - 20,68,535 Cr
Amalgamation Proposal
[15]
Co. has proposed a scheme of amalgamation for the amalgamation of (i) HDFC Investments Limited and HDFC Holdings Limited, wholly-owned subsidiaries of Housing Development Finance Corporation Limited, with and into HDFC Limited, and (ii) HDFC Limited with and into HDFC Bank Limited. The Co. has received approval from the CCI and the RBI and the amalgamation is expected to be complete by the third quarter of FY24.
Fun fact
[16]
- HDFC Bank was the first bank in India to launch an International Debit Card in association with VISA (VISA Electron) and issues the MasterCard Maestro debit card as well.
Last edited 1 month ago
Request an update
© Protected by Copyright
