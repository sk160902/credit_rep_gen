# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/voltas-ltd/voltas/500575/corp-announcements/)
- [Intimation Under Regulation 30 Of SEBI (LODR) Regulations, 2015
16 Jul - Company has received an Order from the Office of the Joint Commissioner State -Tax, Patliputra Circle, Patna Commercial Taxes Department Bihar.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a340836c-ffe8-434f-9f69-bb0f5a8e98b6.pdf)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018
12 Jul - Certificate received from Link Intime India Private Limited, Company''s Registrar and Share Transfer Agent for the quarter ended 30th June, 2024, certifying compliance with Regulation …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28aa11fd-6de3-45f9-9fc5-9c6526888065.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3e20d76-a8ef-42e2-afae-15a4bec2f554.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88d62e9d-bab1-42e9-8b10-73ba170cf34c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57aadcdd-76fe-41e9-83c0-bbf45ef26593.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8727cbfa-a27a-411b-a8b1-56e7e0ed8379.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\7371fe96-bd18-43fe-bbb8-e50003066129.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/73030500575.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/69201500575.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_674_VOLTAS_2012_2013_22072013111246.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750311.pdf)

## Credit Ratings
- [Rating update
12 Jan from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=124800)
- [Rating update
4 Oct 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=122742)
- [Rating update
24 Aug 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=113950)
- [Rating update
26 Aug 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=105881)
- [Rating update
11 May 2020 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=94893)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=79100)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=de9d7ba7-5dd8-43ff-ae66-09e1a9cd9445.pdf)
- [REC](https://www.voltas.in/images/Investor/schedule-announcements/audio/Q4FY24InvestorCallRecording.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=30c69141-5f72-484d-8aa0-3dc46f7f7917.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7c53cc6d-09bf-4046-bfc0-450f38528cec.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d91454af-3408-4fc2-a18e-19ec11b52003.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=809d1a07-e507-49b4-8b66-1069f720fbba.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e25b9937-9d75-4ede-b8b0-4efe308b180f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=886dcbd5-2332-4065-867f-0090c329fca7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c67f27b8-0f8b-49c2-9871-e7c0a70b2fbf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8b1f98af-7b82-4c71-96a1-6508653c8b6e.pdf)

