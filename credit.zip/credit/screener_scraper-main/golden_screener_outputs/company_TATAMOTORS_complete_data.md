# Complete Company Data

## Modal Content
About
[
edit
]
Tata Motors Group is a leading global automobile manufacturer. Part of the illustrious multi-national conglomerate, the Tata group, it offers a wide and diverse portfolio of cars, sports utility vehicles, trucks, buses and defence vehicles to the world.
It has operations in India, the UK, South Korea, South Africa, China, Brazil, Austria and Slovakia through a strong global network of subsidiaries, associate companies and Joint Ventures (JVs), including Jaguar Land Rover in the UK and Tata Daewoo in South Korea.
[1]
Key Points
[
edit
]
Revenue Mix(FY24)
Jaguar Land Rover - 69.1%
Tata Commercial Vehicles - 18%
Tata Passenger Vehicles - 12%
Vehicles financing - 0.8%
Jaguar Land Rover Ltd.
Tata Motors Ltd (TML) bought British iconic brands Jaguar & Land Rover from Ford in 2008 and merged them together in 2013 to form one unified company.
[1]
. In H1FY24, order book remained strong with ~168k units, 77% of which are for RR, RRS & Defender.
[2]
New Range Rover & Range Rover Sport production continues to grow through new body shop in Solihull to be live in Q3FY24 and is expected to increase capacity by 30% over time.
[3]
Tata Commercial Vehicles
This includes Tata CV India, Tata Cummins and Tata CV International. The company has ~42% market share in FY23.
[4]
. In FY24, 223+ variants have been introduced.
[5]
Tata Passenger Vehicles
[6]
This includes  Tata PV, EV India,  FIAPL JO results and International business (PV + EV). VAHAN Domestic Market share in H1FY24 was 13.5%. The company has 287 dealers for EVs in 190+ cities in H1FY24 and ~75% market share in EV market. The charging infra also reached to ~77800 in H1FY24.
[7]
Capex
The company spent Rs. ~3781 crs. in H1FY24. Major expenditure was done on PV + EV segment. FY24 capex estimated at ~ Rs. 8,000 crs. as electrification investments step up.
[8]
Expansion
[9]
The company is expanding its manufacturing capacity after acquiring the facility from Ford in Sanand. The annual capacity of 300,000 units - scalable to 420,000 units. Industrialization of Sanand plant to begin in CY2024.
TPEM + JLR strategic collaboration
EMA platform to underpin the next generation of ‘pure electric’ mid-sized SUVs of JLR to be launched from 2025 onwards. JLR and TPEM have entered into an MOU for access to the EMA platform, including the E&E architecture, EDU, battery assembly and manufacturing
know-how for a royalty fee.
[10]
Robust Infrastructure.
The Group owns 10 manufacturing facilities in India, 5 in UK, 2 in Europe, and has also set up a manufacturing facility in China in a Joint Venture with Chery Automobiles. It also operates various R&D centres from UK, North America, Europe and India.
[11]
Acquisition in Freight Tiger
TaMo acquired ~27% stake in Freight Tiger in H1FY24 for Rs. 150 crs. Fleet Edge + Freight Tiger to provide an end-to-end solution by integrating the truck and trip eco-systems. In next 2-3 years, TaMo plans to invest an additional Rs. 100 Cr and buy out other investors by FY29 .
[12]
IPO of Tata Technologies
[13]
In Nov,23, Tata Technologies (a subsidiary of Tata Motors) issued its IPO at offer price of Rs. 500/-. IPO aggregated to ~Rs. 30,000 mn, comprising of an offer for sale of 46,275,000 Equity Shares by the Company amounting to Rs. 23,137.50 mn, 9,716,853 Equity Shares by Alpha TC Holdings Pte. Ltd. amounting to Rs. 4,858.43 mn and 4,858,425 Equity Shares by Tata Capital Growth Fund I amounting to Rs. 2,429.21 mn. Consequently, Company’s shareholding in Tata Technologies Limited reduced
from 64.79% to 53.39%.
[14]
Last edited 1 month ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 188,793 | 232,834 | 263,159 | 273,046 | 269,693 | 291,550 | 301,938 | 261,068 | 249,795 | 278,454 | 345,967 | 437,928 |
| Expenses + | 164,197 | 197,980 | 223,920 | 234,650 | 240,104 | 260,093 | 277,274 | 243,081 | 217,507 | 253,734 | 314,151 | 378,389 |
| Operating Profit | 24,596 | 34,853 | 39,239 | 38,395 | 29,589 | 31,458 | 24,664 | 17,987 | 32,287 | 24,720 | 31,816 | 59,538 |
| OPM % | 13% | 15% | 15% | 14% | 11% | 11% | 8% | 7% | 13% | 9% | 9% | 14% |
| Other Income + | 213 | -157 | 714 | -2,670 | 1,869 | 5,933 | -26,686 | 102 | -11,118 | 2,424 | 6,664 | 5,673 |
| Interest | 3,560 | 4,749 | 4,861 | 4,889 | 4,238 | 4,682 | 5,759 | 7,243 | 8,097 | 9,312 | 10,225 | 9,986 |
| Depreciation | 7,601 | 11,078 | 13,389 | 16,711 | 17,905 | 21,554 | 23,591 | 21,425 | 23,547 | 24,836 | 24,860 | 27,270 |
| Profit before tax | 13,647 | 18,869 | 21,703 | 14,126 | 9,315 | 11,155 | -31,371 | -10,580 | -10,474 | -7,003 | 3,394 | 27,955 |
| Tax % | 28% | 25% | 35% | 21% | 35% | 39% | -8% | 4% | 24% | 60% | 21% | -14% |
| Net Profit + | 9,976 | 14,050 | 14,073 | 11,678 | 7,557 | 9,091 | -28,724 | -11,975 | -13,395 | -11,309 | 2,690 | 31,807 |
| EPS in Rs | 34.62 | 48.46 | 48.44 | 40.11 | 25.82 | 31.13 | -99.84 | -39.08 | -40.51 | -34.46 | 7.27 | 94.47 |
| Dividend Payout % | 6% | 5% | 0% | 1% | 0% | 0% | 0% | 0% | 0% | 0% | 32% | 15% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 93% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 128% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1266% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 49% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 69% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 49% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata Sons Pvt. Ltd., its subsidiaries and joint ventures |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  |  |  |  | 5,494 | 3,149 |  |  |  |  |
| Finance taken (including loans and equity) |  |  |  |  |  | 4,561 |  |  |  |  |
| Services received |  |  |  |  | 1,867 | 1,560 |  |  |  |  |
| Sale of products |  |  |  |  | 828 | 848 |  |  |  |  |
| Finance taken, paid back (including loans and equity) |  |  |  |  |  | 858 |  |  |  |  |
| Sale of Investments |  |  |  |  | 533 |  |  |  |  |  |
| Trade payables |  |  |  |  | 373 | 158 |  |  |  |  |
| Trade and other receivables |  |  |  |  | 199 | 189 |  |  |  |  |
| Purchase of products |  |  |  |  | 203 | 43 |  |  |  |  |
| Services rendered |  |  |  |  | 116 | 81 |  |  |  |  |
| Acceptances |  |  |  |  | 69 | 77 |  |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  | 95 |  |  |  |  |
| Interest (income)/expense, dividend (income)/paid.(net) |  |  |  |  |  | 29 |  |  |  |  |
| Interest (income)/expense, dividend (income)/ paid, (net) |  |  |  |  | 23 |  |  |  |  |  |
| Amounts payable in respect of loans and interest thereon |  |  |  |  | 3.60 | 1.93 |  |  |  |  |
| Amount receivable in respect of Loans and interest thereon |  |  |  |  |  | 4.18 |  |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  |  |  |  | 3.80 |  |  |  |  |  |
| Finance given, taken back (including loans and equity) |  |  |  |  |  | 3.50 |  |  |  |  |
| Purchase of property, plant and equipment |  |  |  |  | 0.80 | 2.37 |  |  |  |  |
| Tata Sons Ltd |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  | 2,902 | 3,203 |  |  |  |  |  |  |  |
| Services received | 1.94 | 1,850 | 1,970 |  |  |  |  |  |  |  |
| Loans taken/repaid |  | 918 | 1,217 |  |  |  |  |  |  |  |
| Proceeds from issue of shares |  | 1,967 |  |  |  |  |  |  |  |  |
| Sale of products |  | 757 | 462 |  |  |  |  |  |  |  |
| Trade payables |  | 163 | 471 |  |  |  |  |  |  |  |
| Trade and other receivables |  | 455 | 160 |  |  |  |  |  |  |  |
| Services rendered |  | 112 | 130 |  |  |  |  |  |  |  |
| Loans given/repaid |  | 125 | 91 |  |  |  |  |  |  |  |
| Amounts payable in respect of loans and interest thereon |  | 106 | 106 |  |  |  |  |  |  |  |
| Purchase of products |  | 67 | 67 |  |  |  |  |  |  |  |
| Interest income dividend income(net) |  | 38 | 64 |  |  |  |  |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  | 35 | 9.33 |  |  |  |  |  |  |  |
| Sale of Investments |  | 7.15 |  |  |  |  |  |  |  |  |
| Deposit given as security |  | 3 | 3 |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  | 0.92 | 0.11 |  |  |  |  |  |  |  |
| Dividend received | -0.99 |  |  |  |  |  |  |  |  |  |
| Tata Sons Pvt Ltd, its subsidiaries and joint ventures |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  |  |  |  |  |  | 5,947 |  |  |  |
| Finance taken - including loans and equity |  |  |  |  |  |  | 2,603 |  |  |  |
| Services received |  |  |  |  |  |  | 1,425 |  |  |  |
| Sale of products |  |  |  |  |  |  | 946 |  |  |  |
| Acceptances |  |  |  |  |  |  | 929 |  |  |  |
| Trade and other receivables |  |  |  |  |  |  | 348 |  |  |  |
| Trade payables |  |  |  |  |  |  | 222 |  |  |  |
| Services rendered |  |  |  |  |  |  | 170 |  |  |  |
| Interest expense, dividend /paid, - net |  |  |  |  |  |  | 59 |  |  |  |
| Finance given - including loans and equity |  |  |  |  |  |  | 41 |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  |  | 34 |  |  |  |
| Purchase of products |  |  |  |  |  |  | 28 |  |  |  |
| Amounts payable in respect of loans and interest thereon |  |  |  |  |  |  | 6.07 |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  |  |  |  |  |  | 4.59 |  |  |  |
| Purchase of property, plant and equipment |  |  |  |  |  |  | 3.72 |  |  |  |
| Tata Capital |  |  |  |  |  |  |  |  |  |  |
| Vendor bills discounting |  |  |  |  |  |  | 5,947 |  |  |  |
| Bill discounted |  |  |  | 4,135 |  |  |  |  |  |  |
| Chery Jaguar Land Rover Automotive Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Services rendered | 11 |  |  | 1,208 | 765 | 960 | 1,077 |  |  |  |
| Sale of goods (inclusive of sales tax) | 74 |  |  |  |  |  |  |  |  |  |
| Tata Sons Pvt. Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Preferential allotment |  |  |  |  |  | 3,892 |  |  |  |  |
| Tata Sons Pvt Ltd Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Converstion of Warrant/ Preferential allotment |  |  |  |  |  |  | 2,603 |  |  |  |
| Fiat India Automobiles Private Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 150 |  |  |  |  |  |  |  |  |  |
| Sale of goods (inclusive of sales tax) | 53 |  |  |  |  |  |  |  |  |  |
| Interest received | -1.30 |  |  |  |  |  |  |  |  |  |
| Tata Cummins Private Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 117 |  |  |  |  |  |  |  |  |  |
| Tata AutoComp Systems Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 117 |  |  |  |  |  |  |  |  |  |
| Dividend received | -1.05 |  |  |  |  |  |  |  |  |  |
| Automobile Corporation of Goa Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 38 |  |  |  |  |  |  |  |  |  |
| Inter-corporate deposits | 6.40 |  |  |  |  |  |  |  |  |  |
| Nita Company Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods (inclusive of sales tax) | 14 |  |  |  |  |  |  |  |  |  |
| Spark 44 (JV) Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Services received | 4.58 |  |  |  |  |  |  |  |  |  |
| Tata Hitachi Construction Machinery Company Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Services rendered | 0.79 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 188,793 | 232,834 | 263,159 | 273,046 | 269,693 | 291,550 | 301,938 | 261,068 | 249,795 | 278,454 | 345,967 | 437,928 |
| Expenses + | 164,197 | 197,980 | 223,920 | 234,650 | 240,104 | 260,093 | 277,274 | 243,081 | 217,507 | 253,734 | 314,151 | 378,389 |
| Operating Profit | 24,596 | 34,853 | 39,239 | 38,395 | 29,589 | 31,458 | 24,664 | 17,987 | 32,287 | 24,720 | 31,816 | 59,538 |
| OPM % | 13% | 15% | 15% | 14% | 11% | 11% | 8% | 7% | 13% | 9% | 9% | 14% |
| Other Income + | 213 | -157 | 714 | -2,670 | 1,869 | 5,933 | -26,686 | 102 | -11,118 | 2,424 | 6,664 | 5,673 |
| Interest | 3,560 | 4,749 | 4,861 | 4,889 | 4,238 | 4,682 | 5,759 | 7,243 | 8,097 | 9,312 | 10,225 | 9,986 |
| Depreciation | 7,601 | 11,078 | 13,389 | 16,711 | 17,905 | 21,554 | 23,591 | 21,425 | 23,547 | 24,836 | 24,860 | 27,270 |
| Profit before tax | 13,647 | 18,869 | 21,703 | 14,126 | 9,315 | 11,155 | -31,371 | -10,580 | -10,474 | -7,003 | 3,394 | 27,955 |
| Tax % | 28% | 25% | 35% | 21% | 35% | 39% | -8% | 4% | 24% | 60% | 21% | -14% |
| Net Profit + | 9,976 | 14,050 | 14,073 | 11,678 | 7,557 | 9,091 | -28,724 | -11,975 | -13,395 | -11,309 | 2,690 | 31,807 |
| EPS in Rs | 34.62 | 48.46 | 48.44 | 40.11 | 25.82 | 31.13 | -99.84 | -39.08 | -40.51 | -34.46 | 7.27 | 94.47 |
| Dividend Payout % | 6% | 5% | 0% | 1% | 0% | 0% | 0% | 0% | 0% | 0% | 32% | 15% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 93% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 128% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1266% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 49% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 69% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 49% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 22,163 | 36,151 | 35,531 | 37,900 | 30,199 | 23,857 | 18,891 | 26,633 | 29,001 | 14,283 | 35,388 | 67,915 |
| Cash from Investing Activity + | -22,969 | -27,991 | -36,232 | -36,694 | -39,571 | -25,139 | -20,878 | -33,115 | -25,672 | -4,444 | -15,417 | -22,782 |
| Cash from Financing Activity + | -1,692 | -3,883 | 5,201 | -3,795 | 6,205 | 2,012 | 8,830 | 3,390 | 9,904 | -3,380 | -26,243 | -37,006 |
| Net Cash Flow | -2,499 | 4,277 | 4,500 | -2,589 | -3,167 | 730 | 6,843 | -3,092 | 13,232 | 6,459 | -6,272 | 8,128 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 21 | 17 | 17 | 18 | 19 | 25 | 23 | 16 | 19 | 16 | 17 | 14 |
| Inventory Days | 64 | 69 | 67 | 73 | 77 | 83 | 73 | 82 | 83 | 71 | 66 | 64 |
| Days Payable | 137 | 146 | 131 | 138 | 138 | 151 | 133 | 145 | 175 | 141 | 128 | 126 |
| Cash Conversion Cycle | -51 | -60 | -47 | -46 | -41 | -43 | -38 | -48 | -74 | -53 | -45 | -48 |
| Working Capital Days | -57 | -41 | -44 | -47 | -50 | -50 | -53 | -68 | -48 | -32 | -24 | -24 |
| ROCE % | 21% | 22% | 21% | 15% | 9% | 9% | 2% | -0% | 6% | 1% | 6% | 20% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 46.41% | 46.40% | 46.40% | 46.40% | 46.40% | 46.39% | 46.39% | 46.39% | 46.38% | 46.37% | 46.36% | 46.36% |
| FIIs + | 13.35% | 14.57% | 14.45% | 13.71% | 14.13% | 13.89% | 15.34% | 17.72% | 18.40% | 18.62% | 19.20% | 18.18% |
| DIIs + | 13.30% | 13.64% | 14.38% | 15.17% | 14.75% | 15.21% | 17.69% | 17.38% | 17.37% | 17.25% | 16.01% | 15.93% |
| Government + | 0.15% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% | 0.14% |
| Public + | 26.80% | 25.24% | 24.62% | 24.57% | 24.58% | 24.36% | 20.41% | 18.38% | 17.70% | 17.60% | 18.31% | 19.39% |
| No. of Shareholders | 26,95,590 | 32,52,513 | 37,97,100 | 40,08,506 | 39,76,830 | 39,93,043 | 38,14,831 | 35,02,408 | 37,73,314 | 41,84,369 | 46,16,908 | 50,98,550 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 34.73% | 36.37% | 38.37% | 42.39% | 46.41% | 46.40% | 46.39% | 46.36% | 46.36% |
| FIIs + | 23.24% | 20.26% | 19.14% | 16.84% | 13.78% | 14.45% | 15.34% | 19.20% | 18.18% |
| DIIs + | 15.35% | 17.50% | 16.10% | 13.42% | 11.91% | 14.38% | 17.69% | 16.01% | 15.93% |
| Government + | 0.13% | 0.16% | 0.17% | 0.16% | 0.15% | 0.14% | 0.14% | 0.14% | 0.14% |
| Public + | 26.56% | 25.71% | 26.22% | 27.19% | 27.75% | 24.62% | 20.41% | 18.31% | 19.39% |
| No. of Shareholders | 5,05,495 | 7,23,869 | 10,88,172 | 13,54,298 | 20,38,757 | 37,97,100 | 38,14,831 | 46,16,908 | 50,98,550 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/tata-motors-ltd/tatamotors/500570/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac3751f4-c163-438d-abc8-790a54405490.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation
19 Jul - Read with Schedule III of Part A of para A of the SEBI (LODR) Regulations, 2015 and with further reference to our letter bearing sc …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d134a6fb-ee5a-4ca8-aee3-572188a741b2.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 18 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=090a4611-19e4-42de-b980-580f136c92d3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ccf6d5c2-2b2b-4e2f-a816-2332b4002462.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23bd9f51-3d07-4e7b-9303-6e000dd0b052.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0913b647-b205-4a3c-ad9b-8c493f97f972.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b089df52-72ff-4b10-9c63-8375fa1f7d7e.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500570/73198500570.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500570/68662500570_30_06_21.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_792_TATAMOTORS_2012_2013_29072013120804.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700311.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/apr-2015/tata-motors-limited_29517.html)

## Credit Ratings
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407140700_Tata_Motors_Limited.pdf)
- [Rating update
13 Jun from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128075)
- [Rating update
13 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TataMotorsLimited_June%2013_%202024_RR_345536.html)
- [Rating update
2 Apr from care](https://www.careratings.com/upload/CompanyFiles/PR/202404130426_Tata_Motors_Limited.pdf)
- [Rating update
13 Mar from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=126168)
- [](https://www.careratings.com/upload/CompanyFiles/PR/202403150317_Tata_Motors_Limited.pdf)

## Concalls
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/06/tata-motors-group-investor-day-presentation.pdf)
- [Transcript](https://www.bseindia.com/xml-data/corpfiling/AttachLive/cfd0020f-d9cc-4148-9606-10eb86705ffd.pdf)
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/05/q4fy24-presentation-1.pdf)
- [PPT](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/05/q4fy24-presentation-1.pdf)
- [Transcript](https://www.bseindia.com/xml-data/corpfiling/AttachHis/c11e47a4-1619-4267-ab64-7a9a14e11ed8.pdf)
- [PPT](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/02/Tata-Motors-Investor-presentation-Q3-FY24.pdf)
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/02/Tata-Motors-Investor-presentation-Q3-FY24.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3a82121b-4528-440d-ad7f-22728f47a946.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ceb2ac38-d83d-4813-9e2f-00a2cff253c0.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/11/q2fy24-presentation.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/07/tata-motors-group-earnings-call-transcript-q1-fy24.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f58e98cb-d41f-4c7d-94eb-b3975f3d31d5.pdf)
- [](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/01/q1fy24-earnings-call-transcript.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/07/tata-motors-group-investor-presentation-Q1FY24.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0c81a1b7-bdef-4df1-bd2e-7cb362f50beb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d3a17db2-17f5-43db-b69c-d272318bf3b7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f4edb2c0-78a7-4290-8dea-57f978bb853d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a16e0aea-e5b0-499e-a8a5-f0911a51e244.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94c9b207-6c8c-4952-b062-f2066cb94cd7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b0c9d9f9-4979-497e-8d29-b2f0ccf23fdb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5fd9edb5-f6fe-4b62-995e-064e36132674.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfe41f3c-ac3b-44b4-8fb0-ed1053c02ac9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b95fcfc0-d452-417f-bb4f-e20ea498ad12.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=27b1a9d0-5db1-4b19-a21e-b1a1cb7d4bba.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=937faf1d-7146-49da-a10e-d51814b31845.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d63bde0d-0952-4676-88a6-6d33b4bb2fc1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1663bbdd-d52f-4b86-8748-f1bd32c2a511.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8f9c4280-a237-4f49-9330-8a4e248ec7aa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9ce25fee-c848-4a6b-909b-698598cd175a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=155a79a8-fe08-44fe-bff0-d40f096a4b19.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2022/02/Q3-FY22-earnings-call-transcript.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/11/tata-motors-q2-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d17cbf0c-457f-4102-ae50-a849dedf1088.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3e09439f-c4dc-425b-8426-8cb2cfabbec4.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/10/22093739/ev-business-analyst-investor-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=edb3c3f4-8baa-4472-b2e4-17400549c8bd.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/08/03093742/Earnings-Call-Transcript-Q1FY22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8859359d-1248-468e-b7e4-aa9974c5e124.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/05/31080653/tata-motors-group-analyst-call-transcript-q4fy21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5cc79501-158a-4991-bc24-5650ba5b4b0b.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/02/05110935/TATA-Motors-Analyst-Jan29-2021.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2020/11/04071425/TM-Concall-Transcript-Q2FY21.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2020/08/14045300/Tata-Motors-Webcast-Audio-31-July-2020.pdf)
- [](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/03/Results-Concall-Transcript-TML-Q1-FY-17.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Tata Motors | 1117.90 | 410524.09 | 12.73 | 4.32 | 0.94 | 21.23 | 7.13 | 49.28 | 0.27 | 20.11 | 9.26 | 49.44 | 1.24 | 1.26 | 3.90 | 4.15 | 437927.77 | 13.60 | 32193.28 | 119986.31 | 17482.35 | 13.27 | 213.80 | 94.47 | 107262.50 | 46.36 | 0.00 | 8.42 | 27.33 | 0.00 | 26.58 | 1265.71 | 471979.90 | 0.88 | 0.14 | 9.15 | 34.38 | 55.28 | 69.48 | 14.63 | 5.84 | 93.11 | 128.07 | 7.72 | 20.58 | 5.25 | 6.30 | 0.61 | 94.47 | 88.17 | 18.77 | 18.55 | 18.03 | -47.68 | 332.13 |
| 2. | Ashok Leyland | 246.55 | 72397.70 | 28.98 | 7.99 | 1.55 | -21.18 | 12.57 | 25.65 | 1.97 | 15.01 | 4.42 | 28.35 | 0.75 | 4.53 | 2.32 | 6.79 | 46823.81 | 17.73 | 2497.57 | 10724.49 | 506.40 | 10.66 | -6.17 | 8.34 | 40802.18 | 51.42 | -0.02 | 7.36 | 27.33 | 22.10 | 9.16 | 44.00 | 106119.83 | 1.05 | 7.17 | 25.64 | 36.92 | 23.83 | 27.78 | 15.68 | 10.07 | 4.04 | 205.53 | 6.64 | 33.02 | 15.05 | 11.44 | 0.90 | 8.46 | 4.04 | 27.21 | 35.66 | 22.64 | -3.77 | 293.61 |
| 3. | Tata Motors-DVR | 765.10 | 38905.63 |  |  |  |  |  | 60.16 | 0.40 |  |  |  |  |  |  |  |  |  |  | 7769.67 | 1251.40 | -26.91 | 372.94 |  |  | 7.67 | 0.00 |  | 27.33 | 0.00 |  |  |  |  |  | 11.08 | 38.91 | 76.72 | 78.21 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 4. | Olectra Greentec | 1712.10 | 14053.05 | 182.92 | 15.41 | 12.18 | 987.10 | 75.47 | 55.43 | 0.02 | 14.79 | 5.00 | 8.76 | 0.73 | 0.13 | 3.46 | 1.72 | 1154.14 | 14.37 | 76.83 | 288.81 | 13.71 | -23.17 | -49.24 | 9.36 | 120.75 | 50.02 | 0.00 | 1.07 | 27.33 | 0.00 | 5.81 | 17.15 | 13999.26 | 1.88 | 3.93 | -2.50 | 0.23 | 85.44 | 40.22 | 7.34 | 4.82 | 46.55 | 111.68 | 46.66 | 60.07 | 8.11 | 13.29 | 1.53 | 9.36 | 45.87 | 148.84 | 146.69 | 124.71 | 85.59 | 8.21 |
| 5. | Force Motors | 8488.35 | 11187.63 | 28.81 | 5.02 | 1.60 | 43.73 | 12.06 | 48.29 | 0.11 | 23.77 | 9.21 | 18.79 | 1.66 | 0.23 | 10.74 | 1.87 | 6992.13 | 12.80 | 388.09 | 2011.21 | 140.26 | 34.96 | 259.90 | 294.54 | 524.50 | 61.63 | 0.00 | 6.12 | 27.33 | 0.00 | 39.04 | 1119.40 | 11263.37 | 1.25 | 1.31 | -14.54 | 133.09 | 75.30 | 223.37 | 5.79 | 3.23 | 22.06 | 79.99 | 13.87 | 52.07 | 1.76 | 4.73 | 0.54 | 294.54 | 22.06 | 25.66 | 31.57 | 20.13 | 27.43 | 1.32 |
| 6. | SML ISUZU | 2050.00 | 2966.33 | 27.53 | 10.39 | 1.35 | -117.78 | 18.11 | 26.51 | 0.00 | 23.81 | 10.04 | 46.55 | 2.04 | 1.48 | 4.51 | 3.76 | 2195.93 | 8.15 | 107.88 | 679.60 | 52.32 | 16.53 | 95.30 | 74.55 | 421.27 | 43.96 | 0.00 | 4.17 | 27.33 | 0.00 | 20.55 | 443.75 | 3338.91 | 1.01 | 0.67 | -10.80 | 54.91 | 52.16 | 92.12 | 4.58 | -9.55 | 40.87 | 41.06 | 9.28 | 54.88 | 11.69 | 9.39 | 0.30 | 74.55 | 40.87 | 49.47 | 35.16 | 57.54 | 81.38 | 1.45 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | Sales | ₹ 4,37,928 Cr. |
| TATAMOTORS | OPM | 13.6 % |
| TATAMOTORS | Profit after tax | ₹ 32,193 Cr. |
| TATAMOTORS | Mar Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Sales Qtr | ₹ 1,19,986 Cr. |
| TATAMOTORS | PAT Qtr | ₹ 17,482 Cr. |
| TATAMOTORS | Qtr Sales Var | 13.3 % |
| TATAMOTORS | Qtr Profit Var | 214 % |
| TATAMOTORS | Price to Earning | 12.7 |
| TATAMOTORS | Dividend yield | 0.27 % |
| TATAMOTORS | Price to book value | 4.32 |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | Return on assets | 9.26 % |
| TATAMOTORS | Debt to equity | 1.26 |
| TATAMOTORS | Return on equity | 49.4 % |
| TATAMOTORS | EPS | ₹ 94.5 |
| TATAMOTORS | Debt | ₹ 1,07,262 Cr. |
| TATAMOTORS | Promoter holding | 46.4 % |
| TATAMOTORS | Change in Prom Hold | 0.00 % |
| TATAMOTORS | Earnings yield | 8.42 % |
| TATAMOTORS | Pledged percentage | 0.00 % |
| TATAMOTORS | Industry PE | 27.3 |
| TATAMOTORS | Sales growth | 26.6 % |
| TATAMOTORS | Profit growth | 1,266 % |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | Price to Sales | 0.94 |
| TATAMOTORS | CMP / FCF | 21.2 |
| TATAMOTORS | EVEBITDA | 7.13 |
| TATAMOTORS | Enterprise Value | ₹ 4,72,035 Cr. |
| TATAMOTORS | Current ratio | 0.88 |
| TATAMOTORS | Int Coverage | 3.90 |
| TATAMOTORS | PEG Ratio | 0.14 |
| TATAMOTORS | Return over 3months | 9.15 % |
| TATAMOTORS | Return over 6months | 34.4 % |
| TATAMOTORS | No. Eq. Shares | 332 |
| TATAMOTORS | Sales growth 3Years | 20.6 % |
| TATAMOTORS | Sales growth 5Years | 7.72 % |
| TATAMOTORS | Profit Var 3Yrs | 128 % |
| TATAMOTORS | Profit Var 5Yrs | 93.1 % |
| TATAMOTORS | ROE 5Yr | 5.84 % |
| TATAMOTORS | ROE 3Yr | 14.6 % |
| TATAMOTORS | Return over 1year | 69.5 % |
| TATAMOTORS | Return over 3years | 55.3 % |
| TATAMOTORS | Return over 5years | 49.3 % |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | Sales last year | ₹ 4,37,928 Cr. |
| TATAMOTORS | OP Ann | ₹ 59,538 Cr. |
| TATAMOTORS | Other Inc Ann | ₹ 5,673 Cr. |
| TATAMOTORS | EBIDT last year | ₹ 66,188 Cr. |
| TATAMOTORS | Dep Ann | ₹ 27,270 Cr. |
| TATAMOTORS | EBIT last year | ₹ 38,918 Cr. |
| TATAMOTORS | Interest last year | ₹ 9,986 Cr. |
| TATAMOTORS | PBT Ann | ₹ 27,955 Cr. |
| TATAMOTORS | Tax last year | ₹ -3,852 Cr. |
| TATAMOTORS | PAT Ann | ₹ 32,193 Cr. |
| TATAMOTORS | Extra Ord Item Ann | ₹ -977 Cr. |
| TATAMOTORS | NP Ann | ₹ 31,807 Cr. |
| TATAMOTORS | Dividend last year | ₹ 4,676 Cr. |
| TATAMOTORS | Raw Material | 62.3 % |
| TATAMOTORS | Employee cost | ₹ 42,487 Cr. |
| TATAMOTORS | OPM last year | 13.6 % |
| TATAMOTORS | NPM last year | 7.45 % |
| TATAMOTORS | Operating profit | ₹ 59,538 Cr. |
| TATAMOTORS | Interest | ₹ 9,986 Cr. |
| TATAMOTORS | Depreciation | ₹ 27,270 Cr. |
| TATAMOTORS | EPS last year | ₹ 94.5 |
| TATAMOTORS | EBIT | ₹ 38,918 Cr. |
| TATAMOTORS | Net profit | ₹ 31,807 Cr. |
| TATAMOTORS | Current Tax | ₹ 4,937 Cr. |
| TATAMOTORS | Tax | ₹ -3,852 Cr. |
| TATAMOTORS | Other income | ₹ 5,673 Cr. |
| TATAMOTORS | Ann Date | 2,02,403 |
| TATAMOTORS | Sales Prev Ann | ₹ 3,45,967 Cr. |
| TATAMOTORS | OP Prev Ann | ₹ 31,816 Cr. |
| TATAMOTORS | Other Inc Prev Ann | ₹ 6,664 Cr. |
| TATAMOTORS | EBIDT Prev Ann | ₹ 36,889 Cr. |
| TATAMOTORS | Dep Prev Ann | ₹ 24,860 Cr. |
| TATAMOTORS | EBIT preceding year | ₹ 12,029 Cr. |
| TATAMOTORS | Interest Prev Ann | ₹ 10,225 Cr. |
| TATAMOTORS | PBT Prev Ann | ₹ 3,394 Cr. |
| TATAMOTORS | Tax preceding year | ₹ 704 Cr. |
| TATAMOTORS | PAT Prev Ann | ₹ 2,357 Cr. |
| TATAMOTORS | Extra Ord Prev Ann | ₹ 1,591 Cr. |
| TATAMOTORS | NP Prev Ann | ₹ 2,690 Cr. |
| TATAMOTORS | Dividend Prev Ann | ₹ 766 Cr. |
| TATAMOTORS | OPM preceding year | 9.20 % |
| TATAMOTORS | NPM preceding year | 0.76 % |
| TATAMOTORS | EPS preceding year | ₹ 7.27 |
| TATAMOTORS | Sales Prev 12M | ₹ 4,23,874 Cr. |
| TATAMOTORS | Profit Prev 12M | ₹ 19,774 Cr. |
| TATAMOTORS | Med Sales Gwth 10Yrs | 3.76 % |
| TATAMOTORS | Med Sales Gwth 5Yrs | 11.5 % |
| TATAMOTORS | Sales growth 7Years | 7.17 % |
| TATAMOTORS | Sales Var 10Yrs | 6.52 % |
| TATAMOTORS | EBIDT growth 3Years | 24.0 % |
| TATAMOTORS | EBIDT growth 5Years | 19.2 % |
| TATAMOTORS | EBIDT growth 7Years | 11.9 % |
| TATAMOTORS | EBIDT Var 10Yrs | 6.41 % |
| TATAMOTORS | EPS growth 3Years | 128 % |
| TATAMOTORS | EPS growth 5Years | 88.2 % |
| TATAMOTORS | EPS growth 7Years | 22.8 % |
| TATAMOTORS | EPS growth 10Years | 6.69 % |
| TATAMOTORS | Profit Var 7Yrs | 25.3 % |
| TATAMOTORS | Profit Var 10Yrs | 8.20 % |
| TATAMOTORS | Chg in Prom Hold 3Yr | -0.05 % |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | OP Qtr | ₹ 17,135 Cr. |
| TATAMOTORS | Other Inc Qtr | ₹ 1,618 Cr. |
| TATAMOTORS | EBIDT Qtr | ₹ 18,842 Cr. |
| TATAMOTORS | Dep Qtr | ₹ 7,151 Cr. |
| TATAMOTORS | EBIT latest quarter | ₹ 11,691 Cr. |
| TATAMOTORS | Interest Qtr | ₹ 2,234 Cr. |
| TATAMOTORS | PBT Qtr | ₹ 9,369 Cr. |
| TATAMOTORS | Tax latest quarter | ₹ -8,159 Cr. |
| TATAMOTORS | Extra Ord Item Qtr | ₹ -88.1 Cr. |
| TATAMOTORS | NP Qtr | ₹ 17,529 Cr. |
| TATAMOTORS | GPM latest quarter | 38.5 % |
| TATAMOTORS | OPM latest quarter | 14.3 % |
| TATAMOTORS | NPM latest quarter | 14.7 % |
| TATAMOTORS | Eq Cap Qtr | ₹ 766 Cr. |
| TATAMOTORS | EPS latest quarter | ₹ 52.4 |
| TATAMOTORS | OP 2Qtr Bk | ₹ 13,767 Cr. |
| TATAMOTORS | OP 3Qtr Bk | ₹ 13,218 Cr. |
| TATAMOTORS | Sales 2Qtr Bk | ₹ 1,05,128 Cr. |
| TATAMOTORS | Sales 3Qtr Bk | ₹ 1,02,236 Cr. |
| TATAMOTORS | NP 2Qtr Bk | ₹ 3,832 Cr. |
| TATAMOTORS | NP 3Qtr Bk | ₹ 3,301 Cr. |
| TATAMOTORS | Opert Prft Gwth | 87.1 % |
| TATAMOTORS | Last result date | 2,02,403 |
| TATAMOTORS | Exp Qtr Sales Var | 27.5 % |
| TATAMOTORS | Exp Qtr Sales | ₹ 1,30,316 Cr. |
| TATAMOTORS | Exp Qtr OP | ₹ 17,398 Cr. |
| TATAMOTORS | Exp Qtr NP | ₹ 7,036 Cr. |
| TATAMOTORS | Exp Qtr EPS | ₹ 21.0 |
| TATAMOTORS | Sales Prev Qtr | ₹ 1,10,577 Cr. |
| TATAMOTORS | OP Prev Qtr | ₹ 15,418 Cr. |
| TATAMOTORS | Other Inc Prev Qtr | ₹ 1,604 Cr. |
| TATAMOTORS | EBIDT Prev Qtr | ₹ 17,110 Cr. |
| TATAMOTORS | Dep Prev Qtr | ₹ 6,850 Cr. |
| TATAMOTORS | EBIT Prev Qtr | ₹ 10,260 Cr. |
| TATAMOTORS | Interest Prev Qtr | ₹ 2,485 Cr. |
| TATAMOTORS | PBT Prev Qtr | ₹ 7,687 Cr. |
| TATAMOTORS | Tax Prev Qtr | ₹ 542 Cr. |
| TATAMOTORS | PAT Prev Qtr | ₹ 7,099 Cr. |
| TATAMOTORS | Extra Ord Prev Qtr | ₹ -88.3 Cr. |
| TATAMOTORS | NP Prev Qtr | ₹ 7,145 Cr. |
| TATAMOTORS | OPM Prev Qtr | 13.9 % |
| TATAMOTORS | NPM Prev Qtr | 6.53 % |
| TATAMOTORS | Eq Cap Prev Qtr | ₹ 766 Cr. |
| TATAMOTORS | EPS Prev Qtr | ₹ 21.1 |
| TATAMOTORS | Sales PY Qtr | ₹ 1,05,932 Cr. |
| TATAMOTORS | OP PY Qtr | ₹ 13,114 Cr. |
| TATAMOTORS | Other Inc PY Qtr | ₹ 1,453 Cr. |
| TATAMOTORS | EBIDT PY Qtr | ₹ 14,783 Cr. |
| TATAMOTORS | Dep PY Qtr | ₹ 7,050 Cr. |
| TATAMOTORS | EBIT PY Qtr | ₹ 7,732 Cr. |
| TATAMOTORS | Interest PY Qtr | ₹ 2,642 Cr. |
| TATAMOTORS | PBT PY Qtr | ₹ 4,875 Cr. |
| TATAMOTORS | Tax PY Qtr | ₹ -621 Cr. |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | Equity capital | ₹ 766 Cr. |
| TATAMOTORS | Preference capital | ₹ 0.00 Cr. |
| TATAMOTORS | Reserves | ₹ 84,152 Cr. |
| TATAMOTORS | Secured loan | ₹ 24,643 Cr. |
| TATAMOTORS | Unsecured loan | ₹ 82,620 Cr. |
| TATAMOTORS | Balance sheet total | ₹ 3,69,521 Cr. |
| TATAMOTORS | Gross block | ₹ 3,34,482 Cr. |
| TATAMOTORS | Revaluation reserve | ₹ 0.00 Cr. |
| TATAMOTORS | Accum Dep | ₹ 2,13,197 Cr. |
| TATAMOTORS | Net block | ₹ 1,21,285 Cr. |
| TATAMOTORS | CWIP | ₹ 35,698 Cr. |
| TATAMOTORS | Investments | ₹ 22,971 Cr. |
| TATAMOTORS | Current assets | ₹ 1,53,465 Cr. |
| TATAMOTORS | Current liabilities | ₹ 1,73,617 Cr. |
| TATAMOTORS | BV Unq Invest | ₹ 0.00 Cr. |
| TATAMOTORS | MV Quoted Inv | ₹ 2,301 Cr. |
| TATAMOTORS | Cont Liab | ₹ 8,014 Cr. |
| TATAMOTORS | Total Assets | ₹ 3,69,521 Cr. |
| TATAMOTORS | Working capital | ₹ 17,292 Cr. |
| TATAMOTORS | Lease liabilities | ₹ 8,762 Cr. |
| TATAMOTORS | Inventory | ₹ 47,788 Cr. |
| TATAMOTORS | Trade receivables | ₹ 16,952 Cr. |
| TATAMOTORS | Face value | ₹ 2.00 |
| TATAMOTORS | Cash Equivalents | ₹ 45,807 Cr. |
| TATAMOTORS | Adv Cust | ₹ 0.00 Cr. |
| TATAMOTORS | Trade Payables | ₹ 93,979 Cr. |
| TATAMOTORS | No. Eq. Shares PY | 332 |
| TATAMOTORS | Debt preceding year | ₹ 1,34,113 Cr. |
| TATAMOTORS | Work Cap PY | ₹ 14,684 Cr. |
| TATAMOTORS | Net Block PY | ₹ 1,32,080 Cr. |
| TATAMOTORS | Gross Block PY | ₹ 3,31,141 Cr. |
| TATAMOTORS | CWIP PY | ₹ 14,274 Cr. |
| TATAMOTORS | Work Cap 3Yr | ₹ 13,693 Cr. |
| TATAMOTORS | Work Cap 5Yr | ₹ -11,389 Cr. |
| TATAMOTORS | Work Cap 7Yr | ₹ -691 Cr. |
| TATAMOTORS | Work Cap 10Yr | ₹ 3,613 Cr. |
| TATAMOTORS | Debt 3Years back | ₹ 1,42,131 Cr. |
| TATAMOTORS | Debt 5Years back | ₹ 1,06,175 Cr. |
| TATAMOTORS | Debt 7Years back | ₹ 78,604 Cr. |
| TATAMOTORS | Debt 10Years back | ₹ 60,642 Cr. |
| TATAMOTORS | Net Block 3Yrs Back | ₹ 1,38,708 Cr. |
| TATAMOTORS | Net Block 5Yrs Back | ₹ 1,11,234 Cr. |
| TATAMOTORS | Net Block 7Yrs Back | ₹ 95,944 Cr. |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | CF Operations | ₹ 67,915 Cr. |
| TATAMOTORS | Free Cash Flow | ₹ 36,733 Cr. |
| TATAMOTORS | CF Investing | ₹ -22,782 Cr. |
| TATAMOTORS | CF Financing | ₹ -37,006 Cr. |
| TATAMOTORS | Net CF | ₹ 8,128 Cr. |
| TATAMOTORS | Cash Beginning | ₹ 31,887 Cr. |
| TATAMOTORS | Cash End | ₹ 45,807 Cr. |
| TATAMOTORS | FCF Prev Ann | ₹ 16,443 Cr. |
| TATAMOTORS | CF Operations PY | ₹ 35,388 Cr. |
| TATAMOTORS | CF Investing PY | ₹ -15,417 Cr. |
| TATAMOTORS | CF Financing PY | ₹ -26,243 Cr. |
| TATAMOTORS | Net CF PY | ₹ -6,272 Cr. |
| TATAMOTORS | Cash Beginning PY | ₹ 38,159 Cr. |
| TATAMOTORS | Cash End PY | ₹ 37,016 Cr. |
| TATAMOTORS | Free Cash Flow 3Yrs | ₹ 52,520 Cr. |
| TATAMOTORS | Free Cash Flow 5Yrs | ₹ 58,768 Cr. |
| TATAMOTORS | Free Cash Flow 7Yrs | ₹ 31,232 Cr. |
| TATAMOTORS | Free Cash Flow 10Yrs | ₹ 55,511 Cr. |
| TATAMOTORS | CF Opr 3Yrs | ₹ 1,17,586 Cr. |
| TATAMOTORS | CF Opr 5Yrs | ₹ 1,73,220 Cr. |
| TATAMOTORS | CF Opr 7Yrs | ₹ 2,15,968 Cr. |
| TATAMOTORS | CF Opr 10Yrs | ₹ 3,19,598 Cr. |
| TATAMOTORS | CF Inv 10Yrs | ₹ -2,59,944 Cr. |
| TATAMOTORS | CF Inv 7Yrs | ₹ -1,47,447 Cr. |
| TATAMOTORS | CF Inv 5Yrs | ₹ -1,01,429 Cr. |
| TATAMOTORS | CF Inv 3Yrs | ₹ -42,642 Cr. |
| TATAMOTORS | Cash 3Years back | ₹ 46,792 Cr. |
| TATAMOTORS | Cash 5Years back | ₹ 32,649 Cr. |
| TATAMOTORS | Cash 7Years back | ₹ 36,078 Cr. |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | No. Eq. Shares | 332 |
| TATAMOTORS | Book value | ₹ 255 |
| TATAMOTORS | Inven TO | 6.21 |
| TATAMOTORS | Quick ratio | 0.61 |
| TATAMOTORS | Exports percentage | 0.00 % |
| TATAMOTORS | Piotroski score | 8.00 |
| TATAMOTORS | G Factor | 5.00 |
| TATAMOTORS | Asset Turnover | 1.24 |
| TATAMOTORS | Financial leverage | 4.15 |
| TATAMOTORS | No. of Share Holders | 50,98,550 |
| TATAMOTORS | Unpledged Prom Hold | 46.4 % |
| TATAMOTORS | ROIC | 28.1 % |
| TATAMOTORS | Debtor days | 14.1 |
| TATAMOTORS | Industry PBV | 7.58 |
| TATAMOTORS | Credit rating |  |
| TATAMOTORS | WC Days | -23.8 |
| TATAMOTORS | Earning Power | 10.5 % |
| TATAMOTORS | Graham Number | ₹ 737 |
| TATAMOTORS | Cash Cycle | -47.7 |
| TATAMOTORS | Days Payable | 126 |
| TATAMOTORS | Days Receivable | 14.1 |
| TATAMOTORS | Inventory Days | 64.0 |
| TATAMOTORS | Public holding | 19.4 % |
| TATAMOTORS | FII holding | 18.2 % |
| TATAMOTORS | Chg in FII Hold | -1.02 % |
| TATAMOTORS | DII holding | 15.9 % |
| TATAMOTORS | Chg in DII Hold | -0.08 % |
| TATAMOTORS | B.V. Prev Ann | ₹ 136 |
| TATAMOTORS | ROCE Prev Yr | 6.30 % |
| TATAMOTORS | ROA Prev Yr | 0.79 % |
| TATAMOTORS | ROE Prev Ann | 5.25 % |
| TATAMOTORS | No. of Share Holders Prev Qtr | 46,16,908 |
| TATAMOTORS | No. Eq. Shares 10 Yrs | 289 |
| TATAMOTORS | BV 3yrs back | ₹ 166 |
| TATAMOTORS | BV 5yrs back | ₹ 201 |
| TATAMOTORS | BV 10yrs back | ₹ 195 |
| TATAMOTORS | Inven TO 3Yr | 4.33 |
| TATAMOTORS | Inven TO 5Yr | 4.40 |
| TATAMOTORS | Inven TO 7Yr | 4.85 |
| TATAMOTORS | Inven TO 10Yr | 5.70 |
| TATAMOTORS | Export 3Yr | 0.00 % |
| TATAMOTORS | Export 5Yr | 0.00 % |
| TATAMOTORS | Div 5Yrs | ₹ 1,088 Cr. |
| TATAMOTORS | ROCE 3Yr | 9.26 % |
| TATAMOTORS | ROCE 5Yr | 6.64 % |
| TATAMOTORS | ROCE 7Yr | 6.28 % |
| TATAMOTORS | ROCE 10Yr | 8.81 % |
| TATAMOTORS | ROE 10Yr | 8.92 % |
| TATAMOTORS | ROE 7Yr | 5.24 % |
| TATAMOTORS | ROE 5Yr Var | 99.6 % |
| TATAMOTORS | OPM 5Year | 10.6 % |
| TATAMOTORS | OPM 10Year | 11.1 % |
| TATAMOTORS | No. of Share Holders 1Yr | 35,02,408 |
| TATAMOTORS | Avg Div Payout 3Yrs | 15.5 % |
| TATAMOTORS | Debtor days 3yrs | 15.7 |
| TATAMOTORS | Debtor days 3yrs back | 18.5 |
| TATAMOTORS | Debtor days 5yrs back | 23.0 |
| TATAMOTORS | ROA 5Yr | 0.89 % |
| TATAMOTORS | ROA 3Yr | 2.24 % |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | Avg Vol 1Mth | 1,28,17,624 |
| TATAMOTORS | Avg Vol 1Wk | 1,60,95,642 |
| TATAMOTORS | Volume | 3,41,38,443 |
| TATAMOTORS | High price | ₹ 1,118 |
| TATAMOTORS | Low price | ₹ 593 |
| TATAMOTORS | High price all time | ₹ 1,118 |
| TATAMOTORS | Low price all time | ₹ 24.1 |
| TATAMOTORS | Return over 1day | 2.48 % |
| TATAMOTORS | Return over 1week | 10.2 % |
| TATAMOTORS | Return over 1month | 14.6 % |
| TATAMOTORS | DMA 50 | ₹ 991 |
| TATAMOTORS | DMA 200 | ₹ 879 |
| TATAMOTORS | DMA 50 previous day | ₹ 987 |
| TATAMOTORS | 200 DMA prev. | ₹ 877 |
| TATAMOTORS | RSI | 71.2 |
| TATAMOTORS | MACD | 16.5 |
| TATAMOTORS | MACD Previous Day | 10.7 |
| TATAMOTORS | MACD Signal | 12.0 |
| TATAMOTORS | MACD Signal Prev | 10.8 |
| TATAMOTORS | Avg Vol 1Yr | 1,20,13,918 |
| TATAMOTORS | Return over 7years | 13.6 % |
| TATAMOTORS | Return over 10years | 9.28 % |
| TATAMOTORS | Market Cap | ₹ 4,10,579 Cr. |
| TATAMOTORS | Current Price | ₹ 1,118 |
| TATAMOTORS | High / Low | ₹ 1,118 / 593 |
| TATAMOTORS | Stock P/E | 12.7 |
| TATAMOTORS | Book Value | ₹ 255 |
| TATAMOTORS | Dividend Yield | 0.27 % |
| TATAMOTORS | ROCE | 20.1 % |
| TATAMOTORS | ROE | 49.4 % |
| TATAMOTORS | Face Value | ₹ 2.00 |
| TATAMOTORS | WC to Sales | 3.95 % |
| TATAMOTORS | QoQ Profits | 145 % |
| TATAMOTORS | QoQ Sales | 8.51 % |
| TATAMOTORS | Net worth | ₹ 84,918 Cr. |
| TATAMOTORS | Market Cap to Sales | 0.94 |
| TATAMOTORS | Interest Coverage | 3.90 |
| TATAMOTORS | EV / EBIT | 12.1 |
| TATAMOTORS | Debt Capacity | 0.17 |
| TATAMOTORS | Debt To Profit | 3.37 |
| TATAMOTORS | Capital Employed | ₹ 1,74,276 Cr. |
| TATAMOTORS | CROIC | 9.05 % |
| TATAMOTORS | debtplus | 1.36 |
| TATAMOTORS | Leverage | ₹ 4.15 |
| TATAMOTORS | Dividend Payout | 14.9 % |
| TATAMOTORS | Intrinsic Value | ₹ 644 |
| TATAMOTORS | CDL | -16.9 % |
| TATAMOTORS | Cash by market cap | 0.10 |
| TATAMOTORS | 52w Index | 100 % |
| TATAMOTORS | Down from 52w high | 0.00 % |
| TATAMOTORS | Up from 52w low | 88.4 % |
| TATAMOTORS | From 52w high | 1.00 |
| TATAMOTORS | Mkt Cap To Debt Cap | 0.95 |
| TATAMOTORS | Dividend Payout | 14.9 % |
| TATAMOTORS | Graham | ₹ 737 |
| TATAMOTORS | Price to Cash Flow | 5.47 |
| TATAMOTORS | ROCE3yr avg | 9.26 % |
| TATAMOTORS | PB X PE | 55.0 |
| TATAMOTORS | NCAVPS | ₹ 52.0 |
| TATAMOTORS | Mar Cap to CF | 6.05 |
| TATAMOTORS | Altman Z Score | 3.69 |
| TATAMOTORS | M.Cap / Qtr Profit | 23.5 |