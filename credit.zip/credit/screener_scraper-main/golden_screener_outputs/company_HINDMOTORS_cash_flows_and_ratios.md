# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2006 | Mar 2007 | Mar 2008 | Mar 2009 | Mar 2010 | Mar 2011 | Mar 2012 | Sep 2013 | Mar 2014 | Mar 2015 | Mar 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -29 | -21 | -53 | -45 | 9 | -102 | -101 | -109 | -24 | 33 | 9 |
| Cash from Investing Activity + | -4 | 62 | 101 | 47 | 57 | 76 | 102 | 143 | 78 | 1 | 0 |
| Cash from Financing Activity + | -15 | 12 | -97 | -6 | -35 | 25 | -10 | -47 | -61 | -35 | -9 |
| Net Cash Flow | -48 | 54 | -49 | -3 | 31 | -1 | -9 | -13 | -6 | -1 | -0 |

## Ratios Data
| Unknown | Mar 2006 | Mar 2007 | Mar 2008 | Mar 2009 | Mar 2010 | Mar 2011 | Mar 2012 | Sep 2013 | Mar 2014 | Mar 2015 | Mar 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 44 | 22 | 25 | 10 | 8 | 9 | 14 | 10 | 36 | 31 | 505 |
| Inventory Days | 96 | 78 | 61 | 59 | 59 | 68 | 53 | 50 | 37 | 279 | 774 |
| Days Payable | 187 | 126 | 109 | 101 | 126 | 115 | 75 | 50 | 119 | 674 | 2,785 |
| Cash Conversion Cycle | -47 | -26 | -23 | -33 | -59 | -37 | -8 | 11 | -46 | -364 | -1,506 |
| Working Capital Days | -26 | -18 | -3 | -20 | -62 | -43 | -59 | -46 | -140 | -1,737 | -50,595 |
| ROCE % |  | -16% | -13% | -32% | -39% | -43% | -70% | -115% |  |  |  |