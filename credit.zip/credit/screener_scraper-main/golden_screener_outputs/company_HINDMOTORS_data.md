About
[
edit
]
Incorporated in 1948, Hindustan
Motors Ltd manufactures and sells
Vehicles, Spare Parts of Vehicles,
Steel Products and Components.
It also does trading of Spare Parts
of Vehicles

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}

Key Points
[
edit
]
Operational Review:

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}


{reference id: 2
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=22
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}

Company has declared
Suspension of
Work
at its Uttarpara Plant (West Bengal)
from 24th May, 2014, due to low productivity, growing indiscipline, shortage of funds and lack of product demand. The suspension of work is continuing. Management is scouting for tie-ups and potential investment /strategic partners to introduce new products & infuse capital in the company. It is also considering various measures including restructuring and rationalising of its manpower and other fixed costsalternative use of Fixed Assets to generate revenue.
Company's outstanding liabilities are expected to be met by sale proceeds of assets of the Company
Manufacturing Units:

{reference id: 3
source: http://www.hindmotor.com/aboutus.asp
context: Corporate Vehicles Plants Investors Newsroom Careers
‘an Motors Limited

Key Personnel n Motors Limited was established during the pre-Independence era at Port Okha in

Milestones Operations were moved in 1948 to Uttarpara in district Hooghly, West Bengal, where the
' began the production of the iconic Ambassador. Equipped with integrated facilities such
Composition of Board Directors and shop, forge shop, foundry, machine shop, aggregate assembly units for engines, axles etc
Committees rong R&D wing, the company currently manufactures the Ambassador (1500 and 2000 cc
800 cc petrol, CNG and LPG variants) in the passenger car segment and light commercial

Terms and Conditions of Appointment 7! . . > .
-tonne payload mini-truck Winner (2000 cc diesel and CNG) at its Uttarpara and Pithampur

of Independent Directors

pease

The first and only integrated automobile plant in India, the Uttarpara factory, popularly known as
Hind Motor, also manufactures automotive and forged components. View details

The company also has operations in Pithampur near Indore in Madhya Pradesh where it produces
1800 cc CNG and other variants of Winner.

Hindustan Motors is committed to core values of quality, safety, environmental care and holistic
The Birla Building, Kolkata customer orientation.

The plants

e Uttarpara (West Bengal)
The automobile division at Uttarpara is engaged in the manufacture of the iconic
Ambassador and light commercial vehicle Winner. View details

e Pithampur (Madhya Pradesh)
The company produces 1800 cc CNG and other variants of Winner here.

Our offices:

Registered office:

Hindustan Motors Limited,

Birla Building, 10th floor, Western Side
9/1, R. N. Mukherjee Road,

Kolkata - 700001

West Bengal

Tel : 91-33-30533700 / 30410900

Fax : 91-33-22480055

Best viewed in IE5 or higher on 800x600 resolution. All rights reserved. © Copyright Hindustan Motors Ltd.

Designed & Developed by ePagemaker Pvt Ltd.}

The company currently manufactures
the
Ambassador (1500 and 2000 cc diesel, 1800 cc petrol, CNG and LPG variants)
in the passenger car segment and
light commercial vehicle 1-tonne payload mini-truck Winner (2000 cc diesel and CNG)
by the name of Winner, at its Uttarpara and Pithampur plants.
The Co's manufacturing plants were the first
integrated automobile plant
in India, the Uttarpara factory, popularly known as Hind Motor, also manufactures
automotive and forged components
. The plant is equipped
with integrated facilities such as a press shop, forge shop, foundry, machine shop, aggregate assembly units for engines, axles, etc., and an R&D wing. At the Pithampur plant, the company produces
1800 cc CNG
and other variants of Winner.
Automotive components division:

{reference id: 4
source: http://www.hindmotor.com/Automotive-components.asp
context: Corporate Vehicles Plants Investors Newsroom Careers }HM Sites v i

48 Key Personnel 1 Motors’ components division comprises Accu Cast (casting unit) and Accu Forge (forging
milestones provide engines and transmission and axle components for HM vehicle business and also

astablished OEMs.

Composition of Board Directors and
Committees t

Terms and Conditions of Appointment t was established primarily for HM’s internal consumption. Later on, it started catering to
of Independent Directors sll established OEMs. The manufacturing facility includes 2-tonne dual track induction
re ~ Which can melt up to 1500 tonnes of metal per month. Moulding facilities include three
pairs of ARPA 900 machines and three pairs of ARPA 450 machines which have capacity to mould
1200 tonnes of castings per month. Further, the unit possesses automated sand plant and facilities
for fettling and machining. It also has a well-equipped laboratory with spectrometer apart from
full-fledged testing facilities. The unit also possesses well established facility for machining.

The unit currently manufactures all types of grey iron, SG iron, steel and aluminium pressure die
castings for passenger cars, LCVs, HCV and tractor segments. Accu Cast specializes in
manufacturing of intricate castings like 3-cylinder and 4-cylinder blocks, heads, gear box housings,
manifolds, SG iron casings, cover, wheel hubs, aluminium gear box extension, steering arms etc.
The unit can produce grey iron/ SG iron/ steel castings ranging from 5 kg to 500 kg unit weight and
gravity die castings ranging from 1 kg to 25 kg unit weight.

Accu Forge

Accu Forge too was established primarily for the company’s own use. It has now started catering to
well established OEM customers. The manufacturing facility includes 6000 T, 2500 T, 1300 T presses
with induction furnace and 5” upsetter, and can, altogether, forge 1300 tonnes/month. The unit
has in house facility for heat treatment, lab with spectrometer and all other necessary facilities.
The unit has excellent facility for design, simulation and model development. The unit has a well
established die shop with VMCs and all dies are being developed in-house.

The unit, currently, manufactures all types of profile forgings catering to passenger car, LCV, HCV
and tractor segments and specializes in manufacturing intricate forgings like 2- cylinder, 3-cylinder,
4-cylinder crankshafts, camshafts, stub axles, spindles, draw hooks, all types of gears and shafts
for reputed customers. The unit has the capacity to produce forgings ranging from 1 kg to 75 kg
unit weight.

Best viewed in IE5 or higher on 800x600 resolution. All rights reserved. © Copyright Hindustan Motors Ltd.
Designed & Developed by ePagemaker Pvt Ltd.}

The company's components division comprises Accu Cast (casting unit) and
Accu Forge (forging unit) which provide
engines and transmission and axle
components for HM vehicle business
and also cater to established OEMs.
A)
Accu Cast:
This particular unit currently manufactures
all types of grey iron, SG iron, steel, and aluminum pressure die castings for the passenger cars, LCVs, HCV, tractor
segments. Accu Cast specializes in manufacturing intricate castings like
3-cylinder and 4-cylinder blocks,
heads, gearbox housings, manifolds,
SG iron castings, cover, wheel hubs,
aluminum gearbox extension, steering
arms, etc. The unit can produce grey iron
/ SG iron/ steel castings ranging from 5 kg
to 500 kg unit weight and gravity die castings ranging from 1 kg to 25 kg unit weight
B)
Accu Forge:
This unit manufactures all types of profile forgings catering to passenger car, LCV,
HCV, and tractor segments and specializes
in manufacturing intricate forgings like 2- cylinder, 3-cylinder, 4-cylinder crankshafts, camshafts, stub axles, spindles, draw hooks,
all types of gears and shafts for reputed customers. The unit has the capacity to produce forgings ranging from 1
kg to 75 kg unit weight.
MoU:

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}


{reference id: 5
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=91
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

89

90

91

91 / 95 — 100% +{| ES

Notes to Accounts (contd.)

- The Company has signed a MOA (Memorandum of Agreement) with a Company wherein the Company is
handing over part of surplus land at Uttarpara for upcoming project.
The Company has also signed a MOU (Memorandum of Understanding) and is in developed stage of discussion
for a joint venture with a Company involved in EV Segment, however the project is stalled at the moment due to
a notice from W. B. State Govt. on resumption of H M Uttarpara Land.
However, the Company has alternate plans to facilitate and generate additional revenue and realize adequate fund
required, after the resumption issue is resolved. Accordingly, the Company continues to prepare its accounts on a
going concern basis. The Auditors in their audit report for the year 31st March, 2023 have given a separate paragraph,
Material uncertainty related to 'going concern' on above.

. Due to low productivity, growing indiscipline, shortage of funds and lack of demand of products, the management

declared “Suspension of work” at Company’s Uttarpara Plant with effect from 24th May 2014.

Based on legal opinion obtained, the employees and workmen, falling under the purview of “Suspension of work”
at Uttarpara plant, are not entitled to any salary & wages during that period and accordingly the Company has not
provided for such salary & wages.

.. The Government of West Bengal issued an order for resumption of HM Uttarpara land. Application filed before

West Bengal Land Reform and Tenancy Tribunal and matter is pending for final hearing as per guideline of Hon'ble
Calcutta High Court.

. The wholly owned immaterial foreign subsidiary of the Company namely Hindustan Motors Limited, USA was

already dissolved on 16th February, 2017 as per the laws appliacble in USA and as such not in existence since after
dissolution. Further, the application made by the Company to Reserve Bank of India seeking permission for writing
off its entire investment in Hindustan Motors Limited, USA (Capital, Loan and other receivables/payables) for which
necessary provision has been made in the accounts of the Company, is under consideration.

. During the year ended 31st March, 2023, by virtue of Brand Transfer Agreement dated 16th June, 2022 executed
between the Company (The Assignor) and S. G. Corporate Mobility Private Limited (The Assignee), by which the
assignor assigned the “Contessa” Brand and the related Rights thereof to the assignee for a consideration of Rs. 100
lakhs, which has been shown as “Exceptional Item”

le
ra |]}

a)
Company has entered into a  MOU to extend their Electric Vehicle domain to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from Govt. of West Bengal on resumption of Uttarpara Land.
b)
Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the resumption issue is resolved
c)  HML has signed a Memorandum
of Agreement with a Company where
HML is handing over part of surplus
land at Uttarpara for upcoming project
Agreement:

{reference id: 6
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/8d0b1739-a36f-4de1-8f13-682fecc26f00.pdf
context: 8d0b1739-a36f-4de1-8f13-682fecc26f00.pdf

1/2 — 100% +{| ES

Hindustan Motors ** j WB1942PLC018967

www. hindmotor.c

orate Relationship Dept.
Limited

RE: Additional Details Required for Corporate Announcement filed under
Regulation 30 of SEBI (LODR) Regulations, 2015.

In reply to your last trailing mail dated 29 December, 2023, regarding announcement
filed by the Company under Regulation 30 of the SEBI (Listing Obligations and Disclosure
Requirements) Regulations, 2015 Annexu 1 - Point 5. Agreements/JV/Family
settlement agreements) not in normal course of business, the point-wise reply are as
follows:-

Name of partie with whom the | Hindustan Motors Limited entered into an
agreement is entered agreement with Indigenous Vanijya Private

| Limited on 6™ October, 2023.

b) Purpose of entering into’ the | t is under suspension of work effective

| agreement May, 2014. The machineries lying at the
Plant are getting deteriorated day by day
due to natural wear and tear. These are
very old machine and equipment which
are obsolete and unserviceable/unusab
As a result of which the same cannot be
further utilized and hence sold as

le
ra |]}

On 6th October 2023, company entered into an agreement with Indigenous Vanijya Private Limited for sale of scrap and obsolete equipment for
Rs. 65.50 Cr
Brand Transfer Agreement:

{reference id: 7
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/5dbb4136-7b39-420b-9009-8a2a47c58b2b.pdf
context: 5dbb4136-7b39-420b-9009-8a2a47c58b2b.pdf

1

[1 — 100% +{| ES

Hindustan Motors  Pesisteres Office :

Hindustan Motors Limited
Birla Building, 13th Floor
9/1, R. N. Mukherjee Road

Kolkata - 700 001

June 21, 2022

The Manager, Listing Department
National Stock Exchange of India Ltd
Exchange Plaza, 5°” floor

Plot No. C/1, G Block

Bandra-Kurla Complex, Bandra (East)
Mumbai - 400 051

(Company Code : HINDMOTORS)

Dear Sirs

CIN-L34103WB1942PLC018967 WV
T +91 033 22420932 (D) F +91 033 22480055 Aw
“1491 033 4082 3700 Hmcosecy@hindmotor.com

1 +91 033 2220 0600 www.hindmotor.com

2 Corporate Relationship Dept.
BSE Limited
1* floor, New Trading Ring
Rotunda Building, P. J. Towers
Dalal Street, Fort
Mumbai - 400 001
(Company Code : 500500)

Sub: Disclosure pursuant to Regulation 30 of SEBI (Listing
Obligations and Disclosure Requirements) Regulations, 2015

Hindustan Motors Limited has executed a Brand Transfer Agreement with
S.G. Corporate Mobility Private Limited on 16" June, 2022 for the transfer of

the Contessa Brand (including the trademarks having application number
5372807) and certain related rights (“Contessa Brand”). The transfer of

the Contessa Brand shall be effective upon fulfilment of the terms &

conditions as prescribed in the said Agreement.

le
ra |]}

On 16th June 2022, company executed a Brand Transfer Agreement with S.G. Corporate Mobility Private Limited for transfer of
Contessa Brand
and certain related rights
Revenue Breakup - FY23:

{reference id: 8
source: https://www.screener.in/company/HINDMOTORS/#profit-loss
context: screeneni! FEED SCREENS TOOLS v Q_ Search for a company A GROWTH v

Hindustan Motors Chart Analysis Peers Quarters Profit & Loss Balance Sheet Cash Flow Ratios Investors Documents &8 Notebook

Profit & Loss

Standalone Figures in Rs. Crores / View Consolidated

RELATED PARTY | | PRODUCT SEGMENTS

Sep 2013 Mar 2014 Mar 2015 Mar 2016 Mar 2017 Mar 2018 Mar 2019 Mar 2020 Mar 2021 Mar 2022 Mar 2023 Mar 2024

Sales + 723 183 15 1 1 -3 1 ie) 1 (e) ie) 3
Expenses + 841 227 53 22 18 13 7 6 5 7 5 4
Operating Profit -118 -44 -38 -21 -16 -16 -6 -6 -4 -7 -5 -1
OPM % -16% -24% -251% -2,632% -1,450% -1,124% -2,757% -331% -36%
Other Income + 91 108 6 2 12 88 36 6 11 28 5 27
Interest 31 56 8 10 10 9 2 0 ie) 0 0 0
Depreciation 22 8 2 2 2 1 1 1 1 1 1 (e)
Profit before tax -80 -1 -42 -32 -16 62 27 -1 6 20 -1 25
Tax % -11% 339% 0% 0% 0% 9% -0% -2% 40% 8% -104% -1%
Net Profit + -71 -3 -42 -32 -16 57 27 -1 4 19 (0) 25
EPS in Rs -3.85 -0.17 -2.01 -1.54 -0.77 2.71 1.28 -0.04 0.18 0.89 0.00 1.22
Dividend Payout % 0% 0% 0% 0% 0% 0% 0% 0% 0% 0% 0% 0%

Compounded Sales Growth Compounded Profit Growth Stock Price CAGR Return on Equity

10 Years: -33% 10 Years: 8% 10 Years: 13% 10 Years: %

RK Vaare: AQ0f RK Vaarec: _40/ RK Vaare: celel' ls RK Vaare: of}


{reference id: 9
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=80
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf 80 / 95 — 100% + Ea] »S

HINDUSTAN MOTORS LIMITED

78 Notes to Accounts (Contd.)

(Amounts in INR Lakhs)
Year ended Year ended
March 31, 2023. March 31, 2022
24. OTHER INCOME

a) Interest on Fixed Deposit with Banks and Others * 37.64 37.98
b) Other Non Operating Income
Unspent Liabilities and Provisions no longer required Written Back 297.07 1,324.51
Rent and Hire Charges (Including Access Fees) 35.30 36.88
Miscellaneous Income -Non Operating 9.03 0.61
79 Profit on Disposal of Property, Plant and Equipment (Net) - 57.79

* Includes : Interest on Income Tax Refund Rs. Nil (Rs. 0.29 Lakhs)
Total other income 1,457.77

. EMPLOYEE BENEFITS EXPENSE
Salaries & Wages
Contribution to Provident and Other Funds
Staff Welfare Expense
Total employee benefits expense

. FINANCE COSTS *
Interest on delayed payment of statutory liabilities & others

Total finance costs

* includes interest on arrear Municipal Tax INR 10.00 Lakhs (Nil).

. DEPRECIATION AND AMORTISATION EXPENSE
Depreciation of property, plant and equipment
Amortisation of intangible assets
Total depreciation and amortisation expense

81 . RATES & TAXES
Municipal & other taxes

le
ra |]}

Company is generating continuous
operational losses and its net worh
has eroded. In FY23, it was unable to
generate any revenue except Other
Income which consists of: Interest
on Fixed Deposit with Banks and
Others ~
10%
, Other Non Operating
Income ~
90%
Last edited 4 months, 1 week ago
Request an update
© Protected by Copyright
