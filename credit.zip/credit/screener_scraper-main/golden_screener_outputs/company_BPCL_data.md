About
[
edit
]
Bharat Petroleum Corporation is a public sector company which is engaged in the business of refining of crude oil and marketing of petroleum products.
[1]
Key Points
[
edit
]
Refineries Capacity
Total Capacity - 35.3 MMTPA
Refinery Locations:
Mumbai - 12 MMTPA
Kochi - 15.5 MMTPA
Bina, Madhya Pradesh - 7.8 MMTPA
[1]
It possesses 14-15% of the country's total refining capacity.
[2]
Expansion
BPCL, on a consolidated basis, intends to spend around ₹10,000 crore in FY23, of which it will spend around ₹2,100 crore on refinery and on the Petchem project in Kerala, ₹5,200 crore on marketing, ₹800 crore on CGD/GAS, ₹1,400 crore on upstream and ₹500 crore on other projects (including pipeline).
[3]
Revenue Breakup FY22
High speed diesel (HSD) accounts for ~52% of revenues, followed by Motor spirit (23.4%) and Liquefied Petroleum Gas (11.3%).
[4]
Presence Across Value Chain
Retail (Petroleum) -
The company owns 82 retail depots and operates ~20,000 retail outlets across India.
Presently, it has a market share of ~26% in the domestic petroleum market.
LPG -
The company owns and operates 54 LPG bottling plants and serves over 6,200 distributors of LPG in India.
It has a base of ~9 crore customers with a market share of 27%.
Industrial/ Commercial -
The company serves 8,000+ customers and provides them with a reliable supply of industrial and commercial petroleum products.
Aviation -
The company has 56 aviation service stations across airports in India and has a 21% market share in ATF (Aviation Turbine Fuel) in the domestic market.
Lubricants -
The company sells more than 400 grades of lubricant products through its own brand MAK Lubricants. It has a market share of ~25% through a base of over 18,000 customers.
Gas -
The company has a customer base of 55+ major LNG customers. The company undertakes this business through its wholly owned subsidiary Bharat Gas Resources Ltd which has business interest in 50 GAs (geographical areas).
[5]
Exploration Activities
BPRL has Participating Interest (PI) in 18 blocks, of which nine are in India and nine overseas, along with equity stake in two Russian entities holding the license to four producing blocks in Russia.
The blocks of BPRL are in various stages of exploration, appraisal, development and production. The total acreage held by BPRL and its subsidiaries is around 22,000 sq. km, of which approximately 49% is offshore.
[6]
Listed Joint Ventures
Petronet LNG Limited :-
The company was formed in 1998 for importing LNG and setting up a LNG terminal with facilities like jetty, storage, regasification etc. to supply natural gas to various industries in the country.
It was promoted by 4 public sector companies viz. BPCL, IOCL, ONGC and GAIL which owns 12.5% each in the company. BPCL’s equity investment in PLL currently stands at ~₹ 100 crore.
[7]
Indraprastha Gas Limited:- ** It is a leading CGD (city gas distribution) company in India, supplying natural gas to transport, domestic, commercial and industrial consumers. The operations of IGL spread over NCT of Delhi, Noida & Greater Noida, Ghaziabad & Hapur, Gurugram, Meerut, Shamli, Muzaffarnagar, Karnal and Rewari.
It is a JV with Gail India wherein the company holds 22.5% stake.**
[8]
Amalgamation
On June 22, 2022, MCA approved the amalgamation of Bharat Oman Refineries Ltd. with BPCL. The Order has been filed with ROC and BORL stands merged with BPCL effective July 1, 2022.
BGRL, a wholly owned subsidiary of BPCL, was incorporated for handling Natural Gas business. In March 2021, the Board of Directors approved the amalgamation of BGRL with BPCL. Thereafter, the companies filed a petition with the MCA for amalgamation. The process is in an advanced stage now.
[9]
Privatization of the Company
The Government of India vide its letter dated June 3, 2022 has advised to call off the present process for strategic disinvestment of BPCL and accordingly, all the activities in connection with the disinvestment have been discontinued.
[9]
Sale of stake in Numaligarh Facility
In 2021, The company sold its entire ~61.6% stake in Numaligarh Refinery Ltd for Rs. 9,876 crores. It operates a 3 MMTPA refinery in the state of Assam.
Buyers include Oil India Ltd, Engineers India Ltd, and the Govt. of Assam.
[10]
Changes in KMP
Shri Arun Kumar Singh, Director (Marketing), took over charge of Chairman & Managing Director w.e.f. 07.09.2021 and Shri Vetsa Ramakrishna Gupta was appointed as Chief Financial Officer of the Company w.e.f. 01.08.2021.
[11]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright
