# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 176 | 254 | 318 | 411 | 507 | 639 | 670 | 753 | 985 | 1,197 |
| Expenses + | 228 | 373 | 391 | 487 | 490 | 472 | 344 | 458 | 755 | 906 |
| Operating Profit | -52 | -119 | -74 | -76 | 17 | 167 | 326 | 296 | 230 | 291 |
| OPM % | -29% | -47% | -23% | -19% | 3% | 26% | 49% | 39% | 23% | 24% |
| Other Income + | 23 | 8 | 14 | 19 | 41 | 69 | 87 | 112 | 181 | 209 |
| Interest | 0 | 1 | 0 | 0 | 0 | 3 | 7 | 5 | 8 | 9 |
| Depreciation | 3 | 4 | 5 | 3 | 4 | 21 | 16 | 12 | 31 | 36 |
| Profit before tax | -32 | -115 | -64 | -60 | 54 | 211 | 389 | 390 | 371 | 454 |
| Tax % | 0% | 0% | 0% | -191% | 63% | 30% | 28% | 24% | 24% | 26% |
| Net Profit + | -32 | -116 | -64 | 55 | 20 | 147 | 280 | 298 | 284 | 334 |
| EPS in Rs | -17.43 | -63.34 | -35.16 | 27.38 | 3.50 | 25.50 | 46.09 | 48.71 | 46.38 | 55.68 |
| Dividend Payout % | 0% | 0% | 0% | 0% | 0% | 20% | 16% | 2% | 22% | 36% |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 76% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 37% |  |  |  |  |  |  |  |  |  |
| 3 Years: | -6% |  |  |  |  |  |  |  |  |  |
| 1 Year: | 0% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| IB MonotaRO Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 104 | 118 |
| Investment in associates |  |  |  |  | 104 |  | 14 |
| Investment in associates (At cost) |  |  |  |  | 104 |  |  |
| Simply Vyapar Apps Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 97 | 97 |
| Investment in associates (At cost) |  |  |  | 31 | 93 |  |  |
| Investment in associates |  |  |  |  | 62 | 3.98 |  |
| Investment in |  |  | 31 |  |  |  |  |
| Web, advertisement & marketing services provided to |  |  |  |  |  | 1.65 | 0.72 |
| Compulsory convertible preference shares (Face value 100/- each) |  |  |  |  |  |  | 1.48 |
| Web & Advertisement services provided to |  |  |  |  | 0.84 |  |  |
| Miscellaneous services provided to |  |  |  |  | 0.24 | 0.04 |  |
| Trade receivables |  |  |  |  |  | 0.20 | 0.06 |
| Contract Liabilities |  |  |  |  |  | 0.25 |  |
| Deferred Revenue |  |  |  | 0.05 | 0.10 |  |  |
| Equity Shares Capital (Face value 10/- each) |  |  |  |  |  |  | 0.01 |
| Mynd Solutions Private Limited |  |  |  |  |  |  |  |
| Investment in Entities where KMP and Individuals exercise Significant influence (at FVTPL) |  |  |  |  |  | 58 | 58 |
| Purchase of Investment |  |  |  |  |  | 24 |  |
| Sale of Investment |  |  |  |  |  | 14 |  |
| Web, advertisement & marketing services provided to |  |  |  |  |  |  | 0.50 |
| Mobisy Technologies Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 46 | 46 |
| Investment in associates |  |  |  |  |  | 23 | 8 |
| Investment in debt instruments of associates (at FVTPL) |  |  |  |  |  | 8 | 16 |
| Agillos E-Commerce Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 26 | 26 |
| Investment in associates |  |  |  |  | 26 |  |  |
| Investment in associates (At cost) |  |  |  |  | 26 |  |  |
| Shipway Technology Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 18 | 18 |
| Investment in associates |  |  |  |  | 18 |  |  |
| Investment in associates (At cost) |  |  |  |  | 18 |  |  |
| Truckhall Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 11 | 19 |
| Investment in associates |  |  |  |  | 11 | 7.50 | 3 |
| Investment in associates (At cost) |  |  |  |  | 11 |  |  |
| Investment in debt instruments of associates (at FVTPL) |  |  |  |  |  | 7.50 | 3 |
| Edgewise Technologies Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 13 | 13 |
| Investment in associates |  |  |  |  | 13 |  |  |
| Investment in associates (At cost) |  |  |  |  | 13 |  |  |
| Adansa Solutions Private Limited Associate |  |  |  |  |  |  |  |
| Investment in equity instruments of associates (at cost) |  |  |  |  |  | 14 | 14 |
| Investment in associates |  |  |  |  |  | 14 |  |
| Dinesh Chandra Agarwal Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 8.63 |  | 13 |  |  |
| Brijesh Kumar Agrawal Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 5.85 |  | 8.77 |  |  |
| Mansa Enterprises Private Limited |  |  |  |  |  |  |  |
| Expenses for rent | 0.55 | 0.42 | 0.31 | 0.16 | 0.17 |  |  |
| Rent & related miscellaneous expenses |  |  |  |  |  | 0.26 | 0.53 |
| Trade Payable (including accrued expenses) |  |  |  |  |  |  | 0.01 |
| Indiamart Employee Benefit Trust |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.04 |  | 0.33 |  |  |
| Repayment of loan given |  |  |  | 0.12 | 0.20 |  |  |
| Loan given |  |  | 0.15 | 0.15 |  |  |  |
| Share capital issued |  |  | -0.14 | 0.14 | 0.17 |  |  |
| Interest free loan given |  |  |  | 0.12 | 0.05 |  |  |
| Interest free Loan given |  |  | 0.15 |  |  |  |  |
| Dhruv Prakash Key Person |  |  |  |  |  |  |  |
| Recruitment and training expenses | 0.21 | 0.18 | 0.31 | 0.04 |  |  |  |
| Dividend paid |  |  | 0.04 |  | 0.04 |  |  |
| Amount Payable |  |  | 0.01 |  |  |  |  |
| IB Monotaro Private Limited Associate |  |  |  |  |  |  |  |
| Contract Liabilities |  |  |  |  |  | 0.11 | 0.37 |
| Web, advertisement & marketing services provided to |  |  |  |  |  | 0.03 | 0.14 |
| Marketing services availed from |  |  |  |  |  |  | 0.01 |
| S R Dinodia & Co LLP |  |  |  |  |  |  |  |
| Tax consultancy and litigation support service |  |  |  |  |  |  | 0.16 |
| Trade Payable (including accrued expenses) |  |  |  |  |  |  | 0.10 |
| Prateek Chandra Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.10 |  | 0.15 |  |  |
| Ten Times Online Private Limited Associate |  |  |  |  |  |  |  |
| Investment in associates (At cost) |  |  |  | 0.09 | 0.09 |  |  |
| Internet and online services availed |  |  |  |  | 0.02 |  |  |
| Manoj Bhargava Key Person |  |  |  |  |  |  |  |
| Loans |  |  |  |  | 0.15 |  |  |
| Ten Times Online Pvt. Ltd Associate |  |  |  |  |  |  |  |
| Sale of Investment in associates |  |  |  |  |  | 0.12 |  |
| Rajesh Sawhney Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.02 |  | 0.01 |  |  |
| Vivek Narayan Gour Key Person |  |  |  |  |  |  |  |
| Dividend paid |  |  | 0.01 |  | 0.02 |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 176 | 254 | 318 | 411 | 507 | 639 | 670 | 753 | 985 | 1,197 |
| Expenses + | 228 | 373 | 391 | 487 | 490 | 472 | 344 | 458 | 755 | 906 |
| Operating Profit | -52 | -119 | -74 | -76 | 17 | 167 | 326 | 296 | 230 | 291 |
| OPM % | -29% | -47% | -23% | -19% | 3% | 26% | 49% | 39% | 23% | 24% |
| Other Income + | 23 | 8 | 14 | 19 | 41 | 69 | 87 | 112 | 181 | 209 |
| Interest | 0 | 1 | 0 | 0 | 0 | 3 | 7 | 5 | 8 | 9 |
| Depreciation | 3 | 4 | 5 | 3 | 4 | 21 | 16 | 12 | 31 | 36 |
| Profit before tax | -32 | -115 | -64 | -60 | 54 | 211 | 389 | 390 | 371 | 454 |
| Tax % | 0% | 0% | 0% | -191% | 63% | 30% | 28% | 24% | 24% | 26% |
| Net Profit + | -32 | -116 | -64 | 55 | 20 | 147 | 280 | 298 | 284 | 334 |
| EPS in Rs | -17.43 | -63.34 | -35.16 | 27.38 | 3.50 | 25.50 | 46.09 | 48.71 | 46.38 | 55.68 |
| Dividend Payout % | 0% | 0% | 0% | 0% | 0% | 20% | 16% | 2% | 22% | 36% |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 76% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 37% |  |  |  |  |  |  |  |  |  |
| 3 Years: | -6% |  |  |  |  |  |  |  |  |  |
| 1 Year: | 0% |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |

