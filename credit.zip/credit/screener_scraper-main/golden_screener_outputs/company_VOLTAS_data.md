About
[
edit
]
Voltas is engaged in the business of air conditioning, refrigeration, electro - mechanical projects as an EPC contractor both in domestic and international geographies (Middle East and Singapore) and engineering product services for mining, water management and treatment, construction equipments and textile industry.
Voltas was created 6 decades ago when Tata Sons joined hands with a swiss company Volkart Brothers. Voltas is also one of the most reputed engineering solution providers specializing in project management.
[1]
The company has 5,000+ Customer sites actively managed across India
[2]
Key Points
[
edit
]
Unitary Cooling Products(UCP)
[1]
Unitary Cooling products comprises Air Conditioners, Air Coolers, and Commercial Refrigeration products etc in B2B & B2C segment. As of Fy23, company has 21% market share in room Acs and 36% in window ACs. It has 25,000+ touchpoints, 64 New RAC SKUs, 51 Voltas Fresh Air Coolers SKUs, 23 New Commercial Refrigeration SKUs.
[2]
Voltas Beko
It is a JV with a Turkish company Arçelik through which Voltas entered the home appliances industry under the brand,
Voltas Beko
in 2018.
[3]
The company produces refrigerators, washing machine, microwaves and dishwashers. As of FY23, it has 7,000+ touchpoints and 150+ SKUs with ~100 launched in FY23.
[4]
International Operations Business Group (IOBG)
The company operates in Mechanical, Electrical & Plumbing (MEP), Heating, Ventilation and Air Conditioning (HVAC) and Water Management. IOBG specializes in providing comprehensive electromechanical solutions and services to its
clients in Middle East and Asia region. The company has successfully completed multiple projects across GCC, including Dubai, Oman, Qatar, Bahrain etc.
[5]
The company has an order book of Rs.2,356 crs. in FY23.
Universal MEP Projects & Engineering
Services Limited (UMPESL)
[6]
The company has restructured their B2B business into this segment. The company has an order book of ~Rs. 5800 crs. as of FY23. In FY23, it secured MEP-Major projects: Chennai Metro, Bangalore Metro, Data Centre Jobs (Noida), Godrej Commercial Building (Bangalore), Phoenix Equinox Commercial Complex (Hyderabad) etc. It also completed Water Projects of SAIL, Bokaro & Rourkela and OWSSB Cuttack. It delivered Solar EPC Project, secured orders of ~₹ 500 crores for Water supply under Jal Jeevan Mission. It has installed 265 water treatment and distribution plants in the Madhepura (Bihar). The Company is working on similar groundwater projects, to benefit 600 villages in UP.
Textile Machinery Division(TMD)
In  FY23, company plans to grow market share in capital machines, in Spinning and Post Spinning. The company has added Spreading machines and Weaving preparatory machines to its portfolio. It plans to add new Principals for Non-woven, Embroidery to strengthen value chain in Post Spinning.
[7]
The company enjoys 60% Market share of spinning machinery.
[8]
Mining and Construction Equipment (M&CE)
M&CE has grown its business across India and
expanded its reach to Mozambique through partnerships with Tata Mozambique and Tata Africa. In FY23, the segment had a decent year in  Mozambique.On the domestic front, export
levy on iron ore impacted the mining activities which impacted equipment sales and after sales services for the major part of the year. However, the subsequent removal of this levy helped sustain the demand for crushing
and screening equipment in India.
[7]
Vestfrost Solutions, Denmark
[7]
In FY23, the company entered into a technology license agreement with Vestfrost Solutions, Denmark, to develop, manufacture, sell and service
medical refrigeration and vaccine storage equipment
. This will enable the compant to enter the Bio Medical and
Cold Chain industry for vaccine storage equipment such as ice-lined refrigerators, vaccine freezers, and ultralow temperature freezers, in the Indian market.
Order Book
In FY23, company's WOS, UMPESL won multiple project orders valued at ~Rs. 3,762 crs, including a solar power project. The IOBG segment bagged a project worth Rs. 942 crs in Riyadh, Saudi Arabia, for Qiddiya Water Theme Park. IOBG also won multiple projects, including Jubail for HVAC division, involving the world’s largest desalinated water production plant.
[7]
Manufacturing Facility
[9]
The company has 4 manufacturing facilities at Waghodia (Gujarat), Sanand (Gujarat) and 2 at  Pantnagar (Uttarakhand). The company has a manufacturing capacity (CAC) 5 lakh ton and  (AC) 2.7 million units. The company has 5 R&D centres too.
[10]
Expansion
[11]
The company plans to expand its manufacturing facility in Chennai for rooms ACs with a proposed capex of around Rs. 450-500 crores BY FY25. The company  is trying for backward integration of certain products like Heat Exchanger, Cross Flow Fan and Plastic components, and has applied  for PLI provided by the Government for this category.
Distribution Network
[10]
As of FY23, company has 260+EBOs,  25,000+ Touchpoints and 5 Experience Zones.
Business Restructuring
Business Transfer Agreement(BTA)
:
In FY23, company signed BTA for transferring its B2B businesses relating to Projects business comprising Mechanical Electrical and Plumbing (MEP)/Heating, Ventilation and Air-Conditioning (HVAC) and Water projects,
Mining and Construction Equipment (M&CE) business and Textile Machinery Division (TMD) business to its WOS,
Universal MEP Projects & Engineering Services Limited (UMPESL)
w.e.f. Aug22. Through this subsidiary, the Company provides a wide range of engineering solutions.
[12]
International Projects
:
In FY23,the Board decided to transfer its international projects business to its step-down WOS, Universal MEP Projects Pte Limited (UMPPL), Singapore.
[13]
Exceptional Item FY23
[14]
In FY23, company made a provision of Rs.244 crores under exceptional items, relating to the termination of a contract and
encashment of bank guarantees for two overseas projects in Dubai and Qatar, respectively.
Last edited 10 months, 3 weeks ago
Request an update
© Protected by Copyright
