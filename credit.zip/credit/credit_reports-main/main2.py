import instructor
from pydantic import BaseModel, HttpUrl
# from litellm import RouterConfig
from utils2 import KeyStrengths, llm_call_nomodel, run_search, parse_jina, PromotersList, llm_call, KeyIssues, BriefFinancials, IndustryRisks, search_web, CRISILModel, Peers,ValuationRatios,ValuationRatio,PerformanceRatios,Graph,LeverageRatios,ActivityRatios
from utils2 import search_web_plain, bing_engine
import json

ticker = "VOLTAS"
report_data = {}
company_profiles_raw = {
    "introduction": [
        "Give me some introduction information on {ticker}",
        """
 It was founded in 1996 and rebranded as Polycab India Ltd in 2018. It was publicly listed in 2019.
 Polycab's registered office is in Gujarat, and it operates a significant network of manufacturing facilities across strategic locations in India.
 It has a vertically integrated business model that spans a large manufacturing and distribution network.
 Product variety include wide array of electrical products including wires, cables, electrical
appliances, switches, and other electrical accessories.
"""],
    "core_products_services": [
        "Give me some information on the core products and services of {ticker}", 
        """
1) Wires and Cables: This is Polycab's core products and constitutes 89% of the product mix.
It includes products like electrical cables, power cables, telecommunications cables and
specialty cables. Products are critical for power transmission and distribution across various
sectors such as infrastructure, power, telecom, and more.
2) Fast Moving Electrical Goods (FMEG): FMEG includes Electric Fans, lighting products, switches and switchgear and solar products and constitutes 9% of the product mix.
3) EPC Services: EPC involves designing, constructing, and commissioning projects related to power distribution and electrification and constitutes 2% of the product mix.
"""],
    "primary_revenue": [
        "Give me the primary revenue sources of {ticker}",
        """
1) Electric Wire and Cables: Majority of Polycab's revenue and makes about 91% as of FY-23 comes from the sale of wires and cables.
2) FMEG Segment: FMEG sector has been a growing revenue stream for Polycab and makes about 9% of revenue as of FY-23.
3) Institutional Sales and EPC Contracts: Revenue is also generated from institutional sales to large industrial, governmental, and corporate clients. The EPC division further adds to the revenue by securing contracts for comprehensive electrical solutions. Almost 3% of the revenue comes from this source as of FY-23.
4) Export Markets: Polycab has been progressively expanding its presence in international markets like the Middle East, Africa, and Southeast Asia.
"""
],
    "manufactering_facilities": [
        "What are the manufacturing facilities of {ticker}", """
 Halol Facility: One of the largest and most important facilities, specializing in the production of a wide range of cables and wires.
 Daman Facility: Situated in the Union Territory of Daman and produces wires & cables. It is strategically built near the major markets of Maharashtra and Gujarat.
 Nashik Facility: Focuses on the production of switchgears and other electrical components (FMEG).
 Roorkee Facility: Specializes in the manufacturing of fans and lighting products (FMEG).
 Chennai Facility: This facility focuses on the southern market, producing a range of electrical products tailored to meet regional demands.
"""
],
    "corporate_offices": [
        "where are the corporate and regional offices of {ticker}",
        """
 The corporate headquarters of Polycab is located in Mumbai.
 It has established regional offices across major cities in India including New Delhi, Kolkata, Bangalore and Hyderabad.
"""
],
    "research_dev" : [
    "Give me information about the research and development centres of {ticker}", 
    """
 Polycab places a strong emphasis on innovation and technological advancement. It operates R&D centers that are integrated within some of its manufacturing sites.
 They have a central quality and test laboratory in Halol, Gujarat and their focus on quality control. This lab is accredited by NABL and UL, signifying their commitment to meeting high quality standards.
 Four international research teams are employed for R&D of polymers required in cables used in niche sectors.
"""
]
}


# instructor.patch(
#     RouterConfig
# )                

report_data["company_profile"] = {}
for key in company_profiles_raw:
    company_profile_messages = [
        {"role": "system", "content": """
Input Details:
1. Company Profile
2. User Question

Answer Instructions:
1. ANSWER IN BULLET POINTS ONLY
2. TALK ABOUT COMPANY DETAILS AND THE INCORPORATION DETAILS
3. MAKE EACH POINT SLIGHLY DESCRIPTIVE

EXAMPLE OUTPUT : 
{company_profiles_raw[key][1]}
    """},
        {"role": "user", "content": f"Company Profile:\n{run_search(company_profiles_raw[key][0])}\nQuestion:\n{company_profiles_raw[key][0]}"}
    ]
    report_data["company_profile"][key] = llm_call_nomodel(company_profile_messages)


promoters_question = "What has been the trend in the overall promoters' shareholding percentage from September 2021 to March 2024?"
promoters = llm_call_nomodel(
    [
        {"role": "system", "content": "Return the output as an unordered list."},
        {"role": "user", "content": f"Context:\n{run_search(promoters_question)}\n\n\nQuestion:\n{promoters_question}"}
    ]
)

promoters_data = parse_jina(bing_engine(f"'{ticker}' board of directors"))

promoters_parsed_profiles = llm_call(
    messages=[
        {"role": "system", "content": "Task: What is the name, experience and qualifications of each of the promoters whose holdings have been mentioned"},
        {"role": "user", "content": f"Promoters Holdings:\n{promoters}\n-------\nPromoterProfiles:{promoters_data}"}
    ],
    model=PromotersList
)

report_data["promoters"] = json.loads(promoters_parsed_profiles.model_dump_json())



key_strengths_question = "What are the key strengths of {ticker} ?"
report_data["key_strengths"] = json.loads(llm_call(
    messages=[
        {"role": "system", "content": "Task: Identify the KEY STRENGTHS of {ticker} as defined by the credit rating agency."},
        {"role": "user", "content": f"Context:\n{run_search(key_strengths_question)}\n\n\nQuestion:\n{key_strengths_question}"}
    ],
    model=KeyStrengths
).model_dump_json())

key_issues_question = "What are the key weaknesses of {ticker}? "
report_data["key_issues"] = json.loads(llm_call(
    messages=[
        {"role": "system", "content": "Task: Identify the KEY ISSUES OR WEAKNESSES of {ticker} as defined by the credit rating agency."},
        {"role": "user", "content": f"Context:\n{run_search(key_issues_question)}\n\n\nQuestion:\n{key_issues_question}"}
    ],
    model=KeyIssues
).model_dump_json())


query = "Give me the industry risks, trends for Agro Chemicals  and Pigments industry in India."
risks = llm_call(
    messages=[
        {"role": "system", "content": """
**Task**: Analyze the provided context and generate a detailed report on the industry risks associated with the specified market/domain mentioned in the query. The response should include quantitative data and projections to enhance the depth of the analysis.

**Instructions**:
1. **Context Understanding**: Thoroughly review the given web response content to understand the market/domain dynamics and current trends.
2. **Identify Risks**: Based on the query and the context provided, identify specific industry risks related to the market. Focus on aspects such as market competition, regulatory challenges, environmental impacts, and economic factors.
3. **Quantitative Analysis**:
    - Provide numerical values such as market size, growth rates (CAGR), or other relevant financial metrics to support the discussion of each risk.
    - Highlight any financial implications of these risks, such as potential costs, revenue impacts, or investment risks.
4. **Detailed Explanation**:
    - Elaborate on each identified risk, explaining how it affects the industry and the potential long-term consequences for businesses operating within it.
    - Discuss mitigation strategies or industry responses to these risks where applicable.

**Example Request**:
"Based on this query, 'Analyze the industry risks for the Indian footwear market', give me detailed insights into the risks associated with this market. Include numerical values and analysis based on the current market context provided."

**Example Response**:
"User: Provide a detailed risk analysis for the Indian footwear market.
Assistant: The Indian footwear market, valued at INR 900 billion in FY-24, is expected to grow at a CAGR of approximately 8% to reach INR 1,050 billion by FY-26. The sector has witnessed significant growth driven by urbanization and increasing disposable income. However, it faces several challenges:
- Intense competition from unorganized sectors and e-commerce disruptors.
- Environmental concerns due to the use of non-sustainable leather and chemicals in production, with potential regulatory impacts on material usage and disposal.
- Market entry and operational costs influenced by stringent regulatory standards, which may affect profitability.
These factors collectively contribute to the risk landscape of the Indian footwear industry, necessitating strategic planning and regulatory compliance to mitigate impacts."
"""},
        {"role": "user", "content": f"Context:\n{search_web(query)}\n\n\nQuestion:\n{query}"}
    ],
    model=IndustryRisks
)
report_data["industry_risks"] = json.loads(risks.model_dump_json())


# TODO: The brief financials section is not extracting data properly
brief_financials_question = "What are the values for Equity Capital and Profit Before Tax for {ticker}?"
brief_financials = llm_call(
    messages=[
        {"role": "system", "content": """
Task: You have been given financials of {ticker} and you need to answer the analyst's question **diligently and accurately**.

Answer Instructions:
0. DONOT INVENT ANY NEW DETAILS
1. FOLLOW FORMATTING INSTRUCTIONS
"""},
        {"role": "user", "content": f"Context:\n{run_search(brief_financials_question, n=5)}\n\n\nQuestion:\nExtract the relevant values without making shit up."}
    ],
    model=BriefFinancials
)
report_data["brief_financials"] = json.loads(brief_financials.model_dump_json())


peers_question = "Provide insights into the overall performance and market sentiment of the chemical sector based on the data provided in the table."
peers_list = llm_call(
    messages=[
        {"role": "system", "content": """
Task: You have been given a list of peer companies of {ticker} and you need to answer the analyst's question **diligently and accurately**.

Answer Instructions:
0. DONOT INVENT ANY NEW DETAILS
1. FOLLOW FORMATTING INSTRUCTIONS
"""},
        {"role": "user", "content": f"Context:\n{run_search(peers_question)}\n-------\nQuestion:\n{peers_question}"}
    ],
    model=Peers
).peer_names_list

ctx = ""
for i in peers_list:
    query_str = f"what is the crisil rating of {i} after:2024-02-21"
    ctx += f"{search_web_plain(query_str)}\n----------------\n"
    
    
    
peer_ratings = llm_call(
    model=CRISILModel,
    messages=[
        {
            "role": "system",
            "content": f"""
**Task**: Analyze the provided web search result and extract detailed information about CRISIL ratings for a specific company. The output should include the company's name, its long-term and short-term CRISIL ratings, and any relevant commentary or rationale provided in the text.

**Instructions**:
1. **Company Name Extraction**:
- Extract the company name mentioned in the context. Look for the company name preceding the phrase "ratings on" or similar context clues within the text.

2. **Ratings Extraction**:
- Identify the CRISIL ratings from the text. These ratings are typically formatted like 'CRISIL AA+/Stable/CRISIL A1+'. 
- Split this rating to distinguish between long-term and short-term ratings. The format is usually 'Long-term rating/Stability/Short-term rating'.

3. **Commentary Extraction**:
- Extract any commentary related to the ratings. This might begin with phrases like "Detailed Rationale" or "CRISIL Ratings has reaffirmed".
- Summarize this commentary to capture key insights about the rating decision, focusing on growth percentages, financial performance, or market challenges mentioned.

4. **Output Format**:
- Format your findings into a structured JSON object with fields for the company name, long-term rating, short-term rating, and a summary of the commentary.
- Ensure all extracted information is accurate and relevant to the query provided.
        """},
        {
            "role": "user",
            "content": f"User Request:\nGenerate the credit ratings table for all the peers of {ticker} \n\n\nWeb Context:\n{ctx}"
        }

        
]
)
valuation_data = llm_call(
    model=ValuationRatios,  
    messages=[
        {
            "role": "system",
            "content": """
**Task**: Extract and analyze key financial valuation ratios from the given financial data. Provide insights into each ratio and its implications for the company's valuation.

**Instructions**:
1. **Data Extraction**:
   - Extract key valuation ratios like P/E, EV/EBITDA, P/B, etc.
   - Ensure the data is sourced from reliable financial reports and databases.

2. **Analysis**:
   - Provide a brief analysis of each ratio, discussing what it indicates about the company's current valuation.
   - Compare these ratios to industry standards or historical performance where relevant.

3. **Output Format**:
   - Format your findings into a structured JSON object with fields for each ratio and their respective values and analysis.

**Example Request**:
"Given the latest financial reports, extract and analyze the valuation ratios for {ticker} and compare them with industry averages."

**Example Response**:
"User: Provide detailed insights into the valuation ratios of {ticker}.
Assistant: The P/E ratio of {ticker} stands at 15, which is below the industry average of 18, indicating a potential undervaluation relative to peers..."
            """
        },
        {
            "role": "user",
            "content": "User Request:\nPlease provide the valuation ratios and their analysis for {ticker} based on the latest financial data."
        }
    ]
)

performance_ratios_data = PerformanceRatios(
    graphs={
        "5Yrs return %": Graph(url="https://prodpublic24.blob.core.windows.net/generated-tables/shreyas_test_cred_rep.png?se=2024-07-30T10%3A20%3A43Z&sp=r&sv=2024-08-04&sr=b&sig=UbeS%2BnP3Ux5/tePz%2B%2BxTatzIcWwCrZTHBC%2BNImSIzaU%3D"),
        "Dividend Yield": Graph(url="https://drive.google.com/file/d/1dM_MTXzwYW9nZcffhCAHFaFakuLh4tsC/view?usp=sharing"),
        "ROCE": Graph(url="https://drive.google.com/file/d/1okf3pk36K4curCD8ksHTODc9vQb09dvQ/view?usp=sharing"),
        "ROA": Graph(url="https://drive.google.com/file/d/1Oem6s2k5Gpi3vA1oP2aOSmUdt3UVQx6K/view?usp=sharing"),
        "Asset Turnover": Graph(url="https://drive.google.com/file/d/1Np3_HkJi2w806XzrhMszDSD6EHWo3ZfV/view?usp=sharing")
    },
    commentary=[
        "The 5-year return for Meghmani Organics Ltd. is not available as the company results have most likely not been published yet...",
        "Meghmani Organics Ltd. offers a dividend yield of 1.70%, which is among the highest in its peer group...",
        "Meghmani Organics Ltd.'s ROCE of -3.13% is the lowest among its peers, indicating that the company is not effectively utilizing its capital...",
        "The company's ROA of -3.44% is also the lowest in the peer group, further emphasizing concerns about profitability and asset utilization...",
        "Meghmani Organics Ltd.'s ROE of -6.71% is the lowest among its peers, indicating that the company is not generating adequate returns on shareholder equity...",
        "With an asset turnover of 0.50, Meghmani Organics Ltd. is tied with UPL for the lowest efficiency in utilizing its assets to generate sales..."
    ]
)

leverage_ratio_data = LeverageRatios(
    graphs={
        "Debt/Equity": Graph(url="https://prodpublic24.blob.core.windows.net/generated-tables/shreyas_test_cred_rep.png?se=2024-07-30T10%3A20%3A43Z&sp=r&sv=2024-08-04&sr=b&sig=UbeS%2BnP3Ux5/tePz%2B%2BxTatzIcWwCrZTHBC%2BNImSIzaU%3D"),
        "Interest Coverage": Graph(url="https://drive.google.com/file/d/183SKVNZD1NBqJZtwUeM4IDf59z9xlYRE/view?usp=sharing")
    },
    commentary=[
        "Meghmani Organics Ltd. has a Debt/Equity ratio of 0.55, significantly higher than most peers, indicating heavier reliance on debt financing; only UPL has a higher ratio at 1.07.",
        "Despite higher debt, Meghmani Organics Ltd. has a negative interest coverage ratio of -1.64, raising concerns about debt obligations and suggesting financial distress; in contrast, Dhanuka Agritech has the highest ratio at 104.16."
    ]
)

activity_ratio_data = ActivityRatios(
    graphs={
        "Current Ratio": Graph(url="https://drive.google.com/file/d/1F2xCzUGg5_meimuJMktlrlTqS8zHD3zh/view?usp=sharing"),
        "Quick Ratio": Graph(url="https://drive.google.com/file/d/183SKVNZD1NBqJZtwUeM4IDf59z9xlYRE/view?usp=sharing"),
        "Inventory Turnover": Graph(url="https://drive.google.com/file/d/183SKVNZD1NBqJZtwUeM4IDf59z9xlYRE/view?usp=sharing"),
        "Cash Cycle Days": Graph(url="https://drive.google.com/file/d/183SKVNZD1NBqJZtwUeM4IDf59z9xlYRE/view?usp=sharing")                
    },
    commentary=[
                "Meghmani Organics Ltd.'s current ratio is 1.13, which is lower than the median value of 1.9 for its peer group. This suggests that the company has a relatively weaker ability to meet its short-term obligations compared to its peers. A current ratio below 1 is generally considered a warning sign, indicating potential liquidity issues.",
                "The quick ratio, a more stringent measure of short-term liquidity, is even lower at 0.73 for Meghmani Organics Ltd. This further reinforces concerns about the company's ability to cover its immediate liabilities with its most liquid assets.",
                "The company's inventory turnover ratio is 5.90, which is in line with the median value for its peer group. This suggests that Meghmani Organics Ltd. is managing its inventory at a comparable pace to its peers. However, it's important to note that a high inventory turnover ratio doesn't always indicate efficient inventory management; it could also point to insufficient inventory levels, potentially leading to lost sales.",
                "Meghmani Organics Ltd. has a cash cycle of 105 days, which is higher than the median value of 93 days for its peer group. This indicates that the company takes a longer time to convert its inventory into cash, potentially tying up working capital and impacting its operational efficiency. Bharat Rasayan has the shortest cash cycle in the peer group at 65.7 days, highlighting its superior working capital management."
    ]
)

# Parsing the output from the model/API
report_data["valuation_ratios"] = json.loads(valuation_data.model_dump_json())
report_data["peer_ratings"] = json.loads(peer_ratings.model_dump_json())
report_data["performance_ratios"] = json.loads(performance_ratios_data.model_dump_json())
report_data["leverage_ratio"] = json.loads(leverage_ratio_data.model_dump_json())
report_data["activity_ratio"] = json.loads(activity_ratio_data.model_dump_json())
if __name__ == "__main__":
    file_path = "report_data.json"
    #print(json.dumps(report_data))

    with open(file_path, 'w') as file:
        json.dump(report_data, file, indent=4)
    
    print(f"Data successfully written to {file_path}")    