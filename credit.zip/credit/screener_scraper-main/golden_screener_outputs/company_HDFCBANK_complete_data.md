# Complete Company Data

## Modal Content
About
[
edit
]
HDFC Bank Limited (also known as HDFC) is an Indian banking and financial services company headquartered in Mumbai. It is India's largest private sector bank by assets and the world's tenth-largest bank by market capitalization as of May 2024.
As of April 2024, HDFC Bank has a market capitalization of $145 billion, making it the third-largest company on the Indian stock exchanges.
[1]
Key Points
[
edit
]
Key Ratios - FY22
[1]
Capital Adequacy Ratio - 18.9%
Net Interest Margin - 4.12%
Gross NPA - 1.17%
Net NPA - 0.32%
CASA Ratio - 48%
Cost to Income ratio – 38.3%
Segment revenue - FY22
[2]
Treasury – 14%
Retail banking – 46%
Wholesale banking – 27%
Other banking operations – 13%
Location-wise breakup
[3]
Domestic - 99%
International - 1%
International Footprints
[4]
The Bank has offices and branches in Bahrain, Hong Kong, UAE, and Kenya where they offer NRI clients Offshore Deposits, Bonds, Equity, Mutual Funds, Treasury, and Structured products offered by third parties from Bahrain Branch. As on March 31, 2022, Balance Sheet size of International Business was US$7.66 Billion.
PAN India Presence
[5]
The Bank's network includes 21,683 Banking outlets comprising Branches (6342) and Business Correspondents (15,431), ATMs/ Cash Deposits, and Withdrawal Machines (18,130) spread across India as of FY22.
Loan Mix - FY22
[6]
Retail – 39%
CRB – 35%
Wholesale – 26%
Sector-wise loan breakup
[7]
Agriculture and allied activities – 26%
Advances to industries eligible as priority sector lending – 33%
Services – 32%
Personal loans – 9%
Leadership in the Payments business
[8]
HDFC is a leading player in the Payments ecosystem in the country. Every third rupee spent on cards in India happens on an HDFC Bank’s issued instrument.
They have issued almost 3.21 Crore debit cards and 1.45 Crore credit cards.
On the acquiring side currently they have over 17 Lakh merchant acceptance points across India. They have a dominant market share, with approximately 50% of electronic card volumes.
Leadership
HDFC Bank is the second largest collector of direct taxes.
[9]
Number 1 in middle-market banking with 60% market share.
[10]
One of the largest banking networks in semi-urban and rural India.
[11]
HDFC Bank continues to be a leader in the auto loans segment with strong presence in passenger, commercial vehicle and two-wheeler financing.
[12]
Market leader in almost every asset category with best-in-class portfolio quality.
[13]
Market leader in cash management services.
[13]
Market share
[14]
Advances – 11.2%
Deposits – 9.5%
Acquiring volumes – 46%
Credit Cards – 23%
Reach
[14]
Customer Base – 70 Mn+
Banking Branches – 6.3K+
Banking Outlets  - 21K+
Balance sheet size - 20,68,535 Cr
Amalgamation Proposal
[15]
Co. has proposed a scheme of amalgamation for the amalgamation of (i) HDFC Investments Limited and HDFC Holdings Limited, wholly-owned subsidiaries of Housing Development Finance Corporation Limited, with and into HDFC Limited, and (ii) HDFC Limited with and into HDFC Bank Limited. The Co. has received approval from the CCI and the RBI and the amalgamation is expected to be complete by the third quarter of FY24.
Fun fact
[16]
- HDFC Bank was the first bank in India to launch an International Debit Card in association with VISA (VISA Electron) and issues the MasterCard Maestro debit card as well.
Last edited 1 month ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 35,861 | 42,555 | 50,666 | 63,162 | 73,271 | 85,288 | 105,161 | 122,189 | 128,552 | 135,936 | 170,754 | 283,649 | 314,027 |
| Interest | 19,695 | 23,445 | 27,288 | 34,070 | 38,042 | 42,381 | 53,713 | 62,137 | 59,248 | 58,584 | 77,780 | 154,139 | 172,763 |
| Expenses + | 12,631 | 13,508 | 16,164 | 20,055 | 23,856 | 29,532 | 34,856 | 45,459 | 52,457 | 56,557 | 63,042 | 174,196 | 208,507 |
| Financing Profit | 3,534 | 5,602 | 7,214 | 9,037 | 11,374 | 13,374 | 16,592 | 14,593 | 16,848 | 20,795 | 29,932 | -44,685 | -67,244 |
| Financing Margin % | 10% | 13% | 14% | 14% | 16% | 16% | 16% | 12% | 13% | 15% | 18% | -16% | -21% |
| Other Income + | 7,133 | 8,298 | 9,546 | 11,212 | 12,905 | 16,057 | 18,947 | 24,879 | 27,333 | 31,759 | 33,912 | 124,346 | 149,943 |
| Depreciation | 663 | 689 | 680 | 738 | 886 | 967 | 1,221 | 1,277 | 1,385 | 1,681 | 2,345 | 3,092 | 0 |
| Profit before tax | 10,004 | 13,211 | 16,079 | 19,511 | 23,393 | 28,464 | 34,318 | 38,195 | 42,796 | 50,873 | 61,498 | 76,569 | 82,699 |
| Tax % | 31% | 34% | 33% | 34% | 35% | 35% | 35% | 29% | 26% | 25% | 25% | 15% |  |
| Net Profit + | 6,903 | 8,768 | 10,703 | 12,821 | 15,317 | 18,561 | 22,446 | 27,296 | 31,857 | 38,151 | 46,149 | 65,446 | 70,231 |
| EPS in Rs | 14.44 | 18.22 | 21.32 | 25.32 | 29.81 | 35.66 | 41.00 | 49.70 | 57.74 | 68.62 | 82.44 | 84.33 | 89.75 |
| Dividend Payout % | 19% | 19% | 19% | 19% | 18% | 18% | 18% | 5% | 11% | 23% | 23% | 23% |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 70% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 40% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transactions |  |  |  |  |  |  |  |  |  |  |
| Deposits taken | 2,329 | 4,517 | 2,539 | 3,265 | 3,318 | 7,740 | 4,297 | 5,157 | 4,531 | 6,939 |
| Deposits placed | 36 | 9.76 | 2.66 | 2.98 | 2.98 | 1.23 | 4.73 | 0.32 | 0.32 | 0.53 |
| Advances given | 48 | 38 | 3.49 | 3.16 | 3.11 | 2.87 | 2.34 | 0.74 | 0.61 | 3,403 |
| Fixed assets purchased from |  |  |  |  |  |  |  |  |  | 13 |
| Interest paid to | 13 | 12 | 7.10 | 8.71 | 6.62 | 10 | 20 | 21 | 10 | 13 |
| Interest received from | 4.55 | 2.29 | 0.03 | 13 | 35 | 0.09 | 0.05 | 0.02 | 0.01 | 201 |
| Income from services rendered to | 157 | 185 | 207 | 264 | 233 | 309 | 325 | 464 | 589 | 200 |
| Expenses for receiving services from | 1,180 | 1,422 | 344 | 406 |  | 587 | 590 | 720 | 865 | 293 |
| Equity investments | 31 | 31 | 31 |  |  |  |  |  |  | 2,635 |
| Dividend paid to | 272 | 318 | 378 | 438 | 519 | 875 |  | 564 | 1,347 | 9.19 |
| Dividend received from | 0.01 | 0.01 |  |  |  |  |  |  |  | 0.01 |
| Receivable from / Advance paid |  |  |  |  |  |  |  |  |  | 19 |
| Guarantees given | 0.11 | 0.14 | 0.14 | 0.25 | 0.40 | 0.40 | 0.46 | 0.40 | 0.35 | 68 |
| Remuneration paid | 15 | 18 | 21 | 19 | 26 | 28 | 22 | 17 | 21 | 27 |
| Loans purchased from | 8,249 | 12,773 | 13,846 | 5,624 | 23,982 | 24,127 | 18,980 | 28,205 | 36,910 | 11,632 |
| Other investments |  |  |  |  |  |  |  |  |  | 49 |
| Payable to | 112 | 130 | 34 | 33 | 34 | 100 | 199 | 64 | 77 | 98 |
| Receivable from | 16 | 29 | 23 | 28 | 48 | 55 | 139 | 136 | 97 |  |
| Expenses for receiving servioes from |  |  |  |  | 488 |  |  |  |  |  |
| Other Investments |  |  |  | 1,604 | 1,740 |  |  |  |  |  |
| Balance - Deposits taken |  |  |  | 3,288 |  |  |  |  |  |  |
| Balance - Deposits placed |  |  |  | 2.98 |  |  |  |  |  |  |
| Balance - Advances given |  |  |  | 3.45 |  |  |  |  |  |  |
| Balance - Other Investments |  |  |  | 1,604 |  |  |  |  |  |  |
| Balance - Receivable from |  |  |  | 61 |  |  |  |  |  |  |
| Balance - Payable to |  |  |  | 36 |  |  |  |  |  |  |
| Balance - Guarantees given |  |  |  | 0.27 |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 35,861 | 42,555 | 50,666 | 63,162 | 73,271 | 85,288 | 105,161 | 122,189 | 128,552 | 135,936 | 170,754 | 283,649 | 314,027 |
| Interest | 19,695 | 23,445 | 27,288 | 34,070 | 38,042 | 42,381 | 53,713 | 62,137 | 59,248 | 58,584 | 77,780 | 154,139 | 172,763 |
| Expenses + | 12,631 | 13,508 | 16,164 | 20,055 | 23,856 | 29,532 | 34,856 | 45,459 | 52,457 | 56,557 | 63,042 | 174,196 | 208,507 |
| Financing Profit | 3,534 | 5,602 | 7,214 | 9,037 | 11,374 | 13,374 | 16,592 | 14,593 | 16,848 | 20,795 | 29,932 | -44,685 | -67,244 |
| Financing Margin % | 10% | 13% | 14% | 14% | 16% | 16% | 16% | 12% | 13% | 15% | 18% | -16% | -21% |
| Other Income + | 7,133 | 8,298 | 9,546 | 11,212 | 12,905 | 16,057 | 18,947 | 24,879 | 27,333 | 31,759 | 33,912 | 124,346 | 149,943 |
| Depreciation | 663 | 689 | 680 | 738 | 886 | 967 | 1,221 | 1,277 | 1,385 | 1,681 | 2,345 | 3,092 | 0 |
| Profit before tax | 10,004 | 13,211 | 16,079 | 19,511 | 23,393 | 28,464 | 34,318 | 38,195 | 42,796 | 50,873 | 61,498 | 76,569 | 82,699 |
| Tax % | 31% | 34% | 33% | 34% | 35% | 35% | 35% | 29% | 26% | 25% | 25% | 15% |  |
| Net Profit + | 6,903 | 8,768 | 10,703 | 12,821 | 15,317 | 18,561 | 22,446 | 27,296 | 31,857 | 38,151 | 46,149 | 65,446 | 70,231 |
| EPS in Rs | 14.44 | 18.22 | 21.32 | 25.32 | 29.81 | 35.66 | 41.00 | 49.70 | 57.74 | 68.62 | 82.44 | 84.33 | 89.75 |
| Dividend Payout % | 19% | 19% | 19% | 19% | 18% | 18% | 18% | 5% | 11% | 23% | 23% | 23% |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 70% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 40% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -5,847 | 4,211 | -21,281 | -34,435 | 17,282 | 17,214 | -62,872 | -16,869 | 42,476 | -11,960 | 20,814 | 19,069 |
| Cash from Investing Activity + | -902 | -1,099 | -800 | -837 | -1,146 | -842 | -1,503 | -1,403 | -1,823 | -2,051 | -2,992 | 16,600 |
| Cash from Financing Activity + | 13,105 | 9,270 | 18,694 | 37,815 | -5,893 | 57,378 | 23,131 | 24,394 | -7,321 | 48,124 | 23,941 | -3,983 |
| Net Cash Flow | 6,356 | 12,382 | -3,387 | 2,542 | 10,242 | 73,750 | -41,244 | 6,122 | 33,332 | 34,113 | 41,762 | 31,687 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % | 21% | 22% | 20% | 19% | 18% | 18% | 17% | 16% | 16% | 17% | 17% | 17% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 25.83% | 25.80% | 25.78% | 25.73% | 25.64% | 25.60% | 25.59% | 25.52% | 0.00% | 0.00% | 0.00% | 0.00% |
| FIIs + | 38.23% | 37.47% | 35.62% | 32.31% | 32.14% | 32.10% | 32.24% | 33.38% | 52.13% | 52.31% | 47.83% | 47.17% |
| DIIs + | 22.53% | 22.97% | 24.55% | 27.11% | 27.53% | 28.13% | 28.09% | 26.75% | 30.39% | 30.54% | 33.33% | 35.20% |
| Government + | 0.16% | 0.16% | 0.16% | 0.16% | 0.16% | 0.16% | 0.16% | 0.16% | 0.17% | 0.17% | 0.18% | 0.18% |
| Public + | 13.25% | 13.60% | 13.89% | 14.69% | 14.51% | 13.99% | 13.91% | 14.19% | 17.30% | 16.98% | 18.64% | 17.44% |
| No. of Shareholders | 15,98,813 | 18,88,276 | 21,51,630 | 26,60,577 | 25,20,911 | 23,03,291 | 22,90,092 | 23,45,672 | 30,58,659 | 30,18,247 | 41,21,815 | 36,64,325 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 26.00% | 25.60% | 26.50% | 26.14% | 25.97% | 25.78% | 25.59% | 0.00% | 0.00% |
| FIIs + | 42.13% | 40.43% | 38.71% | 36.68% | 39.79% | 35.62% | 32.24% | 47.83% | 47.17% |
| DIIs + | 12.94% | 14.97% | 16.41% | 21.74% | 20.99% | 24.55% | 28.09% | 33.33% | 35.20% |
| Government + | 0.13% | 0.13% | 0.20% | 0.23% | 0.24% | 0.16% | 0.16% | 0.18% | 0.18% |
| Public + | 18.80% | 18.87% | 18.19% | 15.21% | 13.01% | 13.89% | 13.91% | 18.64% | 17.44% |
| No. of Shareholders | 4,63,568 | 5,10,377 | 5,89,930 | 12,86,083 | 13,75,294 | 21,51,630 | 22,90,092 | 41,21,815 | 36,64,325 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/hdfc-bank-ltd/hdfcbank/500180/corp-announcements/)
- [Intimation Under Regulation 30 Of The SEBI (LODR) Regulations, 2015 2m](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91898dcf-4fd7-4d6f-96af-a2179b2e9ff9.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
17h - Transcript of Earnings call for the quarter ended June 30, 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94d03650-9410-4870-b9ba-d4c553d2740b.pdf)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e47bef7e-d747-4557-9b29-257bdd078551.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=54667276-2161-476a-9729-df57637b5d97.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a390e197-60e6-49cf-a197-b7aa88f2a9f7.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2160dea5-d49e-4409-83a4-c2b111a3bd12.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\0fb0e6bd-7110-44c3-a750-76933ddf105c.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/73256500180.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/68609500180.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_HDFCBANK_2011_2012_20062012100212.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800311.pdf)

## Credit Ratings
- [Rating update
1 Jul from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128559)
- [Rating update
28 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/HDFCBankLimited_June%2028_%202024_RR_346791.html)
- [Rating update
7 Mar from care](https://www.careratings.com/upload/CompanyFiles/PR/202403120301_HDFC_Bank_Limited.pdf)
- [Rating update
5 Dec 2023 from fitch](https://www.indiaratings.co.in/pressrelease/67483)
- [Rating update
13 Nov 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202311121153_HDFC_Bank_Limited.pdf)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=120819)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94d03650-9410-4870-b9ba-d4c553d2740b.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdf)
- [REC](https://www.youtube.com/watch?v=bi_jiwKLKnQ)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdfhttps://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=880ee466-e764-4e05-9ef3-3d9bb8e485f4.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/20April/Q4FY24-Earnings-Presentation.pdf)
- [REC](https://youtu.be/xh0oa926udk?si=WQGaj1nPMlGJcHpr)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=12bab14e-f504-46e9-90cd-0881a76dd4a6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d34bd589-124e-40f2-80b5-82f360a98639.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=163829d1-3b5f-41f7-bd9e-9f3509869245.pdf)
- [Transcript](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/23/Earnings-Call-Transcript-Jan16-2024.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/16/Q3FY24_Earnings_Presentation.pdf)
- [REC](https://www.youtube.com/watch?v=j6_jnIErxXE)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/Financial%20Information/PDF/HDFC-Bank-Day/1.%20HDFCB_Day_30Oct23_vF.pdf)
- [](https://www.youtube.com/watch?v=APkBOH4Y2Jw)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d420b35c-488c-4ea9-84ca-6183de7e29f4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7931b031-359d-4da8-8425-b4f26c2d2547.pdf)
- [](https://www.youtube.com/watch?v=sDUS9GSyRqc&t=1s)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/oct/HDFC-EarningsCall-Oct16-2023_CallTranscript.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/oct/Q2FY24%20Earnings%20Presentation.pdf)
- [](https://www.youtube.com/watch?v=eFTe9K7T9Pk)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d28f086c-3d7a-4a6d-a138-a0c2123a963a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=989cf3a5-9a81-458e-b0ec-7ea60cc482a7.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/july/HDFCB_Q1FY24_Earnings_Presentation.pdf)
- [](https://www.youtube.com/watch?v=KfKI0xSaKxw)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57e720ab-83b3-4b34-bb81-0c364e88c938.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/Q4FY23-Earnings-Presentation.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=42e79ecc-a641-4f9d-8fdc-a4dde6cefb16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e9327050-8f62-42f3-a539-bd91f156647d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5ad442e-6916-47c7-ac65-c42c31df289f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25b7a31b-fd86-456f-8a27-51b4119fe7ce.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=27bf8aa3-9098-4724-9192-7f384e76f3c2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3087c6b-5b89-43bd-bea9-4250ab026f85.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | HDFC Bank | 1616.00 | 1229472.57 | 18.03 | 2.69 | 3.92 | 203.82 | 16.08 | 7.26 | 1.22 | 7.67 | 1.99 | 17.14 | 0.09 | 6.81 | 1.48 | 7.19 | 314027.08 | 33.60 | 68166.51 | 81546.20 | 16474.85 | 59.37 | 33.18 | 89.75 | 3107502.74 | 0.00 | 0.00 | 6.22 | 12.00 | 0.00 | 70.07 | 39.72 | 4108140.80 | 2.50 | 0.77 | 7.07 | 12.66 | 3.94 | -3.38 | 16.99 | 16.85 | 23.42 | 26.19 | 21.95 | 30.19 | 17.11 | 6.24 | 2.50 | 84.33 | 15.48 | 21.14 | 19.93 | 24.91 | 0.00 | 557.97 |
| 2. | ICICI Bank | 1218.00 | 857265.73 | 19.34 | 3.96 | 5.37 | 12.60 | 15.64 | 23.57 | 0.83 | 8.37 | 2.35 | 20.63 | 0.08 | 6.53 | 1.83 | 9.13 | 159515.92 | 36.37 | 44256.37 | 42606.72 | 11671.52 | 23.72 | 18.46 | 63.02 | 1399893.96 | 0.00 | 0.00 | 6.44 | 12.00 | 0.00 | 31.76 | 30.17 | 2120703.20 | 2.20 | 0.32 | 8.12 | 18.61 | 20.92 | 20.97 | 17.74 | 15.61 | 59.74 | 34.01 | 17.25 | 21.40 | 17.15 | 6.32 | 2.20 | 63.02 | 57.03 | 22.48 | 19.58 | 22.46 | 0.00 | 698.28 |
| 3. | Axis Bank | 1176.35 | 363605.48 | 13.57 | 2.33 | 3.09 | 27.61 | 15.38 | 10.01 | 0.09 | 7.06 | 1.85 | 18.40 | 0.08 | 8.25 | 1.55 | 9.12 | 117671.83 | 62.96 | 26731.28 | 31158.52 | 6436.43 | 18.72 | 5.67 | 86.63 | 1295301.95 | 8.31 | 0.09 | 6.50 | 12.00 | 0.00 | 24.52 | 17.09 | 1542414.25 | 2.68 | 0.35 | 4.03 | 12.82 | 17.13 | 22.50 | 13.57 | 10.97 | 39.18 | 54.17 | 15.01 | 20.53 | 8.73 | 5.12 | 2.68 | 85.49 | 34.19 | 20.56 | 14.40 | 30.77 | 0.00 | 307.69 |
| 4. | Kotak Mah. Bank | 1813.00 | 360415.61 | 19.40 | 2.74 | 6.09 | 53.89 | 16.70 | 3.26 | 0.11 | 7.86 | 2.62 | 15.06 | 0.08 | 4.00 | 1.99 | 5.34 | 59204.49 | 15.88 | 18642.68 | 15836.79 | 4579.66 | 23.06 | 10.35 | 108.22 | 520374.37 | 25.89 | -0.01 | 6.04 | 12.00 | 0.00 | 29.11 | 14.23 | 815583.59 | 1.97 | 0.95 | 10.36 | 0.38 | 1.49 | -5.26 | 14.32 | 14.06 | 20.42 | 22.27 | 13.52 | 19.66 | 14.31 | 6.86 | 1.97 | 91.62 | 19.45 | 29.26 | 26.25 | 34.60 | 0.00 | 198.66 |
| 5. | IDBI Bank | 104.21 | 112050.72 | 17.77 | 2.24 | 4.27 | 782.79 | 17.40 | 26.64 | 1.40 | 6.23 | 1.65 | 11.77 | 0.08 | 5.77 | 1.71 | 6.81 | 26251.87 | 68.52 | 6293.17 | 6669.84 | 1734.32 | -2.82 | 41.09 | 5.85 | 294448.21 | 94.71 | 0.00 | 5.79 | 12.00 | 0.00 | 15.06 | 51.03 | 380489.45 | 2.23 | 0.94 | 14.51 | 21.51 | 38.73 | 75.54 | 8.98 | 0.32 | 18.98 | 55.84 | 3.65 | 9.84 | 8.34 | 4.79 | 2.23 | 5.38 | 17.89 | 17.67 | 17.02 | 17.67 | 0.00 | 1075.24 |
| 6. | IndusInd Bank | 1404.45 | 109368.08 | 12.18 | 1.96 | 2.39 | -23.11 | 11.82 | -0.52 | 1.20 | 8.42 | 1.95 | 16.39 | 0.10 | 7.06 | 1.48 | 8.38 | 45748.21 | 60.52 | 8949.78 | 12198.53 | 2346.84 | 21.73 | 15.01 | 114.99 | 385449.37 | 15.79 | -0.02 | 8.50 | 12.00 | 45.48 | 25.79 | 21.08 | 438306.31 | 4.57 | 0.55 | -4.65 | -8.79 | 12.22 | -2.58 | 13.85 | 12.76 | 22.07 | 46.69 | 15.50 | 16.41 | 14.45 | 6.91 | 4.57 | 114.99 | 15.98 | 15.48 | 14.42 | 19.35 | 0.00 | 77.59 |
| 7. | Yes Bank | 24.95 | 78182.44 | 53.84 | 1.74 | 2.71 | 44.04 | 18.16 | -23.83 | 0.00 | 5.83 | 0.34 | 3.18 | 0.07 | 8.41 | 1.09 | 9.24 | 28885.91 | 58.49 | 1454.52 | 7725.41 | 516.00 | 19.86 | 48.84 | 0.49 | 346737.14 | 0.00 | 0.00 | 5.52 | 12.00 | 0.00 | 20.30 | 89.30 | 405601.13 | 4.42 | -9.75 | -5.85 | -0.93 | 23.56 | 45.25 | 2.79 | -10.37 | -5.52 | 33.31 | -1.40 | 11.27 | 1.99 | 4.94 | 4.42 | 0.45 | -42.92 | 50.33 | 52.98 | 27.25 | 0.00 | 2875.48 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | Sales | ₹ 3,14,027 Cr. |
| HDFCBANK | OPM | 33.6 % |
| HDFCBANK | Profit after tax | ₹ 68,167 Cr. |
| HDFCBANK | Mar Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Sales Qtr | ₹ 81,546 Cr. |
| HDFCBANK | PAT Qtr | ₹ 16,475 Cr. |
| HDFCBANK | Qtr Sales Var | 59.4 % |
| HDFCBANK | Qtr Profit Var | 33.2 % |
| HDFCBANK | Price to Earning | 18.0 |
| HDFCBANK | Dividend yield | 1.22 % |
| HDFCBANK | Price to book value | 2.69 |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | Return on assets | 1.99 % |
| HDFCBANK | Debt to equity | 6.81 |
| HDFCBANK | Return on equity | 17.1 % |
| HDFCBANK | EPS | ₹ 89.8 |
| HDFCBANK | Debt | ₹ 31,07,503 Cr. |
| HDFCBANK | Promoter holding | 0.00 % |
| HDFCBANK | Change in Prom Hold | 0.00 % |
| HDFCBANK | Earnings yield | 6.22 % |
| HDFCBANK | Pledged percentage | 0.00 % |
| HDFCBANK | Industry PE | 12.0 |
| HDFCBANK | Sales growth | 70.1 % |
| HDFCBANK | Profit growth | 39.7 % |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | Price to Sales | 3.92 |
| HDFCBANK | CMP / FCF | 204 |
| HDFCBANK | EVEBITDA | 16.1 |
| HDFCBANK | Enterprise Value | ₹ 41,08,141 Cr. |
| HDFCBANK | Current ratio | 2.50 |
| HDFCBANK | Int Coverage | 1.48 |
| HDFCBANK | PEG Ratio | 0.77 |
| HDFCBANK | Return over 3months | 7.07 % |
| HDFCBANK | Return over 6months | 12.7 % |
| HDFCBANK | No. Eq. Shares | 761 |
| HDFCBANK | Sales growth 3Years | 30.2 % |
| HDFCBANK | Sales growth 5Years | 22.0 % |
| HDFCBANK | Profit Var 3Yrs | 26.2 % |
| HDFCBANK | Profit Var 5Yrs | 23.4 % |
| HDFCBANK | ROE 5Yr | 16.8 % |
| HDFCBANK | ROE 3Yr | 17.0 % |
| HDFCBANK | Return over 1year | -3.38 % |
| HDFCBANK | Return over 3years | 3.94 % |
| HDFCBANK | Return over 5years | 7.26 % |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | Sales last year | ₹ 2,83,649 Cr. |
| HDFCBANK | OP Ann | ₹ 1,09,453 Cr. |
| HDFCBANK | Other Inc Ann | ₹ 1,24,346 Cr. |
| HDFCBANK | EBIDT last year | ₹ 2,33,599 Cr. |
| HDFCBANK | Dep Ann | ₹ 3,092 Cr. |
| HDFCBANK | EBIT last year | ₹ 2,30,507 Cr. |
| HDFCBANK | Interest last year | ₹ 1,54,139 Cr. |
| HDFCBANK | PBT Ann | ₹ 76,569 Cr. |
| HDFCBANK | Tax last year | ₹ 11,122 Cr. |
| HDFCBANK | PAT Ann | ₹ 63,902 Cr. |
| HDFCBANK | Extra Ord Item Ann | ₹ 200 Cr. |
| HDFCBANK | NP Ann | ₹ 65,446 Cr. |
| HDFCBANK | Dividend last year | ₹ 14,814 Cr. |
| HDFCBANK | Raw Material | 0.00 % |
| HDFCBANK | Employee cost | ₹ 31,050 Cr. |
| HDFCBANK | OPM last year | 38.6 % |
| HDFCBANK | NPM last year | 23.0 % |
| HDFCBANK | Operating profit | ₹ 1,05,520 Cr. |
| HDFCBANK | Interest | ₹ 1,72,763 Cr. |
| HDFCBANK | Depreciation | ₹ 0.00 Cr. |
| HDFCBANK | EPS last year | ₹ 84.3 |
| HDFCBANK | EBIT | ₹ 2,55,463 Cr. |
| HDFCBANK | Net profit | ₹ 70,231 Cr. |
| HDFCBANK | Current Tax | ₹ 12,468 Cr. |
| HDFCBANK | Tax | ₹ 12,468 Cr. |
| HDFCBANK | Other income | ₹ 1,49,943 Cr. |
| HDFCBANK | Ann Date | 2,02,403 |
| HDFCBANK | Sales Prev Ann | ₹ 1,70,754 Cr. |
| HDFCBANK | OP Prev Ann | ₹ 1,07,712 Cr. |
| HDFCBANK | Other Inc Prev Ann | ₹ 33,912 Cr. |
| HDFCBANK | EBIDT Prev Ann | ₹ 1,41,530 Cr. |
| HDFCBANK | Dep Prev Ann | ₹ 2,345 Cr. |
| HDFCBANK | EBIT preceding year | ₹ 1,39,185 Cr. |
| HDFCBANK | Interest Prev Ann | ₹ 77,780 Cr. |
| HDFCBANK | PBT Prev Ann | ₹ 61,498 Cr. |
| HDFCBANK | Tax preceding year | ₹ 15,350 Cr. |
| HDFCBANK | PAT Prev Ann | ₹ 45,927 Cr. |
| HDFCBANK | Extra Ord Prev Ann | ₹ 93.4 Cr. |
| HDFCBANK | NP Prev Ann | ₹ 46,149 Cr. |
| HDFCBANK | Dividend Prev Ann | ₹ 10,601 Cr. |
| HDFCBANK | OPM preceding year | 63.1 % |
| HDFCBANK | NPM preceding year | 27.0 % |
| HDFCBANK | EPS preceding year | ₹ 82.4 |
| HDFCBANK | Sales Prev 12M | ₹ 2,83,649 Cr. |
| HDFCBANK | Profit Prev 12M | ₹ 65,446 Cr. |
| HDFCBANK | Med Sales Gwth 10Yrs | 16.4 % |
| HDFCBANK | Med Sales Gwth 5Yrs | 16.2 % |
| HDFCBANK | Sales growth 7Years | 21.3 % |
| HDFCBANK | Sales Var 10Yrs | 20.9 % |
| HDFCBANK | EBIDT growth 3Years | 31.2 % |
| HDFCBANK | EBIDT growth 5Years | 21.2 % |
| HDFCBANK | EBIDT growth 7Years | 20.8 % |
| HDFCBANK | EBIDT Var 10Yrs | 20.1 % |
| HDFCBANK | EPS growth 3Years | 13.4 % |
| HDFCBANK | EPS growth 5Years | 15.5 % |
| HDFCBANK | EPS growth 7Years | 16.0 % |
| HDFCBANK | EPS growth 10Years | 16.5 % |
| HDFCBANK | Profit Var 7Yrs | 22.7 % |
| HDFCBANK | Profit Var 10Yrs | 22.0 % |
| HDFCBANK | Chg in Prom Hold 3Yr | -25.9 % |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | OP Qtr | ₹ 31,857 Cr. |
| HDFCBANK | Other Inc Qtr | ₹ 35,450 Cr. |
| HDFCBANK | EBIDT Qtr | ₹ 67,307 Cr. |
| HDFCBANK | Dep Qtr | ₹ 0.00 Cr. |
| HDFCBANK | EBIT latest quarter | ₹ 67,307 Cr. |
| HDFCBANK | Interest Qtr | ₹ 44,580 Cr. |
| HDFCBANK | PBT Qtr | ₹ 22,727 Cr. |
| HDFCBANK | Tax latest quarter | ₹ 5,539 Cr. |
| HDFCBANK | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| HDFCBANK | NP Qtr | ₹ 17,188 Cr. |
| HDFCBANK | GPM latest quarter | 100 % |
| HDFCBANK | OPM latest quarter | 39.1 % |
| HDFCBANK | NPM latest quarter | 21.1 % |
| HDFCBANK | Eq Cap Qtr | ₹ 761 Cr. |
| HDFCBANK | EPS latest quarter | ₹ 21.6 |
| HDFCBANK | OP 2Qtr Bk | ₹ 27,478 Cr. |
| HDFCBANK | OP 3Qtr Bk | ₹ 29,690 Cr. |
| HDFCBANK | Sales 2Qtr Bk | ₹ 78,008 Cr. |
| HDFCBANK | Sales 3Qtr Bk | ₹ 75,039 Cr. |
| HDFCBANK | NP 2Qtr Bk | ₹ 17,718 Cr. |
| HDFCBANK | NP 3Qtr Bk | ₹ 17,312 Cr. |
| HDFCBANK | Opert Prft Gwth | -8.89 % |
| HDFCBANK | Last result date | 2,02,406 |
| HDFCBANK | Exp Qtr Sales Var | 70.5 % |
| HDFCBANK | Exp Qtr Sales | ₹ 1,27,951 Cr. |
| HDFCBANK | Exp Qtr OP | ₹ 45,583 Cr. |
| HDFCBANK | Exp Qtr NP | ₹ 1,002 Cr. |
| HDFCBANK | Exp Qtr EPS | ₹ 1.26 |
| HDFCBANK | Sales Prev Qtr | ₹ 79,434 Cr. |
| HDFCBANK | OP Prev Qtr | ₹ 16,495 Cr. |
| HDFCBANK | Other Inc Prev Qtr | ₹ 44,958 Cr. |
| HDFCBANK | EBIDT Prev Qtr | ₹ 61,453 Cr. |
| HDFCBANK | Dep Prev Qtr | ₹ 0.00 Cr. |
| HDFCBANK | EBIT Prev Qtr | ₹ 61,453 Cr. |
| HDFCBANK | Interest Prev Qtr | ₹ 43,692 Cr. |
| HDFCBANK | PBT Prev Qtr | ₹ 17,761 Cr. |
| HDFCBANK | Tax Prev Qtr | ₹ -251 Cr. |
| HDFCBANK | PAT Prev Qtr | ₹ 17,622 Cr. |
| HDFCBANK | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| HDFCBANK | NP Prev Qtr | ₹ 18,013 Cr. |
| HDFCBANK | OPM Prev Qtr | 20.8 % |
| HDFCBANK | NPM Prev Qtr | 22.7 % |
| HDFCBANK | Eq Cap Prev Qtr | ₹ Cr. |
| HDFCBANK | EPS Prev Qtr | ₹ 23.2 |
| HDFCBANK | Sales PY Qtr | ₹ 51,168 Cr. |
| HDFCBANK | OP PY Qtr | ₹ 32,698 Cr. |
| HDFCBANK | Other Inc PY Qtr | ₹ 9,853 Cr. |
| HDFCBANK | EBIDT PY Qtr | ₹ 42,551 Cr. |
| HDFCBANK | Dep PY Qtr | ₹ 0.00 Cr. |
| HDFCBANK | EBIT PY Qtr | ₹ 42,551 Cr. |
| HDFCBANK | Interest PY Qtr | ₹ 25,955 Cr. |
| HDFCBANK | PBT PY Qtr | ₹ 16,597 Cr. |
| HDFCBANK | Tax PY Qtr | ₹ 4,193 Cr. |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | Equity capital | ₹ 760 Cr. |
| HDFCBANK | Preference capital | ₹ 0.00 Cr. |
| HDFCBANK | Reserves | ₹ 4,55,636 Cr. |
| HDFCBANK | Secured loan | ₹ 7,30,615 Cr. |
| HDFCBANK | Unsecured loan | ₹ 23,76,887 Cr. |
| HDFCBANK | Balance sheet total | ₹ 40,30,194 Cr. |
| HDFCBANK | Gross block | ₹ 30,266 Cr. |
| HDFCBANK | Revaluation reserve | ₹ 0.00 Cr. |
| HDFCBANK | Accum Dep | ₹ 17,663 Cr. |
| HDFCBANK | Net block | ₹ 12,604 Cr. |
| HDFCBANK | CWIP | ₹ 0.00 Cr. |
| HDFCBANK | Investments | ₹ 10,05,682 Cr. |
| HDFCBANK | Current assets | ₹ 4,36,716 Cr. |
| HDFCBANK | Current liabilities | ₹ 1,74,832 Cr. |
| HDFCBANK | BV Unq Invest | ₹ 3,23,206 Cr. |
| HDFCBANK | MV Quoted Inv | ₹ 0.00 Cr. |
| HDFCBANK | Cont Liab | ₹ 24,09,821 Cr. |
| HDFCBANK | Total Assets | ₹ 40,30,194 Cr. |
| HDFCBANK | Working capital | ₹ 2,61,883 Cr. |
| HDFCBANK | Lease liabilities | ₹ 0.00 Cr. |
| HDFCBANK | Inventory | ₹ 0.00 Cr. |
| HDFCBANK | Trade receivables | ₹ 0.00 Cr. |
| HDFCBANK | Face value | ₹ 1.00 |
| HDFCBANK | Cash Equivalents | ₹ 2,28,835 Cr. |
| HDFCBANK | Adv Cust | ₹ 0.00 Cr. |
| HDFCBANK | Trade Payables | ₹ 13,933 Cr. |
| HDFCBANK | No. Eq. Shares PY | 558 |
| HDFCBANK | Debt preceding year | ₹ 21,39,212 Cr. |
| HDFCBANK | Work Cap PY | ₹ 2,40,255 Cr. |
| HDFCBANK | Net Block PY | ₹ 8,431 Cr. |
| HDFCBANK | Gross Block PY | ₹ 21,822 Cr. |
| HDFCBANK | CWIP PY | ₹ 0.00 Cr. |
| HDFCBANK | Work Cap 3Yr | ₹ 86,964 Cr. |
| HDFCBANK | Work Cap 5Yr | ₹ 66,752 Cr. |
| HDFCBANK | Work Cap 7Yr | ₹ 30,790 Cr. |
| HDFCBANK | Work Cap 10Yr | ₹ 21,061 Cr. |
| HDFCBANK | Debt 3Years back | ₹ 15,11,418 Cr. |
| HDFCBANK | Debt 5Years back | ₹ 10,80,235 Cr. |
| HDFCBANK | Debt 7Years back | ₹ 7,41,550 Cr. |
| HDFCBANK | Debt 10Years back | ₹ 4,16,677 Cr. |
| HDFCBANK | Net Block 3Yrs Back | ₹ 5,248 Cr. |
| HDFCBANK | Net Block 5Yrs Back | ₹ 4,369 Cr. |
| HDFCBANK | Net Block 7Yrs Back | ₹ 4,000 Cr. |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | CF Operations | ₹ 19,069 Cr. |
| HDFCBANK | Free Cash Flow | ₹ 14,882 Cr. |
| HDFCBANK | CF Investing | ₹ 16,600 Cr. |
| HDFCBANK | CF Financing | ₹ -3,983 Cr. |
| HDFCBANK | Net CF | ₹ 31,687 Cr. |
| HDFCBANK | Cash Beginning | ₹ 1,97,148 Cr. |
| HDFCBANK | Cash End | ₹ 2,28,835 Cr. |
| HDFCBANK | FCF Prev Ann | ₹ 17,390 Cr. |
| HDFCBANK | CF Operations PY | ₹ 20,814 Cr. |
| HDFCBANK | CF Investing PY | ₹ -2,992 Cr. |
| HDFCBANK | CF Financing PY | ₹ 23,941 Cr. |
| HDFCBANK | Net CF PY | ₹ 41,762 Cr. |
| HDFCBANK | Cash Beginning PY | ₹ 1,55,386 Cr. |
| HDFCBANK | Cash End PY | ₹ 1,97,148 Cr. |
| HDFCBANK | Free Cash Flow 3Yrs | ₹ 18,096 Cr. |
| HDFCBANK | Free Cash Flow 5Yrs | ₹ 40,406 Cr. |
| HDFCBANK | Free Cash Flow 7Yrs | ₹ -7,688 Cr. |
| HDFCBANK | Free Cash Flow 10Yrs | ₹ -48,875 Cr. |
| HDFCBANK | CF Opr 3Yrs | ₹ 27,923 Cr. |
| HDFCBANK | CF Opr 5Yrs | ₹ 53,531 Cr. |
| HDFCBANK | CF Opr 7Yrs | ₹ 7,874 Cr. |
| HDFCBANK | CF Opr 10Yrs | ₹ -30,561 Cr. |
| HDFCBANK | CF Inv 10Yrs | ₹ 3,203 Cr. |
| HDFCBANK | CF Inv 7Yrs | ₹ 5,987 Cr. |
| HDFCBANK | CF Inv 5Yrs | ₹ 8,331 Cr. |
| HDFCBANK | CF Inv 3Yrs | ₹ 11,557 Cr. |
| HDFCBANK | Cash 3Years back | ₹ 1,21,273 Cr. |
| HDFCBANK | Cash 5Years back | ₹ 81,818 Cr. |
| HDFCBANK | Cash 7Years back | ₹ 49,311 Cr. |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | No. Eq. Shares | 761 |
| HDFCBANK | Book value | ₹ 601 |
| HDFCBANK | Inven TO |  |
| HDFCBANK | Quick ratio | 2.50 |
| HDFCBANK | Exports percentage | 0.00 % |
| HDFCBANK | Piotroski score | 5.00 |
| HDFCBANK | G Factor | 5.00 |
| HDFCBANK | Asset Turnover | 0.09 |
| HDFCBANK | Financial leverage | 7.19 |
| HDFCBANK | No. of Share Holders | 36,64,325 |
| HDFCBANK | Unpledged Prom Hold | 0.00 % |
| HDFCBANK | ROIC | 7.67 % |
| HDFCBANK | Debtor days | 0.00 |
| HDFCBANK | Industry PBV | 1.87 |
| HDFCBANK | Credit rating |  |
| HDFCBANK | WC Days | 42.5 |
| HDFCBANK | Earning Power | 6.34 % |
| HDFCBANK | Graham Number | ₹ 1,101 |
| HDFCBANK | Cash Cycle | 0.00 |
| HDFCBANK | Days Payable |  |
| HDFCBANK | Days Receivable | 0.00 |
| HDFCBANK | Inventory Days |  |
| HDFCBANK | Public holding | 17.4 % |
| HDFCBANK | FII holding | 47.2 % |
| HDFCBANK | Chg in FII Hold | -0.66 % |
| HDFCBANK | DII holding | 35.2 % |
| HDFCBANK | Chg in DII Hold | 1.87 % |
| HDFCBANK | B.V. Prev Ann | ₹ 519 |
| HDFCBANK | ROCE Prev Yr | 6.24 % |
| HDFCBANK | ROA Prev Yr | 1.98 % |
| HDFCBANK | ROE Prev Ann | 17.1 % |
| HDFCBANK | No. of Share Holders Prev Qtr | 41,21,815 |
| HDFCBANK | No. Eq. Shares 10 Yrs | 501 |
| HDFCBANK | BV 3yrs back | ₹ 381 |
| HDFCBANK | BV 5yrs back | ₹ 322 |
| HDFCBANK | BV 10yrs back | ₹ 126 |
| HDFCBANK | Inven TO 3Yr |  |
| HDFCBANK | Inven TO 5Yr |  |
| HDFCBANK | Inven TO 7Yr |  |
| HDFCBANK | Inven TO 10Yr |  |
| HDFCBANK | Export 3Yr | 0.00 % |
| HDFCBANK | Export 5Yr | 0.00 % |
| HDFCBANK | Div 5Yrs | ₹ 7,793 Cr. |
| HDFCBANK | ROCE 3Yr | 6.58 % |
| HDFCBANK | ROCE 5Yr | 6.67 % |
| HDFCBANK | ROCE 7Yr | 6.94 % |
| HDFCBANK | ROCE 10Yr | 7.31 % |
| HDFCBANK | ROE 10Yr | 17.2 % |
| HDFCBANK | ROE 7Yr | 17.0 % |
| HDFCBANK | ROE 5Yr Var | 0.22 % |
| HDFCBANK | OPM 5Year | 53.4 % |
| HDFCBANK | OPM 10Year | 57.6 % |
| HDFCBANK | No. of Share Holders 1Yr | 23,45,672 |
| HDFCBANK | Avg Div Payout 3Yrs | 22.9 % |
| HDFCBANK | Debtor days 3yrs | 0.00 |
| HDFCBANK | Debtor days 3yrs back | 0.00 |
| HDFCBANK | Debtor days 5yrs back | 0.00 |
| HDFCBANK | ROA 5Yr | 1.94 % |
| HDFCBANK | ROA 3Yr | 1.97 % |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | Avg Vol 1Mth | 2,44,92,617 |
| HDFCBANK | Avg Vol 1Wk | 2,47,65,787 |
| HDFCBANK | Volume | 1,31,90,428 |
| HDFCBANK | High price | ₹ 1,794 |
| HDFCBANK | Low price | ₹ 1,363 |
| HDFCBANK | High price all time | ₹ 1,794 |
| HDFCBANK | Low price all time | ₹ 44.8 |
| HDFCBANK | Return over 1day | -0.04 % |
| HDFCBANK | Return over 1week | 0.58 % |
| HDFCBANK | Return over 1month | -4.99 % |
| HDFCBANK | DMA 50 | ₹ 1,603 |
| HDFCBANK | DMA 200 | ₹ 1,556 |
| HDFCBANK | DMA 50 previous day | ₹ 1,603 |
| HDFCBANK | 200 DMA prev. | ₹ 1,556 |
| HDFCBANK | RSI | 47.6 |
| HDFCBANK | MACD | -1.05 |
| HDFCBANK | MACD Previous Day | -0.10 |
| HDFCBANK | MACD Signal | 7.74 |
| HDFCBANK | MACD Signal Prev | 9.94 |
| HDFCBANK | Avg Vol 1Yr | 2,15,86,013 |
| HDFCBANK | Return over 7years | 8.91 % |
| HDFCBANK | Return over 10years | 14.6 % |
| HDFCBANK | Market Cap | ₹ 12,29,473 Cr. |
| HDFCBANK | Current Price | ₹ 1,616 |
| HDFCBANK | High / Low | ₹ 1,794 / 1,363 |
| HDFCBANK | Stock P/E | 18.0 |
| HDFCBANK | Book Value | ₹ 601 |
| HDFCBANK | Dividend Yield | 1.22 % |
| HDFCBANK | ROCE | 7.67 % |
| HDFCBANK | ROE | 17.1 % |
| HDFCBANK | Face Value | ₹ 1.00 |
| HDFCBANK | WC to Sales | 83.4 % |
| HDFCBANK | QoQ Profits | -4.58 % |
| HDFCBANK | QoQ Sales | 2.66 % |
| HDFCBANK | Net worth | ₹ 4,56,395 Cr. |
| HDFCBANK | Market Cap to Sales | 3.92 |
| HDFCBANK | Interest Coverage | 1.48 |
| HDFCBANK | EV / EBIT | 16.1 |
| HDFCBANK | Debt Capacity | -1.50 |
| HDFCBANK | Debt To Profit | 47.5 |
| HDFCBANK | Capital Employed | ₹ 2,74,487 Cr. |
| HDFCBANK | CROIC | 0.20 % |
| HDFCBANK | debtplus | 12.1 |
| HDFCBANK | Leverage | ₹ 7.19 |
| HDFCBANK | Dividend Payout | 23.1 % |
| HDFCBANK | Intrinsic Value | ₹ 1,144 |
| HDFCBANK | CDL | -430 % |
| HDFCBANK | Cash by market cap | 0.17 |
| HDFCBANK | 52w Index | 58.7 % |
| HDFCBANK | Down from 52w high | 9.92 % |
| HDFCBANK | Up from 52w low | 18.5 % |
| HDFCBANK | From 52w high | 0.90 |
| HDFCBANK | Mkt Cap To Debt Cap | 9.19 |
| HDFCBANK | Dividend Payout | 23.1 % |
| HDFCBANK | Graham | ₹ 1,101 |
| HDFCBANK | Price to Cash Flow | 64.5 |
| HDFCBANK | ROCE3yr avg | 6.58 % |
| HDFCBANK | PB X PE | 48.5 |
| HDFCBANK | NCAVPS | ₹ 344 |
| HDFCBANK | Mar Cap to CF | 64.5 |
| HDFCBANK | Altman Z Score | 1.01 |
| HDFCBANK | M.Cap / Qtr Profit | 74.6 |