# Complete Company Data

## Modal Content
About
[
edit
]
Established in 1910, ITC is the largest cigarette manufacturer and seller in the country. ITC operates in five business segments at present — FMCG Cigarettes, FMCG Others, Hotels, Paperboards, Paper and Packaging, and Agri Business.
[1]
Key Points
[
edit
]
Geographical Distribution
For FY22, India accounted for 78% of ITC's revenue while rest was from exports
[1]
FMCG - Cigarettes
ITC is the leader in the organised domestic cigarette market with a market share of over 80%
[2]
. It's wide range of brands include Insignia, India Kings, Classic, Gold Flake, American Club, Wills Navy Cut, Players, Scissors, Capstan, Berkeley, Bristol, Flake, Silk Cut, Duke & Royal.
[3]
Despite this vertical contributing only 40% to the revenues, it is the
most profitable business of the company with 81% contribution towards PBIT.
[4]
Industry:
India is the 4th largest market for illegal cigarettes. While the consumption rate of legal cigarettes is only 1/10th in the tobacco industry, It accounts for 4/5th Tax revenue share. Legal cigarette industry remains under pressure due to growth in illicit duty-evaded cigarette consumption.
[5]
FMCG - Others
ITC has 25 mother brands spread across multiple FMCG sectors
[6]
. Popular brands include:
- Packaged foods: Aashirvaad, Sunfeast, Bingo, Yippee noodles, Candyman and mint-o
- Personal Care: Savlon, Fiama, Vivel and Superia
- Stationary: Classmate and Paperkraft
- Apparels: WLS
- Agarbattis: Mangaldeep and AIM (matches)
‘ITC e-Store’, the Company’s exclusive D2C platform, is operational in 24,000+ pin-codes.
[7]
Hotels Business
Launched in 1975, ITC Hotels is one of the fastest growing hospitality chains in India. It is the second-largest hotel chain in India, with 108 hotels at 70 locations in the country, operating across multiple market segments. It possess a room inventory of ~290,000 rooms.
[8]
It's hotels are classified under 4 distinctive brands.
- ITC Hotels: which has an exclusive tie up with Marriott International Inc's 'The Luxury Collection'.
- Welcomhotels: which offers 5-star hospitality for the discerning business & leisure traveller.
- Fortune Hotels: which operates in mid-market to upscale properties hotel segment all over India.
- WelcomHeritage: which brings together a chain of palaces, forts, havelis & resorts that offer unique experience.
[9]
In H1FY24, they added 3 new properties to the Group portfolio including ‘WelcomHeritage Santa Roza, Kasauli’, ‘Fortune Park Hoshiarpur’ and ‘Fortune Ranjit Vihar, Amritsar.
[10]
Agri. Business
ITC is the second largest exporter of agri products from the country. It trades in feed ingredients, food grains, marine products, processed fruits, coffee etc
[11]
.
It also exports leaf tobacco under this vertical. ITC is India's largest and world's 5th largest leaf tobacco exporter
[12]
.
In H1FY24, ITC IndiVision Limited (IIVL), (WOS) received requisite regulatory approvals for its facility to manufacture Nicotine & Nicotine Derivative products conforming to US &
EU pharmacopoeia standards.
[13]
Paperboards, Paper & Packaging
ITC is the market leader in value added paperboards segment. It is also India’s largest converter of paperboard into high quality packaging.
[14]
ITC manufactures the entire spectrum of paperboards - from 100% virgin, food-grade boards which are made from renewable and sustainable sources to 100% recycled boards.
[15]
Revenue Split FY23
[2]
Cigarettes : 37% (vs ~57% in FY17)
FMCG : 23%
Hotels  : 3%
Paperboards & Packaging :11%
Agri : 23%
Demerger of Hotel Business
[2]
In Aug,23, the company has approved to dmerge its hotels  business into  a  new  entity
ITC  Hotels  Limited
.  ITC  will  continue  to have  a 40%  shareholding  in  the  new  entity  and  the balance 60% will be held by ITC’s existing shareholders in the proportion of their shareholding in ITC.
Last edited 6 months, 4 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 31,618 | 35,306 | 38,817 | 39,192 | 42,768 | 43,449 | 48,340 | 49,388 | 49,257 | 60,645 | 70,919 | 70,866 |
| Expenses + | 20,398 | 22,227 | 24,566 | 24,661 | 27,298 | 26,928 | 29,802 | 30,044 | 32,193 | 40,021 | 45,215 | 44,634 |
| Operating Profit | 11,221 | 13,080 | 14,252 | 14,531 | 15,470 | 16,521 | 18,537 | 19,344 | 17,065 | 20,623 | 25,704 | 26,233 |
| OPM % | 35% | 37% | 37% | 37% | 36% | 38% | 38% | 39% | 35% | 34% | 36% | 37% |
| Other Income + | 852 | 966 | 1,229 | 1,483 | 1,759 | 2,240 | 2,080 | 2,417 | 2,577 | 1,910 | 2,098 | 2,804 |
| Interest | 108 | 29 | 91 | 78 | 49 | 115 | 71 | 81 | 58 | 60 | 78 | 80 |
| Depreciation | 859 | 965 | 1,028 | 1,077 | 1,153 | 1,236 | 1,397 | 1,645 | 1,646 | 1,732 | 1,809 | 1,816 |
| Profit before tax | 11,106 | 13,052 | 14,362 | 14,859 | 16,026 | 17,409 | 19,150 | 20,035 | 17,938 | 20,740 | 25,915 | 27,140 |
| Tax % | 31% | 31% | 32% | 36% | 35% | 34% | 33% | 22% | 25% | 25% | 25% | 24% |
| Net Profit + | 7,704 | 9,001 | 9,779 | 9,501 | 10,477 | 11,493 | 12,836 | 15,593 | 13,383 | 15,503 | 19,477 | 20,751 |
| EPS in Rs | 6.42 | 7.45 | 8.04 | 7.74 | 8.47 | 9.24 | 10.27 | 12.45 | 10.69 | 12.37 | 15.44 | 16.39 |
| Dividend Payout % | 55% | 54% | 52% | 73% | 56% | 56% | 56% | 82% | 101% | 93% | 100% | 84% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tobacco Manufacturers (India) Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments |  |  |  |  |  |  |  |  | 3,648 | 4,691 |
| British American Tobacco (GLP) Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 1,352 | 1,071 |
| Adjustment / Payment towards Refund of Advances |  |  |  |  |  |  |  |  | 1,325 | 1,035 |
| Advances Received during the year |  |  |  |  |  |  |  |  | 1,153 | 882 |
| Advances taken |  |  |  |  |  |  |  |  | 521 | 368 |
| Receivables |  |  |  |  |  |  |  |  | 36 | 24 |
| Expenses Recovered |  |  |  |  |  |  |  |  | 22 | 4.86 |
| Tobacco Manufacturers (India) Limited, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments | 1,191 | 1,241 | 1,688 |  | 1,534 | 1,713 |  |  |  |  |
| JSC ‘British American Tobacco-SPb’ Associate |  |  |  |  |  |  |  |  |  |  |
| Advances Received during the year |  |  |  |  |  |  |  |  | 651 | 100 |
| Adjustment / Payment towards Refund of Advances |  |  |  |  |  |  |  |  | 452 | 299 |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 447 | 299 |
| ITC Essentra Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods/Services | 303 |  |  |  | 272 | 243 |  |  |  |  |
| Purchase of Goods / Services |  | 291 | 253 |  |  |  |  |  |  |  |
| Sale of Goods/Services | 9.84 |  |  |  | 42 | 26 |  |  |  |  |
| Payables | 4.56 | 5.78 | 0.87 |  | 16 | 8.49 |  |  |  |  |
| Sale of Goods / Services |  | 9.30 | 6.88 |  |  |  |  |  |  |  |
| Dividend Income | 2.02 | 2.02 | 2.03 |  | 2.70 | 6.75 |  |  |  |  |
| Receivables |  |  | 1.22 |  | 0.20 | 5.68 |  |  |  |  |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 0.55 | 0.73 |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.60 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.52 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.18 | 0.06 |  |  |  |  |
| Expenses Reimbursed | 0.08 |  |  |  |  |  |  |  |  |  |
| Myddleton Investment Company Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments |  |  |  |  |  |  |  |  | 596 | 766 |
| ITC Filtrona Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 438 | 639 |
| Dividend Income |  |  |  |  |  |  |  |  | 18 | 22 |
| Payables |  |  |  |  |  |  |  |  | 21 | 9.65 |
| British American Shared Services (GSD) Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 219 | 392 |
| Receivables |  |  |  |  |  |  |  |  | 56 | 179 |
| International Travel House Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  | 89 | 85 |  |  |  |  |  | 87 | 122 |
| Purchase of Goods/Services | 93 |  |  |  | 99 | 110 |  |  |  |  |
| Payables | 11 | 7.14 | 6.16 |  | 4.75 | 3.34 |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 1.54 | 2.02 |  |  |  |  |  | 4.06 | 3.54 |
| Receivables |  |  | 5.20 |  | 0.60 | 2.83 |  |  |  |  |
| Sale of Goods/Services | 1.77 |  |  |  | 3.45 | 3.02 |  |  |  |  |
| Dividend Income | 1.66 | 1.66 | 1.66 |  | 1.66 | 0.98 |  |  |  |  |
| Rent Received | 1.41 | 1.17 | 1.02 |  | 1.05 | 1.08 |  |  | 0.87 | 0.88 |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 2.84 | 2.59 |  |  |  |  |
| Sale of Goods / Services |  | 2.47 | 2.77 |  |  |  |  |  |  |  |
| Deposits Taken | 0.67 | 0.67 | 0.63 |  | 0.63 | 0.63 |  |  | 0.60 | 0.60 |
| Reimbursement for Share Based Payments |  |  |  |  | 0.99 | 0.12 |  |  | 1.46 | 0.57 |
| Capital Contribution for Share Based |  |  | 2.58 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 2.58 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 2.27 |  |  |  |  |  |  |  |
| Expenses Recovered | 0.71 | 0.18 | 0.36 |  | 0.23 | 0.22 |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 1.45 |  |  |  |  |  |  |  |  |  |
| Adjustment/Receipt towards Refund of Advances | 0.02 |  |  |  |  | 1.12 |  |  |  |  |
| Advances Given during the year |  |  |  |  | 0.26 | 0.68 |  |  |  |  |
| Advances Given |  |  |  |  | 0.49 | 0.05 |  |  |  |  |
| Expenses Reimbursed | 0.13 | 0.17 | 0.03 |  |  |  |  |  |  |  |
| Adjustment / Payment towards Refund of Deposit |  |  | 0.04 |  |  |  |  |  |  |  |
| Deposit Received |  |  |  |  | 0.01 |  |  |  |  |  |
| IATC Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 24 | 23 | 25 |  |  | 36 |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 39 | 43 |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 30 |  |  |  |  |  |
| ITC Pension Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 41 | 21 | 37 |  |  | 22 |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 21 | 56 |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 21 |  |  |  |  |  |
| Employee Trust - Gratuity Funds |  |  |  |  |  |  |  |  |  |  |
| Payables | 38 |  |  |  |  | 30 |  |  | 25 | 46 |
| Advances Given |  |  |  |  | 18 |  |  |  |  |  |
| Employee Trust - Pension Funds |  |  |  |  |  |  |  |  |  |  |
| Advances Given |  |  |  |  | 42 |  |  |  |  | 31 |
| Payables |  |  | 6.44 |  |  | 61 |  |  |  |  |
| ITC Management Staff Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 23 | 17 | 15 |  |  |  |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 24 | 30 |
| ITC Defined Contribution Pension Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 15 | 16 | 18 |  |  | 16 |  |  |  |  |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 22 |  |  |  |  |  |
| S. Puri Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 6.16 | 10 |  |  | 12 | 13 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 10 | 13 |
| Gujarat Hotels Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 3.20 | 3.49 | 3.74 |  | 4.36 | 4.42 |  |  | 4.32 | 4.06 |
| Remuneration of Managers on Deputation reimbursed |  | 3.93 | 5.05 |  | 0.59 | 0.67 |  |  | 7.06 | 6.45 |
| Payables |  |  |  |  | 2.09 | 2.01 |  |  |  |  |
| Remuneration of Managers on Deputation Reimbursed | 3.44 |  |  |  |  |  |  |  |  |  |
| Dividend Income | 0.61 | 0.61 | 0.61 |  | 0.61 | 0.61 |  |  |  |  |
| Expenses Reimbursed | 0.08 | 0.06 | 0.09 |  | 0.22 | 0.25 |  |  | 0.25 | 0.27 |
| Remuneration of Managers on Deputation recovered |  |  | 0.62 |  |  |  |  |  |  |  |
| Employees Trust - Pension Funds |  |  |  |  |  |  |  |  |  |  |
| Advances Given | 48 | 13 |  |  |  |  |  |  |  |  |
| ITC Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 3.30 | 21 | 11 |  |  | 13 |  |  |  |  |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 10 |  |  |  |  |  |
| Sproutlife Foods Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in Associates |  |  |  |  |  |  |  |  |  | 50 |
| Remuneration of Managers on Deputation recovered |  |  |  |  |  |  |  |  |  | 1.97 |
| Reimbursement for Share Based Payments |  |  |  |  |  |  |  |  |  | 0.25 |
| ATC Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 1.88 | 1.81 |  |  |  |  |  | 3.11 | 2.99 |
| Loans Given | 4.20 | 2.80 | 1.40 |  |  |  |  |  |  |  |
| Payables |  |  |  |  | 3.16 | 2.39 |  |  |  |  |
| Receivables | 0.78 | 0.11 | 2.21 |  | 1.15 | 0.52 |  |  |  |  |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 2.19 | 2.30 |  |  |  |  |
| Receipt towards Loan Repayment | 1.40 | 1.40 | 1.40 |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 3.12 |  |  |  |  |  |  |  |  |  |
| Expenses Reimbursed | 0.33 | 0.38 | 0.62 |  |  |  |  |  |  |  |
| Interest Income | 0.59 | 0.42 | 0.24 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.48 | 0.17 |  |  | 0.35 | 0.14 |
| Capital Contribution for Share Based |  |  | 0.63 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.63 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.57 |  |  |  |  |  |  |  |
| Sale of Fixed Assets/Scraps | 0.53 |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipments etc./ Scraps |  | 0.27 | 0.05 |  |  |  |  |  |  |  |
| Mr. Y.C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  | 14 | 19 |  |  |  |  |  |  |  |
| N. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 3.74 | 5.65 |  |  | 5.96 | 4.81 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 4.47 | 7.41 |
| Adjustment / Receipt towards Refund of Deposit |  |  |  |  |  |  |  |  |  | 0.05 |
| Deposits Given |  |  |  |  |  | 0.05 |  |  |  |  |
| B. Sumant Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 1.17 | 4.95 |  |  | 5.35 | 5.74 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 5.04 | 6.69 |
| Sale of Property, Plant and Equipment |  |  |  |  |  |  |  |  |  | 0.09 |
| ITC Sangeet Research Academy |  |  |  |  |  |  |  |  |  |  |
| Expenditure towards Corporate Social Responsibility | 24 |  |  |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation Reimbursed | 0.19 |  |  |  |  |  |  |  |  |  |
| Employees Trust - Gratuity Funds |  |  |  |  |  |  |  |  |  |  |
| Payables |  | 21 | 1.56 |  |  |  |  |  |  |  |
| Y.C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 16 | 5.12 |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.10 |  |  |  |  |
| Maharaja Heritage Resorts Limited JV |  |  |  |  |  |  |  |  |  |  |
| Receivables | 3.33 | 2.73 | 3.32 |  | 3.33 | 2.30 |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 0.95 | 0.96 |  |  |  |  |  |  |  |
| Expenses Recovered | 0.36 | 0.35 | 0.29 |  | 0.31 | 0.20 |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 0.92 |  |  |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.53 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.44 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.23 | 0.03 |  |  |  |  |
| Russell Investments Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Loans Taken |  |  | 18 |  |  |  |  |  |  |  |
| Interest Paid |  |  | 0.43 |  |  |  |  |  |  |  |
| S. Dutta Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  |  |  |  |  | 4.31 | 5.08 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 2.51 | 4.15 |
| Sale of Property, Plant and Equipment |  |  |  |  |  |  |  |  |  | 0.12 |
| Deposits Given |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Mr. Y. C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration to | 14 |  |  |  |  |  |  |  |  |  |
| Deposits Given | 0.05 | 0.05 | 0.05 |  |  |  |  |  |  |  |
| Logix Developers Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Impairment of investment in |  |  |  |  | 4.82 | 4.67 |  |  |  |  |
| Investment in | 3.87 |  |  |  |  |  |  |  |  |  |
| Mother Sparsh Baby Care Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in Associates |  |  |  |  |  |  |  |  |  | 12 |
| R. Tandon Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 3.20 | 4.92 |  |  |  |  |
| Deposits Given |  |  |  |  | 0.03 | 0.03 |  |  |  |  |
| Mrs. B. Deveshwar Relative |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.66 | 0.66 | 0.72 |  |  |  |  |  |  |  |
| Deposits Given | 0.30 | 0.30 | 0.30 |  |  |  |  |  |  |  |
| M. Shankar Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.81 |  |  |  |  |
| S. Banerjee Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.72 | 0.81 |  |  |  |  |
| S. B. Mathur Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.80 |  |  |  |  |
| A. Duggal Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.78 |  |  |  |  |
| British American Tobacco Exports Limited |  |  |  |  |  |  |  |  |  |  |
| Expenses Recovered |  |  |  |  |  |  |  |  |  | 1.31 |
| H. Bhargava Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.48 | 0.80 |  |  |  |  |
| B. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Rent Paid |  |  |  |  | 0.75 | 0.13 |  |  |  |  |
| Deposits Given |  |  |  |  | 0.38 |  |  |  |  |  |
| S. S. H. Rehman Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.78 | 0.41 |  |  |  |  |
| Mr. S. B. Mathur Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.31 | 0.51 |  |  |  |  |  |  |  |
| Ms. M. Shankar Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.30 | 0.51 |  |  |  |  |  |  |  |
| Mr. S. S. H. Rehman Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.30 | 0.51 |  |  |  |  |  |  |  |
| Classic Infrastructure & Development Limited |  |  |  |  |  |  |  |  |  |  |
| Acquisition cost of Property, Plant and Equipments etc. |  | 0.37 |  |  |  |  |  |  |  |  |
| Deposits Given | 0.10 |  |  |  |  |  |  |  |  |  |
| N. Singhi Relative |  |  |  |  |  |  |  |  |  |  |
| Deposits Given |  |  |  |  | 0.03 | 0.03 |  |  | 0.03 | 0.03 |
| K.S. Suresh Key Person |  |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipment |  |  |  |  |  | 0.11 |  |  |  |  |
| T. Anand Relative |  |  |  |  |  |  |  |  |  |  |
| Adjustment / Receipt towards Refund of Deposit |  |  |  |  |  |  |  |  |  | 0.05 |
| Deposits Given |  |  |  |  |  | 0.05 |  |  |  |  |
| R. K. Singhi Key Person |  |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipment |  |  |  |  |  | 0.07 |  |  |  |  |
| Y. C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Deposits Given |  |  |  |  | 0.05 |  |  |  |  |  |
| Mr. R. Tandon Relative |  |  |  |  |  |  |  |  |  |  |
| Deposits Given during the year | 0.02 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 31,618 | 35,306 | 38,817 | 39,192 | 42,768 | 43,449 | 48,340 | 49,388 | 49,257 | 60,645 | 70,919 | 70,866 |
| Expenses + | 20,398 | 22,227 | 24,566 | 24,661 | 27,298 | 26,928 | 29,802 | 30,044 | 32,193 | 40,021 | 45,215 | 44,634 |
| Operating Profit | 11,221 | 13,080 | 14,252 | 14,531 | 15,470 | 16,521 | 18,537 | 19,344 | 17,065 | 20,623 | 25,704 | 26,233 |
| OPM % | 35% | 37% | 37% | 37% | 36% | 38% | 38% | 39% | 35% | 34% | 36% | 37% |
| Other Income + | 852 | 966 | 1,229 | 1,483 | 1,759 | 2,240 | 2,080 | 2,417 | 2,577 | 1,910 | 2,098 | 2,804 |
| Interest | 108 | 29 | 91 | 78 | 49 | 115 | 71 | 81 | 58 | 60 | 78 | 80 |
| Depreciation | 859 | 965 | 1,028 | 1,077 | 1,153 | 1,236 | 1,397 | 1,645 | 1,646 | 1,732 | 1,809 | 1,816 |
| Profit before tax | 11,106 | 13,052 | 14,362 | 14,859 | 16,026 | 17,409 | 19,150 | 20,035 | 17,938 | 20,740 | 25,915 | 27,140 |
| Tax % | 31% | 31% | 32% | 36% | 35% | 34% | 33% | 22% | 25% | 25% | 25% | 24% |
| Net Profit + | 7,704 | 9,001 | 9,779 | 9,501 | 10,477 | 11,493 | 12,836 | 15,593 | 13,383 | 15,503 | 19,477 | 20,751 |
| EPS in Rs | 6.42 | 7.45 | 8.04 | 7.74 | 8.47 | 9.24 | 10.27 | 12.45 | 10.69 | 12.37 | 15.44 | 16.39 |
| Dividend Payout % | 55% | 54% | 52% | 73% | 56% | 56% | 56% | 82% | 101% | 93% | 100% | 84% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 7,102 | 7,344 | 9,843 | 9,799 | 10,627 | 13,169 | 12,583 | 14,690 | 12,527 | 15,776 | 18,878 | 17,179 |
| Cash from Investing Activity + | -3,881 | -3,254 | -5,275 | -3,921 | -3,251 | -7,114 | -5,546 | -6,174 | 5,740 | -2,238 | -5,732 | 1,563 |
| Cash from Financing Activity + | -3,310 | -4,122 | -4,661 | -5,613 | -7,301 | -6,221 | -6,869 | -8,181 | -18,634 | -13,580 | -13,006 | -18,551 |
| Net Cash Flow | -90 | -32 | -93 | 266 | 75 | -166 | 169 | 334 | -367 | -43 | 139 | 191 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 16 | 25 | 19 | 18 | 21 | 23 | 30 | 19 | 19 | 15 | 15 | 21 |
| Inventory Days | 227 | 228 | 212 | 244 | 185 | 173 | 165 | 187 | 189 | 150 | 148 | 190 |
| Days Payable | 53 | 58 | 50 | 63 | 60 | 80 | 74 | 76 | 78 | 61 | 59 | 64 |
| Cash Conversion Cycle | 189 | 195 | 181 | 199 | 145 | 115 | 122 | 129 | 129 | 104 | 105 | 146 |
| Working Capital Days | -5 | 9 | -4 | 52 | 45 | 31 | 32 | 35 | 36 | 31 | 20 | 38 |
| ROCE % | 51% | 50% | 47% | 40% | 36% | 34% | 34% | 32% | 28% | 33% | 39% | 37% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 10.81% | 9.99% | 11.99% | 12.68% | 42.68% | 42.99% | 43.35% | 43.62% | 43.34% | 43.26% | 40.95% | 40.47% |
| DIIs + | 43.72% | 43.79% | 42.77% | 42.82% | 42.38% | 42.19% | 42.08% | 41.92% | 41.94% | 41.98% | 43.76% | 44.02% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% |
| Public + | 45.47% | 46.22% | 45.24% | 44.50% | 14.87% | 14.78% | 14.52% | 14.41% | 14.68% | 14.71% | 15.23% | 15.47% |
| No. of Shareholders | 25,68,030 | 29,97,699 | 28,40,964 | 28,38,036 | 28,96,358 | 29,36,692 | 29,30,527 | 30,13,793 | 32,74,360 | 33,35,815 | 36,48,537 | 37,56,541 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 20.08% | 18.00% | 17.04% | 14.65% | 12.79% | 11.99% | 43.35% | 40.95% | 40.47% |
| DIIs + | 35.79% | 37.10% | 38.20% | 42.46% | 42.50% | 42.77% | 42.08% | 43.76% | 44.02% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.04% | 0.04% | 0.04% |
| Public + | 44.13% | 44.90% | 44.76% | 42.89% | 44.71% | 45.24% | 14.52% | 15.23% | 15.47% |
| No. of Shareholders | 5,47,642 | 7,95,843 | 8,57,729 | 13,02,214 | 21,96,475 | 28,40,964 | 29,30,527 | 36,48,537 | 37,56,541 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/itc-ltd/itc/500875/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 18h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6687839f-ece7-470e-b424-6fc7ccdc78dd.pdf)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS
1d - Allotment of Shares under the Employee Stock Option Scheme of the Company](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d19190d0-d68a-4d7e-a67b-c617971b8587.pdf)
- [Announcement under Regulation 30 (LODR)-Acquisition
1d - Incorporation of a new step-down subsidiary](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8bdc0678-404b-4473-8da9-4da0011c99dd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e0b5341-4e69-4542-91a0-6b54e5394689.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=abb630cb-3d0d-4c5b-9c5d-d8452123a027.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0d1e906-3c13-4993-ad06-e04ad1d3edf9.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\139aec7a-7a7c-458f-ac5a-29f6dbe67c93.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/73265500875.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/68921500875.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_78_ITC_2012_2013_14062013150845.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ITC_2011_2012_19062012102526.zip)

## Credit Ratings
- [Rating update
30 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123920)
- [Rating update
25 Aug 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_August%2025,%202023_RR_326644.html)
- [Rating update
30 May 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_May%2030,%202022_RR_285350.html)
- [Rating update
30 Nov 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=108456)
- [Rating update
22 Mar 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_March%2022,%202021_RR_266798.html)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=99619)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=454583fe-e8a2-460f-ba6c-a1a1a18cb212.pdf)
- [PPT](https://www.itcportal.com/investor/pdf/ITC-Quarterly-Result-Presentation-Q3-FY2024.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=15fd926d-385d-48cb-b633-2881957ea931.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48d23504-9689-4992-84d0-3fa3d87f1292.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cd6cc39f-c7ae-4992-a507-cf03c161331c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd8c529d-569d-48b3-a6a5-20775e32469a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d3fdc92d-c38c-47e8-970f-3a3cd3029ad3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fcf710b0-8cea-4618-b926-529b0b507173.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b85d79fe-a90f-4658-a40f-694c2129b575.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=130deaf2-2b61-45d8-a8ef-f32fc5101725.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e5729d2a-7bba-4fa9-aee5-e54e02af782a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9acadc1b-6a34-4f24-9a60-beae911c443f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ce674fb0-b609-40ba-ba6d-a83a52ecb99f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cadd3c07-476f-48d0-a4d2-4191b0526c6f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7e129185-3494-413a-bf72-82dafec0466b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=86bb35bf-feea-4dde-81b0-3d76fd7b8ac1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28198f4c-275e-41f7-86ae-7762089286b1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8708013f-f5bf-43a2-b5ac-5697dcd7b1d5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e7c9402-6b1a-44fd-8f94-0c40d68a9f73.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=00d9271e-d28e-41af-8e44-c261de2e56a8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=20533893-3b74-46d2-a05b-f4056bc43fa7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2603809a-76e9-4152-ac56-8272825a9ad7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1c378d93-a1bd-4728-b6e1-5c876a6c8b4e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=582a7a17-ead9-45cd-9eb2-2524f42b99e3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=83ea3cbd-781f-4e97-b0d5-f2065db99dec.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | ITC | 505.20 | 631291.56 | 30.91 | 8.48 | 8.91 | 43.36 | 21.54 | 12.62 | 2.73 | 37.47 | 23.33 | 28.43 | 0.80 | 0.00 | 339.39 | 1.19 | 70866.22 | 37.02 | 20422.35 | 17922.70 | 5122.09 | 1.63 | 0.02 | 16.39 | 303.43 | 0.00 | 0.00 | 4.49 | 24.64 | 0.00 | -0.07 | 6.69 | 624377.31 | 2.05 | 3.08 | 11.35 | 7.53 | 32.92 | 5.35 | 27.51 | 25.74 | 10.05 | 15.65 | 7.95 | 12.89 | 29.09 | 39.01 | 1.02 | 16.39 | 9.64 | 21.74 | 25.04 | 25.17 | 146.05 | 1242.80 |
| 2. | Godfrey Phillips | 4303.65 | 22376.40 | 25.36 | 5.28 | 5.06 | 50.36 | 20.51 | 43.35 | 1.01 | 22.62 | 16.35 | 22.70 | 0.82 | 0.08 | 36.74 | 1.28 | 4419.59 | 20.19 | 883.04 | 965.78 | 214.16 | 21.31 | 45.60 | 169.84 | 345.39 | 72.58 | 0.00 | 4.24 | 24.64 | 0.00 | 24.06 | 50.11 | 22696.81 | 1.66 | 0.78 | 29.64 | 89.92 | 58.87 | 125.06 | 18.68 | 17.21 | 32.66 | 42.43 | 12.09 | 20.51 | 18.17 | 21.51 | 0.47 | 169.84 | 32.66 | 14.54 | 14.11 | 15.79 | 159.80 | 5.20 |
| 3. | VST Industries | 4110.00 | 6345.83 | 23.38 | 5.07 | 4.51 | 231.45 | 15.87 | 4.32 | 3.62 | 32.46 | 17.88 | 24.80 | 0.84 | 0.00 |  | 1.35 | 1408.51 | 22.80 | 271.45 | 321.33 | 53.58 | -3.59 | -35.99 | 175.79 | 0.00 | 32.16 | 0.00 | 5.84 | 24.64 | 0.00 | 6.32 | -16.10 | 6310.67 | 2.66 | 3.98 | -3.11 | 14.15 | 4.57 | 8.50 | 28.30 | 31.64 | 5.87 | -1.00 | 5.27 | 8.54 | 29.01 | 38.05 | 1.64 | 195.29 | 5.87 | 16.86 | 16.22 | 17.91 | 174.73 | 1.54 |
| 4. | NTC Industries | 154.70 | 184.80 | 27.09 | 1.83 | 4.39 | 231.08 | 19.06 | 27.31 | 0.00 | 8.18 | 4.83 | 7.14 | 0.30 | 0.45 | 22.20 | 1.38 | 42.13 | 11.01 | 6.83 | 12.61 | 0.64 | 23.02 | 156.14 | 4.24 | 46.33 | 65.90 | 0.00 | 4.77 | 24.64 | 0.00 | -14.75 | 8.41 | 230.40 | 0.31 | 4.10 | 21.33 | 36.05 | 22.11 | 77.73 | 8.58 | 8.78 | 6.61 | -5.29 | 14.16 | 13.53 | 7.35 | 10.03 | 0.21 | 4.24 | 4.48 | 10.41 | 15.32 | 10.48 | 126.10 | 1.19 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| ITC | Market Cap | ₹ 6,32,041 Cr. |
| ITC | Current Price | ₹ 506 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 31.0 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | Sales | ₹ 70,866 Cr. |
| ITC | OPM | 37.0 % |
| ITC | Profit after tax | ₹ 20,422 Cr. |
| ITC | Mar Cap | ₹ 6,32,041 Cr. |
| ITC | Sales Qtr | ₹ 17,923 Cr. |
| ITC | PAT Qtr | ₹ 5,122 Cr. |
| ITC | Qtr Sales Var | 1.63 % |
| ITC | Qtr Profit Var | 0.02 % |
| ITC | Price to Earning | 31.0 |
| ITC | Dividend yield | 2.73 % |
| ITC | Price to book value | 8.49 |
| ITC | ROCE | 37.5 % |
| ITC | Return on assets | 23.3 % |
| ITC | Debt to equity | 0.00 |
| ITC | Return on equity | 28.4 % |
| ITC | EPS | ₹ 16.4 |
| ITC | Debt | ₹ 303 Cr. |
| ITC | Promoter holding | 0.00 % |
| ITC | Change in Prom Hold | 0.00 % |
| ITC | Earnings yield | 4.49 % |
| ITC | Pledged percentage | 0.00 % |
| ITC | Industry PE | 24.6 |
| ITC | Sales growth | -0.07 % |
| ITC | Profit growth | 6.69 % |
| ITC | Current Price | ₹ 506 |
| ITC | Price to Sales | 8.92 |
| ITC | CMP / FCF | 43.4 |
| ITC | EVEBITDA | 21.6 |
| ITC | Enterprise Value | ₹ 6,25,127 Cr. |
| ITC | Current ratio | 2.05 |
| ITC | Int Coverage | 339 |
| ITC | PEG Ratio | 3.08 |
| ITC | Return over 3months | 11.4 % |
| ITC | Return over 6months | 7.53 % |
| ITC | No. Eq. Shares | 1,250 |
| ITC | Sales growth 3Years | 12.9 % |
| ITC | Sales growth 5Years | 7.95 % |
| ITC | Profit Var 3Yrs | 15.6 % |
| ITC | Profit Var 5Yrs | 10.0 % |
| ITC | ROE 5Yr | 25.7 % |
| ITC | ROE 3Yr | 27.5 % |
| ITC | Return over 1year | 5.35 % |
| ITC | Return over 3years | 32.9 % |
| ITC | Return over 5years | 12.6 % |
| ITC | Market Cap | ₹ 6,32,041 Cr. |
| ITC | Current Price | ₹ 506 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 31.0 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | Sales last year | ₹ 70,866 Cr. |
| ITC | OP Ann | ₹ 26,233 Cr. |
| ITC | Other Inc Ann | ₹ 2,804 Cr. |
| ITC | EBIDT last year | ₹ 28,988 Cr. |
| ITC | Dep Ann | ₹ 1,816 Cr. |
| ITC | EBIT last year | ₹ 27,172 Cr. |
| ITC | Interest last year | ₹ 80.1 Cr. |
| ITC | PBT Ann | ₹ 27,140 Cr. |
| ITC | Tax last year | ₹ 6,389 Cr. |
| ITC | PAT Ann | ₹ 20,422 Cr. |
| ITC | Extra Ord Item Ann | ₹ 48.3 Cr. |
| ITC | NP Ann | ₹ 20,751 Cr. |
| ITC | Dividend last year | ₹ 17,166 Cr. |
| ITC | Raw Material | 38.4 % |
| ITC | Employee cost | ₹ 6,134 Cr. |
| ITC | OPM last year | 37.0 % |
| ITC | NPM last year | 29.2 % |
| ITC | Operating profit | ₹ 26,233 Cr. |
| ITC | Interest | ₹ 80.1 Cr. |
| ITC | Depreciation | ₹ 1,816 Cr. |
| ITC | EPS last year | ₹ 16.4 |
| ITC | EBIT | ₹ 27,172 Cr. |
| ITC | Net profit | ₹ 20,751 Cr. |
| ITC | Current Tax | ₹ 6,165 Cr. |
| ITC | Tax | ₹ 6,389 Cr. |
| ITC | Other income | ₹ 2,804 Cr. |
| ITC | Ann Date | 2,02,403 |
| ITC | Sales Prev Ann | ₹ 70,919 Cr. |
| ITC | OP Prev Ann | ₹ 25,704 Cr. |
| ITC | Other Inc Prev Ann | ₹ 2,098 Cr. |
| ITC | EBIDT Prev Ann | ₹ 27,734 Cr. |
| ITC | Dep Prev Ann | ₹ 1,809 Cr. |
| ITC | EBIT preceding year | ₹ 25,925 Cr. |
| ITC | Interest Prev Ann | ₹ 77.8 Cr. |
| ITC | PBT Prev Ann | ₹ 25,915 Cr. |
| ITC | Tax preceding year | ₹ 6,438 Cr. |
| ITC | PAT Prev Ann | ₹ 19,141 Cr. |
| ITC | Extra Ord Prev Ann | ₹ 68.1 Cr. |
| ITC | NP Prev Ann | ₹ 19,477 Cr. |
| ITC | Dividend Prev Ann | ₹ 19,263 Cr. |
| ITC | OPM preceding year | 36.2 % |
| ITC | NPM preceding year | 27.4 % |
| ITC | EPS preceding year | ₹ 15.4 |
| ITC | Sales Prev 12M | ₹ 70,593 Cr. |
| ITC | Profit Prev 12M | ₹ 20,803 Cr. |
| ITC | Med Sales Gwth 10Yrs | 2.17 % |
| ITC | Med Sales Gwth 5Yrs | 2.17 % |
| ITC | Sales growth 7Years | 7.48 % |
| ITC | Sales Var 10Yrs | 7.22 % |
| ITC | EBIDT growth 3Years | 13.8 % |
| ITC | EBIDT growth 5Years | 6.95 % |
| ITC | EBIDT growth 7Years | 7.84 % |
| ITC | EBIDT Var 10Yrs | 7.77 % |
| ITC | EPS growth 3Years | 15.1 % |
| ITC | EPS growth 5Years | 9.64 % |
| ITC | EPS growth 7Years | 9.99 % |
| ITC | EPS growth 10Years | 8.45 % |
| ITC | Profit Var 7Yrs | 10.4 % |
| ITC | Profit Var 10Yrs | 8.94 % |
| ITC | Chg in Prom Hold 3Yr | 0.00 % |
| ITC | Market Cap | ₹ 6,32,041 Cr. |
| ITC | Current Price | ₹ 506 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 31.0 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | OP Qtr | ₹ 6,626 Cr. |
| ITC | Other Inc Qtr | ₹ 682 Cr. |
| ITC | EBIDT Qtr | ₹ 7,310 Cr. |
| ITC | Dep Qtr | ₹ 461 Cr. |
| ITC | EBIT latest quarter | ₹ 6,849 Cr. |
| ITC | Interest Qtr | ₹ 12.6 Cr. |
| ITC | PBT Qtr | ₹ 6,834 Cr. |
| ITC | Tax latest quarter | ₹ 1,647 Cr. |
| ITC | Extra Ord Item Qtr | ₹ -2.05 Cr. |
| ITC | NP Qtr | ₹ 5,191 Cr. |
| ITC | GPM latest quarter | 63.2 % |
| ITC | OPM latest quarter | 37.0 % |
| ITC | NPM latest quarter | 29.0 % |
| ITC | Eq Cap Qtr | ₹ 1,248 Cr. |
| ITC | EPS latest quarter | ₹ 4.10 |
| ITC | OP 2Qtr Bk | ₹ 6,454 Cr. |
| ITC | OP 3Qtr Bk | ₹ 6,670 Cr. |
| ITC | Sales 2Qtr Bk | ₹ 17,774 Cr. |
| ITC | Sales 3Qtr Bk | ₹ 17,164 Cr. |
| ITC | NP 2Qtr Bk | ₹ 4,965 Cr. |
| ITC | NP 3Qtr Bk | ₹ 5,190 Cr. |
| ITC | Opert Prft Gwth | 2.06 % |
| ITC | Last result date | 2,02,403 |
| ITC | Exp Qtr Sales Var | 0.11 % |
| ITC | Exp Qtr Sales | ₹ 17,183 Cr. |
| ITC | Exp Qtr OP | ₹ 6,471 Cr. |
| ITC | Exp Qtr NP | ₹ 6,004 Cr. |
| ITC | Exp Qtr EPS | ₹ 4.74 |
| ITC | Sales Prev Qtr | ₹ 18,019 Cr. |
| ITC | OP Prev Qtr | ₹ 6,504 Cr. |
| ITC | Other Inc Prev Qtr | ₹ 651 Cr. |
| ITC | EBIDT Prev Qtr | ₹ 7,161 Cr. |
| ITC | Dep Prev Qtr | ₹ 459 Cr. |
| ITC | EBIT Prev Qtr | ₹ 6,701 Cr. |
| ITC | Interest Prev Qtr | ₹ 13.6 Cr. |
| ITC | PBT Prev Qtr | ₹ 6,682 Cr. |
| ITC | Tax Prev Qtr | ₹ 1,282 Cr. |
| ITC | PAT Prev Qtr | ₹ 5,340 Cr. |
| ITC | Extra Ord Prev Qtr | ₹ -5.52 Cr. |
| ITC | NP Prev Qtr | ₹ 5,407 Cr. |
| ITC | OPM Prev Qtr | 36.1 % |
| ITC | NPM Prev Qtr | 30.0 % |
| ITC | Eq Cap Prev Qtr | ₹ 1,247 Cr. |
| ITC | EPS Prev Qtr | ₹ 4.28 |
| ITC | Sales PY Qtr | ₹ 17,635 Cr. |
| ITC | OP PY Qtr | ₹ 6,624 Cr. |
| ITC | Other Inc PY Qtr | ₹ 683 Cr. |
| ITC | EBIDT PY Qtr | ₹ 7,234 Cr. |
| ITC | Dep PY Qtr | ₹ 461 Cr. |
| ITC | EBIT PY Qtr | ₹ 6,772 Cr. |
| ITC | Interest PY Qtr | ₹ 12.2 Cr. |
| ITC | PBT PY Qtr | ₹ 6,833 Cr. |
| ITC | Tax PY Qtr | ₹ 1,608 Cr. |
| ITC | Market Cap | ₹ 6,31,292 Cr. |
| ITC | Current Price | ₹ 505 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 30.9 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | Equity capital | ₹ 1,248 Cr. |
| ITC | Preference capital | ₹ 0.00 Cr. |
| ITC | Reserves | ₹ 73,259 Cr. |
| ITC | Secured loan | ₹ 0.00 Cr. |
| ITC | Unsecured loan | ₹ 303 Cr. |
| ITC | Balance sheet total | ₹ 91,754 Cr. |
| ITC | Gross block | ₹ 40,189 Cr. |
| ITC | Revaluation reserve | ₹ 0.00 Cr. |
| ITC | Accum Dep | ₹ 12,368 Cr. |
| ITC | Net block | ₹ 27,820 Cr. |
| ITC | CWIP | ₹ 2,861 Cr. |
| ITC | Investments | ₹ 31,114 Cr. |
| ITC | Current assets | ₹ 28,121 Cr. |
| ITC | Current liabilities | ₹ 13,690 Cr. |
| ITC | BV Unq Invest | ₹ 2,596 Cr. |
| ITC | MV Quoted Inv | ₹ 0.00 Cr. |
| ITC | Cont Liab | ₹ 1,145 Cr. |
| ITC | Total Assets | ₹ 91,754 Cr. |
| ITC | Working capital | ₹ 14,502 Cr. |
| ITC | Lease liabilities | ₹ 292 Cr. |
| ITC | Inventory | ₹ 14,153 Cr. |
| ITC | Trade receivables | ₹ 4,026 Cr. |
| ITC | Face value | ₹ 1.00 |
| ITC | Cash Equivalents | ₹ 7,218 Cr. |
| ITC | Adv Cust | ₹ 886 Cr. |
| ITC | Trade Payables | ₹ 4,798 Cr. |
| ITC | No. Eq. Shares PY | 1,243 |
| ITC | Debt preceding year | ₹ 306 Cr. |
| ITC | Work Cap PY | ₹ 8,788 Cr. |
| ITC | Net Block PY | ₹ 25,851 Cr. |
| ITC | Gross Block PY | ₹ 36,608 Cr. |
| ITC | CWIP PY | ₹ 3,003 Cr. |
| ITC | Work Cap 3Yr | ₹ 9,514 Cr. |
| ITC | Work Cap 5Yr | ₹ 8,390 Cr. |
| ITC | Work Cap 7Yr | ₹ 8,280 Cr. |
| ITC | Work Cap 10Yr | ₹ 4,360 Cr. |
| ITC | Debt 3Years back | ₹ 271 Cr. |
| ITC | Debt 5Years back | ₹ 13.4 Cr. |
| ITC | Debt 7Years back | ₹ 45.7 Cr. |
| ITC | Debt 10Years back | ₹ 242 Cr. |
| ITC | Net Block 3Yrs Back | ₹ 23,298 Cr. |
| ITC | Net Block 5Yrs Back | ₹ 19,374 Cr. |
| ITC | Net Block 7Yrs Back | ₹ 15,893 Cr. |
| ITC | Market Cap | ₹ 6,31,292 Cr. |
| ITC | Current Price | ₹ 505 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 30.9 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | CF Operations | ₹ 17,179 Cr. |
| ITC | Free Cash Flow | ₹ 13,724 Cr. |
| ITC | CF Investing | ₹ 1,563 Cr. |
| ITC | CF Financing | ₹ -18,551 Cr. |
| ITC | Net CF | ₹ 191 Cr. |
| ITC | Cash Beginning | ₹ 406 Cr. |
| ITC | Cash End | ₹ 7,218 Cr. |
| ITC | FCF Prev Ann | ₹ 16,184 Cr. |
| ITC | CF Operations PY | ₹ 18,878 Cr. |
| ITC | CF Investing PY | ₹ -5,732 Cr. |
| ITC | CF Financing PY | ₹ -13,006 Cr. |
| ITC | Net CF PY | ₹ 139 Cr. |
| ITC | Cash Beginning PY | ₹ 267 Cr. |
| ITC | Cash End PY | ₹ 4,880 Cr. |
| ITC | Free Cash Flow 3Yrs | ₹ 43,675 Cr. |
| ITC | Free Cash Flow 5Yrs | ₹ 66,643 Cr. |
| ITC | Free Cash Flow 7Yrs | ₹ 86,456 Cr. |
| ITC | Free Cash Flow 10Yrs | ₹ 1,08,022 Cr. |
| ITC | CF Opr 3Yrs | ₹ 51,832 Cr. |
| ITC | CF Opr 5Yrs | ₹ 79,049 Cr. |
| ITC | CF Opr 7Yrs | ₹ 1,04,801 Cr. |
| ITC | CF Opr 10Yrs | ₹ 1,35,071 Cr. |
| ITC | CF Inv 10Yrs | ₹ -31,949 Cr. |
| ITC | CF Inv 7Yrs | ₹ -19,502 Cr. |
| ITC | CF Inv 5Yrs | ₹ -6,842 Cr. |
| ITC | CF Inv 3Yrs | ₹ -6,408 Cr. |
| ITC | Cash 3Years back | ₹ 4,659 Cr. |
| ITC | Cash 5Years back | ₹ 4,152 Cr. |
| ITC | Cash 7Years back | ₹ 2,967 Cr. |
| ITC | Market Cap | ₹ 6,31,292 Cr. |
| ITC | Current Price | ₹ 505 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 30.9 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | No. Eq. Shares | 1,250 |
| ITC | Book value | ₹ 59.7 |
| ITC | Inven TO | 2.19 |
| ITC | Quick ratio | 1.02 |
| ITC | Exports percentage | 0.00 % |
| ITC | Piotroski score | 5.00 |
| ITC | G Factor | 5.00 |
| ITC | Asset Turnover | 0.80 |
| ITC | Financial leverage | 1.19 |
| ITC | No. of Share Holders | 37,56,541 |
| ITC | Unpledged Prom Hold | 0.00 % |
| ITC | ROIC | 49.1 % |
| ITC | Debtor days | 20.7 |
| ITC | Industry PBV | 5.10 |
| ITC | Credit rating |  |
| ITC | WC Days | 37.5 |
| ITC | Earning Power | 29.6 % |
| ITC | Graham Number | ₹ 148 |
| ITC | Cash Cycle | 146 |
| ITC | Days Payable | 64.3 |
| ITC | Days Receivable | 20.7 |
| ITC | Inventory Days | 190 |
| ITC | Public holding | 15.5 % |
| ITC | FII holding | 40.5 % |
| ITC | Chg in FII Hold | -0.48 % |
| ITC | DII holding | 44.0 % |
| ITC | Chg in DII Hold | 0.26 % |
| ITC | B.V. Prev Ann | ₹ 55.6 |
| ITC | ROCE Prev Yr | 39.0 % |
| ITC | ROA Prev Yr | 23.8 % |
| ITC | ROE Prev Ann | 29.1 % |
| ITC | No. of Share Holders Prev Qtr | 36,48,537 |
| ITC | No. Eq. Shares 10 Yrs | 1,202 |
| ITC | BV 3yrs back | ₹ 49.0 |
| ITC | BV 5yrs back | ₹ 53.1 |
| ITC | BV 10yrs back | ₹ 26.4 |
| ITC | Inven TO 3Yr | 2.16 |
| ITC | Inven TO 5Yr | 2.17 |
| ITC | Inven TO 7Yr | 2.12 |
| ITC | Inven TO 10Yr | 1.83 |
| ITC | Export 3Yr | 0.00 % |
| ITC | Export 5Yr | 0.00 % |
| ITC | Div 5Yrs | ₹ 15,262 Cr. |
| ITC | ROCE 3Yr | 36.6 % |
| ITC | ROCE 5Yr | 34.2 % |
| ITC | ROCE 7Yr | 34.2 % |
| ITC | ROCE 10Yr | 36.2 % |
| ITC | ROE 10Yr | 25.2 % |
| ITC | ROE 7Yr | 24.9 % |
| ITC | ROE 5Yr Var | 4.63 % |
| ITC | OPM 5Year | 36.2 % |
| ITC | OPM 10Year | 36.7 % |
| ITC | No. of Share Holders 1Yr | 30,13,793 |
| ITC | Avg Div Payout 3Yrs | 92.4 % |
| ITC | Debtor days 3yrs | 16.9 |
| ITC | Debtor days 3yrs back | 18.5 |
| ITC | Debtor days 5yrs back | 30.5 |
| ITC | ROA 5Yr | 21.3 % |
| ITC | ROA 3Yr | 22.6 % |
| ITC | Market Cap | ₹ 6,31,292 Cr. |
| ITC | Current Price | ₹ 505 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 30.9 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | Avg Vol 1Mth | 2,15,03,941 |
| ITC | Avg Vol 1Wk | 3,42,75,141 |
| ITC | Volume | 1,90,30,901 |
| ITC | High price | ₹ 511 |
| ITC | Low price | ₹ 399 |
| ITC | High price all time | ₹ 511 |
| ITC | Low price all time | ₹ 29.4 |
| ITC | Return over 1day | 3.11 % |
| ITC | Return over 1week | 3.25 % |
| ITC | Return over 1month | 15.6 % |
| ITC | DMA 50 | ₹ 446 |
| ITC | DMA 200 | ₹ 434 |
| ITC | DMA 50 previous day | ₹ 444 |
| ITC | 200 DMA prev. | ₹ 434 |
| ITC | RSI | 75.3 |
| ITC | MACD | 15.0 |
| ITC | MACD Previous Day | 14.3 |
| ITC | MACD Signal | 10.7 |
| ITC | MACD Signal Prev | 9.66 |
| ITC | Avg Vol 1Yr | 1,66,57,269 |
| ITC | Return over 7years | 7.70 % |
| ITC | Return over 10years | 7.48 % |
| ITC | Market Cap | ₹ 6,31,292 Cr. |
| ITC | Current Price | ₹ 505 |
| ITC | High / Low | ₹ 511 / 399 |
| ITC | Stock P/E | 30.9 |
| ITC | Book Value | ₹ 59.7 |
| ITC | Dividend Yield | 2.73 % |
| ITC | ROCE | 37.5 % |
| ITC | ROE | 28.4 % |
| ITC | Face Value | ₹ 1.00 |
| ITC | WC to Sales | 20.5 % |
| ITC | QoQ Profits | -3.99 % |
| ITC | QoQ Sales | -0.54 % |
| ITC | Net worth | ₹ 74,507 Cr. |
| ITC | Market Cap to Sales | 8.91 |
| ITC | Interest Coverage | 339 |
| ITC | EV / EBIT | 23.0 |
| ITC | Debt Capacity | 0.14 |
| ITC | Debt To Profit | 0.01 |
| ITC | Capital Employed | ₹ 45,183 Cr. |
| ITC | CROIC | 20.1 % |
| ITC | debtplus | 0.02 |
| ITC | Leverage | ₹ 1.19 |
| ITC | Dividend Payout | 83.9 % |
| ITC | Intrinsic Value | ₹ 183 |
| ITC | CDL | 0.91 % |
| ITC | Cash by market cap | 0.01 |
| ITC | 52w Index | 95.1 % |
| ITC | Down from 52w high | 1.07 % |
| ITC | Up from 52w low | 26.5 % |
| ITC | From 52w high | 0.99 |
| ITC | Mkt Cap To Debt Cap | 3.19 |
| ITC | Dividend Payout | 83.9 % |
| ITC | Graham | ₹ 148 |
| ITC | Price to Cash Flow | 36.8 |
| ITC | ROCE3yr avg | 36.6 % |
| ITC | PB X PE | 262 |
| ITC | NCAVPS | ₹ 11.6 |
| ITC | Mar Cap to CF | 36.8 |
| ITC | Altman Z Score | 14.1 |
| ITC | M.Cap / Qtr Profit | 123 |