# Complete Company Data

## Modal Content
About
[
edit
]
Bharat Heavy Electricals Ltd is an integrated power plant equipment manufacturer engaged in design, engineering, manufacture, erection, testing, commissioning and servicing of a wide range of products and services for the core sectors of the economy, viz. Power, transmission, Industry, transportation, renewable energy, Oil & Gas and defence.
[1]
It is the flagship engineering and manufacturing company of India owned and controlled by the Govt. of India.
[2]
Key Points
[
edit
]
Power Sector (~76% of revenues)
[1]
The company has capabilities to manufacture the entire range of power plant equipment including thermal, gas, hydro and nuclear power projects.
[2]
Execution Record -
It has executed ~1,000
coal, hydro, gas and nuclear based utility sets since its inception in 1964.
It accounts for ~53% of India's total capacity of utility power projects.
[3]
As per FY22, the total capacity of company's electricity utility installed base is ~164 GW out of which ~132 GW is from coal based power projects.
[4]
Industry Sector (~24% of revenues)
Under this segment, the company offers various products/ solutions for various sectors viz. transportation, renewables, defence & aerospace, energy storage solutions & other business areas, captive power & process plants, transmission and industrial products.
[5]
Product Profile -
The company's product profile for both its sectors can be found here.
[6]
Order Book Position
As per FY22, the company has an outstanding order book of ~102,500 crores. It received ~23,690 crores of orders in FY22 out of which 76% is from Power Sector.
[7]
For Power Sector, out of the total order from 2017-2022 which was 16,320MW, BHEL accounted for ~75%, 12,180MW and commands 100% market share in Nuclear Power
[8]
International Presence
The company has its footprint in 88 countries across 6 continents in the world.
[9]
In FY22, exports accounted for ~8% revenues compared to 11% in FY21.
[10]
Manufacturing Capabilities
As per FY22, the company operates 16, manufacturing units and 2 repair units across the nation.
[11]
R&D Capabilities
The company has 14 R&D centers established across India. It also has 5 specialized research institutes for pollution control, welding, ceramic technology, electric transportation and amorphous silicon solar cell across various cities.
[12]
It has consistently spent ~2.5% of total sales towards R&D over years.
[13]
Intense Competition
The company operates in an increasingly competitive market as several domestic companies have entered into the boiler-turbine-generator space through JVs with international players.
[14]
Last edited 1 year, 8 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 48,903 | 39,561 | 31,323 | 25,505 | 28,465 | 28,827 | 30,441 | 21,463 | 17,309 | 21,211 | 23,365 | 23,893 |
| Expenses + | 39,420 | 34,982 | 29,183 | 26,862 | 27,370 | 27,174 | 28,409 | 21,596 | 20,357 | 20,383 | 22,557 | 23,280 |
| Operating Profit | 9,483 | 4,579 | 2,141 | -1,357 | 1,095 | 1,653 | 2,032 | -133 | -3,049 | 828 | 807 | 613 |
| OPM % | 19% | 12% | 7% | -5% | 4% | 6% | 7% | -1% | -18% | 4% | 3% | 3% |
| Other Income + | 1,132 | 1,617 | 1,221 | 1,492 | 753 | 679 | 662 | 590 | 393 | 405 | 544 | 610 |
| Interest | 128 | 133 | 92 | 360 | 413 | 330 | 378 | 613 | 467 | 448 | 612 | 731 |
| Depreciation | 957 | 985 | 1,082 | 937 | 850 | 787 | 476 | 503 | 473 | 314 | 260 | 249 |
| Profit before tax | 9,531 | 5,078 | 2,187 | -1,161 | 586 | 1,215 | 1,840 | -659 | -3,596 | 470 | 479 | 243 |
| Tax % | 30% | 31% | 34% | -39% | 22% | 64% | 46% | 123% | -25% | 5% | 0% | -16% |
| Net Profit + | 6,693 | 3,502 | 1,450 | -706 | 455 | 438 | 1,002 | -1,468 | -2,700 | 445 | 477 | 282 |
| EPS in Rs | 18.23 | 9.54 | 3.96 | -1.92 | 1.25 | 1.20 | 2.89 | -4.21 | -7.75 | 1.28 | 1.37 | 0.81 |
| Dividend Payout % | 20% | 20% | 20% | -14% | 85% | 151% | 69% | 0% | 0% | 31% | 29% | 31% |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 72% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 201% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 1% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RPCL JV |  |  |  |  |  |  |  |  |  |
| Amounts due to BHEL at the end of the year |  |  | 472 | 485 | 511 | 542 | 552 | 551 | 637 |
| Sales of Goods and services |  |  | 130 | 91 | 35 | 17 | 7.80 | 3.27 | 9.42 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 28 | 17 | 11 | 9.30 | 7.67 | 21 | 21 |
| Rendering of Services |  |  | 106 |  |  |  |  |  |  |
| Purchase of shares |  |  |  | 75 |  |  |  |  |  |
| Provision for Doubtful debts & advances |  |  |  |  |  |  | 20 | 20 | 21 |
| Purchase of Goods and Services |  |  |  |  |  | 22 |  |  |  |
| NBPPL JV |  |  |  |  |  |  |  |  |  |
| Amounts due to BHEL at the end of the year |  |  | 309 | 310 | 281 | 263 | 196 | 264 | 225 |
| Provision for Doubtful debts & advances |  |  |  |  |  |  | 188 | 189 | 190 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 92 | 91 | 83 | 79 | 57 | 68 | 24 |
| Sales of Goods and services |  |  | 359 | 77 | 6.08 | 2.80 | 11 | 3.83 | 2.21 |
| Provision for doubtful debts & advances |  |  |  | 23 | 1.64 |  |  |  |  |
| Purchase of Goods and Services |  |  | 1.43 | 7.38 | 4.83 | 3.05 | 0.75 | 1.52 |  |
| Provision for Doubtful advances |  |  | 12 |  |  |  |  |  |  |
| Receiving of Services |  |  | 8.06 |  |  |  |  |  |  |
| Rendering of Services |  |  | 2.43 |  |  |  |  |  |  |
| Provision for Doubtful debts |  |  | 0.70 |  |  |  |  |  |  |
| BGGTS Subsidiary |  |  |  |  |  |  |  |  |  |
| Sales of Goods and services |  |  | 188 | 196 | 278 | 170 | 216 | 281 | 239 |
| Amounts due to BHEL at the end of the year |  |  | 43 | 48 | 77 | 29 | 69 | 144 | 112 |
| Dividend income |  |  | 13 | 15 | 16 | 16 | 21 | 30 | 26 |
| Provision for Doubtful debts & advances |  |  |  |  |  |  |  |  | 10 |
| Royalty income |  |  | 1.47 | 0.90 | 1.17 | 1.10 | 1.46 | 1.80 | 1.85 |
| Purchase of Goods and Services |  |  | 0.56 | 1.02 | 0.98 | 0.86 | 1.96 | 1.04 | 0.87 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 0.16 | 0.08 | 0.35 | 0.24 | 0.15 | 0.11 | 0.44 |
| Provision for doubtful debts & advances |  |  |  | 0.22 | 0.70 |  |  |  |  |
| Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Pension Fund |  |  |  |  |  |  | 280 | 115 | 247 |
| BFIEL EPF Trust,Ranipur,Hardwar |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 52 | 55 | 58 |
| BHEL Employee Provident Fund-Trichy |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 53 | 53 | 56 |
| BFIEL Employee Provident Fund Bhopal |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 51 | 53 | 56 |
| Gratuity Trust JV |  |  |  |  |  |  |  |  |  |
| Gratuity |  |  |  |  |  |  | 154 |  |  |
| BHEL New Delhi Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 39 | 41 | 44 |
| BHEL Employee Provident Fund-Hyderabad |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 39 | 41 | 42 |
| BHEL Employee Provident Fund-Bengaluru |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 29 | 28 | 29 |
| BHEL PPD EPF Trust.Chennai |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 26 | 28 | 31 |
| BHEL (BAP Unit) EPF Trust.Ranipet |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 19 | 19 | 18 |
| PRMB Trust |  |  |  |  |  |  |  |  |  |
| Post Retirement medical scheme |  |  |  |  |  |  | 42 |  |  |
| BHEL Employee Provident Fund Trust Jhansi |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 13 | 13 | 14 |
| Bharat Heavy Plates b Vessels Limited Employee Contributory Provident Fund-Vizag |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 5.45 | 5.81 | 6.50 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 48,903 | 39,561 | 31,323 | 25,505 | 28,465 | 28,827 | 30,441 | 21,463 | 17,309 | 21,211 | 23,365 | 23,893 |
| Expenses + | 39,420 | 34,982 | 29,183 | 26,862 | 27,370 | 27,174 | 28,409 | 21,596 | 20,357 | 20,383 | 22,557 | 23,280 |
| Operating Profit | 9,483 | 4,579 | 2,141 | -1,357 | 1,095 | 1,653 | 2,032 | -133 | -3,049 | 828 | 807 | 613 |
| OPM % | 19% | 12% | 7% | -5% | 4% | 6% | 7% | -1% | -18% | 4% | 3% | 3% |
| Other Income + | 1,132 | 1,617 | 1,221 | 1,492 | 753 | 679 | 662 | 590 | 393 | 405 | 544 | 610 |
| Interest | 128 | 133 | 92 | 360 | 413 | 330 | 378 | 613 | 467 | 448 | 612 | 731 |
| Depreciation | 957 | 985 | 1,082 | 937 | 850 | 787 | 476 | 503 | 473 | 314 | 260 | 249 |
| Profit before tax | 9,531 | 5,078 | 2,187 | -1,161 | 586 | 1,215 | 1,840 | -659 | -3,596 | 470 | 479 | 243 |
| Tax % | 30% | 31% | 34% | -39% | 22% | 64% | 46% | 123% | -25% | 5% | 0% | -16% |
| Net Profit + | 6,693 | 3,502 | 1,450 | -706 | 455 | 438 | 1,002 | -1,468 | -2,700 | 445 | 477 | 282 |
| EPS in Rs | 18.23 | 9.54 | 3.96 | -1.92 | 1.25 | 1.20 | 2.89 | -4.21 | -7.75 | 1.28 | 1.37 | 0.81 |
| Dividend Payout % | 20% | 20% | 20% | -14% | 85% | 151% | 69% | 0% | 0% | 31% | 29% | 31% |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 72% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 201% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 1% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 1,759 | 4,512 | 821 | 374 | 560 | 989 | -3,860 | -2,892 | 560 | 660 | -742 | -3,713 |
| Cash from Investing Activity + | -1,113 | -868 | 650 | 23 | -565 | 961 | 1,919 | 1,877 | -42 | -1,118 | 1,480 | 1,331 |
| Cash from Financing Activity + | 472 | 523 | -3,543 | -122 | -468 | -667 | -32 | 1,622 | -394 | -329 | 89 | 2,656 |
| Net Cash Flow | 1,118 | 4,167 | -2,071 | 275 | -473 | 1,283 | -1,973 | 608 | 123 | -787 | 828 | 274 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 219 | 260 | 309 | 321 | 283 | 178 | 142 | 121 | 85 | 52 | 49 | 73 |
| Inventory Days | 186 | 195 | 270 | 272 | 200 | 191 | 218 | 321 | 333 | 274 | 261 | 157 |
| Days Payable | 152 | 174 | 239 | 240 | 225 | 301 | 297 | 300 | 281 | 291 | 345 | 189 |
| Cash Conversion Cycle | 253 | 281 | 340 | 353 | 258 | 68 | 63 | 142 | 137 | 35 | -35 | 41 |
| Working Capital Days | 126 | 158 | 193 | 209 | 162 | 121 | 130 | 157 | 146 | 84 | 98 | 182 |
| ROCE % | 33% | 15% | 6% | -2% | 3% | 5% | 7% | -0% | -10% | 3% | 3% | 3% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% |
| FIIs + | 4.31% | 3.86% | 4.00% | 4.22% | 4.81% | 8.48% | 8.58% | 7.77% | 7.23% | 7.04% | 8.76% | 9.10% |
| DIIs + | 13.73% | 13.80% | 12.66% | 12.59% | 14.45% | 14.71% | 15.50% | 16.36% | 15.99% | 17.58% | 15.95% | 15.03% |
| Public + | 18.79% | 19.17% | 20.17% | 20.02% | 17.57% | 13.63% | 12.76% | 12.71% | 13.62% | 12.23% | 12.14% | 12.71% |
| No. of Shareholders | 11,38,654 | 12,04,729 | 12,81,743 | 12,87,798 | 11,92,232 | 10,27,958 | 10,16,936 | 10,12,617 | 12,27,658 | 12,65,436 | 14,99,202 | 18,80,851 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 63.06% | 63.06% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% | 63.17% |
| FIIs + | 15.89% | 13.04% | 11.68% | 9.36% | 4.47% | 4.00% | 8.58% | 8.76% | 9.10% |
| DIIs + | 16.43% | 18.50% | 18.54% | 17.81% | 12.49% | 12.66% | 15.50% | 15.95% | 15.03% |
| Public + | 4.62% | 5.40% | 6.61% | 9.66% | 19.87% | 20.17% | 12.76% | 12.14% | 12.71% |
| No. of Shareholders | 3,83,371 | 4,71,048 | 4,92,165 | 5,84,236 | 9,86,752 | 12,81,743 | 10,16,936 | 14,99,202 | 18,80,851 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/bharat-heavy-electricals-ltd/bhel/500103/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
1d - Published Notice of 60th AGM, Record Date & other related information](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=720e2a12-0ddf-4f27-a0fa-91f7b1b09bcf.pdf)
- [Board Meeting Intimation for Unaudited Financial Results For The Quarter Ended 30Th June, 2024 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=303e2fc4-72e6-4f1c-8bf3-7a2f8c85fb2f.pdf)
- [Intimation Of Record Date For Final Dividend For FY 2023-24 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa630432-03bd-49a6-995f-8c4c1c9e78e0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bff2633f-f8ba-43ff-a13b-1517ebf988a4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=59a19481-8cb2-429e-9c09-8a49be34527d.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b6e66b29-cb68-48f7-9a6a-d309a42dd11c.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/76557500103.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/70082500103.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/66171500103.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_1154_BHEL_2012_2013_23082013190414.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030313.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_BHEL_2011_2012_18092012091256.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030311.pdf)

## Credit Ratings
- [Rating update
27 Jun from fitch](https://www.indiaratings.co.in/pressrelease/70641)
- [Rating update
18 Jun from care](https://www.careratings.com/upload/CompanyFiles/PR/202406130631_Bharat_Heavy_Electricals_Limited.pdf)
- [Rating update
17 Oct 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatHeavyElectricalsLimited_October%2017,%202023_RR_318353.html)
- [Rating update
28 Jun 2023 from fitch](https://www.indiaratings.co.in/pressrelease/62468)
- [Rating update
19 Jun 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202306130652_Bharat_Heavy_Electricals_Limited.pdf)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatHeavyElectricalsLimited_March%2030,%202023_RR_316263.html)

## Concalls
- [REC](https://www.bhel.com/sites/default/files/2024-05/ICI0420240521153066.mp3)
- [PPT](https://www.bhel.com/sites/default/files/Supplementary%20Information%20BHEL%20Q2FY24.pdf)
- [Transcript](https://www.bhel.com/sites/default/files/BHEL-Q4FY23%20concall%20transcript-26May2023.pdf)
- [REC](https://www.bhel.com/sites/ANT0420230526147376.mp3)
- [PPT](https://www.bhel.com/sites/default/files/Supplementary%20Information%20BHEL%20Q3FY23%20Results%2010.02.2023_updated.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=def3e115-c2f3-4c39-80af-f866bf99b0b6.pdf)
- [Transcript](https://www.bhel.com/sites/default/files/BHEL%20Q1FY22%20ConCall%20transcript%20300721%20%281%29_0.pdf)
- [](https://www.bhel.com/sites/default/files/Q1FY21_BHEL_ConCall_transcript_110920_130920.pdf)
- [](https://www.bhel.com/sites/default/files/BHEL-Q4FY20-ConCall-transcript-130620.pdf)
- [](https://www.bhel.com/sites/default/files/Q3FY20BHELConCallTranscript.pdf)
- [](https://www.bhel.com/sites/default/files/Q2FY20BHELConcallTranscript221119.pdf)
- [](https://www.bhel.com/sites/default/files/BHEL_Q1FY20_ConCall_transcript_090819.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Siemens | 6920.05 | 246436.99 | 106.27 | 17.76 | 12.57 | 237.75 | 71.88 | 41.95 | 0.15 | 20.66 | 9.22 | 15.36 | 0.88 | 0.01 | 75.65 | 1.57 | 19604.20 | 12.49 | 2317.50 | 5313.80 | 896.40 | 19.00 | 73.72 | 65.08 | 163.10 | 75.00 | 0.00 | 1.31 | 63.21 | 6.67 | 19.85 | 41.20 | 239348.79 | 2.16 | 6.57 | 18.93 | 62.58 | 52.11 | 82.22 | 13.58 | 12.35 | 16.18 | 35.72 | 7.14 | 22.10 | 13.79 | 15.41 | 1.85 | 53.67 | 16.18 | 78.00 | 81.36 | 70.94 | 15.03 | 35.61 |
| 2. | A B B | 7795.40 | 165191.09 | 112.96 | 27.81 | 14.86 | 217.65 | 76.90 | 44.20 | 0.31 | 30.69 | 12.28 | 22.92 | 1.03 | 0.01 | 137.81 | 1.71 | 11115.67 | 15.92 | 1462.61 | 3080.36 | 459.60 | 27.75 | 87.46 | 68.73 | 48.98 | 75.00 | 0.00 | 1.25 | 63.21 | 0.00 | 23.37 | 68.72 | 160423.90 | 1.90 | 5.65 | 18.93 | 60.86 | 65.92 | 73.26 | 17.76 | 14.06 | 19.98 | 92.69 | 9.32 | 21.52 | 17.01 | 23.03 | 1.59 | 58.61 | 19.98 | 100.99 | 103.82 | 89.54 | -0.40 | 21.19 |
| 3. | CG Power & Ind | 731.05 | 111728.91 | 124.14 | 36.99 | 13.30 | 230.75 | 84.84 | 105.05 | 0.21 | 46.63 | 27.00 | 57.78 | 1.56 | 0.01 | 511.55 | 1.71 | 8399.50 | 14.05 | 899.47 | 2227.52 | 241.14 | 18.86 | 22.70 | 9.59 | 17.44 | 58.09 | -0.02 | 1.10 | 63.21 | 0.00 | 16.25 | 8.61 | 110891.94 | 1.42 | 2.95 | 30.67 | 57.33 | 111.47 | 83.62 | 71.03 |  | 42.06 | 140.60 | 0.12 | 39.50 | 66.05 | 61.65 | 1.12 | 9.34 | 28.86 | 68.25 | 69.06 | 68.25 | 21.37 | 152.71 |
| 4. | B H E L | 316.30 | 110137.65 | 390.22 | 4.51 | 4.61 | -75.77 | 92.27 | 38.72 | 0.08 | 2.97 | 0.47 | 1.10 | 0.40 | 0.36 | 1.33 | 2.44 | 23892.78 | 2.56 | 282.22 | 8260.25 | 489.62 | 0.40 | -25.59 | 0.81 | 8856.46 | 63.17 | 0.00 | 0.88 | 63.21 | 0.00 | 2.26 | -37.59 | 112836.64 | 1.36 | -17.55 | 11.73 | 41.68 | 71.75 | 201.01 | 1.49 | -2.20 | -22.23 | 28.15 | -4.73 | 11.34 | 1.70 | 3.33 | 1.08 | 0.81 | -22.23 | 36.53 | 56.82 | 59.72 | 41.06 | 348.21 |
| 5. | Suzlon Energy | 61.56 | 83196.40 | 90.07 | 21.26 | 11.56 | 168.03 | 66.30 | 70.87 | 0.00 | 24.70 | 11.24 | 28.45 | 1.03 | 0.04 | 7.29 | 1.62 | 7199.70 | 16.67 | 923.48 | 2021.59 | 302.29 | 49.64 | 225.95 | 0.64 | 150.24 | 13.27 | -0.02 | 1.29 | 63.21 | 0.00 | 21.19 | 218.86 | 82919.80 | 1.76 | 4.58 | 47.59 | 44.47 | 112.79 | 244.37 |  |  | 19.68 | 44.67 | 5.38 | 24.96 |  | 20.78 | 1.00 | 0.49 | 17.31 | 109.71 | 109.71 | 89.43 | 147.79 | 1247.14 |
| 6. | Hitachi Energy | 11522.25 | 48833.29 | 284.29 | 35.91 | 8.84 | -1066.84 | 132.34 |  | 0.03 | 17.85 | 3.80 | 12.74 | 1.21 | 0.16 | 6.02 | 3.17 | 5524.67 | 6.57 | 171.79 | 1327.24 | 10.42 | 27.61 | 332.37 | 40.53 | 213.68 | 75.00 | 0.00 | 0.56 | 63.21 | 0.00 | 22.16 | 80.89 | 48918.77 | 1.16 |  | 31.79 | 99.51 | 82.75 | 189.65 | 12.54 |  |  | 10.98 |  | 15.26 | 8.03 | 12.91 | 0.89 | 38.64 |  | 141.17 | 150.14 | 141.17 | 1.53 | 4.24 |
| 7. | GE T&D India | 1574.00 | 40302.30 | 222.63 | 32.40 | 12.72 | 288.66 | 117.74 | 52.87 | 0.00 | 22.15 | 4.98 | 15.64 | 0.87 | 0.03 | 10.30 | 2.92 | 3167.91 | 10.07 | 181.05 | 913.60 | 66.29 | 29.95 | 353.79 | 7.07 | 41.82 | 75.00 | 0.00 | 0.74 | 63.21 | 0.00 | 14.23 | 8560.28 | 40210.02 | 1.17 | -60.99 | 40.84 | 144.57 | 122.59 | 524.62 | 0.72 | -2.94 | -3.65 | 46.28 | -5.57 | -2.83 | -0.20 | 7.53 | 0.91 | 7.07 | -3.65 | 192.54 | 249.82 | 58.55 | 113.56 | 25.60 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | Sales | ₹ 23,893 Cr. |
| BHEL | OPM | 2.56 % |
| BHEL | Profit after tax | ₹ 282 Cr. |
| BHEL | Mar Cap | ₹ 1,10,242 Cr. |
| BHEL | Sales Qtr | ₹ 8,260 Cr. |
| BHEL | PAT Qtr | ₹ 490 Cr. |
| BHEL | Qtr Sales Var | 0.40 % |
| BHEL | Qtr Profit Var | -25.6 % |
| BHEL | Price to Earning | 391 |
| BHEL | Dividend yield | 0.08 % |
| BHEL | Price to book value | 4.51 |
| BHEL | ROCE | 2.97 % |
| BHEL | Return on assets | 0.47 % |
| BHEL | Debt to equity | 0.36 |
| BHEL | Return on equity | 1.10 % |
| BHEL | EPS | ₹ 0.81 |
| BHEL | Debt | ₹ 8,856 Cr. |
| BHEL | Promoter holding | 63.2 % |
| BHEL | Change in Prom Hold | 0.00 % |
| BHEL | Earnings yield | 0.88 % |
| BHEL | Pledged percentage | 0.00 % |
| BHEL | Industry PE | 63.2 |
| BHEL | Sales growth | 2.26 % |
| BHEL | Profit growth | -37.6 % |
| BHEL | Current Price | ₹ 317 |
| BHEL | Price to Sales | 4.61 |
| BHEL | CMP / FCF | -75.8 |
| BHEL | EVEBITDA | 92.4 |
| BHEL | Enterprise Value | ₹ 1,12,941 Cr. |
| BHEL | Current ratio | 1.36 |
| BHEL | Int Coverage | 1.33 |
| BHEL | PEG Ratio | -17.6 |
| BHEL | Return over 3months | 11.7 % |
| BHEL | Return over 6months | 41.7 % |
| BHEL | No. Eq. Shares | 348 |
| BHEL | Sales growth 3Years | 11.3 % |
| BHEL | Sales growth 5Years | -4.73 % |
| BHEL | Profit Var 3Yrs | 28.2 % |
| BHEL | Profit Var 5Yrs | -22.2 % |
| BHEL | ROE 5Yr | -2.20 % |
| BHEL | ROE 3Yr | 1.49 % |
| BHEL | Return over 1year | 201 % |
| BHEL | Return over 3years | 71.8 % |
| BHEL | Return over 5years | 38.7 % |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | Sales last year | ₹ 23,893 Cr. |
| BHEL | OP Ann | ₹ 613 Cr. |
| BHEL | Other Inc Ann | ₹ 610 Cr. |
| BHEL | EBIDT last year | ₹ 1,223 Cr. |
| BHEL | Dep Ann | ₹ 249 Cr. |
| BHEL | EBIT last year | ₹ 974 Cr. |
| BHEL | Interest last year | ₹ 731 Cr. |
| BHEL | PBT Ann | ₹ 243 Cr. |
| BHEL | Tax last year | ₹ -39.6 Cr. |
| BHEL | PAT Ann | ₹ 282 Cr. |
| BHEL | Extra Ord Item Ann | ₹ 0.00 Cr. |
| BHEL | NP Ann | ₹ 282 Cr. |
| BHEL | Dividend last year | ₹ 87.0 Cr. |
| BHEL | Raw Material | 70.3 % |
| BHEL | Employee cost | ₹ 5,629 Cr. |
| BHEL | OPM last year | 2.56 % |
| BHEL | NPM last year | 1.18 % |
| BHEL | Operating profit | ₹ 613 Cr. |
| BHEL | Interest | ₹ 731 Cr. |
| BHEL | Depreciation | ₹ 249 Cr. |
| BHEL | EPS last year | ₹ 0.81 |
| BHEL | EBIT | ₹ 974 Cr. |
| BHEL | Net profit | ₹ 282 Cr. |
| BHEL | Current Tax | ₹ -113 Cr. |
| BHEL | Tax | ₹ -39.6 Cr. |
| BHEL | Other income | ₹ 610 Cr. |
| BHEL | Ann Date | 2,02,403 |
| BHEL | Sales Prev Ann | ₹ 23,365 Cr. |
| BHEL | OP Prev Ann | ₹ 807 Cr. |
| BHEL | Other Inc Prev Ann | ₹ 544 Cr. |
| BHEL | EBIDT Prev Ann | ₹ 1,319 Cr. |
| BHEL | Dep Prev Ann | ₹ 260 Cr. |
| BHEL | EBIT preceding year | ₹ 1,059 Cr. |
| BHEL | Interest Prev Ann | ₹ 612 Cr. |
| BHEL | PBT Prev Ann | ₹ 479 Cr. |
| BHEL | Tax preceding year | ₹ 2.05 Cr. |
| BHEL | PAT Prev Ann | ₹ 452 Cr. |
| BHEL | Extra Ord Prev Ann | ₹ 33.0 Cr. |
| BHEL | NP Prev Ann | ₹ 477 Cr. |
| BHEL | Dividend Prev Ann | ₹ 139 Cr. |
| BHEL | OPM preceding year | 3.46 % |
| BHEL | NPM preceding year | 1.94 % |
| BHEL | EPS preceding year | ₹ 1.37 |
| BHEL | Sales Prev 12M | ₹ 23,860 Cr. |
| BHEL | Profit Prev 12M | ₹ 136 Cr. |
| BHEL | Med Sales Gwth 10Yrs | 1.27 % |
| BHEL | Med Sales Gwth 5Yrs | 2.26 % |
| BHEL | Sales growth 7Years | -2.47 % |
| BHEL | Sales Var 10Yrs | -4.92 % |
| BHEL | EBIDT growth 3Years | 35.0 % |
| BHEL | EBIDT growth 5Years | -14.5 % |
| BHEL | EBIDT growth 7Years | -5.71 % |
| BHEL | EBIDT Var 10Yrs | -15.0 % |
| BHEL | EPS growth 3Years | 28.2 % |
| BHEL | EPS growth 5Years | -22.2 % |
| BHEL | EPS growth 7Years | -5.89 % |
| BHEL | EPS growth 10Years | -21.9 % |
| BHEL | Profit Var 7Yrs | -6.60 % |
| BHEL | Profit Var 10Yrs | -22.3 % |
| BHEL | Chg in Prom Hold 3Yr | 0.00 % |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | OP Qtr | ₹ 728 Cr. |
| BHEL | Other Inc Qtr | ₹ 170 Cr. |
| BHEL | EBIDT Qtr | ₹ 898 Cr. |
| BHEL | Dep Qtr | ₹ 68.4 Cr. |
| BHEL | EBIT latest quarter | ₹ 830 Cr. |
| BHEL | Interest Qtr | ₹ 193 Cr. |
| BHEL | PBT Qtr | ₹ 636 Cr. |
| BHEL | Tax latest quarter | ₹ 147 Cr. |
| BHEL | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| BHEL | NP Qtr | ₹ 490 Cr. |
| BHEL | GPM latest quarter | 33.2 % |
| BHEL | OPM latest quarter | 8.81 % |
| BHEL | NPM latest quarter | 5.93 % |
| BHEL | Eq Cap Qtr | ₹ 696 Cr. |
| BHEL | EPS latest quarter | ₹ 1.41 |
| BHEL | OP 2Qtr Bk | ₹ -388 Cr. |
| BHEL | OP 3Qtr Bk | ₹ -364 Cr. |
| BHEL | Sales 2Qtr Bk | ₹ 5,125 Cr. |
| BHEL | Sales 3Qtr Bk | ₹ 5,003 Cr. |
| BHEL | NP 2Qtr Bk | ₹ -238 Cr. |
| BHEL | NP 3Qtr Bk | ₹ -344 Cr. |
| BHEL | Opert Prft Gwth | -24.1 % |
| BHEL | Last result date | 2,02,403 |
| BHEL | Exp Qtr Sales Var | 2.36 % |
| BHEL | Exp Qtr Sales | ₹ 5,121 Cr. |
| BHEL | Exp Qtr OP | ₹ -142 Cr. |
| BHEL | Exp Qtr NP | ₹ -391 Cr. |
| BHEL | Exp Qtr EPS | ₹ -1.12 |
| BHEL | Sales Prev Qtr | ₹ 5,504 Cr. |
| BHEL | OP Prev Qtr | ₹ 217 Cr. |
| BHEL | Other Inc Prev Qtr | ₹ 118 Cr. |
| BHEL | EBIDT Prev Qtr | ₹ 335 Cr. |
| BHEL | Dep Prev Qtr | ₹ 60.6 Cr. |
| BHEL | EBIT Prev Qtr | ₹ 274 Cr. |
| BHEL | Interest Prev Qtr | ₹ 190 Cr. |
| BHEL | PBT Prev Qtr | ₹ 84.5 Cr. |
| BHEL | Tax Prev Qtr | ₹ 24.2 Cr. |
| BHEL | PAT Prev Qtr | ₹ 60.3 Cr. |
| BHEL | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| BHEL | NP Prev Qtr | ₹ 60.3 Cr. |
| BHEL | OPM Prev Qtr | 3.93 % |
| BHEL | NPM Prev Qtr | 1.10 % |
| BHEL | Eq Cap Prev Qtr | ₹ 696 Cr. |
| BHEL | EPS Prev Qtr | ₹ 0.17 |
| BHEL | Sales PY Qtr | ₹ 8,227 Cr. |
| BHEL | OP PY Qtr | ₹ 1,049 Cr. |
| BHEL | Other Inc PY Qtr | ₹ 125 Cr. |
| BHEL | EBIDT PY Qtr | ₹ 1,173 Cr. |
| BHEL | Dep PY Qtr | ₹ 72.6 Cr. |
| BHEL | EBIT PY Qtr | ₹ 1,101 Cr. |
| BHEL | Interest PY Qtr | ₹ 161 Cr. |
| BHEL | PBT PY Qtr | ₹ 940 Cr. |
| BHEL | Tax PY Qtr | ₹ 282 Cr. |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | Equity capital | ₹ 696 Cr. |
| BHEL | Preference capital | ₹ 0.00 Cr. |
| BHEL | Reserves | ₹ 23,742 Cr. |
| BHEL | Secured loan | ₹ 5,385 Cr. |
| BHEL | Unsecured loan | ₹ 68.5 Cr. |
| BHEL | Balance sheet total | ₹ 59,006 Cr. |
| BHEL | Gross block | ₹ 6,949 Cr. |
| BHEL | Revaluation reserve | ₹ 0.00 Cr. |
| BHEL | Accum Dep | ₹ 4,473 Cr. |
| BHEL | Net block | ₹ 2,600 Cr. |
| BHEL | CWIP | ₹ 282 Cr. |
| BHEL | Investments | ₹ 256 Cr. |
| BHEL | Current assets | ₹ 34,546 Cr. |
| BHEL | Current liabilities | ₹ 25,333 Cr. |
| BHEL | BV Unq Invest | ₹ 0.00 Cr. |
| BHEL | MV Quoted Inv | ₹ 0.00 Cr. |
| BHEL | Cont Liab | ₹ 7,357 Cr. |
| BHEL | Total Assets | ₹ 59,006 Cr. |
| BHEL | Working capital | ₹ 18,046 Cr. |
| BHEL | Lease liabilities | ₹ 48.5 Cr. |
| BHEL | Inventory | ₹ 7,221 Cr. |
| BHEL | Trade receivables | ₹ 4,785 Cr. |
| BHEL | Face value | ₹ 2.00 |
| BHEL | Cash Equivalents | ₹ 6,157 Cr. |
| BHEL | Adv Cust | ₹ 0.00 Cr. |
| BHEL | Trade Payables | ₹ 8,696 Cr. |
| BHEL | No. Eq. Shares PY | 348 |
| BHEL | Debt preceding year | ₹ 5,454 Cr. |
| BHEL | Work Cap PY | ₹ 12,894 Cr. |
| BHEL | Net Block PY | ₹ 2,476 Cr. |
| BHEL | Gross Block PY | ₹ 6,949 Cr. |
| BHEL | CWIP PY | ₹ 354 Cr. |
| BHEL | Work Cap 3Yr | ₹ 13,603 Cr. |
| BHEL | Work Cap 5Yr | ₹ 18,326 Cr. |
| BHEL | Work Cap 7Yr | ₹ 23,118 Cr. |
| BHEL | Work Cap 10Yr | ₹ 29,148 Cr. |
| BHEL | Debt 3Years back | ₹ 4,951 Cr. |
| BHEL | Debt 5Years back | ₹ 2,598 Cr. |
| BHEL | Debt 7Years back | ₹ 156 Cr. |
| BHEL | Debt 10Years back | ₹ 4,693 Cr. |
| BHEL | Net Block 3Yrs Back | ₹ 2,491 Cr. |
| BHEL | Net Block 5Yrs Back | ₹ 2,970 Cr. |
| BHEL | Net Block 7Yrs Back | ₹ 3,601 Cr. |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | CF Operations | ₹ -3,713 Cr. |
| BHEL | Free Cash Flow | ₹ -3,936 Cr. |
| BHEL | CF Investing | ₹ 1,331 Cr. |
| BHEL | CF Financing | ₹ 2,656 Cr. |
| BHEL | Net CF | ₹ 274 Cr. |
| BHEL | Cash Beginning | ₹ 1,561 Cr. |
| BHEL | Cash End | ₹ 6,157 Cr. |
| BHEL | FCF Prev Ann | ₹ -922 Cr. |
| BHEL | CF Operations PY | ₹ -742 Cr. |
| BHEL | CF Investing PY | ₹ 1,480 Cr. |
| BHEL | CF Financing PY | ₹ 89.0 Cr. |
| BHEL | Net CF PY | ₹ 828 Cr. |
| BHEL | Cash Beginning PY | ₹ 733 Cr. |
| BHEL | Cash End PY | ₹ 6,643 Cr. |
| BHEL | Free Cash Flow 3Yrs | ₹ -4,361 Cr. |
| BHEL | Free Cash Flow 5Yrs | ₹ -7,326 Cr. |
| BHEL | Free Cash Flow 7Yrs | ₹ -10,890 Cr. |
| BHEL | Free Cash Flow 10Yrs | ₹ -10,297 Cr. |
| BHEL | CF Opr 3Yrs | ₹ -3,794 Cr. |
| BHEL | CF Opr 5Yrs | ₹ -6,126 Cr. |
| BHEL | CF Opr 7Yrs | ₹ -8,997 Cr. |
| BHEL | CF Opr 10Yrs | ₹ -7,241 Cr. |
| BHEL | CF Inv 10Yrs | ₹ 6,516 Cr. |
| BHEL | CF Inv 7Yrs | ₹ 6,408 Cr. |
| BHEL | CF Inv 5Yrs | ₹ 3,528 Cr. |
| BHEL | CF Inv 3Yrs | ₹ 1,693 Cr. |
| BHEL | Cash 3Years back | ₹ 6,701 Cr. |
| BHEL | Cash 5Years back | ₹ 7,504 Cr. |
| BHEL | Cash 7Years back | ₹ 10,494 Cr. |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | No. Eq. Shares | 348 |
| BHEL | Book value | ₹ 70.2 |
| BHEL | Inven TO | 2.28 |
| BHEL | Quick ratio | 1.08 |
| BHEL | Exports percentage | 0.00 % |
| BHEL | Piotroski score | 3.00 |
| BHEL | G Factor | 2.00 |
| BHEL | Asset Turnover | 0.40 |
| BHEL | Financial leverage | 2.44 |
| BHEL | No. of Share Holders | 18,80,851 |
| BHEL | Unpledged Prom Hold | 63.2 % |
| BHEL | ROIC | 4.72 % |
| BHEL | Debtor days | 73.1 |
| BHEL | Industry PBV | 8.81 |
| BHEL | Credit rating |  |
| BHEL | WC Days | 182 |
| BHEL | Earning Power | 1.65 % |
| BHEL | Graham Number | ₹ 35.8 |
| BHEL | Cash Cycle | 41.1 |
| BHEL | Days Payable | 189 |
| BHEL | Days Receivable | 73.1 |
| BHEL | Inventory Days | 157 |
| BHEL | Public holding | 12.7 % |
| BHEL | FII holding | 9.10 % |
| BHEL | Chg in FII Hold | 0.34 % |
| BHEL | DII holding | 15.0 % |
| BHEL | Chg in DII Hold | -0.92 % |
| BHEL | B.V. Prev Ann | ₹ 77.0 |
| BHEL | ROCE Prev Yr | 3.33 % |
| BHEL | ROA Prev Yr | 0.77 % |
| BHEL | ROE Prev Ann | 1.70 % |
| BHEL | No. of Share Holders Prev Qtr | 14,99,202 |
| BHEL | No. Eq. Shares 10 Yrs | 367 |
| BHEL | BV 3yrs back | ₹ 74.6 |
| BHEL | BV 5yrs back | ₹ 82.3 |
| BHEL | BV 10yrs back | ₹ 93.2 |
| BHEL | Inven TO 3Yr | 1.04 |
| BHEL | Inven TO 5Yr | 1.26 |
| BHEL | Inven TO 7Yr | 1.84 |
| BHEL | Inven TO 10Yr | 1.43 |
| BHEL | Export 3Yr | 0.00 % |
| BHEL | Export 5Yr | 0.00 % |
| BHEL | Div 5Yrs | ₹ 73.1 Cr. |
| BHEL | ROCE 3Yr | 3.08 % |
| BHEL | ROCE 5Yr | -0.13 % |
| BHEL | ROCE 7Yr | 1.52 % |
| BHEL | ROCE 10Yr | 1.75 % |
| BHEL | ROE 10Yr | -0.13 % |
| BHEL | ROE 7Yr | -0.79 % |
| BHEL | ROE 5Yr Var | -18.9 % |
| BHEL | OPM 5Year | -0.87 % |
| BHEL | OPM 10Year | 1.84 % |
| BHEL | No. of Share Holders 1Yr | 10,12,617 |
| BHEL | Avg Div Payout 3Yrs | 30.4 % |
| BHEL | Debtor days 3yrs | 58.0 |
| BHEL | Debtor days 3yrs back | 85.1 |
| BHEL | Debtor days 5yrs back | 142 |
| BHEL | ROA 5Yr | -0.99 % |
| BHEL | ROA 3Yr | 0.67 % |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | Avg Vol 1Mth | 2,81,20,721 |
| BHEL | Avg Vol 1Wk | 3,10,03,861 |
| BHEL | Volume | 1,39,81,737 |
| BHEL | High price | ₹ 335 |
| BHEL | Low price | ₹ 94.8 |
| BHEL | High price all time | ₹ 391 |
| BHEL | Low price all time | ₹ 18.4 |
| BHEL | Return over 1day | 1.62 % |
| BHEL | Return over 1week | 5.93 % |
| BHEL | Return over 1month | 5.34 % |
| BHEL | DMA 50 | ₹ 300 |
| BHEL | DMA 200 | ₹ 237 |
| BHEL | DMA 50 previous day | ₹ 299 |
| BHEL | 200 DMA prev. | ₹ 236 |
| BHEL | RSI | 52.2 |
| BHEL | MACD | 2.80 |
| BHEL | MACD Previous Day | 3.01 |
| BHEL | MACD Signal | 5.02 |
| BHEL | MACD Signal Prev | 5.58 |
| BHEL | Avg Vol 1Yr | 3,63,84,113 |
| BHEL | Return over 7years | 18.3 % |
| BHEL | Return over 10years | 7.35 % |
| BHEL | Market Cap | ₹ 1,10,242 Cr. |
| BHEL | Current Price | ₹ 317 |
| BHEL | High / Low | ₹ 335 / 94.8 |
| BHEL | Stock P/E | 391 |
| BHEL | Book Value | ₹ 70.2 |
| BHEL | Dividend Yield | 0.08 % |
| BHEL | ROCE | 2.97 % |
| BHEL | ROE | 1.10 % |
| BHEL | Face Value | ₹ 2.00 |
| BHEL | WC to Sales | 75.5 % |
| BHEL | QoQ Profits | 712 % |
| BHEL | QoQ Sales | 50.1 % |
| BHEL | Net worth | ₹ 24,439 Cr. |
| BHEL | Market Cap to Sales | 4.61 |
| BHEL | Interest Coverage | 1.33 |
| BHEL | EV / EBIT | 116 |
| BHEL | Debt Capacity | -0.06 |
| BHEL | Debt To Profit | 31.4 |
| BHEL | Capital Employed | ₹ 20,928 Cr. |
| BHEL | CROIC | -4.43 % |
| BHEL | debtplus | 0.66 |
| BHEL | Leverage | ₹ 2.44 |
| BHEL | Dividend Payout | 30.8 % |
| BHEL | Intrinsic Value | ₹ 21.3 |
| BHEL | CDL | -9.12 % |
| BHEL | Cash by market cap | 0.06 |
| BHEL | 52w Index | 92.2 % |
| BHEL | Down from 52w high | 5.61 % |
| BHEL | Up from 52w low | 234 % |
| BHEL | From 52w high | 0.94 |
| BHEL | Mkt Cap To Debt Cap | -7.20 |
| BHEL | Dividend Payout | 30.8 % |
| BHEL | Graham | ₹ 35.8 |
| BHEL | Price to Cash Flow | -29.7 |
| BHEL | ROCE3yr avg | 3.08 % |
| BHEL | PB X PE | 1,762 |
| BHEL | NCAVPS | ₹ 51.8 |
| BHEL | Mar Cap to CF | -29.7 |
| BHEL | Altman Z Score | 4.40 |
| BHEL | M.Cap / Qtr Profit | 225 |