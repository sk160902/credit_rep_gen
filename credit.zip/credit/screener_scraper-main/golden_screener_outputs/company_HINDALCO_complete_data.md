# Complete Company Data

## Modal Content
About
[
edit
]
Incorporated in 1958, Hindalco Industries Ltd. is a flagship company of the Aditya Birla Group. The Co and its subsidiaries are primarily engaged in the production of Aluminium and Copper. It is also
engaged in the manufacturing of aluminium sheet, extrusion and light gauge products for use in packaging markets like beverage and food, can and foil products, etc.
[1]
Key Points
[
edit
]
Business Segments
Aluminum
: The Co. ranks among the top global five aluminium producers based on shipments and is an integrated producer with a low-cost base and a strong presence across the value chain.
[1]
Copper
: The Co’s copper division operates one of the world's largest single-location customs copper smelters. Hindalco produces copper cathodes, and continuous cast copper rods in various sizes.
[2]
Chemicals
: The Co. is also engaged in the manufacturing of Calcined alumina (used in grinding media, wear-resistant ceramic components, etc.) and Alumina hydrates (used in the manufacture of water treatment chemicals like aluminium sulphate, zeolite, etc.)
[3]
Market Leadership
The Co. is the world’s largest aluminium rolling and recycling company. It is also one of Asia’s largest producers of primary aluminium.
[4]
Moreover, it is the largest flat rolled aluminium producer in the world and the largest downstream aluminium player in India.
[5]
Revenue Split FY22
Aluminium - 16%
Copper - 19%
Novelis (Subsidiary) - 65%
[6]
Geographical Split FY22
India - 24%
Outside India - 76%
[7]
Novelis
Novelis is a subsidiary of Hindalco Industries Limited producing automotive and beverage can sheets. It operates an integrated network of technically advanced rolling and recycling facilities across North America, South America, Europe and Asia.
[8]
Manufacturing Capabilities
The Co. has 50 manufacturing units spread across 10 countries. It has 17 units in India, 19 operational bauxite mines, and 33 overseas units of Novelis.
[5]
Production Capacity (in MN MT)
Alumina - 3.6
Specialty Alumina - ~0.4
Primary Aluminium - 1.3
Aluminium VAP - ~0.4
Copper Cathode - 0.4
Copper Rods - 0.5
Novelis Rolling Capacity - 4
Novelis recycling capacity - 2.5
[9]
Expanding Geographical Footprint
The Co. has expanded its scale by acquiring Kuppam facility at Rs. 247 Cr. of enterprise value and Ryker Base Private Limited, now Asoj at an enterprise value of Rs. 323 Cr.
[9]
Capacity Expansion
In FY22, the Co. completed its 500 kt Utkal’s Alumina refinery brownfield capacity expansion which required a capital outlay of Rs. 1,500 crores. Further debottlenecking is planned at Utkal Alumina by 350 kt to take the capacity to around 2.5 Million MT by FY 2023-24.
[10]
[11]
Additionally, it has started to expand the FRP production capacity at Aditya Aluminium and Hirakud plants by 170 KTPA with a planned investment of about Rs. 2,690 Crore. The plants at Aditya and Mahan are due to get an 18-pot expansion each at a cost of Rs. 417 Crore and Rs. 429 Crore.
[9]
Investments
The Co. has invested Rs. 609 Crore in Silvassa to build new extrusions plants with a planned capacity of 34 KTPA.
[9]
The Co. announced certain organic growth investments in India in the businesses of Aluminium, Copper, Specialty Alumina and also Resource Securitisation over the next 5 years in the range of $3.0 - 3.3 billion. Novelis has identified more than $4.5 billion of potential capital investment opportunities in new capacities and facilities. The new facilities will be established in the US, China, South Korea, Germany, and Brazil. Of the estimated range of total investments, ~$3 Billion is expected to be invested in the US.
[11]
Renewable Energy Target
At present, the Co. has a total renewable capacity of 100 MW. It intends to achieve a renewable capacity of 300 MW by FY2024-25, including 100 MW solar power capacity with hybrid storage.
[12]
Fund Raising
In March 2021, Novelis Inc. announced the completion of €500 million aggregate principal amount of 3.375% euro-denominated senior green notes due April 15, 2029, by Novelis Sheet Ingot GmbH, an indirect wholly-owned subsidiary of Novelis.
[13]
Further, in July 2021, Novelis Inc. raised $750M principal amount of its senior notes due in 2026 and $750M aggregate principal amount of its senior notes due in 2031.
[14]
Focus
The Co. continues to focus on its downstream strategy to increase its downstream capacities in the Flat Rolled Products, Extrusions and other flat rolled products.
[10]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 80,193 | 87,695 | 104,281 | 98,759 | 100,184 | 115,183 | 130,542 | 118,144 | 131,985 | 195,059 | 223,202 | 215,962 |
| Expenses + | 72,494 | 79,671 | 95,437 | 90,981 | 87,867 | 101,488 | 115,031 | 103,838 | 114,449 | 166,712 | 200,536 | 192,090 |
| Operating Profit | 7,699 | 8,024 | 8,844 | 7,778 | 12,317 | 13,695 | 15,511 | 14,306 | 17,536 | 28,347 | 22,666 | 23,872 |
| OPM % | 10% | 9% | 8% | 8% | 12% | 12% | 12% | 12% | 13% | 15% | 10% | 11% |
| Other Income + | 1,111 | 677 | -832 | 1,500 | 1,198 | 2,879 | 1,127 | 906 | -964 | 1,253 | 1,307 | 1,519 |
| Interest | 2,079 | 2,702 | 4,178 | 5,134 | 5,742 | 3,911 | 3,778 | 4,197 | 3,738 | 3,768 | 3,646 | 3,858 |
| Depreciation | 2,822 | 3,347 | 3,493 | 4,347 | 4,457 | 4,506 | 4,777 | 5,091 | 6,628 | 6,729 | 7,086 | 7,521 |
| Profit before tax | 3,909 | 2,653 | 340 | -203 | 3,315 | 8,157 | 8,083 | 5,924 | 6,206 | 19,103 | 13,241 | 14,012 |
| Tax % | 23% | 20% | 75% | 245% | 43% | 25% | 32% | 36% | 44% | 28% | 24% | 28% |
| Net Profit + | 3,007 | 2,195 | 259 | -702 | 1,882 | 6,083 | 5,495 | 3,767 | 3,483 | 13,730 | 10,097 | 10,155 |
| EPS in Rs | 15.81 | 10.53 | 4.14 | -1.21 | 8.47 | 27.10 | 24.48 | 16.77 | 15.50 | 61.10 | 44.93 | 45.19 |
| Dividend Payout % | 6% | 9% | 24% | -82% | 13% | 4% | 5% | 6% | 19% | 6% | 7% | 8% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Aluminium Norf GmbH Associate |  |  |  |  |  |  |  |  |  |
| Service Received | 1,598 | 1,519 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 418 | 489 |  |  |  |  |  |  |  |
| Trade and Other Payables | 271 | 317 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits given | 127 | 17 |  |  |  |  |  |  |  |
| Interest and Dividend Received | 4.41 | 4.66 |  |  |  |  |  |  |  |
| Trade and other Receivables | 1.51 | 5.32 |  |  |  |  |  |  |  |
| Aditya Birla Management Corporation Private Limited |  |  |  |  |  |  |  |  |  |
| Services received |  |  |  |  | 429 |  |  |  | 832 |
| Payables |  |  |  |  |  |  |  |  | 98 |
| Loans, Deposits and Advances given |  |  |  |  |  |  |  |  | 94 |
| Credit Balances |  |  |  |  | 32 |  |  |  |  |
| Debit Balances |  |  |  |  | 19 |  |  |  |  |
| Services rendered |  |  |  |  |  |  |  |  | 11 |
| Reimbursement of Expenses from |  |  |  |  |  |  |  |  | 1 |
| Receivable against reimbursement |  |  |  |  |  |  |  |  | 1 |
| Hindalco Employees Provident Fund Institution, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 164 |  | 72 |  |  |  |  |
| Aditya Birla Science and Technology Company Pvt. Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 58 | 58 |  |  |  |  |  |  |  |
| Service Received | 15 | 12 |  |  |  |  |  |  |  |
| Interest and Dividend Received | 5.14 | 5.14 |  |  |  |  |  |  |  |
| Trade and other Receivables | 0.04 |  |  |  |  |  |  |  |  |
| Service Rendered | 0.02 |  |  |  |  |  |  |  |  |
| Aditya Birla Science & Technology Company Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Deposits, Loans and Advances |  |  | 55 |  |  |  |  |  |  |
| Deposits and Loans (given) |  |  |  |  | 51 |  |  |  |  |
| Services received |  |  |  |  | 15 |  |  |  |  |
| Services Received |  |  | 12 |  |  |  |  |  |  |
| Interest and dividend received |  |  | 4.56 |  |  |  |  |  |  |
| Interest received |  |  |  |  | 4 |  |  |  |  |
| Deposits, Loans and Advances received back during the year |  |  | 2.45 |  |  |  |  |  |  |
| Hindalco Industries Limited Employees Provident Fund II |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 51 |  | 58 |  |  |  |  |
| Mr. D. Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration | 23 | 21 | 48 | 6.93 |  |  |  |  |  |
| Hindalco Employees Gratuity Fund, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 41 |  | 43 |  |  |  |  |
| Aditya Birla Science & Technology Company Pvt Ltd Associate |  |  |  |  |  |  |  |  |  |
| Deposits, Loans and Advances |  |  |  | 51 |  |  |  |  |  |
| Services Received |  |  |  | 13 |  |  |  |  |  |
| Deposits, Loans and Advances received back during the year |  |  |  | 4.90 |  |  |  |  |  |
| Interest and dividend received |  |  |  | 3.45 |  |  |  |  |  |
| Payables |  |  |  | 0.26 |  |  |  |  |  |
| Mr. Satish Pai Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration | 13 | 15 | 19 | 21 |  |  |  |  |  |
| Directors Remuneration |  |  |  | 1.06 |  |  |  |  |  |
| Executive Directors Subsidiary |  |  |  |  |  |  |  |  |  |
| Short term employment benefit |  |  |  |  |  |  |  | 52 |  |
| Commission & Sitting Fees |  |  |  |  |  |  |  | 9 |  |
| Post employment benefits |  |  |  |  |  |  |  | 4 |  |
| Aditya Birla Science & Technology Company Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans, Deposits and Advances given |  |  |  |  |  |  |  |  | 29 |
| Services received |  |  |  |  |  |  |  |  | 21 |
| Deposits, Loans and Advances received back from |  |  |  |  |  |  |  |  | 7 |
| Interest received |  |  |  |  |  |  |  |  | 2 |
| Reimbursement of Expenses to |  |  |  |  |  |  |  |  | 1 |
| Idea Cellular Limited Associate |  |  |  |  |  |  |  |  |  |
| Interest and Dividend Received | 10 | 15 |  |  |  |  |  |  |  |
| Interest and dividend received |  |  | 15 |  |  |  |  |  |  |
| Service Received | 3.06 | 3.27 |  |  |  |  |  |  |  |
| Services Received |  |  | 3.16 |  |  |  |  |  |  |
| Trade and other Receivables | 0.40 | 0.39 |  |  |  |  |  |  |  |
| Debit Balances |  |  | 0.40 |  |  |  |  |  |  |
| Trade and Other Payables | 0.11 | 0.10 |  |  |  |  |  |  |  |
| Credit Balances |  |  | 0.10 |  |  |  |  |  |  |
| Service Rendered | 0.06 |  |  |  |  |  |  |  |  |
| Services rendered |  |  | 0.03 |  |  |  |  |  |  |
| Aditya Birla Renewables Solar Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 20 |
| Investments made |  |  |  |  |  |  |  |  | 17 |
| Payables |  |  |  |  |  |  |  |  | 3 |
| Aditya Birla Renewables Subsidiary Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 13 |
| Sales of Goods |  |  |  |  |  |  |  |  | 2 |
| Payables |  |  |  |  |  |  |  |  | 1 |
| Hindalco Superannuation Scheme, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 7.19 |  | 7 |  |  |  |  |
| Hindalco Employees Gratuity Fund, Kolkata |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 13 |  |  |  |  |  |  |
| Aditya Birla Renewables Subsidiary Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investments made during the year |  |  |  |  | 6 |  |  |  |  |
| Purchase of Materials, Capital Equipment and Others |  |  |  |  | 5 |  |  |  |  |
| Credit Balances |  |  |  |  | 1 |  |  |  |  |
| Mr. Kumar Mangalam Birla Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 5.21 | 5.19 |  |  |  |  |  |
| Hindalco Industries Limited Senior Management Staff Pension Fund II |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 4.46 |  | 5 |  |  |  |  |
| Mr. Praveen Maheshwari Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration |  |  | 3.68 | 4.08 |  |  |  |  |  |
| Vodafone Idea Limited Associate |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  | 3.91 |  |  |  |  |  |
| Interest and dividend received |  |  |  | 0.92 |  |  |  |  |  |
| Services rendered |  |  |  | 0.03 |  |  |  |  |  |
| Aditya Birla Renewables Utkal Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 3 |
| Payables |  |  |  |  |  |  |  |  | 1 |
| Mr. D Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 1.15 | 1.15 |  |  |  |  |  |
| Mr. A.K.Agarwala Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 1.16 | 1.11 |  |  |  |  |  |
| Managing Director Subsidiary |  |  |  |  |  |  |  |  |  |
| Post employment benefits |  |  |  |  |  |  |  | 2 |  |
| Hindalco Industries Limited Office Employees Pension Fund |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 1.09 |  |  |  |  |  |  |
| Hydromine Global Minerals (GMBH) Limited JV |  |  |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 0.76 | 0.06 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits given | 0.01 | 0.06 |  |  |  |  |  |  |  |
| Mr. M.M. Bhagat Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.23 | 0.24 |  |  |  |  |  |
| Mr. K.N. Bhandari Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.21 | 0.21 |  |  |  |  |  |
| Mr. Y.P. Dandiwala Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.17 | 0.17 |  |  |  |  |  |
| Mr. Jagdish Khattar Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.12 | 0.08 |  |  |  |  |  |
| Smt. Rajashree Birla Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.11 | 0.08 |  |  |  |  |  |
| Mr. Girish Dave Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.07 | 0.10 |  |  |  |  |  |
| Mr. Ram Charan Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.03 | 0.09 |  |  |  |  |  |
| Hydromine Global Minerals GMBH Limited JV |  |  |  |  |  |  |  |  |  |
| Receivables |  |  |  | 0.03 |  |  |  |  |  |
| Debit Balances |  |  | 0.03 |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 80,193 | 87,695 | 104,281 | 98,759 | 100,184 | 115,183 | 130,542 | 118,144 | 131,985 | 195,059 | 223,202 | 215,962 |
| Expenses + | 72,494 | 79,671 | 95,437 | 90,981 | 87,867 | 101,488 | 115,031 | 103,838 | 114,449 | 166,712 | 200,536 | 192,090 |
| Operating Profit | 7,699 | 8,024 | 8,844 | 7,778 | 12,317 | 13,695 | 15,511 | 14,306 | 17,536 | 28,347 | 22,666 | 23,872 |
| OPM % | 10% | 9% | 8% | 8% | 12% | 12% | 12% | 12% | 13% | 15% | 10% | 11% |
| Other Income + | 1,111 | 677 | -832 | 1,500 | 1,198 | 2,879 | 1,127 | 906 | -964 | 1,253 | 1,307 | 1,519 |
| Interest | 2,079 | 2,702 | 4,178 | 5,134 | 5,742 | 3,911 | 3,778 | 4,197 | 3,738 | 3,768 | 3,646 | 3,858 |
| Depreciation | 2,822 | 3,347 | 3,493 | 4,347 | 4,457 | 4,506 | 4,777 | 5,091 | 6,628 | 6,729 | 7,086 | 7,521 |
| Profit before tax | 3,909 | 2,653 | 340 | -203 | 3,315 | 8,157 | 8,083 | 5,924 | 6,206 | 19,103 | 13,241 | 14,012 |
| Tax % | 23% | 20% | 75% | 245% | 43% | 25% | 32% | 36% | 44% | 28% | 24% | 28% |
| Net Profit + | 3,007 | 2,195 | 259 | -702 | 1,882 | 6,083 | 5,495 | 3,767 | 3,483 | 13,730 | 10,097 | 10,155 |
| EPS in Rs | 15.81 | 10.53 | 4.14 | -1.21 | 8.47 | 27.10 | 24.48 | 16.77 | 15.50 | 61.10 | 44.93 | 45.19 |
| Dividend Payout % | 6% | 9% | 24% | -82% | 13% | 4% | 5% | 6% | 19% | 6% | 7% | 8% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 2,977 | 7,956 | 7,143 | 11,688 | 12,687 | 10,898 | 11,977 | 12,745 | 17,232 | 16,838 | 19,208 | 24,056 |
| Cash from Investing Activity + | -13,801 | -8,095 | -3,873 | -3,220 | -2,876 | 5,333 | -5,456 | -7,227 | -25,280 | -6,773 | -7,664 | -14,276 |
| Cash from Financing Activity + | 10,278 | 1,493 | -2,437 | -8,862 | -5,552 | -16,412 | -5,466 | 6,656 | -4,882 | -6,765 | -10,345 | -10,817 |
| Net Cash Flow | -545 | 1,353 | 833 | -394 | 4,259 | -181 | 1,055 | 12,174 | -12,930 | 3,300 | 1,199 | -1,037 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 41 | 38 | 32 | 29 | 30 | 32 | 32 | 29 | 36 | 39 | 27 | 28 |
| Inventory Days | 108 | 114 | 104 | 103 | 120 | 115 | 103 | 120 | 146 | 138 | 111 | 111 |
| Days Payable | 72 | 89 | 87 | 92 | 115 | 108 | 96 | 98 | 135 | 128 | 93 | 94 |
| Cash Conversion Cycle | 76 | 64 | 49 | 40 | 36 | 38 | 39 | 51 | 47 | 49 | 45 | 45 |
| Working Capital Days | 54 | 44 | 34 | 37 | 7 | 27 | 30 | 32 | 20 | 19 | 25 | 27 |
| ROCE % | 7% | 5% | 6% | 4% | 8% | 10% | 11% | 9% | 9% | 17% | 11% | 11% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 34.64% | 34.64% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% | 34.65% |
| FIIs + | 25.47% | 25.99% | 28.85% | 24.76% | 24.85% | 25.66% | 26.08% | 26.25% | 27.01% | 27.89% | 26.82% | 27.18% |
| DIIs + | 20.61% | 21.17% | 19.22% | 21.52% | 26.80% | 26.87% | 26.20% | 26.08% | 25.78% | 25.06% | 25.64% | 25.41% |
| Government + | 0.01% | 0.01% | 0.01% | 0.01% | 0.22% | 0.22% | 0.22% | 0.22% | 0.22% | 0.35% | 0.35% | 0.35% |
| Public + | 18.97% | 17.85% | 16.96% | 18.76% | 13.11% | 12.20% | 12.44% | 12.42% | 11.92% | 11.59% | 12.08% | 11.98% |
| Others + | 0.29% | 0.34% | 0.31% | 0.29% | 0.36% | 0.41% | 0.41% | 0.39% | 0.42% | 0.47% | 0.46% | 0.44% |
| No. of Shareholders | 4,04,878 | 5,06,562 | 5,03,729 | 7,03,180 | 7,45,952 | 6,48,797 | 6,76,110 | 6,66,489 | 6,13,244 | 5,49,231 | 6,41,541 | 6,49,551 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 34.70% | 34.67% | 34.66% | 34.65% | 34.64% | 34.65% | 34.65% | 34.65% | 34.65% |
| FIIs + | 27.51% | 28.09% | 23.69% | 18.68% | 25.00% | 28.85% | 26.08% | 26.82% | 27.18% |
| DIIs + | 17.76% | 19.11% | 22.24% | 26.27% | 20.81% | 19.22% | 26.20% | 25.64% | 25.41% |
| Government + | 0.02% | 0.02% | 0.12% | 0.41% | 0.01% | 0.01% | 0.22% | 0.35% | 0.35% |
| Public + | 20.02% | 18.11% | 19.09% | 19.72% | 19.28% | 16.96% | 12.44% | 12.08% | 11.98% |
| Others + | 0.00% | 0.00% | 0.20% | 0.26% | 0.26% | 0.31% | 0.41% | 0.46% | 0.44% |
| No. of Shareholders | 3,19,787 | 2,99,521 | 3,04,345 | 3,32,014 | 3,48,471 | 5,03,729 | 6,76,110 | 6,41,541 | 6,49,551 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/hindalco-industries-ltd/hindalco/500440/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 3m](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e76b20c2-d0f6-4d57-a514-b0ef762ce824.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cc9a4f38-ed44-4a96-b270-6b217ac7ed52.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
2d - Newspaper advertisement relating to 65th Annual General meeting](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0504ccb5-5251-4d0e-b3ee-e260194b5a97.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=054bdcb4-ea7c-46cb-9dad-afeb66f1e74b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fcd16078-fde3-42cc-b8fe-de2c99fa1b8b.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\57aa00bc-63d7-4dfd-886b-2f590de378fc.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500440/73999500440.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500440/69149500440.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500440/64728500440_01_12_20.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_HINDALCO_2010_2011_20062012125651.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500440/5004400310.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/sep-2008/hindalco-industries-limited_13595.html)

## Credit Ratings
- [Rating update
3 Jul from fitch](https://www.indiaratings.co.in/pressrelease/70713)
- [Rating update
2 Apr from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/HindalcoIndustriesLimited_April%2002_%202024_RR_339544.html)
- [Rating update
8 Feb from care](https://www.careratings.com/upload/CompanyFiles/PR/202402120216_Hindalco_Industries_Limited.pdf)
- [Rating update
5 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310141006_Hindalco_Industries_Limited.pdf)
- [Rating update
5 Jul 2023 from fitch](https://www.indiaratings.co.in/pressrelease/62521)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/HindalcoIndustriesLimited_April%2017,%202023_RR_315759.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3d70c93e-19ee-4888-8920-fcc40aab7093.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa1caad1-546a-43c4-9d6b-5f6a6900040b.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9a18b2bc-ec83-4d71-ba34-b41b100c604e.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0897fd43-cbc7-4a40-a937-fd5dd6923ba5.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0ddcacb7-29d8-4a87-9141-2c724cacc1f0.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=84659644-4d96-41af-96d3-9eb7040518bf.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b53484b-a7dd-4903-b2f4-b7543cd11043.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8176fc01-e8f0-4108-b1f8-c720904d6cc4.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=79b20579-7907-4f2a-8f67-e97475e22734.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=97390bcf-b0fc-4f92-afe7-c32a7d0e397f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a2f5edb7-36b7-4983-81bd-46219984f822.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=34907d8d-a34c-4cf0-a7b6-44132ae4d3e4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ca6c89f5-0b70-4129-8f07-8fab955eeee7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba80013d-9287-4589-820f-64b55c7a7968.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e3f50199-0823-432c-a12a-15f9e87f8626.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=edfed103-496b-4059-a458-60702c3ecb50.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7c09f36b-14e6-499b-ae0b-05508313408b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2cabf9b6-ce58-4d60-a003-4be15f84423c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44fd5326-6ab6-448e-8102-83b50b13f728.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c5329da4-ea4e-46e7-a992-a1db421bbc54.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=636f6388-f098-4759-aa3e-926b8f796f6a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aeaaec05-be61-434d-88cd-93dd00d9f76d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd417f7b-b7e8-4902-95a9-b257b497d855.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0877ee78-d919-46f6-8dd2-87aa20bbbafe.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7c4132ab-de66-4920-9b9b-307352975f73.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=420e109b-b99b-4f63-9dc6-84174a7a2523.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c63783cd-8966-4efc-9a4d-72495b951c54.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f38e2175-e1ce-4217-8afe-4a1f8725fef2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=19b005b7-48d6-4a02-a36e-acca88fde1f1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f0676d5-34b5-4f66-ab38-28f13ba0fbe5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48eafe74-f5cf-413f-8124-f2aa1430cf56.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6270af27-4669-4ef7-ac85-46d2af38a8a3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6287f80c-a5be-4c67-bb06-bd3762f2c402.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=df95c736-f561-4c77-96fa-5a310d67f451.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6ea2ac3b-5a5e-4576-bd69-afef74d9e96f.pdf)
- [](http://hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q3fy22-feb-2022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=df0a51e0-c619-4acd-bb46-dd21420d3818.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c0e4420-08d9-4851-bd5e-2595dce5fe01.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6435adde-e161-457d-9db3-460482c8de15.pdf)
- [](http://hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q2fy22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6f422d44-c06e-40d5-afdf-69e5367ac354.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b5c70f93-863a-40d9-92fa-e9b1d4ddf805.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b2740634-2872-4969-8281-6f3e0ed650d6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1acc3045-eae6-454b-9bdc-3a3e1cbb1afc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49b01bff-9afd-4768-91d8-6474cf2ba391.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac0b29f2-cc8f-489a-b273-02d3d0434a39.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q4fy21-may2021.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6c6ae2cc-ad0e-437f-a00a-c0ffbb279b5d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e015b78c-5b09-4942-9005-5c9e4086a55a.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q3fy21-feb20121.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a49de510-340b-482e-af6b-57280ff01e8d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b1448d94-e653-45b4-8c37-c4950e56d4cc.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q2fy21-nov2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8c53fdd7-b5f5-40c4-a4c4-60ddac1b1f89.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q1fy21-14aug2020.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-q4%20fy20-june12-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ddc71712-258e-4805-8cc0-6af0ce10c6d4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f63ca839-28a6-4acc-92c7-0349c3b15720.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Industries-earnings-concall-transcript-feb12-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=83c40150-74ce-49c9-9f4d-47b0c69c10ec.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-Q2%20FY20-earning-confcall-transcript-11Nov2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ebc8d5a0-364c-4b5f-98ab-4e81a0e487d0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0ff3bd4d-f6ce-49f8-aaf6-fccddd0635e7.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-earning-concall-transcript-aug-09-2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51f371c4-fce1-413c-8e78-5559d17b5044.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d6e9962c-a785-429b-b536-669ebd4ae3cb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac1ba44d-9a00-4423-a1a1-7db314269961.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-earnings-concall-transcript%20-16may2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=97c1dec1-2e33-47e8-80a1-5ab9688b20ec.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=05e965d9-9f33-4687-aabf-275347a0c71e.pdf)
- [](http://www.hindalco.com/upload/pdf/Hindalco_Q3%20FY19_concall%20-transcript_12Feb-2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ee01b439-b2b1-4d43-99aa-3c704c1b41f5.pdf)
- [](http://www.hindalco.com/upload/pdf/transcript-hindalco-earnings%20Concall_Q2%20FY19_02Nov-2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=92f107b2-6a37-4cc6-bc05-d4fabe4faa81.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b56473d5-e759-42d5-a261-0ae8c3f53a12.pdf)
- [](http://www.hindalco.com/upload/pdf/Hindalco-Q1FY19-earnings-concall-transcriot-10Aug-2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0600da0-78b6-41d4-989b-9cead11460bb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=239e42ef-f83b-439a-982b-4ac5ddc618a3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1ae4bef1-f4ed-45b3-a556-f5420a277f8e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e709d341-e33f-4aeb-b9ed-102d07ef1e23.pdf)
- [](http://www.hindalco.com/upload/pdf/Q4FY18-hindalco-earnings-concall-transcript-16May18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=72e21cf0-6be4-4e44-af8f-b07fdde04de9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1815a37f-dc4b-4412-9a2d-eb9533a90a7d.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-q3fy18-earning-script.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cc853c11-252c-4ea2-83f6-b0f542874323.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6ba12c6a-e2ba-4c33-a602-90d3a834bc70.pdf)
- [](http://www.hindalco.com/upload/pdf/earnings-call-transcript-q1fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e60752a7-c61e-4de6-9322-865678fb849f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8944dd56-985e-4093-bfc5-7a4a75d10e48.pdf)
- [](http://www.hindalco.com/upload/pdf/Hindalco-call-transcript-Q4%20FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=39695307-688f-4086-b492-9965691c7008.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c9c035c2-ea3b-4f0a-a6b2-7074c51bbdb6.pdf)
- [](http://www.hindalco.com/upload/pdf/Hindalco-call-transcript-q3fy17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=743496B4_2D5B_4131_8714_2DC6642A6CF6_130735.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2EFACA82_AB4F_4BCD_BC9C_4EBF13C835E2_161644.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco-earnings-call-transcript-12Nov16.pdf)
- [](http://www.hindalco.com/upload/pdf/Hindalco-earnings-call-transcript-Aug-16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9934DA44_EF8D_4689_B4A4_4C1E13145003_145258.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco_earnings_call_transcript_q4fy16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8B6AB447_C71F_48B5_AF8A_852C87594B3A_160152.pdf)
- [](http://www.hindalco.com/upload/pdf/hindalco_earnings_call_transcript_Q3_FY16.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Hindalco Inds. | 667.30 | 149956.70 | 14.83 | 1.41 | 0.69 | 15.34 | 7.56 | 26.70 | 0.53 | 11.24 | 4.45 | 10.09 | 0.95 | 0.53 | 4.63 | 2.15 | 215962.00 | 11.05 | 10139.78 | 55994.00 | 3174.00 | 0.25 | 31.65 | 45.19 | 56356.00 | 34.64 | 0.00 | 9.53 | 26.28 | 0.00 | -3.24 | 0.42 | 191875.70 | 1.39 | 1.03 | -0.42 | 13.99 | 15.71 | 43.23 | 12.96 | 10.74 | 14.34 | 45.03 | 10.59 | 17.84 | 11.67 | 11.34 | 0.70 | 45.19 | 14.32 | 10.69 | 10.95 | 11.30 | 45.09 | 224.72 |
| 2. | Natl. Aluminium | 189.60 | 34822.51 | 19.85 | 2.34 | 2.65 | 32.32 | 10.35 | 32.05 | 2.39 | 16.95 | 9.48 | 12.67 | 0.71 | 0.01 | 137.94 | 1.27 | 13149.15 | 21.85 | 1761.89 | 3579.05 | 699.24 | -2.51 | 33.98 | 11.22 | 96.38 | 51.28 | 0.00 | 7.58 | 26.28 | 0.00 | -7.76 | 14.21 | 32343.74 | 1.93 | 58.38 | -2.53 | 30.49 | 28.32 | 94.32 | 16.28 | 13.04 | 0.34 | 10.70 | 2.72 | 13.66 | 11.96 | 15.13 | 1.35 | 11.22 | 0.65 | 12.36 | 8.90 | 12.40 | 50.26 | 183.66 |
| 3. | MMP Industries | 332.25 | 844.01 | 24.18 | 2.93 | 1.45 | 508.38 | 15.47 | 23.63 | 0.30 | 13.43 | 7.98 | 11.59 | 1.46 | 0.32 | 6.73 | 1.37 | 582.62 | 8.94 | 34.94 | 155.51 | 11.33 | 2.69 | 41.10 | 13.75 | 93.22 | 74.48 | 0.00 | 6.09 | 26.28 | 0.00 | 7.59 | 41.74 | 936.84 | 1.48 | 3.48 | 0.52 | 52.23 | 24.84 | 46.02 | 11.01 | 10.48 | 6.95 | 21.89 | 17.29 | 35.86 | 8.59 | 10.50 | 0.54 | 12.46 | 6.95 | 16.11 | 18.15 | 15.21 | 105.74 | 2.54 |
| 4. | Maan Aluminium | 139.35 | 753.66 | 23.02 | 4.62 | 0.79 | 47.73 | 15.01 | 71.83 | 0.53 | 24.94 | 14.56 | 22.33 | 4.24 | 0.20 | 12.95 | 1.38 | 953.03 | 4.68 | 32.75 | 237.40 | 7.28 | -9.69 | -49.65 | 6.06 | 32.60 | 58.87 | 0.00 | 6.16 | 26.28 | 0.00 | 17.10 | -34.51 | 785.59 | 2.55 | 0.79 | -9.62 | -3.99 | 40.77 | 47.85 | 31.91 | 29.43 | 29.02 | 30.31 | 7.89 | 33.24 | 46.60 | 42.84 | 1.87 | 6.06 | 28.98 | 8.39 | 9.12 | 9.03 | 42.28 | 5.40 |
| 5. | Arfin India | 39.40 | 664.79 | 80.87 | 6.52 | 1.24 | 65.31 | 24.30 | 38.52 | 0.00 | 13.59 | 2.98 | 8.91 | 1.94 | 1.24 | 1.52 | 2.86 | 535.16 | 5.64 | 8.22 | 136.80 | 2.18 | -9.93 | -15.83 | 0.52 | 119.72 | 69.79 | -4.30 | 3.67 | 26.28 | 0.00 | -1.65 | -19.88 | 782.09 | 1.38 | 18.42 | -24.06 | -26.68 | 76.68 | -0.23 | 11.15 | 2.33 | 4.39 | 39.16 | 5.33 | 20.82 | 12.38 | 13.00 | 0.44 | 0.52 | 4.39 | 30.68 | 35.36 | 27.73 | 104.19 | 15.89 |
| 6. | Euro Panel | 204.00 | 499.81 | 34.21 | 4.35 | 1.26 | -524.27 | 17.20 |  | 0.00 | 19.04 | 6.58 | 14.55 | 1.78 | 0.80 | 3.06 | 2.21 | 395.23 | 8.08 | 14.61 | 205.94 | 1.88 |  |  | 5.96 | 91.58 | 62.81 | 0.00 | 5.03 | 26.28 | 0.00 | 19.93 | 45.08 | 586.65 | 1.50 | 1.14 | 10.65 | 8.59 |  | 66.76 | 14.70 | 14.48 | 29.97 | 59.36 | 29.62 | 40.56 | 10.56 | 15.25 | 0.40 | 5.96 | 18.98 | 33.43 | 33.43 | 33.43 | 124.27 | 2.45 |
| 7. | Baheti Recycling | 297.00 | 307.95 | 42.77 | 7.40 | 0.72 | -30.82 | 19.90 |  | 0.00 | 18.40 | 5.67 | 20.91 | 3.38 | 2.38 | 1.92 | 3.69 | 429.34 | 4.74 | 7.20 | 222.61 |  |  |  | 6.94 | 99.02 | 73.40 | 0.00 | 4.77 | 26.28 | 0.00 | 20.04 | 36.36 | 406.66 | 1.30 | 0.59 | 59.76 | 50.76 |  | 165.30 | 20.89 | 16.97 | 72.60 | 148.36 | 23.80 | 49.95 | 20.64 | 14.67 | 0.51 | 6.94 | 40.83 | 31.54 | 31.54 | 31.54 | 80.87 | 1.04 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| HINDALCO | Market Cap | ₹ 1,49,945 Cr. |
| HINDALCO | Current Price | ₹ 667 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | Sales | ₹ 2,15,962 Cr. |
| HINDALCO | OPM | 11.0 % |
| HINDALCO | Profit after tax | ₹ 10,140 Cr. |
| HINDALCO | Mar Cap | ₹ 1,49,945 Cr. |
| HINDALCO | Sales Qtr | ₹ 55,994 Cr. |
| HINDALCO | PAT Qtr | ₹ 3,174 Cr. |
| HINDALCO | Qtr Sales Var | 0.25 % |
| HINDALCO | Qtr Profit Var | 31.6 % |
| HINDALCO | Price to Earning | 14.8 |
| HINDALCO | Dividend yield | 0.53 % |
| HINDALCO | Price to book value | 1.41 |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | Return on assets | 4.45 % |
| HINDALCO | Debt to equity | 0.53 |
| HINDALCO | Return on equity | 10.1 % |
| HINDALCO | EPS | ₹ 45.2 |
| HINDALCO | Debt | ₹ 56,356 Cr. |
| HINDALCO | Promoter holding | 34.6 % |
| HINDALCO | Change in Prom Hold | 0.00 % |
| HINDALCO | Earnings yield | 9.53 % |
| HINDALCO | Pledged percentage | 0.00 % |
| HINDALCO | Industry PE | 26.3 |
| HINDALCO | Sales growth | -3.24 % |
| HINDALCO | Profit growth | 0.42 % |
| HINDALCO | Current Price | ₹ 667 |
| HINDALCO | Price to Sales | 0.69 |
| HINDALCO | CMP / FCF | 15.3 |
| HINDALCO | EVEBITDA | 7.56 |
| HINDALCO | Enterprise Value | ₹ 1,91,864 Cr. |
| HINDALCO | Current ratio | 1.39 |
| HINDALCO | Int Coverage | 4.63 |
| HINDALCO | PEG Ratio | 1.03 |
| HINDALCO | Return over 3months | -0.42 % |
| HINDALCO | Return over 6months | 14.0 % |
| HINDALCO | No. Eq. Shares | 225 |
| HINDALCO | Sales growth 3Years | 17.8 % |
| HINDALCO | Sales growth 5Years | 10.6 % |
| HINDALCO | Profit Var 3Yrs | 45.0 % |
| HINDALCO | Profit Var 5Yrs | 14.3 % |
| HINDALCO | ROE 5Yr | 10.7 % |
| HINDALCO | ROE 3Yr | 13.0 % |
| HINDALCO | Return over 1year | 43.2 % |
| HINDALCO | Return over 3years | 15.7 % |
| HINDALCO | Return over 5years | 26.7 % |
| HINDALCO | Market Cap | ₹ 1,49,945 Cr. |
| HINDALCO | Current Price | ₹ 667 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | Sales last year | ₹ 2,15,962 Cr. |
| HINDALCO | OP Ann | ₹ 23,872 Cr. |
| HINDALCO | Other Inc Ann | ₹ 1,519 Cr. |
| HINDALCO | EBIDT last year | ₹ 25,370 Cr. |
| HINDALCO | Dep Ann | ₹ 7,521 Cr. |
| HINDALCO | EBIT last year | ₹ 17,849 Cr. |
| HINDALCO | Interest last year | ₹ 3,858 Cr. |
| HINDALCO | PBT Ann | ₹ 14,012 Cr. |
| HINDALCO | Tax last year | ₹ 3,857 Cr. |
| HINDALCO | PAT Ann | ₹ 10,140 Cr. |
| HINDALCO | Extra Ord Item Ann | ₹ 21.0 Cr. |
| HINDALCO | NP Ann | ₹ 10,155 Cr. |
| HINDALCO | Dividend last year | ₹ 777 Cr. |
| HINDALCO | Raw Material | 62.0 % |
| HINDALCO | Employee cost | ₹ 14,778 Cr. |
| HINDALCO | OPM last year | 11.0 % |
| HINDALCO | NPM last year | 4.70 % |
| HINDALCO | Operating profit | ₹ 23,872 Cr. |
| HINDALCO | Interest | ₹ 3,858 Cr. |
| HINDALCO | Depreciation | ₹ 7,521 Cr. |
| HINDALCO | EPS last year | ₹ 45.2 |
| HINDALCO | EBIT | ₹ 17,849 Cr. |
| HINDALCO | Net profit | ₹ 10,155 Cr. |
| HINDALCO | Current Tax | ₹ 3,005 Cr. |
| HINDALCO | Tax | ₹ 3,857 Cr. |
| HINDALCO | Other income | ₹ 1,519 Cr. |
| HINDALCO | Ann Date | 2,02,403 |
| HINDALCO | Sales Prev Ann | ₹ 2,23,202 Cr. |
| HINDALCO | OP Prev Ann | ₹ 22,666 Cr. |
| HINDALCO | Other Inc Prev Ann | ₹ 1,307 Cr. |
| HINDALCO | EBIDT Prev Ann | ₹ 23,973 Cr. |
| HINDALCO | Dep Prev Ann | ₹ 7,086 Cr. |
| HINDALCO | EBIT preceding year | ₹ 16,887 Cr. |
| HINDALCO | Interest Prev Ann | ₹ 3,646 Cr. |
| HINDALCO | PBT Prev Ann | ₹ 13,241 Cr. |
| HINDALCO | Tax preceding year | ₹ 3,144 Cr. |
| HINDALCO | PAT Prev Ann | ₹ 10,097 Cr. |
| HINDALCO | Extra Ord Prev Ann | ₹ 0.00 Cr. |
| HINDALCO | NP Prev Ann | ₹ 10,097 Cr. |
| HINDALCO | Dividend Prev Ann | ₹ 666 Cr. |
| HINDALCO | OPM preceding year | 10.2 % |
| HINDALCO | NPM preceding year | 4.52 % |
| HINDALCO | EPS preceding year | ₹ 44.9 |
| HINDALCO | Sales Prev 12M | ₹ 2,15,825 Cr. |
| HINDALCO | Profit Prev 12M | ₹ 9,392 Cr. |
| HINDALCO | Med Sales Gwth 10Yrs | 11.7 % |
| HINDALCO | Med Sales Gwth 5Yrs | 11.7 % |
| HINDALCO | Sales growth 7Years | 11.6 % |
| HINDALCO | Sales Var 10Yrs | 9.43 % |
| HINDALCO | EBIDT growth 3Years | 12.1 % |
| HINDALCO | EBIDT growth 5Years | 9.40 % |
| HINDALCO | EBIDT growth 7Years | 9.35 % |
| HINDALCO | EBIDT Var 10Yrs | 11.2 % |
| HINDALCO | EPS growth 3Years | 45.0 % |
| HINDALCO | EPS growth 5Years | 14.3 % |
| HINDALCO | EPS growth 7Years | 26.9 % |
| HINDALCO | EPS growth 10Years | 15.5 % |
| HINDALCO | Profit Var 7Yrs | 26.9 % |
| HINDALCO | Profit Var 10Yrs | 16.5 % |
| HINDALCO | Chg in Prom Hold 3Yr | 0.00 % |
| HINDALCO | Market Cap | ₹ 1,49,945 Cr. |
| HINDALCO | Current Price | ₹ 667 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | OP Qtr | ₹ 6,680 Cr. |
| HINDALCO | Other Inc Qtr | ₹ 362 Cr. |
| HINDALCO | EBIDT Qtr | ₹ 7,042 Cr. |
| HINDALCO | Dep Qtr | ₹ 2,018 Cr. |
| HINDALCO | EBIT latest quarter | ₹ 5,024 Cr. |
| HINDALCO | Interest Qtr | ₹ 888 Cr. |
| HINDALCO | PBT Qtr | ₹ 4,136 Cr. |
| HINDALCO | Tax latest quarter | ₹ 962 Cr. |
| HINDALCO | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| HINDALCO | NP Qtr | ₹ 3,174 Cr. |
| HINDALCO | GPM latest quarter | 32.1 % |
| HINDALCO | OPM latest quarter | 11.9 % |
| HINDALCO | NPM latest quarter | 5.67 % |
| HINDALCO | Eq Cap Qtr | ₹ 222 Cr. |
| HINDALCO | EPS latest quarter | ₹ 14.1 |
| HINDALCO | OP 2Qtr Bk | ₹ 5,612 Cr. |
| HINDALCO | OP 3Qtr Bk | ₹ 5,714 Cr. |
| HINDALCO | Sales 2Qtr Bk | ₹ 54,169 Cr. |
| HINDALCO | Sales 3Qtr Bk | ₹ 52,991 Cr. |
| HINDALCO | NP 2Qtr Bk | ₹ 2,196 Cr. |
| HINDALCO | NP 3Qtr Bk | ₹ 2,454 Cr. |
| HINDALCO | Opert Prft Gwth | 5.32 % |
| HINDALCO | Last result date | 2,02,403 |
| HINDALCO | Exp Qtr Sales Var | -3.12 % |
| HINDALCO | Exp Qtr Sales | ₹ 51,340 Cr. |
| HINDALCO | Exp Qtr OP | ₹ 5,626 Cr. |
| HINDALCO | Exp Qtr NP | ₹ 2,942 Cr. |
| HINDALCO | Exp Qtr EPS | ₹ 13.1 |
| HINDALCO | Sales Prev Qtr | ₹ 52,808 Cr. |
| HINDALCO | OP Prev Qtr | ₹ 5,865 Cr. |
| HINDALCO | Other Inc Prev Qtr | ₹ 281 Cr. |
| HINDALCO | EBIDT Prev Qtr | ₹ 6,146 Cr. |
| HINDALCO | Dep Prev Qtr | ₹ 1,874 Cr. |
| HINDALCO | EBIT Prev Qtr | ₹ 4,272 Cr. |
| HINDALCO | Interest Prev Qtr | ₹ 944 Cr. |
| HINDALCO | PBT Prev Qtr | ₹ 3,328 Cr. |
| HINDALCO | Tax Prev Qtr | ₹ 997 Cr. |
| HINDALCO | PAT Prev Qtr | ₹ 2,331 Cr. |
| HINDALCO | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| HINDALCO | NP Prev Qtr | ₹ 2,331 Cr. |
| HINDALCO | OPM Prev Qtr | 11.1 % |
| HINDALCO | NPM Prev Qtr | 4.41 % |
| HINDALCO | Eq Cap Prev Qtr | ₹ 222 Cr. |
| HINDALCO | EPS Prev Qtr | ₹ 10.4 |
| HINDALCO | Sales PY Qtr | ₹ 55,857 Cr. |
| HINDALCO | OP PY Qtr | ₹ 5,327 Cr. |
| HINDALCO | Other Inc PY Qtr | ₹ 354 Cr. |
| HINDALCO | EBIDT PY Qtr | ₹ 5,681 Cr. |
| HINDALCO | Dep PY Qtr | ₹ 1,856 Cr. |
| HINDALCO | EBIT PY Qtr | ₹ 3,825 Cr. |
| HINDALCO | Interest PY Qtr | ₹ 986 Cr. |
| HINDALCO | PBT PY Qtr | ₹ 2,839 Cr. |
| HINDALCO | Tax PY Qtr | ₹ 428 Cr. |
| HINDALCO | Market Cap | ₹ 1,50,080 Cr. |
| HINDALCO | Current Price | ₹ 668 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | Equity capital | ₹ 222 Cr. |
| HINDALCO | Preference capital | ₹ 0.00 Cr. |
| HINDALCO | Reserves | ₹ 1,05,924 Cr. |
| HINDALCO | Secured loan | ₹ 25,507 Cr. |
| HINDALCO | Unsecured loan | ₹ 34,784 Cr. |
| HINDALCO | Balance sheet total | ₹ 2,31,907 Cr. |
| HINDALCO | Gross block | ₹ 1,82,450 Cr. |
| HINDALCO | Revaluation reserve | ₹ 0.00 Cr. |
| HINDALCO | Accum Dep | ₹ 71,824 Cr. |
| HINDALCO | Net block | ₹ 1,12,034 Cr. |
| HINDALCO | CWIP | ₹ 14,643 Cr. |
| HINDALCO | Investments | ₹ 15,444 Cr. |
| HINDALCO | Current assets | ₹ 82,299 Cr. |
| HINDALCO | Current liabilities | ₹ 59,351 Cr. |
| HINDALCO | BV Unq Invest | ₹ 97.0 Cr. |
| HINDALCO | MV Quoted Inv | ₹ 13,884 Cr. |
| HINDALCO | Cont Liab | ₹ 1,291 Cr. |
| HINDALCO | Total Assets | ₹ 2,31,907 Cr. |
| HINDALCO | Working capital | ₹ 30,478 Cr. |
| HINDALCO | Lease liabilities | ₹ 1,855 Cr. |
| HINDALCO | Inventory | ₹ 40,812 Cr. |
| HINDALCO | Trade receivables | ₹ 16,404 Cr. |
| HINDALCO | Face value | ₹ 1.00 |
| HINDALCO | Cash Equivalents | ₹ 14,437 Cr. |
| HINDALCO | Adv Cust | ₹ 0.00 Cr. |
| HINDALCO | Trade Payables | ₹ 34,444 Cr. |
| HINDALCO | No. Eq. Shares PY | 225 |
| HINDALCO | Debt preceding year | ₹ 60,291 Cr. |
| HINDALCO | Work Cap PY | ₹ 30,363 Cr. |
| HINDALCO | Net Block PY | ₹ 1,10,626 Cr. |
| HINDALCO | Gross Block PY | ₹ 1,82,450 Cr. |
| HINDALCO | CWIP PY | ₹ 7,700 Cr. |
| HINDALCO | Work Cap 3Yr | ₹ 16,047 Cr. |
| HINDALCO | Work Cap 5Yr | ₹ 20,537 Cr. |
| HINDALCO | Work Cap 7Yr | ₹ 10,063 Cr. |
| HINDALCO | Work Cap 10Yr | ₹ 15,474 Cr. |
| HINDALCO | Debt 3Years back | ₹ 67,206 Cr. |
| HINDALCO | Debt 5Years back | ₹ 52,415 Cr. |
| HINDALCO | Debt 7Years back | ₹ 63,817 Cr. |
| HINDALCO | Debt 10Years back | ₹ 64,756 Cr. |
| HINDALCO | Net Block 3Yrs Back | ₹ 1,00,269 Cr. |
| HINDALCO | Net Block 5Yrs Back | ₹ 85,860 Cr. |
| HINDALCO | Net Block 7Yrs Back | ₹ 84,687 Cr. |
| HINDALCO | Market Cap | ₹ 1,50,080 Cr. |
| HINDALCO | Current Price | ₹ 668 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | CF Operations | ₹ 24,056 Cr. |
| HINDALCO | Free Cash Flow | ₹ 8,378 Cr. |
| HINDALCO | CF Investing | ₹ -14,276 Cr. |
| HINDALCO | CF Financing | ₹ -10,817 Cr. |
| HINDALCO | Net CF | ₹ -1,037 Cr. |
| HINDALCO | Cash Beginning | ₹ 12,838 Cr. |
| HINDALCO | Cash End | ₹ 14,437 Cr. |
| HINDALCO | FCF Prev Ann | ₹ 9,466 Cr. |
| HINDALCO | CF Operations PY | ₹ 19,208 Cr. |
| HINDALCO | CF Investing PY | ₹ -7,664 Cr. |
| HINDALCO | CF Financing PY | ₹ -10,345 Cr. |
| HINDALCO | Net CF PY | ₹ 1,199 Cr. |
| HINDALCO | Cash Beginning PY | ₹ 11,639 Cr. |
| HINDALCO | Cash End PY | ₹ 15,368 Cr. |
| HINDALCO | Free Cash Flow 3Yrs | ₹ 29,327 Cr. |
| HINDALCO | Free Cash Flow 5Yrs | ₹ 46,929 Cr. |
| HINDALCO | Free Cash Flow 7Yrs | ₹ 60,880 Cr. |
| HINDALCO | Free Cash Flow 10Yrs | ₹ 79,761 Cr. |
| HINDALCO | CF Opr 3Yrs | ₹ 60,102 Cr. |
| HINDALCO | CF Opr 5Yrs | ₹ 90,079 Cr. |
| HINDALCO | CF Opr 7Yrs | ₹ 1,12,954 Cr. |
| HINDALCO | CF Opr 10Yrs | ₹ 1,44,472 Cr. |
| HINDALCO | CF Inv 10Yrs | ₹ -71,311 Cr. |
| HINDALCO | CF Inv 7Yrs | ₹ -61,343 Cr. |
| HINDALCO | CF Inv 5Yrs | ₹ -61,220 Cr. |
| HINDALCO | CF Inv 3Yrs | ₹ -28,713 Cr. |
| HINDALCO | Cash 3Years back | ₹ 8,809 Cr. |
| HINDALCO | Cash 5Years back | ₹ 9,787 Cr. |
| HINDALCO | Cash 7Years back | ₹ 8,261 Cr. |
| HINDALCO | Market Cap | ₹ 1,50,080 Cr. |
| HINDALCO | Current Price | ₹ 668 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | No. Eq. Shares | 225 |
| HINDALCO | Book value | ₹ 472 |
| HINDALCO | Inven TO | 3.54 |
| HINDALCO | Quick ratio | 0.70 |
| HINDALCO | Exports percentage | 0.00 % |
| HINDALCO | Piotroski score | 6.00 |
| HINDALCO | G Factor | 5.00 |
| HINDALCO | Asset Turnover | 0.95 |
| HINDALCO | Financial leverage | 2.15 |
| HINDALCO | No. of Share Holders | 6,49,551 |
| HINDALCO | Unpledged Prom Hold | 34.6 % |
| HINDALCO | ROIC | 9.08 % |
| HINDALCO | Debtor days | 27.7 |
| HINDALCO | Industry PBV | 2.64 |
| HINDALCO | Credit rating |  |
| HINDALCO | WC Days | 27.1 |
| HINDALCO | Earning Power | 7.70 % |
| HINDALCO | Graham Number | ₹ 693 |
| HINDALCO | Cash Cycle | 45.1 |
| HINDALCO | Days Payable | 93.9 |
| HINDALCO | Days Receivable | 27.7 |
| HINDALCO | Inventory Days | 111 |
| HINDALCO | Public holding | 12.0 % |
| HINDALCO | FII holding | 27.2 % |
| HINDALCO | Chg in FII Hold | 0.36 % |
| HINDALCO | DII holding | 25.4 % |
| HINDALCO | Chg in DII Hold | -0.23 % |
| HINDALCO | B.V. Prev Ann | ₹ 422 |
| HINDALCO | ROCE Prev Yr | 11.3 % |
| HINDALCO | ROA Prev Yr | 4.53 % |
| HINDALCO | ROE Prev Ann | 11.7 % |
| HINDALCO | No. of Share Holders Prev Qtr | 6,41,541 |
| HINDALCO | No. Eq. Shares 10 Yrs | 206 |
| HINDALCO | BV 3yrs back | ₹ 296 |
| HINDALCO | BV 5yrs back | ₹ 260 |
| HINDALCO | BV 10yrs back | ₹ 186 |
| HINDALCO | Inven TO 3Yr | 3.21 |
| HINDALCO | Inven TO 5Yr | 3.50 |
| HINDALCO | Inven TO 7Yr | 3.88 |
| HINDALCO | Inven TO 10Yr | 4.18 |
| HINDALCO | Export 3Yr | 78.1 % |
| HINDALCO | Export 5Yr | 75.6 % |
| HINDALCO | Div 5Yrs | ₹ 644 Cr. |
| HINDALCO | ROCE 3Yr | 13.0 % |
| HINDALCO | ROCE 5Yr | 11.3 % |
| HINDALCO | ROCE 7Yr | 10.9 % |
| HINDALCO | ROCE 10Yr | 9.50 % |
| HINDALCO | ROE 10Yr | 8.78 % |
| HINDALCO | ROE 7Yr | 10.4 % |
| HINDALCO | ROE 5Yr Var | 1.79 % |
| HINDALCO | OPM 5Year | 12.1 % |
| HINDALCO | OPM 10Year | 11.5 % |
| HINDALCO | No. of Share Holders 1Yr | 6,66,489 |
| HINDALCO | Avg Div Payout 3Yrs | 6.91 % |
| HINDALCO | Debtor days 3yrs | 31.2 |
| HINDALCO | Debtor days 3yrs back | 35.8 |
| HINDALCO | Debtor days 5yrs back | 31.8 |
| HINDALCO | ROA 5Yr | 3.95 % |
| HINDALCO | ROA 3Yr | 5.17 % |
| HINDALCO | Market Cap | ₹ 1,50,080 Cr. |
| HINDALCO | Current Price | ₹ 668 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | Avg Vol 1Mth | 56,28,545 |
| HINDALCO | Avg Vol 1Wk | 55,45,438 |
| HINDALCO | Volume | 63,34,239 |
| HINDALCO | High price | ₹ 715 |
| HINDALCO | Low price | ₹ 438 |
| HINDALCO | High price all time | ₹ 715 |
| HINDALCO | Low price all time | ₹ 36.8 |
| HINDALCO | Return over 1day | 3.29 % |
| HINDALCO | Return over 1week | -2.48 % |
| HINDALCO | Return over 1month | -4.17 % |
| HINDALCO | DMA 50 | ₹ 669 |
| HINDALCO | DMA 200 | ₹ 593 |
| HINDALCO | DMA 50 previous day | ₹ 670 |
| HINDALCO | 200 DMA prev. | ₹ 592 |
| HINDALCO | RSI | 35.8 |
| HINDALCO | MACD | -5.85 |
| HINDALCO | MACD Previous Day | -3.74 |
| HINDALCO | MACD Signal | 0.63 |
| HINDALCO | MACD Signal Prev | 2.24 |
| HINDALCO | Avg Vol 1Yr | 72,41,085 |
| HINDALCO | Return over 7years | 17.0 % |
| HINDALCO | Return over 10years | 13.2 % |
| HINDALCO | Market Cap | ₹ 1,50,080 Cr. |
| HINDALCO | Current Price | ₹ 668 |
| HINDALCO | High / Low | ₹ 715 / 438 |
| HINDALCO | Stock P/E | 14.8 |
| HINDALCO | Book Value | ₹ 472 |
| HINDALCO | Dividend Yield | 0.53 % |
| HINDALCO | ROCE | 11.2 % |
| HINDALCO | ROE | 10.1 % |
| HINDALCO | Face Value | ₹ 1.00 |
| HINDALCO | WC to Sales | 14.1 % |
| HINDALCO | QoQ Profits | 36.2 % |
| HINDALCO | QoQ Sales | 6.03 % |
| HINDALCO | Net worth | ₹ 1,06,146 Cr. |
| HINDALCO | Market Cap to Sales | 0.69 |
| HINDALCO | Interest Coverage | 4.63 |
| HINDALCO | EV / EBIT | 10.8 |
| HINDALCO | Debt Capacity | 0.20 |
| HINDALCO | Debt To Profit | 5.55 |
| HINDALCO | Capital Employed | ₹ 1,57,155 Cr. |
| HINDALCO | CROIC | 6.16 % |
| HINDALCO | debtplus | 0.54 |
| HINDALCO | Leverage | ₹ 2.15 |
| HINDALCO | Dividend Payout | 7.65 % |
| HINDALCO | Intrinsic Value | ₹ 728 |
| HINDALCO | CDL | -28.8 % |
| HINDALCO | Cash by market cap | 0.10 |
| HINDALCO | 52w Index | 82.9 % |
| HINDALCO | Down from 52w high | 6.63 % |
| HINDALCO | Up from 52w low | 52.4 % |
| HINDALCO | From 52w high | 0.93 |
| HINDALCO | Mkt Cap To Debt Cap | 0.67 |
| HINDALCO | Dividend Payout | 7.65 % |
| HINDALCO | Graham | ₹ 693 |
| HINDALCO | Price to Cash Flow | 6.24 |
| HINDALCO | ROCE3yr avg | 13.0 % |
| HINDALCO | PB X PE | 20.9 |
| HINDALCO | NCAVPS | ₹ 136 |
| HINDALCO | Mar Cap to CF | 6.24 |
| HINDALCO | Altman Z Score | 3.02 |
| HINDALCO | M.Cap / Qtr Profit | 47.3 |