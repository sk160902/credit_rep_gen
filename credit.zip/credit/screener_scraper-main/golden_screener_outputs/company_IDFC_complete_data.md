# Complete Company Data

## Modal Content
About
[
edit
]
IDFC Limited was incorporated in 1997. It is a Non-Banking Finance Company (NBFC) regulated by the Reserve Bank of India.  It continues to hold investments in IDFC FIRST Bank and IDFC AMC. It held 39.98% in IDFC FIRST Bank and 99.96% in IDFC AMC. IDFC’s holding in IDFC FIRST Bank has further reduced to 36.60% post the QIP issue done by the Bank in April 2021.
[1]
[2]
Key Points
[
edit
]
History
It was operating as an Infrastructure Finance Company, i.e. financing infrastructure projects in sectors like energy, telecommunication, commercial and industrial projects, etc. upto 2015. The Company had received in-principle approval from the RBI to set up a new private sector bank in 2014. Since 2015 the company has been operating as NBFC - Investment Company.
IDFC and IDFC First Bank are two listed entities of IDFC Group and the rest of the businesses are conducted through unlisted entities.
[1]
[2]
Business segments FY21
Financing: 16% vs 42% in FY20
Asset management: 84% vs 57% in FY20
Other: 1%
[3]
IDFC First Bank
IDFC First Bank is a bank focused on both retail assets and retail liabilities. Retail constitutes 65% of funded loan assets.
[2]
[4]
IDFC Asset Management Company
IDFC Mutual Fund crossed INR 1 lakh crore AuM milestone and entered the Top 10 within the industry in terms of total AUM.
The AMC’s Neo Equity PMS, a unique machine-learning driven strategy, had steady index beating performance.
IDFC Mutual Fund expanded its existing product suite by launching the ‘Emerging Businesses Fund’.
The Market Share of IDFC AMC increased to 4% from 3.7% in FY20 on the back of more than par growth in Average AuM of 19%
[5]
[6]
Divesting Non-retail business
Infrastructure Debt Fund:
Entire 81% stake sold to National Investment and Infrastructure Funds in two tranches, the first tranche of 51.5% already sold in FY19 whereas the second tranche of balance 30% sold in FY20
IDFC securities:
The agreement was made to sell the business to Dharmesh Mehta and a group of financial investors.
Post divestment of non-retail businesses, IDFC FHCL will continue to hold 40% in IDFC FIRST Bank and 100% in IDFC AMC.
[7]
Merger
The BoD of the Company had approved the
merger of IDFC Alternatives Limited and IDFC Trustee Company Limited with IDFC Limited, Expected by March 31, 2022,
IDFC Trustee Company Limited is a subsidiary of IDFC Limited. It acted as a Trustee of various funds managed by IDFC Alternatives.
IDFC Alternatives Limited is a subsidiary of IDFC Limited. It had sold its Infrastructure asset management business to Global Infrastructure Partner.
Both IDFC Trustee Company Ltd. and IDFC Alternatives Ltd. have not had any business operations since December 2019.
[8]
[9]
The BoD of the Company approved the
merger of IDFC with IDFC FIRST Bank
on July 03, 2023.
[10]
Branch Network
The Branch Network stands at 464 branches and 356 ATMs.
[11]
Loans Repayment
HDFC loan of INR 200 crore has been fully paid off.
[12]
Investments
The co. has an
investment of INR 7386 Cr.
It has investments in various financial services businesses such as Banking, Asset Management, Investment Banking, Institutional Broking & Research, and Infrastructure Debt Fund. It holds all these investments under IDFC Financial Holding Company Limited.
[13]
[8]
IDFC Institute
IDFC Institute has been set up as an independent, economic development focused think tank to investigate the political, economic and spatial dimensions of India’s ongoing transition from a low-income, state-led country to a prosperous market-based economy. It has worked on urbanization, criminal justice, Data governance network, etc.
[14]
Focus
Co. is divesting all its non-retail businesses.
Focus on diversifying its products and capabilities, enhance customer engagement and invest in digital technologies and infrastructure.
[7]
[5]
Last edited 9 months, 2 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,145 | 8,778 | 9,720 | 8,968 | 10,400 | 628 | 356 | 342 | 34 | 88 | 154 | 66 |
| Expenses + | 844 | 1,141 | 1,777 | 1,490 | 1,806 | 517 | 1,200 | 1,274 | 503 | 25 | 64 | 21 |
| Operating Profit | 7,301 | 7,637 | 7,943 | 7,478 | 8,594 | 112 | -844 | -932 | -469 | 64 | 91 | 44 |
| OPM % | 90% | 87% | 82% | 83% | 83% | 18% | -237% | -273% | -1,364% | 72% | 59% | 68% |
| Other Income + | 3 | 12 | -0 | -2,640 | -3 | 984 | -107 | 31 | 171 | 61 | 4,545 | 1,016 |
| Interest | 4,676 | 5,055 | 5,658 | 5,736 | 6,650 | 1 | 6 | 3 | 10 | 0 | 0 | 7 |
| Depreciation | 34 | 31 | -61 | 62 | 149 | 13 | 14 | 32 | 3 | 0 | 0 | 0 |
| Profit before tax | 2,594 | 2,563 | 2,346 | -959 | 1,791 | 1,082 | -970 | -936 | -311 | 125 | 4,635 | 1,054 |
| Tax % | 29% | 29% | 25% | -38% | 27% | 18% | -15% | 6% | 8% | 48% | 8% | 1% |
| Net Profit + | 1,844 | 1,826 | 1,728 | -657 | 1,240 | 885 | -822 | -996 | -337 | 64 | 4,244 | 1,046 |
| EPS in Rs | 12.12 | 11.89 | 10.72 | -5.86 | 4.38 | 5.44 | -5.26 | -6.23 | -2.10 | 0.40 | 26.52 | 6.53 |
| Dividend Payout % | 21% | 22% | 24% | 0% | 6% | 14% | 0% | -51% | 0% | 249% | 45% | 0% |
| 10 Years: | -39% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -29% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -58% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 62% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 140% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 8% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Millennium City Expressways Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding Equity Investment | 177 | 90 | 218 |  |  |  |  |  |  |
| Advances recoverable - balance outstanding |  | 60 | 386 |  |  |  |  |  |  |
| Loans given | 422 |  |  |  |  |  |  |  |  |
| Purchase / subscription of Investments | 177 | 11 | 24 |  |  |  |  |  |  |
| Interest income | 36 | 6.57 | 39 |  |  |  |  |  |  |
| Interest accrued on loans - balance outstanding | 3.67 |  |  |  |  |  |  |  |  |
| Outstanding other receivables | 0.17 |  |  |  |  |  |  |  |  |
| Galaxy Mercantiles Limited Subsidiary |  |  |  |  |  |  |  |  |  |
| Redemption receipt of OCDs | 261 |  |  |  |  |  |  |  |  |
| Interest income | 14 |  |  |  |  |  |  |  |  |
| Feedback Infra Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Advances recoverable - balance outstanding |  |  | 126 |  |  |  |  |  |  |
| Outstanding Equity Investment | 20 |  | 20 |  |  |  |  |  |  |
| Outstanding Investment in debentures | 40 |  |  |  |  |  |  |  |  |
| Interest income | 6.67 |  | 12 |  |  |  |  |  |  |
| Interest accrued on loans - balance outstanding | 15 |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  |  | 1.96 |  |  |  |  |  |  |
| Dividend | 0.81 |  | 0.60 |  |  |  |  |  |  |
| Fees |  |  | 1.12 |  |  |  |  |  |  |
| Amount received in advance | 0.84 |  |  |  |  |  |  |  |  |
| Interest unrealised |  |  | 0.31 |  |  |  |  |  |  |
| Interest expense |  |  | 0.06 |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.01 |  |  |  |  |  |  |
| IDFC Foundation Subsidiary |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility | 46 | 27 | 10 |  |  |  |  |  |  |
| Advances recoverable - balance outstanding | 21 | 20 | 19 |  |  |  |  |  |  |
| Outstanding Equity Investment |  | 33 | 13 |  |  |  |  |  |  |
| Advances recovered | 0.50 | 1.50 | 0.76 |  |  |  |  |  |  |
| Interest expense |  | 0.03 | 2.62 |  |  |  |  |  |  |
| Shared Service Cost |  | 0.36 | 0.24 |  |  |  |  |  |  |
| Fees paid | 0.44 |  |  |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.13 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.02 |  |  |  |  |  |  |
| Jetpur Somnath Tollways Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding Equity Investment |  |  | 98 |  |  |  |  |  |  |
| Purchase / subscription of Investments |  |  | 8.06 |  |  |  |  |  |  |
| IDFC Foundation Limited Subsidiary |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 30 | 32 |  |  |  |  |  |  |
| Current account balance |  | 5.24 | 0.04 |  |  |  |  |  |  |
| Purchase of fixed assets |  | 0.03 |  |  |  |  |  |  |  |
| Infrastructure Development Corporation (Karnataka) Limited JV |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 7.98 | 9.35 |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.39 | 1.46 | 5.19 |  |  |  |  |  |  |
| Interest expense |  | 0.08 | 0.71 |  |  |  |  |  |  |
| Current account balance |  | 0.37 | 0.01 |  |  |  |  |  |  |
| Fees paid | 0.32 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.07 |  |  |  |  |  |  |
| Rent paid | 0.02 | 0.01 |  |  |  |  |  |  |  |
| Mr. Vikram Limaye Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid | 3.91 | 5.16 | 5.41 |  |  |  |  |  |  |
| 80CCF Bonds outstanding | 0.01 |  |  |  |  |  |  |  |  |
| Dr. Rajiv B. Lall Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  | 4.32 | 4.65 |  |  |  |  |  |  |
| Dr. Rajiv B.Lall Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid | 4.40 |  |  |  |  |  |  |  |  |
| Delhi Integrated Multi-Modal Transit System Limited JV |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 0.11 | 2.12 |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.06 | 0.30 | 0.24 |  |  |  |  |  |  |
| Interest expense |  |  | 0.11 |  |  |  |  |  |  |
| Current account balance |  | 0.08 | 0.01 |  |  |  |  |  |  |
| Fees paid | 0.02 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.01 |  |  |  |  |  |  |
| Uttarakhand Infrastructure Development Company Limited JV |  |  |  |  |  |  |  |  |  |
| Fees paid | 0.18 |  |  |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.15 |  |  |  |  |  |  |  |  |
| Mr. Bharat Mukund Limaye Relative |  |  |  |  |  |  |  |  |  |
| 80CCF Bonds outstanding | 0.01 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,145 | 8,778 | 9,720 | 8,968 | 10,400 | 628 | 356 | 342 | 34 | 88 | 154 | 66 |
| Expenses + | 844 | 1,141 | 1,777 | 1,490 | 1,806 | 517 | 1,200 | 1,274 | 503 | 25 | 64 | 21 |
| Operating Profit | 7,301 | 7,637 | 7,943 | 7,478 | 8,594 | 112 | -844 | -932 | -469 | 64 | 91 | 44 |
| OPM % | 90% | 87% | 82% | 83% | 83% | 18% | -237% | -273% | -1,364% | 72% | 59% | 68% |
| Other Income + | 3 | 12 | -0 | -2,640 | -3 | 984 | -107 | 31 | 171 | 61 | 4,545 | 1,016 |
| Interest | 4,676 | 5,055 | 5,658 | 5,736 | 6,650 | 1 | 6 | 3 | 10 | 0 | 0 | 7 |
| Depreciation | 34 | 31 | -61 | 62 | 149 | 13 | 14 | 32 | 3 | 0 | 0 | 0 |
| Profit before tax | 2,594 | 2,563 | 2,346 | -959 | 1,791 | 1,082 | -970 | -936 | -311 | 125 | 4,635 | 1,054 |
| Tax % | 29% | 29% | 25% | -38% | 27% | 18% | -15% | 6% | 8% | 48% | 8% | 1% |
| Net Profit + | 1,844 | 1,826 | 1,728 | -657 | 1,240 | 885 | -822 | -996 | -337 | 64 | 4,244 | 1,046 |
| EPS in Rs | 12.12 | 11.89 | 10.72 | -5.86 | 4.38 | 5.44 | -5.26 | -6.23 | -2.10 | 0.40 | 26.52 | 6.53 |
| Dividend Payout % | 21% | 22% | 24% | 0% | 6% | 14% | 0% | -51% | 0% | 249% | 45% | 0% |
| 10 Years: | -39% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -29% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -58% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 62% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 140% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 8% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -5,498 | -1,486 | 7,524 | 2,994 | -3,806 | -761 | 3,418 | -1,206 | -102 | 43 | 4,128 | 860 |
| Cash from Investing Activity + | -2,006 | 184 | -17,628 | 8,640 | -20,361 | -713 | 154 | 2,386 | -509 | 204 | -2,356 | -906 |
| Cash from Financing Activity + | 7,589 | 1,432 | 10,010 | -8,891 | 26,382 | 1,183 | -3,729 | -652 | -25 | -3 | -1,900 | 0 |
| Net Cash Flow | 85 | 130 | -94 | 2,743 | 2,215 | -291 | -157 | 528 | -636 | 244 | -129 | -47 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 7 | 27 | 2 | 1 | 2 | 13 | 14 | 19 | 135 | 0 | 0 | 0 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 7 | 27 | 2 | 1 | 2 | 13 | 14 | 19 | 135 | 0 | 0 | 0 |
| Working Capital Days | -331 | -58 | -285 | -28 | 288 | -110 | 591 | 53 | -371 | 3,945 | 84 | 1,186 |
| ROCE % | 11% | 11% | 10% | 9% | 9% | 2% | -5% | -10% | -5% | 0% | -24% | 8% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 24.27% | 23.31% | 21.34% | 20.58% | 21.22% | 21.45% | 20.42% | 21.75% | 20.03% | 19.54% | 20.99% | 20.82% |
| DIIs + | 6.19% | 7.08% | 11.84% | 12.49% | 16.86% | 17.38% | 20.48% | 20.67% | 15.64% | 14.77% | 13.68% | 14.57% |
| Government + | 16.37% | 16.37% | 16.37% | 16.37% | 16.48% | 16.46% | 16.45% | 16.45% | 16.45% | 16.45% | 16.45% | 16.45% |
| Public + | 53.17% | 53.24% | 50.45% | 50.55% | 45.44% | 44.72% | 42.65% | 41.13% | 47.86% | 49.23% | 48.87% | 48.15% |
| No. of Shareholders | 4,42,410 | 4,56,837 | 4,44,385 | 4,56,408 | 4,34,881 | 4,40,169 | 4,61,968 | 4,52,842 | 5,80,405 | 6,40,553 | 6,73,915 | 6,78,676 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 38.39% | 32.08% | 35.19% | 37.27% | 24.80% | 21.34% | 20.42% | 20.99% | 20.82% |
| DIIs + | 22.70% | 19.92% | 16.14% | 9.55% | 7.95% | 11.84% | 20.48% | 13.68% | 14.57% |
| Government + | 16.38% | 16.37% | 16.37% | 16.37% | 16.37% | 16.37% | 16.45% | 16.45% | 16.45% |
| Public + | 22.53% | 31.62% | 32.30% | 36.80% | 50.87% | 50.45% | 42.65% | 48.87% | 48.15% |
| No. of Shareholders | 4,67,702 | 4,35,867 | 4,21,093 | 4,12,684 | 4,48,298 | 4,44,385 | 4,61,968 | 6,73,915 | 6,78,676 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/idfc-ltd/idfc/532659/corp-announcements/)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018
5 Jul - Copy of certificate under Regulation 74(5) for June 30, 2024 issued by KFIN to NSDL and CDSL.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=683089b2-ae05-4a24-9b1a-465010d41f79.pdf)
- [Declaration Of Interim Dividend And Record Date 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bf4c2f57-a7c5-4c4a-8be6-13658c1f80e9.pdf)
- [Board Meeting Outcome for Outcome Of 184Th Board Meeting Of IDFC Limited 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e75cb5b9-b880-4e80-aa9a-5018e0f55c58.pdf)
- [Corporate Action-Board to consider Dividend 1 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a2f6691-7756-4dc8-9b8b-cbe872c7da38.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49849cc0-9092-4eab-9c26-3f9b1136f482.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\a9d9b73a-f59c-470d-9f95-2912a91dc5db.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/75138532659.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/69918532659_15_09_21.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/65400532659_10_09_20.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_IDFC_2011_2012_20062012101256.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/532659/5326590311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_IDFC_2010_2011_04072011150505.zip)

## Credit Ratings
- [Rating update
31 Dec 2018 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=76291)
- [Rating update
3 Nov 2017 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=63941)
- [Rating update
22 Sep 2017 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=62614)
- [Rating update
4 Aug 2016 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=28493)
- [Rating update
1 Feb 2016 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=8397)
- [](https://www.indiaratings.co.in/pressrelease/21820)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d8563013-666f-47a5-9af1-8fc8ced66b08.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b82ef201-6ed4-4bf3-b4fe-7c2705ec683e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8716118d-a91a-4021-9a40-4ab48991b6ce.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2f982562-fd39-44a2-9b43-1eee4292e198.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f73e3a12-31e1-4fe8-bdd1-dd5846f7613e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=89a57984-5286-4649-baad-4f01ccd51e0d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=242f6f4a-76df-4f59-ac4e-ba812cdeceb7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=09121026-5f0f-402f-be0e-7b199f348acc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b554de17-405f-499b-8628-7b19002ef6a6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=96a34f9f-9518-4793-ba6c-84304cab8a92.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c5abbfbf-956a-4568-a8d2-1c4c1ab743ac.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8d5e3add-531d-4fe0-a2de-be793bfb0540.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a7e46e3a-447e-4dbb-b414-0fe53803118f.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_21/Q3/Q3-FY21-IDFC-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2ef30cf4-3853-4859-a46b-4f859c1660f9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fb72bc8d-f53b-433c-9451-6173a843567e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3374b4fc-09e5-4071-a667-e68fd8cd95cb.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q4/Q4-FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fef6322e-2d24-486c-9a94-c5100ca0c716.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ddb99d7a-111d-4998-b853-c466bba87164.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q2/Q2-FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a6986361-9858-43d8-935b-2609aba4ef46.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_20/Q1/IDFC_Q1FY20-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bca5828-7d61-46ce-afcf-66674a26c167.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q4/Q4-FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d93328b8-0024-47ce-8ed6-957795d88d2c.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q3/Q3-FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e426765b-1247-406d-9e5f-3679ae693794.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q2/IDFC_Q2FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d71a4391-a390-44b8-b323-e4ceb79af58f.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_19/Q1/IDFC_Q1FY19-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=032f9a00-b254-45c8-8f3d-5125596d02ae.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=294eac61-90f2-458a-bb7e-7c4e3205fb97.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_18/Q3/Q3-FY18-Concall-Transcript-Earnings.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_18/Q2/IDFC_Q2FY18-Concall-Transcript-Earnings.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=efa5dd32-99aa-4b28-9bab-ba799334e8b3.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q4/Q4-FY17-Concall-Invite.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q3/Transcript-IDFC-Ltd-Q3FY17-Earnings-Call-31Jan2017.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q2/Q2-FY17_IDFC_Concall-Transcript.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_17/Q1/IDFCLimited-Concall-Transcript-IDFC-Ltd-Q1FY17-Earnings.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_16/Q4/IDFC-Limited-Q4FY16-Concall-Transcript-bank.pdf)
- [](https://www.idfc.com/pdf/quarterly_results/FY_16/Q3/IDFC-Limited-Q3FY16-Concall-Transcript.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Bajaj Finance | 6790.70 | 420341.87 | 28.07 | 5.61 | 7.18 | -8.17 | 17.12 | 15.28 | 0.54 | 11.93 | 4.44 | 22.12 | 0.17 | 3.84 | 1.99 | 4.26 | 58566.70 | 70.06 | 14926.26 | 16098.67 | 3911.98 | 28.81 | 13.82 | 242.47 | 293345.83 | 54.70 | 0.01 | 5.81 | 23.88 | 0.00 | 31.26 | 20.88 | 703063.69 | 2.50 | 0.96 | -1.24 | -6.18 | 2.18 | -8.74 | 21.34 | 19.83 | 29.35 | 48.40 | 24.35 | 27.26 | 23.48 | 11.77 | 2.50 | 233.46 | 27.59 | 44.54 | 39.48 | 48.90 | 11.51 | 60.54 |
| 2. | Bajaj Finserv | 1588.95 | 253701.65 | 30.41 | 4.22 | 2.14 | -5.25 | 12.29 | 16.79 | 0.06 | 11.72 | 3.31 | 15.28 | 0.23 | 4.79 | 2.11 | 7.81 | 118581.86 | 36.38 | 8342.86 | 31479.93 | 2137.70 | 35.22 | 10.04 | 52.28 | 288932.62 | 60.65 | -0.04 | 8.00 | 23.88 | 0.01 | 32.55 | 18.33 | 530247.61 | 0.25 | 1.49 | -1.59 | -3.57 | 4.42 | -2.64 | 14.19 | 13.77 | 20.42 | 22.15 | 20.97 | 22.13 | 14.81 | 11.28 | 0.25 | 51.07 | 20.36 | 38.57 | 40.05 | 36.56 | 19.75 | 159.28 |
| 3. | Jio Financial | 331.90 | 210865.48 | 133.01 | 1.50 | 113.52 |  | 102.49 |  | 0.00 | 1.55 | 1.24 | 1.27 | 0.01 | 0.00 |  | 0.93 | 1857.57 | 82.17 | 1585.26 | 417.82 | 312.63 | 0.89 | -5.81 | 2.50 | 0.00 | 47.12 | 0.00 | 0.97 | 23.88 | 0.00 | 4034.43 | 6282.46 | 199905.71 | 98.41 |  | -13.77 | 37.25 |  |  |  |  |  |  |  |  |  |  | 98.41 | 2.53 |  | 140.40 | 140.40 | 140.40 | 2.75 |  |
| 4. | Cholaman.Inv.&Fn | 1428.00 | 119986.35 | 35.03 | 6.15 | 6.26 | -5.16 | 17.82 | 40.91 | 0.15 | 10.41 | 2.53 | 20.16 | 0.14 | 6.86 | 1.50 | 6.90 | 19163.44 | 71.90 | 3420.82 | 5427.56 | 1065.23 | 45.08 | 24.56 | 40.72 | 134474.88 | 50.33 | -0.02 | 5.66 | 23.88 | 0.00 | 48.73 | 28.34 | 250067.50 | 2.27 | 1.50 | 16.38 | 9.56 | 41.28 | 20.04 | 20.24 | 19.03 | 23.38 | 31.01 | 21.94 | 25.99 | 20.41 | 9.72 | 2.27 | 40.72 | 21.62 | 27.29 | 30.33 | 25.19 | 4.08 | 82.19 |
| 5. | Shriram Finance | 2935.00 | 110335.82 | 14.99 | 2.26 | 3.03 | -5.70 | 11.27 | 23.01 | 1.55 | 11.27 | 3.22 | 15.93 | 0.16 | 3.99 | 1.64 | 4.69 | 36388.26 | 71.76 | 7365.56 | 9904.30 | 2008.80 | 24.33 | 56.30 | 196.02 | 195496.08 | 25.41 | -0.01 | 8.96 | 23.88 | 0.00 | 19.34 | 22.52 | 294659.10 | 4.30 | 0.64 | 7.22 | 16.12 | 25.18 | 47.88 | 15.34 | 14.87 | 23.38 | 43.37 | 18.56 | 27.83 | 17.27 | 12.15 | 4.30 | 196.02 | 14.00 | 10.85 | 11.66 | 11.77 | 0.52 | 37.44 |
| 6. | Bajaj Holdings | 9440.75 | 105066.12 | 14.06 | 1.92 | 62.60 | 59.76 | 13.62 | 22.69 | 1.39 | 13.07 | 12.45 | 14.77 | 0.01 | 0.00 | 3858.65 | 1.09 | 1678.38 | 90.15 | 7462.17 | 133.76 | 1610.46 | 28.53 | 13.77 | 670.49 | 62.57 | 51.46 | 0.00 | 7.33 | 23.88 | 0.00 | 252.03 | 40.88 | 105074.73 | 2.05 | 0.74 | 15.51 | 14.83 | 34.09 | 24.63 | 12.18 | 11.85 | 18.98 | 25.81 | 6.50 | 8.93 | 11.15 | 9.71 | 2.01 | 652.98 | 18.98 | 13.53 | 14.81 | 12.70 | 1.09 | 11.13 |
| 7. | HDFC AMC | 4117.25 | 87935.71 | 42.41 | 12.42 | 31.57 | 66.28 | 32.31 | 13.08 | 1.69 | 37.72 | 27.61 | 29.51 | 0.45 | 0.00 | 294.52 | 1.00 | 2785.07 | 76.40 | 2072.35 | 775.24 | 603.98 | 34.93 | 26.49 | 97.06 | 0.00 | 52.52 | -0.03 | 3.08 | 23.88 | 0.00 | 25.47 | 30.56 | 87924.54 | 0.59 | 2.67 | 9.17 | 18.37 | 12.32 | 65.88 | 27.11 | 28.81 | 15.89 | 13.65 | 8.77 | 12.92 | 24.47 | 32.31 | 0.59 | 91.15 | 15.79 | 40.70 | 34.65 | 40.92 | 10.78 | 21.34 |
| 8. | I D F C | 112.45 | 17991.83 | 17.24 | 1.32 | 274.52 | 10.61 | 16.73 | 26.22 | 0.92 | 8.49 | 8.33 | 8.37 | 0.01 | 0.00 | 145.91 | 0.94 | 65.54 | 67.88 | 1045.58 | 9.77 | 347.85 | -81.43 | 454.55 | 6.53 | 0.00 | 0.00 | 0.00 | 6.02 | 23.88 | 0.00 | -57.51 | 140.28 | 17750.46 | 48.28 | 0.56 | -12.28 | -3.77 | 24.82 | -1.69 | -4.99 | -6.17 | 30.77 | 62.27 | -28.69 | 24.02 | -25.30 | -24.42 | 48.28 | 6.53 | 30.75 | 23.02 | 24.02 | 16.30 | 0.00 | 160.00 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | Sales | ₹ 65.5 Cr. |
| IDFC | OPM | 67.9 % |
| IDFC | Profit after tax | ₹ 1,046 Cr. |
| IDFC | Mar Cap | ₹ 17,992 Cr. |
| IDFC | Sales Qtr | ₹ 9.77 Cr. |
| IDFC | PAT Qtr | ₹ 348 Cr. |
| IDFC | Qtr Sales Var | -81.4 % |
| IDFC | Qtr Profit Var | 455 % |
| IDFC | Price to Earning | 17.2 |
| IDFC | Dividend yield | 0.92 % |
| IDFC | Price to book value | 1.32 |
| IDFC | ROCE | 8.49 % |
| IDFC | Return on assets | 8.33 % |
| IDFC | Debt to equity | 0.00 |
| IDFC | Return on equity | 8.37 % |
| IDFC | EPS | ₹ 6.53 |
| IDFC | Debt | ₹ 0.00 Cr. |
| IDFC | Promoter holding | 0.00 % |
| IDFC | Change in Prom Hold | 0.00 % |
| IDFC | Earnings yield | 6.02 % |
| IDFC | Pledged percentage | 0.00 % |
| IDFC | Industry PE | 23.9 |
| IDFC | Sales growth | -57.5 % |
| IDFC | Profit growth | 140 % |
| IDFC | Current Price | ₹ 112 |
| IDFC | Price to Sales | 275 |
| IDFC | CMP / FCF | 10.6 |
| IDFC | EVEBITDA | 16.7 |
| IDFC | Enterprise Value | ₹ 17,750 Cr. |
| IDFC | Current ratio | 48.3 |
| IDFC | Int Coverage | 146 |
| IDFC | PEG Ratio | 0.56 |
| IDFC | Return over 3months | -12.3 % |
| IDFC | Return over 6months | -3.77 % |
| IDFC | No. Eq. Shares | 160 |
| IDFC | Sales growth 3Years | 24.0 % |
| IDFC | Sales growth 5Years | -28.7 % |
| IDFC | Profit Var 3Yrs | 62.3 % |
| IDFC | Profit Var 5Yrs | 30.8 % |
| IDFC | ROE 5Yr | -6.17 % |
| IDFC | ROE 3Yr | -4.99 % |
| IDFC | Return over 1year | -1.69 % |
| IDFC | Return over 3years | 24.8 % |
| IDFC | Return over 5years | 26.2 % |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | Sales last year | ₹ 65.5 Cr. |
| IDFC | OP Ann | ₹ 44.5 Cr. |
| IDFC | Other Inc Ann | ₹ 1,016 Cr. |
| IDFC | EBIDT last year | ₹ 1,061 Cr. |
| IDFC | Dep Ann | ₹ 0.04 Cr. |
| IDFC | EBIT last year | ₹ 1,061 Cr. |
| IDFC | Interest last year | ₹ 7.27 Cr. |
| IDFC | PBT Ann | ₹ 1,054 Cr. |
| IDFC | Tax last year | ₹ 7.95 Cr. |
| IDFC | PAT Ann | ₹ 1,046 Cr. |
| IDFC | Extra Ord Item Ann | ₹ 0.00 Cr. |
| IDFC | NP Ann | ₹ 1,046 Cr. |
| IDFC | Dividend last year | ₹ 0.00 Cr. |
| IDFC | Raw Material | 0.00 % |
| IDFC | Employee cost | ₹ 7.07 Cr. |
| IDFC | OPM last year | 67.9 % |
| IDFC | NPM last year | 1,595 % |
| IDFC | Operating profit | ₹ 44.5 Cr. |
| IDFC | Interest | ₹ 7.27 Cr. |
| IDFC | Depreciation | ₹ 0.04 Cr. |
| IDFC | EPS last year | ₹ 6.53 |
| IDFC | EBIT | ₹ 1,061 Cr. |
| IDFC | Net profit | ₹ 1,046 Cr. |
| IDFC | Current Tax | ₹ 5.80 Cr. |
| IDFC | Tax | ₹ 7.95 Cr. |
| IDFC | Other income | ₹ 1,016 Cr. |
| IDFC | Ann Date | 2,02,403 |
| IDFC | Sales Prev Ann | ₹ 154 Cr. |
| IDFC | OP Prev Ann | ₹ 90.6 Cr. |
| IDFC | Other Inc Prev Ann | ₹ 4,545 Cr. |
| IDFC | EBIDT Prev Ann | ₹ -2,506 Cr. |
| IDFC | Dep Prev Ann | ₹ 0.08 Cr. |
| IDFC | EBIT preceding year | ₹ -2,506 Cr. |
| IDFC | Interest Prev Ann | ₹ 0.00 Cr. |
| IDFC | PBT Prev Ann | ₹ 4,635 Cr. |
| IDFC | Tax preceding year | ₹ 391 Cr. |
| IDFC | PAT Prev Ann | ₹ -2,596 Cr. |
| IDFC | Extra Ord Prev Ann | ₹ 7,141 Cr. |
| IDFC | NP Prev Ann | ₹ 4,244 Cr. |
| IDFC | Dividend Prev Ann | ₹ 1,920 Cr. |
| IDFC | OPM preceding year | 58.8 % |
| IDFC | NPM preceding year | -1,683 % |
| IDFC | EPS preceding year | ₹ 26.5 |
| IDFC | Sales Prev 12M | ₹ 108 Cr. |
| IDFC | Profit Prev 12M | ₹ 4,085 Cr. |
| IDFC | Med Sales Gwth 10Yrs | -7.74 % |
| IDFC | Med Sales Gwth 5Yrs | -3.79 % |
| IDFC | Sales growth 7Years | -51.5 % |
| IDFC | Sales Var 10Yrs | -38.7 % |
| IDFC | EBIDT growth 3Years | 65.3 % |
| IDFC | EBIDT growth 5Years | 28.9 % |
| IDFC | EBIDT growth 7Years | -25.8 % |
| IDFC | EBIDT Var 10Yrs | -17.9 % |
| IDFC | EPS growth 3Years | 62.2 % |
| IDFC | EPS growth 5Years | 30.8 % |
| IDFC | EPS growth 7Years | 5.84 % |
| IDFC | EPS growth 10Years | -5.77 % |
| IDFC | Profit Var 7Yrs | 5.87 % |
| IDFC | Profit Var 10Yrs | -5.27 % |
| IDFC | Chg in Prom Hold 3Yr | 0.00 % |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | OP Qtr | ₹ 7.15 Cr. |
| IDFC | Other Inc Qtr | ₹ 344 Cr. |
| IDFC | EBIDT Qtr | ₹ 351 Cr. |
| IDFC | Dep Qtr | ₹ 0.01 Cr. |
| IDFC | EBIT latest quarter | ₹ 351 Cr. |
| IDFC | Interest Qtr | ₹ 0.00 Cr. |
| IDFC | PBT Qtr | ₹ 351 Cr. |
| IDFC | Tax latest quarter | ₹ 2.81 Cr. |
| IDFC | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| IDFC | NP Qtr | ₹ 348 Cr. |
| IDFC | GPM latest quarter | 100 % |
| IDFC | OPM latest quarter | 73.2 % |
| IDFC | NPM latest quarter | 3,560 % |
| IDFC | Eq Cap Qtr | ₹ 1,600 Cr. |
| IDFC | EPS latest quarter | ₹ 2.17 |
| IDFC | OP 2Qtr Bk | ₹ 30.6 Cr. |
| IDFC | OP 3Qtr Bk | ₹ 19.4 Cr. |
| IDFC | Sales 2Qtr Bk | ₹ 36.7 Cr. |
| IDFC | Sales 3Qtr Bk | ₹ 26.8 Cr. |
| IDFC | NP 2Qtr Bk | ₹ 224 Cr. |
| IDFC | NP 3Qtr Bk | ₹ 264 Cr. |
| IDFC | Opert Prft Gwth | -50.9 % |
| IDFC | Last result date | 2,02,403 |
| IDFC | Exp Qtr Sales Var | -3.34 % |
| IDFC | Exp Qtr Sales | ₹ 25.9 Cr. |
| IDFC | Exp Qtr OP | ₹ Cr. |
| IDFC | Exp Qtr NP | ₹ Cr. |
| IDFC | Exp Qtr EPS | ₹ |
| IDFC | Sales Prev Qtr | ₹ -7.65 Cr. |
| IDFC | OP Prev Qtr | ₹ -12.7 Cr. |
| IDFC | Other Inc Prev Qtr | ₹ 218 Cr. |
| IDFC | EBIDT Prev Qtr | ₹ 205 Cr. |
| IDFC | Dep Prev Qtr | ₹ 0.01 Cr. |
| IDFC | EBIT Prev Qtr | ₹ 205 Cr. |
| IDFC | Interest Prev Qtr | ₹ 0.00 Cr. |
| IDFC | PBT Prev Qtr | ₹ 205 Cr. |
| IDFC | Tax Prev Qtr | ₹ -5.22 Cr. |
| IDFC | PAT Prev Qtr | ₹ 210 Cr. |
| IDFC | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| IDFC | NP Prev Qtr | ₹ 210 Cr. |
| IDFC | OPM Prev Qtr | % |
| IDFC | NPM Prev Qtr | % |
| IDFC | Eq Cap Prev Qtr | ₹ 1,600 Cr. |
| IDFC | EPS Prev Qtr | ₹ 1.31 |
| IDFC | Sales PY Qtr | ₹ 52.6 Cr. |
| IDFC | OP PY Qtr | ₹ 3.86 Cr. |
| IDFC | Other Inc PY Qtr | ₹ 3,754 Cr. |
| IDFC | EBIDT PY Qtr | ₹ 272 Cr. |
| IDFC | Dep PY Qtr | ₹ 0.01 Cr. |
| IDFC | EBIT PY Qtr | ₹ 272 Cr. |
| IDFC | Interest PY Qtr | ₹ 0.00 Cr. |
| IDFC | PBT PY Qtr | ₹ 3,758 Cr. |
| IDFC | Tax PY Qtr | ₹ 371 Cr. |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | Equity capital | ₹ 1,600 Cr. |
| IDFC | Preference capital | ₹ 0.00 Cr. |
| IDFC | Reserves | ₹ 11,781 Cr. |
| IDFC | Secured loan | ₹ 0.00 Cr. |
| IDFC | Unsecured loan | ₹ 0.00 Cr. |
| IDFC | Balance sheet total | ₹ 13,429 Cr. |
| IDFC | Gross block | ₹ 0.31 Cr. |
| IDFC | Revaluation reserve | ₹ 0.00 Cr. |
| IDFC | Accum Dep | ₹ 0.24 Cr. |
| IDFC | Net block | ₹ 0.05 Cr. |
| IDFC | CWIP | ₹ 0.00 Cr. |
| IDFC | Investments | ₹ 12,964 Cr. |
| IDFC | Current assets | ₹ 464 Cr. |
| IDFC | Current liabilities | ₹ 9.61 Cr. |
| IDFC | BV Unq Invest | ₹ 11,221 Cr. |
| IDFC | MV Quoted Inv | ₹ 0.00 Cr. |
| IDFC | Cont Liab | ₹ 248 Cr. |
| IDFC | Total Assets | ₹ 13,429 Cr. |
| IDFC | Working capital | ₹ 454 Cr. |
| IDFC | Lease liabilities | ₹ 0.00 Cr. |
| IDFC | Inventory | ₹ 0.00 Cr. |
| IDFC | Trade receivables | ₹ 0.00 Cr. |
| IDFC | Face value | ₹ 10.0 |
| IDFC | Cash Equivalents | ₹ 241 Cr. |
| IDFC | Adv Cust | ₹ 0.00 Cr. |
| IDFC | Trade Payables | ₹ 0.00 Cr. |
| IDFC | No. Eq. Shares PY | 160 |
| IDFC | Debt preceding year | ₹ 0.00 Cr. |
| IDFC | Work Cap PY | ₹ 413 Cr. |
| IDFC | Net Block PY | ₹ 0.07 Cr. |
| IDFC | Gross Block PY | ₹ 0.31 Cr. |
| IDFC | CWIP PY | ₹ 0.00 Cr. |
| IDFC | Work Cap 3Yr | ₹ 30.6 Cr. |
| IDFC | Work Cap 5Yr | ₹ 840 Cr. |
| IDFC | Work Cap 7Yr | ₹ 13,477 Cr. |
| IDFC | Work Cap 10Yr | ₹ -1,002 Cr. |
| IDFC | Debt 3Years back | ₹ 37.5 Cr. |
| IDFC | Debt 5Years back | ₹ 0.00 Cr. |
| IDFC | Debt 7Years back | ₹ 92,153 Cr. |
| IDFC | Debt 10Years back | ₹ 56,565 Cr. |
| IDFC | Net Block 3Yrs Back | ₹ 834 Cr. |
| IDFC | Net Block 5Yrs Back | ₹ 885 Cr. |
| IDFC | Net Block 7Yrs Back | ₹ 2,202 Cr. |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | CF Operations | ₹ 860 Cr. |
| IDFC | Free Cash Flow | ₹ 860 Cr. |
| IDFC | CF Investing | ₹ -906 Cr. |
| IDFC | CF Financing | ₹ 0.00 Cr. |
| IDFC | Net CF | ₹ -46.6 Cr. |
| IDFC | Cash Beginning | ₹ 158 Cr. |
| IDFC | Cash End | ₹ 241 Cr. |
| IDFC | FCF Prev Ann | ₹ 4,128 Cr. |
| IDFC | CF Operations PY | ₹ 4,128 Cr. |
| IDFC | CF Investing PY | ₹ -2,356 Cr. |
| IDFC | CF Financing PY | ₹ -1,900 Cr. |
| IDFC | Net CF PY | ₹ -129 Cr. |
| IDFC | Cash Beginning PY | ₹ 286 Cr. |
| IDFC | Cash End PY | ₹ 377 Cr. |
| IDFC | Free Cash Flow 3Yrs | ₹ 5,086 Cr. |
| IDFC | Free Cash Flow 5Yrs | ₹ 3,822 Cr. |
| IDFC | Free Cash Flow 7Yrs | ₹ 6,473 Cr. |
| IDFC | Free Cash Flow 10Yrs | ₹ 12,431 Cr. |
| IDFC | CF Opr 3Yrs | ₹ 5,031 Cr. |
| IDFC | CF Opr 5Yrs | ₹ 3,723 Cr. |
| IDFC | CF Opr 7Yrs | ₹ 6,380 Cr. |
| IDFC | CF Opr 10Yrs | ₹ 13,092 Cr. |
| IDFC | CF Inv 10Yrs | ₹ -31,090 Cr. |
| IDFC | CF Inv 7Yrs | ₹ -1,741 Cr. |
| IDFC | CF Inv 5Yrs | ₹ -1,182 Cr. |
| IDFC | CF Inv 3Yrs | ₹ -3,059 Cr. |
| IDFC | Cash 3Years back | ₹ 65.5 Cr. |
| IDFC | Cash 5Years back | ₹ 264 Cr. |
| IDFC | Cash 7Years back | ₹ 5,282 Cr. |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | No. Eq. Shares | 160 |
| IDFC | Book value | ₹ 83.6 |
| IDFC | Inven TO |  |
| IDFC | Quick ratio | 48.3 |
| IDFC | Exports percentage | 0.00 % |
| IDFC | Piotroski score | 7.00 |
| IDFC | G Factor | 4.00 |
| IDFC | Asset Turnover | 0.01 |
| IDFC | Financial leverage | 0.94 |
| IDFC | No. of Share Holders | 6,78,676 |
| IDFC | Unpledged Prom Hold | 0.00 % |
| IDFC | ROIC | 232 % |
| IDFC | Debtor days | 0.00 |
| IDFC | Industry PBV | 1.79 |
| IDFC | Credit rating |  |
| IDFC | WC Days | 1,186 |
| IDFC | Earning Power | 7.90 % |
| IDFC | Graham Number | ₹ 111 |
| IDFC | Cash Cycle | 0.00 |
| IDFC | Days Payable |  |
| IDFC | Days Receivable | 0.00 |
| IDFC | Inventory Days |  |
| IDFC | Public holding | 48.2 % |
| IDFC | FII holding | 20.8 % |
| IDFC | Chg in FII Hold | -0.17 % |
| IDFC | DII holding | 14.6 % |
| IDFC | Chg in DII Hold | 0.89 % |
| IDFC | B.V. Prev Ann | ₹ 72.5 |
| IDFC | ROCE Prev Yr | -24.4 % |
| IDFC | ROA Prev Yr | -24.9 % |
| IDFC | ROE Prev Ann | -25.3 % |
| IDFC | No. of Share Holders Prev Qtr | 6,73,915 |
| IDFC | No. Eq. Shares 10 Yrs | 159 |
| IDFC | BV 3yrs back | ₹ 51.5 |
| IDFC | BV 5yrs back | ₹ 52.1 |
| IDFC | BV 10yrs back | ₹ 108 |
| IDFC | Inven TO 3Yr |  |
| IDFC | Inven TO 5Yr |  |
| IDFC | Inven TO 7Yr |  |
| IDFC | Inven TO 10Yr |  |
| IDFC | Export 3Yr | 0.00 % |
| IDFC | Export 5Yr | 0.00 % |
| IDFC | Div 5Yrs | ₹ 516 Cr. |
| IDFC | ROCE 3Yr | -5.22 % |
| IDFC | ROCE 5Yr | -6.15 % |
| IDFC | ROCE 7Yr | -4.95 % |
| IDFC | ROCE 10Yr | -0.66 % |
| IDFC | ROE 10Yr | 0.84 % |
| IDFC | ROE 7Yr | -3.96 % |
| IDFC | ROE 5Yr Var | 29.1 % |
| IDFC | OPM 5Year | -176 % |
| IDFC | OPM 10Year | 71.8 % |
| IDFC | No. of Share Holders 1Yr | 4,52,842 |
| IDFC | Avg Div Payout 3Yrs | 98.2 % |
| IDFC | Debtor days 3yrs | 0.00 |
| IDFC | Debtor days 3yrs back | 135 |
| IDFC | Debtor days 5yrs back | 14.0 |
| IDFC | ROA 5Yr | -6.52 % |
| IDFC | ROA 3Yr | -5.57 % |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | Avg Vol 1Mth | 53,10,619 |
| IDFC | Avg Vol 1Wk | 52,62,570 |
| IDFC | Volume | 57,19,304 |
| IDFC | High price | ₹ 137 |
| IDFC | Low price | ₹ 105 |
| IDFC | High price all time | ₹ 137 |
| IDFC | Low price all time | ₹ 13.2 |
| IDFC | Return over 1day | 0.73 % |
| IDFC | Return over 1week | -1.60 % |
| IDFC | Return over 1month | -8.65 % |
| IDFC | DMA 50 | ₹ 117 |
| IDFC | DMA 200 | ₹ 116 |
| IDFC | DMA 50 previous day | ₹ 117 |
| IDFC | 200 DMA prev. | ₹ 116 |
| IDFC | RSI | 35.4 |
| IDFC | MACD | -1.41 |
| IDFC | MACD Previous Day | -1.15 |
| IDFC | MACD Signal | -0.58 |
| IDFC | MACD Signal Prev | -0.37 |
| IDFC | Avg Vol 1Yr | 71,79,562 |
| IDFC | Return over 7years | 9.39 % |
| IDFC | Return over 10years | 4.29 % |
| IDFC | Market Cap | ₹ 17,992 Cr. |
| IDFC | Current Price | ₹ 112 |
| IDFC | High / Low | ₹ 137 / 105 |
| IDFC | Stock P/E | 17.2 |
| IDFC | Book Value | ₹ 83.6 |
| IDFC | Dividend Yield | 0.92 % |
| IDFC | ROCE | 8.49 % |
| IDFC | ROE | 8.37 % |
| IDFC | Face Value | ₹ 10.0 |
| IDFC | WC to Sales | 693 % |
| IDFC | QoQ Profits | 65.6 % |
| IDFC | QoQ Sales | -228 % |
| IDFC | Net worth | ₹ 13,381 Cr. |
| IDFC | Market Cap to Sales | 275 |
| IDFC | Interest Coverage | 146 |
| IDFC | EV / EBIT | 16.7 |
| IDFC | Debt Capacity | 0.86 |
| IDFC | Debt To Profit | 0.00 |
| IDFC | Capital Employed | ₹ 454 Cr. |
| IDFC | CROIC | 13.6 % |
| IDFC | debtplus | 0.02 |
| IDFC | Leverage | ₹ 0.94 |
| IDFC | Dividend Payout | 0.00 % |
| IDFC | Intrinsic Value | ₹ 66.1 |
| IDFC | CDL | -0.04 % |
| IDFC | Cash by market cap | 0.02 |
| IDFC | 52w Index | 23.3 % |
| IDFC | Down from 52w high | 17.9 % |
| IDFC | Up from 52w low | 7.10 % |
| IDFC | From 52w high | 0.82 |
| IDFC | Mkt Cap To Debt Cap | 1.93 |
| IDFC | Dividend Payout | 0.00 % |
| IDFC | Graham | ₹ 111 |
| IDFC | Price to Cash Flow | 20.9 |
| IDFC | ROCE3yr avg | -5.22 % |
| IDFC | PB X PE | 22.8 |
| IDFC | NCAVPS | ₹ 2.84 |
| IDFC | Mar Cap to CF | 20.9 |
| IDFC | Altman Z Score | 3.84 |
| IDFC | M.Cap / Qtr Profit | 51.7 |