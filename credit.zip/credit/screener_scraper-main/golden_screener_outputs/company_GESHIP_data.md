About
[
edit
]
Great Eastern Shipping Company Ltd, along with its subsidiaries is a major player in the Indian shipping and Oil drilling services industry.
[1]
Key Points
[
edit
]
Overview
[1]
GE Shipping was founded in 1948 with the purchase of a Liberty ship. As of FY24, GES is India’s largest private sector shipping company, owning and operating 43 ships and 23 offshore assets.
Business Segment
Shipping Business:
The shipping business is involved in the transportation of crude oil, petroleum products, gas, and dry bulk commodities.
Offshore Business:
The company is involved in the offshore services business through its wholly-owned subsidiary
Greatship India Ltd.
It provides offshore oilfield services with the principal activity of owning and/or operating offshore supply vessels and mobile offshore drilling rigs.
[2]
Segment-Wise Revenue Split
Shipping: ~81% in FY22 vs ~81% in FY21
Offshore: ~19% in FY22 vs ~19% in FY21
[3]
Geography Wise Revenue Split
India: 44% in FY22 vs 50% in FY21
Outside India: 56% in FY22 vs 50% in FY21
[3]
Fleet Profile FY24
[4]
Company has a total fleet of 43 vessels.
Shipping Business -
A Tankers - (i) Crude (6), Products (19) and LPG (4)
B Dry Bulk (14)
Offshore Business (through WOS Greatship (India) Limited)-
C Logistics (19)
D Drilling (4)
Order Book as % of Fleet FY22
Presently, the company has one of the lowest order book-to-fleet ratios in its business.
Bulkers: 7.4%
Product Tankers: 4.8%
Crude Tankers: 3.6%
[5]
Jackup Rigs: 4.1%
Platform Supply vessels and anchor handling tugs: 3%
[6]
Strong Cash Flows
[7]
Company moved from Debt of USD 360 mn in FY19 to cash positive of USD 300 mn in 9MFY24.
New Vessel
[8]
In April,24, Company took delivery of 2010 built Medium Range product tanker “Jag Priya” of about 49,999 dwt. The Company had contracted to buy the vessel in Q4 FY24.
Sale of a vessel
[9]
In April,24, they contracted to sell its 2004 Medium Range Product Tanker, Jag Pahel of about 46,319 dwt to an unaffiliated third party.
NCDs
In Q3FY24, company raised ~Rs. 2150 crs. through NCDs.  Funds raised through NCDs have been swapped into USD using INR-FCY swaps, thus creating synthetic fixed rate USD loans.
[10]
Last edited 3 months ago
Request an update
© Protected by Copyright
