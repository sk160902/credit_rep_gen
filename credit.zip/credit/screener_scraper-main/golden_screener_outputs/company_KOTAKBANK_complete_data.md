# Complete Company Data

## Modal Content
About
[
edit
]
Kotak Mahindra Bank is a diversified financial services group providing a wide range of banking and financial services including Retail Banking, Treasury and Corporate Banking, Investment Banking, Stock Broking, Vehicle Finance, Advisory services, Asset Management, Life Insurance and General Insurance.
[1]
Key Points
[
edit
]
Market Share
The company ranks
4th
in both deposit and gross advances market share. Its securities broking business held an
11.8% market share
in FY24, while the asset management business had a
6.5% market share.
[1]
Business Segments FY24
1) Insurance (~28%):
Offers Life insurance and General Insurance services. It has recorded a gross written premium of Rs 17,708 Cr in FY24 vs Rs 15,320 Cr in FY23.
[2]
2) Retail Banking (27%):
Offers Digital Banking, retail lending, deposit taking, etc.
3) Corporate & Wholesale Banking (22%):
Wholesale borrowings and lending and other related services to the corporate sector.
4) Treasury (~11%):
Engaged in the Money market, forex market, derivatives, investments,
and dealerships of government securities, etc.
5) Vehicle Financing (3%):
Offers loans for vehicle finance and wholesale trade finance to auto dealers through subsidiary Kotak Mahindra Prime Ltd.
6) Broking (3%):
Offers broking and distribution of financial products from subsidiary Kotak Securities Ltd. It has 1196 branches & franchises.
[3]
7) Asset Management (2%):
Bank manages funds and investments on behalf of clients and investment distribution through subsidiary KM Asset Management Company Ltd. Overall AUM as of FY24 stood at Rs. 3,46,589 Cr vs Rs. 2,87,058 Cr as of FY23. Domestic equity and debt account for 44% and 24% share in AUM for FY24 and alternative assets account for 8% of AUM.
[4]
[5]
8) Advisory and Other lendings (4%):
Financial advisory and transactional services such as M&A, advice, equity/ debt issue management services, etc, Securitisation, and other loan services.
[6]
[7]
[8]
Key Ratios
Capital Adequacy Ratio - ~20% in FY24 vs 22.7% in FY22
NIM - ~5.3% in FY24% vs 4.6% in FY22
Gross NPA - 1.39% in FY24 vs 2.34% in FY22
Net NPA - 0.3% in FY24 vs 0.6% in FY22
CASA Ratio - 45.5% in FY24 vs 60.7% in FY22
[9]
[10]
[11]
Branch Network
As of FY24, the bank operates 1,900+ branches, 3,200+ ATMs, and 11 currency chests in India vs ~1,700 branches and ~2,700 ATMs in FY23.
[12]
West: 31%
North: 31%
South: 30%
East: 8%
[13]
International Presence
It has a global presence through its subsidiaries in the UK, USA, Gulf Region, Singapore, and Mauritius. It opened its first international branch in 2019 in Dubai.
[14]
[15]
Customer Base
As of FY24, the bank has a customer base of 5 Cr customers vs 3.27 Cr customers in FY22.
[16]
[17]
Loan Book
As of FY24, total advances stood at Rs. ~3,91,000 Cr vs Rs. ~2,71,000 Cr in FY22.
Advances Mix:
Consumer: 45%
Commercial: 23%
Corporate Banking: 22%
SME: 7%
Others: 2%
[18]
[19]
Deposits
As of FY24, total deposits stood at Rs. ~4,49,000 Cr vs Rs. 2,88,000 Cr in FY22.
[20]
[17]
Divestment
The company has sold a 70% stake in Kotak Mahindra General Insurance Company to Zurich Insurance Company Ltd for Rs. 5,560 Cr on Jun 24.
[21]
Acquisition
On Oct 23, the company acquired a 100% stake in Sonata Finance Pvt Ltd, an NBFC- MFI for Rs.~ 537 Cr.
[22]
Digital Advancement
The company has been focusing on digitizing its banking operations. 98%+ Savings account transactions are done through digital or non-branch modes. Out of the total server base, 75% is handled virtually.
[23]
RBI Restrictions
On Apr 24, RBI directed the company to cease, onboarding new customers through its online and mobile banking channels and issuing fresh credit cards. These actions were taken based on concerns arising out of the Reserve Bank’s IT Examination of the bank for the years 2022 and 2023 and the failure on the part of the bank to address these concerns.
[24]
Bank’s Plan
The Bank will increase its investments to fortify its IT systems and will focus on accelerating the execution of the comprehensive plan for core banking resilience.
[25]
Last edited 1 week, 4 days ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 10,838 | 11,986 | 13,319 | 20,402 | 22,324 | 25,131 | 29,831 | 33,474 | 32,820 | 33,741 | 42,151 | 56,237 | 59,204 |
| Interest | 6,024 | 6,312 | 6,966 | 11,123 | 11,458 | 12,467 | 15,187 | 15,901 | 12,967 | 11,554 | 14,411 | 22,567 | 24,538 |
| Expenses + | 6,603 | 7,053 | 9,718 | 11,541 | 14,832 | 16,805 | 19,758 | 22,578 | 29,812 | 30,699 | 33,485 | 47,052 | 49,803 |
| Financing Profit | -1,789 | -1,379 | -3,366 | -2,263 | -3,965 | -4,141 | -5,114 | -5,005 | -9,958 | -8,512 | -5,746 | -13,382 | -15,137 |
| Financing Margin % | -17% | -12% | -25% | -11% | -18% | -16% | -17% | -15% | -30% | -25% | -14% | -24% | -26% |
| Other Income + | 5,112 | 5,282 | 8,152 | 7,631 | 11,660 | 13,682 | 16,148 | 16,892 | 23,588 | 24,941 | 25,991 | 38,037 | 43,225 |
| Depreciation | 179 | 208 | 237 | 345 | 362 | 383 | 458 | 465 | 461 | 480 | 599 | 792 | 0 |
| Profit before tax | 3,144 | 3,695 | 4,550 | 5,024 | 7,332 | 9,158 | 10,576 | 11,422 | 13,168 | 15,948 | 19,646 | 23,863 | 28,088 |
| Tax % | 30% | 32% | 33% | 32% | 32% | 33% | 33% | 25% | 25% | 25% | 25% | 25% |  |
| Net Profit + | 2,238 | 2,527 | 3,105 | 3,524 | 5,019 | 6,258 | 7,204 | 8,593 | 9,990 | 12,089 | 14,925 | 18,213 | 21,511 |
| EPS in Rs | 14.66 | 16.00 | 19.72 | 18.86 | 26.84 | 32.54 | 37.74 | 44.92 | 50.41 | 60.91 | 75.13 | 91.62 | 108.23 |
| Dividend Payout % | 2% | 2% | 2% | 3% | 2% | 2% | 2% | 0% | 2% | 2% | 2% | 2% |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Phoenix ARC Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investments | 99 | 101 | 101 |  |  |  |  |  |  |  |
| Purchase of / subscription to Investments | 46 | 31 |  |  |  |  |  |  |  |  |
| Loan Disbursed during the year | 30 |  |  |  |  |  |  |  |  |  |
| Loan Repaid during the year | 30 |  |  |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.52 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.50 | 0.01 |  |  |  |  |  |  |  |
| Reimbursements received | 0.11 | 0.10 | 0.03 |  |  |  |  |  |  |  |
| Sale of Fixed Assets | 0.20 |  |  |  |  |  |  |  |  |  |
| Premium Income |  | 0.01 | 0.02 |  |  |  |  |  |  |  |
| ACE Derivatives and Commodity Exchange Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investments | 48 | 48 | 48 |  |  |  |  |  |  |  |
| Loan Disbursed during the year | 1 | 3 |  |  |  |  |  |  |  |  |
| Loan Repaid during the year |  | 4 |  |  |  |  |  |  |  |  |
| Purchase of / subscription to Investments | 2.23 |  |  |  |  |  |  |  |  |  |
| Diminution on investments |  | 0.78 | 0.78 |  |  |  |  |  |  |  |
| Reimbursements received | 0.51 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.37 | 0.01 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.22 |  |  |  |  |  |  |  |  |  |
| Assets - Others | 0.02 | 0.02 | 0.02 |  |  |  |  |  |  |  |
| Deposits given during the year | 0.02 | 0.02 |  |  |  |  |  |  |  |  |
| Infina Finance Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 25 | 26 | 61 |  |  |  |  |  |  |  |
| Brokerage Income | 1.68 | 2.24 | 3.47 |  |  |  |  |  |  |  |
| Other liabilities |  | 0.78 | 0.08 |  |  |  |  |  |  |  |
| Assets - Others | 0.48 | 0.04 | 0.01 |  |  |  |  |  |  |  |
| Reimbursements made | 0.21 | 0.21 | 0.09 |  |  |  |  |  |  |  |
| Reimbursements received | 0.11 | 0.11 | 0.12 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.08 | 0.09 |  |  |  |  |  |  |  |
| Mr. Uday Kotak Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 24 | 28 | 31 |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 2.47 | 2.70 | 2.85 |  |  |  |  |  |  |  |
| USK Benefit Trust II |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 6.22 | 21 | 19 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.89 | 0.87 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.83 |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 0.03 |  |  |  |  |  |  |  |
| Kotak Education Foundation Associate |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 5.63 | 13 | 17 |  |  |  |  |  |  |  |
| Others Key Person |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 5.02 | 9.91 | 8.31 |  |  |  |  |  |  |  |
| Investments | 3.45 | 2.43 | 3.42 |  |  |  |  |  |  |  |
| Expenses - Others | 0.09 | 0.89 | 0.84 |  |  |  |  |  |  |  |
| Reimbursements made | 0.03 | 0.44 | 0.15 |  |  |  |  |  |  |  |
| Assets - Others | 0.08 | 0.26 |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.10 | 0.13 | 0.08 |  |  |  |  |  |  |  |
| Premium Income | 0.07 |  | 0.06 |  |  |  |  |  |  |  |
| Reimbursements received |  | 0.12 |  |  |  |  |  |  |  |  |
| Other liabilities | 0.04 | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Brokerage Income | 0.01 | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Sale of Fixed Assets | 0.02 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  |  | 0.01 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.01 |  |  |  |  |  |  |  |  |  |
| Kotak Commodity Services Private Limited |  |  |  |  |  |  |  |  |  |  |
| Interest Paid |  | 5.34 | 6.51 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 2.32 | 2.82 |  |  |  |  |  |  |  |
| Reimbursements received |  | 2.08 | 1.94 |  |  |  |  |  |  |  |
| Reimbursements made |  | 1.04 | 1.58 |  |  |  |  |  |  |  |
| Assets - Others |  | 0.15 | 0.28 |  |  |  |  |  |  |  |
| Other liabilities |  | 0.14 | 0.03 |  |  |  |  |  |  |  |
| Premium Income |  | 0.01 | 0.06 |  |  |  |  |  |  |  |
| Brokerage Income |  | 0.01 | 0.02 |  |  |  |  |  |  |  |
| Deposits taken during the year |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Deposits repaid during the year |  | 0.01 |  |  |  |  |  |  |  |  |
| Aero Agencies Limited |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 4.30 | 6.91 | 6.12 |  |  |  |  |  |  |  |
| Other liabilities | 0.10 | 0.02 | 0.01 |  |  |  |  |  |  |  |
| Mr. Dipak Gupta Key Person |  |  |  |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 4.01 | 4.15 | 4.20 |  |  |  |  |  |  |  |
| Kotak Commodity Services Limited |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 5.35 |  |  |  |  |  |  |  |  |  |
| Others Fee and Other Income | 2.16 |  |  |  |  |  |  |  |  |  |
| Reimbursements received | 1.54 |  |  |  |  |  |  |  |  |  |
| Reimbursements made | 0.48 |  |  |  |  |  |  |  |  |  |
| Other liabilities | 0.06 |  |  |  |  |  |  |  |  |  |
| Premium Income | 0.02 |  |  |  |  |  |  |  |  |  |
| Deposits taken during the year | 0.02 |  |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 0.01 |  |  |  |  |  |  |  |  |  |
| Mr. C. Jayaram Key Person |  |  |  |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 3 | 4.14 | 0.78 |  |  |  |  |  |  |  |
| Old Mutual Life Assurance Company (South Africa) Limited |  |  |  |  |  |  |  |  |  |  |
| Other liabilities | 0.62 | 0.52 | 0.60 |  |  |  |  |  |  |  |
| Matrix Business Services India Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 0.90 |  |  |  |  |  |  |  |  |  |
| Other liabilities |  | 0.01 | 0.12 |  |  |  |  |  |  |  |
| Reimbursements made | 0.05 | 0.04 | 0.03 |  |  |  |  |  |  |  |
| Kotak & Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Reimbursements made | 0.39 |  |  |  |  |  |  |  |  |  |
| Ms. Indira Kotak Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.10 | 0.11 | 0.12 |  |  |  |  |  |  |  |
| Old Mutual PLC |  |  |  |  |  |  |  |  |  |  |
| Reimbursements received |  |  | 0.21 |  |  |  |  |  |  |  |
| Ms. Pallavi Kotak Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.04 | 0.05 | 0.06 |  |  |  |  |  |  |  |
| Suresh A Kotak HUF |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 0.01 |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 10,838 | 11,986 | 13,319 | 20,402 | 22,324 | 25,131 | 29,831 | 33,474 | 32,820 | 33,741 | 42,151 | 56,237 | 59,204 |
| Interest | 6,024 | 6,312 | 6,966 | 11,123 | 11,458 | 12,467 | 15,187 | 15,901 | 12,967 | 11,554 | 14,411 | 22,567 | 24,538 |
| Expenses + | 6,603 | 7,053 | 9,718 | 11,541 | 14,832 | 16,805 | 19,758 | 22,578 | 29,812 | 30,699 | 33,485 | 47,052 | 49,803 |
| Financing Profit | -1,789 | -1,379 | -3,366 | -2,263 | -3,965 | -4,141 | -5,114 | -5,005 | -9,958 | -8,512 | -5,746 | -13,382 | -15,137 |
| Financing Margin % | -17% | -12% | -25% | -11% | -18% | -16% | -17% | -15% | -30% | -25% | -14% | -24% | -26% |
| Other Income + | 5,112 | 5,282 | 8,152 | 7,631 | 11,660 | 13,682 | 16,148 | 16,892 | 23,588 | 24,941 | 25,991 | 38,037 | 43,225 |
| Depreciation | 179 | 208 | 237 | 345 | 362 | 383 | 458 | 465 | 461 | 480 | 599 | 792 | 0 |
| Profit before tax | 3,144 | 3,695 | 4,550 | 5,024 | 7,332 | 9,158 | 10,576 | 11,422 | 13,168 | 15,948 | 19,646 | 23,863 | 28,088 |
| Tax % | 30% | 32% | 33% | 32% | 32% | 33% | 33% | 25% | 25% | 25% | 25% | 25% |  |
| Net Profit + | 2,238 | 2,527 | 3,105 | 3,524 | 5,019 | 6,258 | 7,204 | 8,593 | 9,990 | 12,089 | 14,925 | 18,213 | 21,511 |
| EPS in Rs | 14.66 | 16.00 | 19.72 | 18.86 | 26.84 | 32.54 | 37.74 | 44.92 | 50.41 | 60.91 | 75.13 | 91.62 | 108.23 |
| Dividend Payout % | 2% | 2% | 2% | 3% | 2% | 2% | 2% | 0% | 2% | 2% | 2% | 2% |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 2,878 | 9,068 | 2,302 | 5,025 | 13,222 | -10,392 | 1,822 | 46,619 | 4,881 | 8,308 | -1,242 | 15,685 |
| Cash from Investing Activity + | -9,035 | -1,130 | -4,467 | -2,353 | -5,289 | -5,475 | -3,323 | -13,068 | -11,172 | -10,903 | -10,381 | -8,919 |
| Cash from Financing Activity + | 7,099 | -5,814 | 2,426 | 2,024 | 6,055 | 14,679 | 8,365 | -735 | -10,072 | 7,543 | 1,883 | 15,515 |
| Net Cash Flow | 942 | 2,125 | 260 | 4,696 | 13,989 | -1,188 | 6,864 | 32,815 | -16,363 | 4,949 | -9,740 | 22,281 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % | 16% | 14% | 15% | 12% | 14% | 14% | 13% | 14% | 13% | 13% | 14% | 15% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 26.00% | 25.99% | 25.98% | 25.97% | 25.96% | 25.95% | 25.95% | 25.94% | 25.92% | 25.91% | 25.90% | 25.89% |
| FIIs + | 42.58% | 42.06% | 40.86% | 40.55% | 40.92% | 40.90% | 39.42% | 41.54% | 40.97% | 39.74% | 37.59% | 33.16% |
| DIIs + | 15.29% | 15.49% | 16.60% | 17.29% | 19.96% | 20.09% | 21.31% | 19.57% | 20.00% | 21.38% | 23.40% | 27.69% |
| Public + | 16.13% | 16.46% | 16.56% | 16.20% | 13.16% | 13.05% | 13.30% | 12.92% | 13.11% | 12.98% | 13.11% | 13.26% |
| No. of Shareholders | 4,75,671 | 5,30,692 | 5,79,821 | 5,64,789 | 5,54,779 | 5,43,736 | 5,82,733 | 5,60,825 | 6,35,299 | 6,34,698 | 6,81,301 | 7,82,680 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 32.08% | 30.04% | 29.99% | 29.92% | 26.02% | 25.98% | 25.95% | 25.90% | 25.89% |
| FIIs + | 38.56% | 39.56% | 40.27% | 39.17% | 44.23% | 40.86% | 39.42% | 37.59% | 33.16% |
| DIIs + | 7.85% | 8.98% | 11.51% | 12.64% | 13.53% | 16.60% | 21.31% | 23.40% | 27.69% |
| Public + | 21.51% | 21.42% | 18.23% | 18.26% | 16.22% | 16.56% | 13.30% | 13.11% | 13.26% |
| No. of Shareholders | 1,60,326 | 1,66,014 | 2,35,542 | 3,34,275 | 4,23,239 | 5,79,821 | 5,82,733 | 6,81,301 | 7,82,680 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/kotak-mahindra-bank-ltd/kotakbank/500247/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 17h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2d0483fe-e1e2-4753-97c0-d37c3abe0002.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a8c48edc-fa1c-43cf-80df-0e0459fcc607.pdf)
- [Change In Senior Management Of The Bank 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c99e618f-0d37-4763-bdfe-cbe75d509f90.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=af0fc68a-4178-4431-98b7-435ca2ae4e6d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e3132a4b-113a-4830-9607-500ce25c9661.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b9e0c871-3353-4ef4-855e-069bcfd848e1.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500247/73932500247.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500247/69160500247.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470320.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_KOTAKBANK_2010_2011_21062011030000.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470311.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500247/5002470310.pdf)

## Credit Ratings
- [Rating update
14 Jun from fitch](https://www.indiaratings.co.in/pressrelease/70488)
- [Rating update
6 Jun from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=127977)
- [Rating update
6 May from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/KotakMahindraBankLimited_May%2006_%202024_RR_342677.html)
- [Rating update
3 May from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=127344)
- [Rating update
5 Apr from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/KotakMahindraBankLimited_April%2005_%202024_RR_341117.html)
- [](https://www.indiaratings.co.in/pressrelease/65528)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91f4b4ce-91cc-4443-a83c-9170679b284f.pdf)
- [REC](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2025/q1/earnings-call-audio-recording/earnings-call-audio-recording.mp3)
- [Transcript](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q4/transcript/Q4FY24-Transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=10cdd399-5457-4a22-99a6-0796e5151c5b.pdf)
- [REC](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q4/earnings-call-audio-recording/Q4FY24-Earnings-Call-Audio-Link.mp3)
- [Transcript](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q3/transcript/Q3FY24-Transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9d53f5e9-3878-44b0-bcff-a046a04c105e.pdf)
- [Transcript](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q2/Transcript/Q2FY24-Transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=df34e601-1ddd-4af9-8b43-4e2cdfbeb385.pdf)
- [REC](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q2/earnings-call-audio-recording/Q2FY24-Earnings-Call-Audio-Recording.mp3)
- [Transcript](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q1/transcript/Q1FY24-Transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e8b98c6b-8d0f-4692-88cb-7f5215269ea0.pdf)
- [REC](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2024/q1/earnings-call-audio-recording/Q1FY24-Earnings-Call-Audio-Recording.mp3)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2fe0e3a0-00b4-4d27-9be8-230e69e4e6de.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fe245451-222f-485a-893a-952f8812889e.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2023/q4/transcript/Q4FY23-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d6354f99-7ef1-4636-860e-1154e2bab128.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3fb8aff6-b20e-4f3d-bd00-80ccd2801acb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b20716f9-c63c-49de-8626-4dc8e246b901.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5042acfc-6b6b-4041-963d-6fe2ac6e2c55.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8385f70e-32bc-4e29-83e3-df47a10b6f4a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3f57063f-5e66-42f7-9056-a3e814cc055e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=636b7c20-2a21-43b2-ac1e-1e43da11891a.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2022/q2/transcript/Transcript_Q2FY22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=90a66dc7-1ba7-4556-9b08-911ab5bb860d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2ade7820-b4c4-4aeb-9e08-722293c721b4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fce79489-c9a6-4129-b2ab-73208e2c1e5e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b253350c-1efc-4742-8db0-c4fd2ae56205.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2022/q1/Transcript/Transcript-Q1FY22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=32f7100d-4e7d-4d8d-b876-a7462ce4033a.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2021/q4/transcript/fy21q4-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8020adb4-d5bb-4b0d-887d-7e7011194dcc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bcada12-5936-439d-b2be-9f4febbbfcf9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f411ee34-a925-4515-9825-6e8a110cee85.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4ccda253-b7eb-464a-afa6-6e331aef0661.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2021/q3/Transcript/Q3FY21-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3cd90ca4-51e3-4409-b3b5-73543335ad8b.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2021/q2/transcript/q2fy21-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7f001074-2e6a-4be0-b9c6-15d1678ac7bf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b5054033-eced-4f3c-a430-08f8566e481f.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2021/q1/Transcript/Transcript-Q1FY21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b18c650b-bd17-43f9-a618-eea3ff4301c3.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2020/q4/transcript/Q4FY20-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7f0160e2-21b3-4da9-8aa1-86e256737d67.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6fcc6273-336d-494e-bcf1-4b1fc3dac52e.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2020/q3/Transcript/Q3FY20-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a30d50cc-4765-49a1-aa6f-9961a2533a52.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2020/q2/Transcript/Q2FY20_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=525f6890-f57c-4db7-a636-ab0f718b7eb5.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2020/q1/transcript/Q1FY20_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e79ba61-96d3-4187-8596-89d69d46bd52.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2019/q4/transcript/Q4FY19-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=477726bb-f929-4625-9a23-7a42b7c881e2.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2019/q3/Transcript/Q3FY19-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dafa5946-8e4f-4739-8851-197f54b07fd5.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2019/q2/Transcript/Q2FY19-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a5ab8c2-257c-4aa1-98b3-cba1076ea949.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2019/q1/Transcript/Q1FY19_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fb383302-bfbb-45e0-aa6a-eeba44870ec8.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2018/q4/Transcript/Q4FY18-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9da30403-4b1f-4362-92b2-529cf3161f5f.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2018/q3/Transcript/transcript-q3fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=85b8b936-9dc0-4333-af15-5b8741c38e71.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=15400d1f-ecf4-4f76-93bf-cfec358c2d7d.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2018/q2/Transcript/transcript_q2fy18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=beac0674-456f-4697-8606-be0003c9c99a.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2017/q4/Transcript/script_q4fy17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=083C508E_35C8_4E1C_8C95_D963FAC5BF3D_105000.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2017/q3/Transcript/script_q3fy17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=45108FD1_1E4A_47AB_99E5_0B258320E5C5_130828.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B6C83E12_4881_4935_8EA5_B60476C49455_161420.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3FEAE60C_048D_4A26_98C0_1AC1A451C62D_115708.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2017/q2/Transcript/script_q2fy17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7CE0116F_EE1C_4EC6_BE09_28ACEA0BEB9E_125906.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2017/q1/Transcript/script_q1fy17.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2016/q4/Transcript/script_q4fy16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=E1F0B5EA_903F_4652_A10D_24568A3674CD_143431.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2016/q3/Transcript/script_q3fy16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2BB1F69C_ECAF_4F7E_BBC5_AEE47EEFA160_172207.pdf)
- [](https://www.kotak.com/content/dam/Kotak/investor-relation/Financial-Result/QuarterlyReport/FY-2016/q2/Transcript/script_q2fy16.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | HDFC Bank | 1617.90 | 1230918.11 | 18.05 | 2.69 | 3.92 | 204.06 | 16.09 | 7.26 | 1.22 | 7.67 | 1.99 | 17.14 | 0.09 | 6.81 | 1.48 | 7.19 | 314027.08 | 33.60 | 68166.51 | 81546.20 | 16474.85 | 59.37 | 33.18 | 89.75 | 3107502.74 | 0.00 | 0.00 | 6.22 | 12.00 | 0.00 | 70.07 | 39.72 | 4109586.34 | 2.50 | 0.77 | 7.07 | 12.66 | 3.94 | -3.38 | 16.99 | 16.85 | 23.42 | 26.19 | 21.95 | 30.19 | 17.11 | 6.24 | 2.50 | 84.33 | 15.48 | 21.14 | 19.93 | 24.91 | 0.00 | 557.97 |
| 2. | ICICI Bank | 1204.35 | 847658.45 | 19.11 | 3.94 | 5.31 | 12.46 | 15.57 | 23.57 | 0.83 | 8.37 | 2.35 | 20.63 | 0.08 | 6.53 | 1.83 | 9.13 | 159515.92 | 36.37 | 44256.37 | 42606.72 | 11671.52 | 23.72 | 18.46 | 63.02 | 1399893.96 | 0.00 | 0.00 | 6.44 | 12.00 | 0.00 | 31.76 | 30.17 | 2111095.92 | 2.20 | 0.32 | 8.12 | 18.61 | 20.92 | 20.97 | 17.74 | 15.61 | 59.74 | 34.01 | 17.25 | 21.40 | 17.15 | 6.32 | 2.20 | 63.02 | 57.03 | 22.48 | 19.58 | 22.46 | 0.00 | 698.28 |
| 3. | Axis Bank | 1178.20 | 364177.28 | 13.59 | 2.33 | 3.09 | 27.66 | 15.38 | 10.01 | 0.09 | 7.06 | 1.85 | 18.40 | 0.08 | 8.25 | 1.55 | 9.12 | 117671.83 | 62.96 | 26731.28 | 31158.52 | 6436.43 | 18.72 | 5.67 | 86.63 | 1295301.95 | 8.31 | 0.09 | 6.50 | 12.00 | 0.00 | 24.52 | 17.09 | 1542986.05 | 2.68 | 0.35 | 4.03 | 12.82 | 17.13 | 22.50 | 13.57 | 10.97 | 39.18 | 54.17 | 15.01 | 20.53 | 8.73 | 5.12 | 2.68 | 85.49 | 34.19 | 20.56 | 14.40 | 30.77 | 0.00 | 307.69 |
| 4. | Kotak Mah. Bank | 1814.00 | 360614.41 | 19.41 | 2.75 | 6.09 | 53.92 | 16.71 | 3.26 | 0.11 | 7.86 | 2.62 | 15.06 | 0.08 | 4.00 | 1.99 | 5.34 | 59204.49 | 15.88 | 18642.68 | 15836.79 | 4579.66 | 23.06 | 10.35 | 108.22 | 520374.37 | 25.89 | -0.01 | 6.04 | 12.00 | 0.00 | 29.11 | 14.23 | 815782.39 | 1.97 | 0.95 | 10.36 | 0.38 | 1.49 | -5.26 | 14.32 | 14.06 | 20.42 | 22.27 | 13.52 | 19.66 | 14.31 | 6.86 | 1.97 | 91.62 | 19.45 | 29.26 | 26.25 | 34.60 | 0.00 | 198.66 |
| 5. | IDBI Bank | 103.93 | 111749.66 | 17.74 | 2.21 | 4.26 | 780.68 | 17.39 | 26.64 | 1.42 | 6.23 | 1.65 | 11.77 | 0.08 | 5.77 | 1.71 | 6.81 | 26251.87 | 68.52 | 6293.17 | 6669.84 | 1734.32 | -2.82 | 41.09 | 5.85 | 294448.21 | 94.71 | 0.00 | 5.79 | 12.00 | 0.00 | 15.06 | 51.03 | 380188.39 | 2.23 | 0.93 | 14.51 | 21.51 | 38.73 | 75.54 | 8.98 | 0.32 | 18.98 | 55.84 | 3.65 | 9.84 | 8.34 | 4.79 | 2.23 | 5.38 | 17.89 | 17.67 | 17.02 | 17.67 | 0.00 | 1075.24 |
| 6. | IndusInd Bank | 1402.05 | 109181.20 | 12.16 | 1.96 | 2.39 | -23.07 | 11.82 | -0.52 | 1.20 | 8.42 | 1.95 | 16.39 | 0.10 | 7.06 | 1.48 | 8.38 | 45748.21 | 60.52 | 8949.78 | 12198.53 | 2346.84 | 21.73 | 15.01 | 114.99 | 385449.37 | 15.79 | -0.02 | 8.50 | 12.00 | 45.48 | 25.79 | 21.08 | 438119.43 | 4.57 | 0.55 | -4.65 | -8.79 | 12.22 | -2.58 | 13.85 | 12.76 | 22.07 | 46.69 | 15.50 | 16.41 | 14.45 | 6.91 | 4.57 | 114.99 | 15.98 | 15.48 | 14.42 | 19.35 | 0.00 | 77.59 |
| 7. | Yes Bank | 25.02 | 78401.79 | 53.98 | 1.74 | 2.71 | 44.16 | 18.17 | -23.83 | 0.00 | 5.83 | 0.34 | 3.18 | 0.07 | 8.41 | 1.09 | 9.24 | 28885.91 | 58.49 | 1454.52 | 7725.41 | 516.00 | 19.86 | 48.84 | 0.49 | 346737.14 | 0.00 | 0.00 | 5.52 | 12.00 | 0.00 | 20.30 | 89.30 | 405820.48 | 4.42 | -9.78 | -5.85 | -0.93 | 23.56 | 45.25 | 2.79 | -10.37 | -5.52 | 33.31 | -1.40 | 11.27 | 1.99 | 4.94 | 4.42 | 0.45 | -42.92 | 50.33 | 52.98 | 27.25 | 0.00 | 2875.48 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| KOTAKBANK | Market Cap | ₹ 3,60,167 Cr. |
| KOTAKBANK | Current Price | ₹ 1,812 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | Sales | ₹ 59,204 Cr. |
| KOTAKBANK | OPM | 15.9 % |
| KOTAKBANK | Profit after tax | ₹ 18,643 Cr. |
| KOTAKBANK | Mar Cap | ₹ 3,60,167 Cr. |
| KOTAKBANK | Sales Qtr | ₹ 15,837 Cr. |
| KOTAKBANK | PAT Qtr | ₹ 4,580 Cr. |
| KOTAKBANK | Qtr Sales Var | 23.1 % |
| KOTAKBANK | Qtr Profit Var | 10.4 % |
| KOTAKBANK | Price to Earning | 19.4 |
| KOTAKBANK | Dividend yield | 0.11 % |
| KOTAKBANK | Price to book value | 2.75 |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | Return on assets | 2.62 % |
| KOTAKBANK | Debt to equity | 4.00 |
| KOTAKBANK | Return on equity | 15.1 % |
| KOTAKBANK | EPS | ₹ 108 |
| KOTAKBANK | Debt | ₹ 5,20,374 Cr. |
| KOTAKBANK | Promoter holding | 25.9 % |
| KOTAKBANK | Change in Prom Hold | -0.01 % |
| KOTAKBANK | Earnings yield | 6.04 % |
| KOTAKBANK | Pledged percentage | 0.00 % |
| KOTAKBANK | Industry PE | 12.0 |
| KOTAKBANK | Sales growth | 29.1 % |
| KOTAKBANK | Profit growth | 14.2 % |
| KOTAKBANK | Current Price | ₹ 1,812 |
| KOTAKBANK | Price to Sales | 6.08 |
| KOTAKBANK | CMP / FCF | 53.8 |
| KOTAKBANK | EVEBITDA | 16.7 |
| KOTAKBANK | Enterprise Value | ₹ 8,15,335 Cr. |
| KOTAKBANK | Current ratio | 1.97 |
| KOTAKBANK | Int Coverage | 1.99 |
| KOTAKBANK | PEG Ratio | 0.95 |
| KOTAKBANK | Return over 3months | 10.4 % |
| KOTAKBANK | Return over 6months | 0.38 % |
| KOTAKBANK | No. Eq. Shares | 199 |
| KOTAKBANK | Sales growth 3Years | 19.7 % |
| KOTAKBANK | Sales growth 5Years | 13.5 % |
| KOTAKBANK | Profit Var 3Yrs | 22.3 % |
| KOTAKBANK | Profit Var 5Yrs | 20.4 % |
| KOTAKBANK | ROE 5Yr | 14.1 % |
| KOTAKBANK | ROE 3Yr | 14.3 % |
| KOTAKBANK | Return over 1year | -5.26 % |
| KOTAKBANK | Return over 3years | 1.49 % |
| KOTAKBANK | Return over 5years | 3.26 % |
| KOTAKBANK | Market Cap | ₹ 3,60,167 Cr. |
| KOTAKBANK | Current Price | ₹ 1,812 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | Sales last year | ₹ 56,237 Cr. |
| KOTAKBANK | OP Ann | ₹ 9,185 Cr. |
| KOTAKBANK | Other Inc Ann | ₹ 38,037 Cr. |
| KOTAKBANK | EBIDT last year | ₹ 47,215 Cr. |
| KOTAKBANK | Dep Ann | ₹ 792 Cr. |
| KOTAKBANK | EBIT last year | ₹ 46,423 Cr. |
| KOTAKBANK | Interest last year | ₹ 22,567 Cr. |
| KOTAKBANK | PBT Ann | ₹ 23,863 Cr. |
| KOTAKBANK | Tax last year | ₹ 5,887 Cr. |
| KOTAKBANK | PAT Ann | ₹ 18,208 Cr. |
| KOTAKBANK | Extra Ord Item Ann | ₹ 7.14 Cr. |
| KOTAKBANK | NP Ann | ₹ 18,213 Cr. |
| KOTAKBANK | Dividend last year | ₹ 398 Cr. |
| KOTAKBANK | Raw Material | 0.00 % |
| KOTAKBANK | Employee cost | ₹ 10,362 Cr. |
| KOTAKBANK | OPM last year | 16.3 % |
| KOTAKBANK | NPM last year | 32.4 % |
| KOTAKBANK | Operating profit | ₹ 9,402 Cr. |
| KOTAKBANK | Interest | ₹ 24,538 Cr. |
| KOTAKBANK | Depreciation | ₹ 0.00 Cr. |
| KOTAKBANK | EPS last year | ₹ 91.6 |
| KOTAKBANK | EBIT | ₹ 48,823 Cr. |
| KOTAKBANK | Net profit | ₹ 21,511 Cr. |
| KOTAKBANK | Current Tax | ₹ 6,821 Cr. |
| KOTAKBANK | Tax | ₹ 6,821 Cr. |
| KOTAKBANK | Other income | ₹ 43,225 Cr. |
| KOTAKBANK | Ann Date | 2,02,403 |
| KOTAKBANK | Sales Prev Ann | ₹ 42,151 Cr. |
| KOTAKBANK | OP Prev Ann | ₹ 8,666 Cr. |
| KOTAKBANK | Other Inc Prev Ann | ₹ 25,991 Cr. |
| KOTAKBANK | EBIDT Prev Ann | ₹ 34,646 Cr. |
| KOTAKBANK | Dep Prev Ann | ₹ 599 Cr. |
| KOTAKBANK | EBIT preceding year | ₹ 34,047 Cr. |
| KOTAKBANK | Interest Prev Ann | ₹ 14,411 Cr. |
| KOTAKBANK | PBT Prev Ann | ₹ 19,646 Cr. |
| KOTAKBANK | Tax preceding year | ₹ 4,866 Cr. |
| KOTAKBANK | PAT Prev Ann | ₹ 14,917 Cr. |
| KOTAKBANK | Extra Ord Prev Ann | ₹ 10.8 Cr. |
| KOTAKBANK | NP Prev Ann | ₹ 14,925 Cr. |
| KOTAKBANK | Dividend Prev Ann | ₹ 298 Cr. |
| KOTAKBANK | OPM preceding year | 20.6 % |
| KOTAKBANK | NPM preceding year | 35.4 % |
| KOTAKBANK | EPS preceding year | ₹ 75.1 |
| KOTAKBANK | Sales Prev 12M | ₹ 56,237 Cr. |
| KOTAKBANK | Profit Prev 12M | ₹ 18,213 Cr. |
| KOTAKBANK | Med Sales Gwth 10Yrs | 12.2 % |
| KOTAKBANK | Med Sales Gwth 5Yrs | 12.2 % |
| KOTAKBANK | Sales growth 7Years | 14.1 % |
| KOTAKBANK | Sales Var 10Yrs | 16.7 % |
| KOTAKBANK | EBIDT growth 3Years | 21.1 % |
| KOTAKBANK | EBIDT growth 5Years | 12.5 % |
| KOTAKBANK | EBIDT growth 7Years | 13.8 % |
| KOTAKBANK | EBIDT Var 10Yrs | 16.5 % |
| KOTAKBANK | EPS growth 3Years | 22.1 % |
| KOTAKBANK | EPS growth 5Years | 19.4 % |
| KOTAKBANK | EPS growth 7Years | 19.2 % |
| KOTAKBANK | EPS growth 10Years | 19.1 % |
| KOTAKBANK | Profit Var 7Yrs | 20.5 % |
| KOTAKBANK | Profit Var 10Yrs | 22.1 % |
| KOTAKBANK | Chg in Prom Hold 3Yr | -0.11 % |
| KOTAKBANK | Market Cap | ₹ 3,60,167 Cr. |
| KOTAKBANK | Current Price | ₹ 1,812 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | OP Qtr | ₹ 3,574 Cr. |
| KOTAKBANK | Other Inc Qtr | ₹ 13,042 Cr. |
| KOTAKBANK | EBIDT Qtr | ₹ 12,813 Cr. |
| KOTAKBANK | Dep Qtr | ₹ 0.00 Cr. |
| KOTAKBANK | EBIT latest quarter | ₹ 12,813 Cr. |
| KOTAKBANK | Interest Qtr | ₹ 6,805 Cr. |
| KOTAKBANK | PBT Qtr | ₹ 9,811 Cr. |
| KOTAKBANK | Tax latest quarter | ₹ 2,412 Cr. |
| KOTAKBANK | Extra Ord Item Qtr | ₹ 3,803 Cr. |
| KOTAKBANK | NP Qtr | ₹ 7,448 Cr. |
| KOTAKBANK | GPM latest quarter | 100 % |
| KOTAKBANK | OPM latest quarter | 22.6 % |
| KOTAKBANK | NPM latest quarter | 28.9 % |
| KOTAKBANK | Eq Cap Qtr | ₹ 994 Cr. |
| KOTAKBANK | EPS latest quarter | ₹ 37.5 |
| KOTAKBANK | OP 2Qtr Bk | ₹ 2,011 Cr. |
| KOTAKBANK | OP 3Qtr Bk | ₹ 3,581 Cr. |
| KOTAKBANK | Sales 2Qtr Bk | ₹ 14,495 Cr. |
| KOTAKBANK | Sales 3Qtr Bk | ₹ 13,717 Cr. |
| KOTAKBANK | NP 2Qtr Bk | ₹ 4,265 Cr. |
| KOTAKBANK | NP 3Qtr Bk | ₹ 4,461 Cr. |
| KOTAKBANK | Opert Prft Gwth | 48.1 % |
| KOTAKBANK | Last result date | 2,02,406 |
| KOTAKBANK | Exp Qtr Sales Var | 29.3 % |
| KOTAKBANK | Exp Qtr Sales | ₹ 17,739 Cr. |
| KOTAKBANK | Exp Qtr OP | ₹ 3,439 Cr. |
| KOTAKBANK | Exp Qtr NP | ₹ -3,358 Cr. |
| KOTAKBANK | Exp Qtr EPS | ₹ -16.9 |
| KOTAKBANK | Sales Prev Qtr | ₹ 15,156 Cr. |
| KOTAKBANK | OP Prev Qtr | ₹ 236 Cr. |
| KOTAKBANK | Other Inc Prev Qtr | ₹ 12,751 Cr. |
| KOTAKBANK | EBIDT Prev Qtr | ₹ 12,987 Cr. |
| KOTAKBANK | Dep Prev Qtr | ₹ 0.00 Cr. |
| KOTAKBANK | EBIT Prev Qtr | ₹ 12,987 Cr. |
| KOTAKBANK | Interest Prev Qtr | ₹ 6,212 Cr. |
| KOTAKBANK | PBT Prev Qtr | ₹ 6,775 Cr. |
| KOTAKBANK | Tax Prev Qtr | ₹ 1,533 Cr. |
| KOTAKBANK | PAT Prev Qtr | ₹ 5,337 Cr. |
| KOTAKBANK | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| KOTAKBANK | NP Prev Qtr | ₹ 5,337 Cr. |
| KOTAKBANK | OPM Prev Qtr | 1.56 % |
| KOTAKBANK | NPM Prev Qtr | 35.2 % |
| KOTAKBANK | Eq Cap Prev Qtr | ₹ Cr. |
| KOTAKBANK | EPS Prev Qtr | ₹ 26.8 |
| KOTAKBANK | Sales PY Qtr | ₹ 12,869 Cr. |
| KOTAKBANK | OP PY Qtr | ₹ 2,566 Cr. |
| KOTAKBANK | Other Inc PY Qtr | ₹ 7,855 Cr. |
| KOTAKBANK | EBIDT PY Qtr | ₹ 10,421 Cr. |
| KOTAKBANK | Dep PY Qtr | ₹ 0.00 Cr. |
| KOTAKBANK | EBIT PY Qtr | ₹ 10,421 Cr. |
| KOTAKBANK | Interest PY Qtr | ₹ 4,834 Cr. |
| KOTAKBANK | PBT PY Qtr | ₹ 5,586 Cr. |
| KOTAKBANK | Tax PY Qtr | ₹ 1,477 Cr. |
| KOTAKBANK | Market Cap | ₹ 3,60,505 Cr. |
| KOTAKBANK | Current Price | ₹ 1,813 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | Equity capital | ₹ 994 Cr. |
| KOTAKBANK | Preference capital | ₹ 0.00 Cr. |
| KOTAKBANK | Reserves | ₹ 1,28,978 Cr. |
| KOTAKBANK | Secured loan | ₹ 75,106 Cr. |
| KOTAKBANK | Unsecured loan | ₹ 4,45,269 Cr. |
| KOTAKBANK | Balance sheet total | ₹ 7,67,667 Cr. |
| KOTAKBANK | Gross block | ₹ 7,349 Cr. |
| KOTAKBANK | Revaluation reserve | ₹ 0.00 Cr. |
| KOTAKBANK | Accum Dep | ₹ 3,839 Cr. |
| KOTAKBANK | Net block | ₹ 3,510 Cr. |
| KOTAKBANK | CWIP | ₹ 0.00 Cr. |
| KOTAKBANK | Investments | ₹ 2,46,446 Cr. |
| KOTAKBANK | Current assets | ₹ 86,727 Cr. |
| KOTAKBANK | Current liabilities | ₹ 43,945 Cr. |
| KOTAKBANK | BV Unq Invest | ₹ 25,508 Cr. |
| KOTAKBANK | MV Quoted Inv | ₹ 0.00 Cr. |
| KOTAKBANK | Cont Liab | ₹ 7,77,539 Cr. |
| KOTAKBANK | Total Assets | ₹ 7,67,667 Cr. |
| KOTAKBANK | Working capital | ₹ 42,782 Cr. |
| KOTAKBANK | Lease liabilities | ₹ 0.00 Cr. |
| KOTAKBANK | Inventory | ₹ 0.00 Cr. |
| KOTAKBANK | Trade receivables | ₹ 0.00 Cr. |
| KOTAKBANK | Face value | ₹ 5.00 |
| KOTAKBANK | Cash Equivalents | ₹ 65,206 Cr. |
| KOTAKBANK | Adv Cust | ₹ 0.00 Cr. |
| KOTAKBANK | Trade Payables | ₹ 3,605 Cr. |
| KOTAKBANK | No. Eq. Shares PY | 199 |
| KOTAKBANK | Debt preceding year | ₹ 4,18,807 Cr. |
| KOTAKBANK | Work Cap PY | ₹ 30,475 Cr. |
| KOTAKBANK | Net Block PY | ₹ 3,075 Cr. |
| KOTAKBANK | Gross Block PY | ₹ 6,397 Cr. |
| KOTAKBANK | CWIP PY | ₹ 0.00 Cr. |
| KOTAKBANK | Work Cap 3Yr | ₹ 41,110 Cr. |
| KOTAKBANK | Work Cap 5Yr | ₹ 26,994 Cr. |
| KOTAKBANK | Work Cap 7Yr | ₹ 25,645 Cr. |
| KOTAKBANK | Work Cap 10Yr | ₹ 4,365 Cr. |
| KOTAKBANK | Debt 3Years back | ₹ 3,27,110 Cr. |
| KOTAKBANK | Debt 5Years back | ₹ 2,91,763 Cr. |
| KOTAKBANK | Debt 7Years back | ₹ 2,05,230 Cr. |
| KOTAKBANK | Debt 10Years back | ₹ 85,937 Cr. |
| KOTAKBANK | Net Block 3Yrs Back | ₹ 2,554 Cr. |
| KOTAKBANK | Net Block 5Yrs Back | ₹ 2,697 Cr. |
| KOTAKBANK | Net Block 7Yrs Back | ₹ 1,759 Cr. |
| KOTAKBANK | Market Cap | ₹ 3,60,505 Cr. |
| KOTAKBANK | Current Price | ₹ 1,813 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | CF Operations | ₹ 15,685 Cr. |
| KOTAKBANK | Free Cash Flow | ₹ 14,593 Cr. |
| KOTAKBANK | CF Investing | ₹ -8,919 Cr. |
| KOTAKBANK | CF Financing | ₹ 15,515 Cr. |
| KOTAKBANK | Net CF | ₹ 22,281 Cr. |
| KOTAKBANK | Cash Beginning | ₹ 42,925 Cr. |
| KOTAKBANK | Cash End | ₹ 65,206 Cr. |
| KOTAKBANK | FCF Prev Ann | ₹ -2,203 Cr. |
| KOTAKBANK | CF Operations PY | ₹ -1,242 Cr. |
| KOTAKBANK | CF Investing PY | ₹ -10,381 Cr. |
| KOTAKBANK | CF Financing PY | ₹ 1,883 Cr. |
| KOTAKBANK | Net CF PY | ₹ -9,740 Cr. |
| KOTAKBANK | Cash Beginning PY | ₹ 52,665 Cr. |
| KOTAKBANK | Cash End PY | ₹ 42,925 Cr. |
| KOTAKBANK | Free Cash Flow 3Yrs | ₹ 20,065 Cr. |
| KOTAKBANK | Free Cash Flow 5Yrs | ₹ 70,852 Cr. |
| KOTAKBANK | Free Cash Flow 7Yrs | ₹ 61,425 Cr. |
| KOTAKBANK | Free Cash Flow 10Yrs | ₹ 81,013 Cr. |
| KOTAKBANK | CF Opr 3Yrs | ₹ 22,751 Cr. |
| KOTAKBANK | CF Opr 5Yrs | ₹ 74,251 Cr. |
| KOTAKBANK | CF Opr 7Yrs | ₹ 65,681 Cr. |
| KOTAKBANK | CF Opr 10Yrs | ₹ 86,230 Cr. |
| KOTAKBANK | CF Inv 10Yrs | ₹ -75,350 Cr. |
| KOTAKBANK | CF Inv 7Yrs | ₹ -63,241 Cr. |
| KOTAKBANK | CF Inv 5Yrs | ₹ -54,443 Cr. |
| KOTAKBANK | CF Inv 3Yrs | ₹ -30,203 Cr. |
| KOTAKBANK | Cash 3Years back | ₹ 47,717 Cr. |
| KOTAKBANK | Cash 5Years back | ₹ 31,264 Cr. |
| KOTAKBANK | Cash 7Years back | ₹ 25,589 Cr. |
| KOTAKBANK | Market Cap | ₹ 3,60,505 Cr. |
| KOTAKBANK | Current Price | ₹ 1,813 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | No. Eq. Shares | 199 |
| KOTAKBANK | Book value | ₹ 654 |
| KOTAKBANK | Inven TO |  |
| KOTAKBANK | Quick ratio | 1.97 |
| KOTAKBANK | Exports percentage | 0.00 % |
| KOTAKBANK | Piotroski score | 5.00 |
| KOTAKBANK | G Factor | 5.00 |
| KOTAKBANK | Asset Turnover | 0.08 |
| KOTAKBANK | Financial leverage | 5.34 |
| KOTAKBANK | No. of Share Holders | 7,82,680 |
| KOTAKBANK | Unpledged Prom Hold | 25.9 % |
| KOTAKBANK | ROIC | 7.86 % |
| KOTAKBANK | Debtor days | 0.00 |
| KOTAKBANK | Industry PBV | 1.87 |
| KOTAKBANK | Credit rating |  |
| KOTAKBANK | WC Days | -146 |
| KOTAKBANK | Earning Power | 6.36 % |
| KOTAKBANK | Graham Number | ₹ 1,262 |
| KOTAKBANK | Cash Cycle | 0.00 |
| KOTAKBANK | Days Payable |  |
| KOTAKBANK | Days Receivable | 0.00 |
| KOTAKBANK | Inventory Days |  |
| KOTAKBANK | Public holding | 13.3 % |
| KOTAKBANK | FII holding | 33.2 % |
| KOTAKBANK | Chg in FII Hold | -4.43 % |
| KOTAKBANK | DII holding | 27.7 % |
| KOTAKBANK | Chg in DII Hold | 4.29 % |
| KOTAKBANK | B.V. Prev Ann | ₹ 563 |
| KOTAKBANK | ROCE Prev Yr | 6.86 % |
| KOTAKBANK | ROA Prev Yr | 2.56 % |
| KOTAKBANK | ROE Prev Ann | 14.3 % |
| KOTAKBANK | No. of Share Holders Prev Qtr | 6,81,301 |
| KOTAKBANK | No. Eq. Shares 10 Yrs | 154 |
| KOTAKBANK | BV 3yrs back | ₹ 426 |
| KOTAKBANK | BV 5yrs back | ₹ 348 |
| KOTAKBANK | BV 10yrs back | ₹ 143 |
| KOTAKBANK | Inven TO 3Yr |  |
| KOTAKBANK | Inven TO 5Yr |  |
| KOTAKBANK | Inven TO 7Yr |  |
| KOTAKBANK | Inven TO 10Yr |  |
| KOTAKBANK | Export 3Yr | 0.00 % |
| KOTAKBANK | Export 5Yr | 0.00 % |
| KOTAKBANK | Div 5Yrs | ₹ 218 Cr. |
| KOTAKBANK | ROCE 3Yr | 7.00 % |
| KOTAKBANK | ROCE 5Yr | 6.97 % |
| KOTAKBANK | ROCE 7Yr | 7.24 % |
| KOTAKBANK | ROCE 10Yr | 7.83 % |
| KOTAKBANK | ROE 10Yr | 13.9 % |
| KOTAKBANK | ROE 7Yr | 14.0 % |
| KOTAKBANK | ROE 5Yr Var | 2.55 % |
| KOTAKBANK | OPM 5Year | 17.5 % |
| KOTAKBANK | OPM 10Year | 23.6 % |
| KOTAKBANK | No. of Share Holders 1Yr | 5,60,825 |
| KOTAKBANK | Avg Div Payout 3Yrs | 2.00 % |
| KOTAKBANK | Debtor days 3yrs | 0.00 |
| KOTAKBANK | Debtor days 3yrs back | 0.00 |
| KOTAKBANK | Debtor days 5yrs back | 0.00 |
| KOTAKBANK | ROA 5Yr | 2.35 % |
| KOTAKBANK | ROA 3Yr | 2.51 % |
| KOTAKBANK | Market Cap | ₹ 3,60,505 Cr. |
| KOTAKBANK | Current Price | ₹ 1,813 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | Avg Vol 1Mth | 64,39,665 |
| KOTAKBANK | Avg Vol 1Wk | 71,55,020 |
| KOTAKBANK | Volume | 31,42,697 |
| KOTAKBANK | High price | ₹ 1,926 |
| KOTAKBANK | Low price | ₹ 1,544 |
| KOTAKBANK | High price all time | ₹ 2,253 |
| KOTAKBANK | Low price all time | ₹ 28.5 |
| KOTAKBANK | Return over 1day | 2.16 % |
| KOTAKBANK | Return over 1week | -2.55 % |
| KOTAKBANK | Return over 1month | -1.28 % |
| KOTAKBANK | DMA 50 | ₹ 1,771 |
| KOTAKBANK | DMA 200 | ₹ 1,767 |
| KOTAKBANK | DMA 50 previous day | ₹ 1,771 |
| KOTAKBANK | 200 DMA prev. | ₹ 1,767 |
| KOTAKBANK | RSI | 47.5 |
| KOTAKBANK | MACD | 3.70 |
| KOTAKBANK | MACD Previous Day | 5.87 |
| KOTAKBANK | MACD Signal | 16.2 |
| KOTAKBANK | MACD Signal Prev | 19.3 |
| KOTAKBANK | Avg Vol 1Yr | 57,17,980 |
| KOTAKBANK | Return over 7years | 8.35 % |
| KOTAKBANK | Return over 10years | 14.2 % |
| KOTAKBANK | Market Cap | ₹ 3,60,505 Cr. |
| KOTAKBANK | Current Price | ₹ 1,813 |
| KOTAKBANK | High / Low | ₹ 1,926 / 1,544 |
| KOTAKBANK | Stock P/E | 19.4 |
| KOTAKBANK | Book Value | ₹ 654 |
| KOTAKBANK | Dividend Yield | 0.11 % |
| KOTAKBANK | ROCE | 7.86 % |
| KOTAKBANK | ROE | 15.1 % |
| KOTAKBANK | Face Value | ₹ 5.00 |
| KOTAKBANK | WC to Sales | 72.3 % |
| KOTAKBANK | QoQ Profits | 39.6 % |
| KOTAKBANK | QoQ Sales | 4.49 % |
| KOTAKBANK | Net worth | ₹ 1,29,972 Cr. |
| KOTAKBANK | Market Cap to Sales | 6.09 |
| KOTAKBANK | Interest Coverage | 1.99 |
| KOTAKBANK | EV / EBIT | 16.7 |
| KOTAKBANK | Debt Capacity | -0.45 |
| KOTAKBANK | Debt To Profit | 28.6 |
| KOTAKBANK | Capital Employed | ₹ 46,292 Cr. |
| KOTAKBANK | CROIC | 1.13 % |
| KOTAKBANK | debtplus | 9.99 |
| KOTAKBANK | Leverage | ₹ 5.34 |
| KOTAKBANK | Dividend Payout | 2.18 % |
| KOTAKBANK | Intrinsic Value | ₹ 1,138 |
| KOTAKBANK | CDL | -342 % |
| KOTAKBANK | Cash by market cap | 0.15 |
| KOTAKBANK | 52w Index | 70.5 % |
| KOTAKBANK | Down from 52w high | 5.87 % |
| KOTAKBANK | Up from 52w low | 17.5 % |
| KOTAKBANK | From 52w high | 0.94 |
| KOTAKBANK | Mkt Cap To Debt Cap | 1.94 |
| KOTAKBANK | Dividend Payout | 2.18 % |
| KOTAKBANK | Graham | ₹ 1,262 |
| KOTAKBANK | Price to Cash Flow | 23.0 |
| KOTAKBANK | ROCE3yr avg | 7.00 % |
| KOTAKBANK | PB X PE | 53.4 |
| KOTAKBANK | NCAVPS | ₹ 215 |
| KOTAKBANK | Mar Cap to CF | 23.0 |
| KOTAKBANK | Altman Z Score | 1.34 |
| KOTAKBANK | M.Cap / Qtr Profit | 78.7 |