# Complete Company Data

## Modal Content
About
[
edit
]
Voltas is engaged in the business of air conditioning, refrigeration, electro - mechanical projects as an EPC contractor both in domestic and international geographies (Middle East and Singapore) and engineering product services for mining, water management and treatment, construction equipments and textile industry.
Voltas was created 6 decades ago when Tata Sons joined hands with a swiss company Volkart Brothers. Voltas is also one of the most reputed engineering solution providers specializing in project management.
[1]
The company has 5,000+ Customer sites actively managed across India
[2]
Key Points
[
edit
]
Unitary Cooling Products(UCP)
[1]
Unitary Cooling products comprises Air Conditioners, Air Coolers, and Commercial Refrigeration products etc in B2B & B2C segment. As of Fy23, company has 21% market share in room Acs and 36% in window ACs. It has 25,000+ touchpoints, 64 New RAC SKUs, 51 Voltas Fresh Air Coolers SKUs, 23 New Commercial Refrigeration SKUs.
[2]
Voltas Beko
It is a JV with a Turkish company Arçelik through which Voltas entered the home appliances industry under the brand,
Voltas Beko
in 2018.
[3]
The company produces refrigerators, washing machine, microwaves and dishwashers. As of FY23, it has 7,000+ touchpoints and 150+ SKUs with ~100 launched in FY23.
[4]
International Operations Business Group (IOBG)
The company operates in Mechanical, Electrical & Plumbing (MEP), Heating, Ventilation and Air Conditioning (HVAC) and Water Management. IOBG specializes in providing comprehensive electromechanical solutions and services to its
clients in Middle East and Asia region. The company has successfully completed multiple projects across GCC, including Dubai, Oman, Qatar, Bahrain etc.
[5]
The company has an order book of Rs.2,356 crs. in FY23.
Universal MEP Projects & Engineering
Services Limited (UMPESL)
[6]
The company has restructured their B2B business into this segment. The company has an order book of ~Rs. 5800 crs. as of FY23. In FY23, it secured MEP-Major projects: Chennai Metro, Bangalore Metro, Data Centre Jobs (Noida), Godrej Commercial Building (Bangalore), Phoenix Equinox Commercial Complex (Hyderabad) etc. It also completed Water Projects of SAIL, Bokaro & Rourkela and OWSSB Cuttack. It delivered Solar EPC Project, secured orders of ~₹ 500 crores for Water supply under Jal Jeevan Mission. It has installed 265 water treatment and distribution plants in the Madhepura (Bihar). The Company is working on similar groundwater projects, to benefit 600 villages in UP.
Textile Machinery Division(TMD)
In  FY23, company plans to grow market share in capital machines, in Spinning and Post Spinning. The company has added Spreading machines and Weaving preparatory machines to its portfolio. It plans to add new Principals for Non-woven, Embroidery to strengthen value chain in Post Spinning.
[7]
The company enjoys 60% Market share of spinning machinery.
[8]
Mining and Construction Equipment (M&CE)
M&CE has grown its business across India and
expanded its reach to Mozambique through partnerships with Tata Mozambique and Tata Africa. In FY23, the segment had a decent year in  Mozambique.On the domestic front, export
levy on iron ore impacted the mining activities which impacted equipment sales and after sales services for the major part of the year. However, the subsequent removal of this levy helped sustain the demand for crushing
and screening equipment in India.
[7]
Vestfrost Solutions, Denmark
[7]
In FY23, the company entered into a technology license agreement with Vestfrost Solutions, Denmark, to develop, manufacture, sell and service
medical refrigeration and vaccine storage equipment
. This will enable the compant to enter the Bio Medical and
Cold Chain industry for vaccine storage equipment such as ice-lined refrigerators, vaccine freezers, and ultralow temperature freezers, in the Indian market.
Order Book
In FY23, company's WOS, UMPESL won multiple project orders valued at ~Rs. 3,762 crs, including a solar power project. The IOBG segment bagged a project worth Rs. 942 crs in Riyadh, Saudi Arabia, for Qiddiya Water Theme Park. IOBG also won multiple projects, including Jubail for HVAC division, involving the world’s largest desalinated water production plant.
[7]
Manufacturing Facility
[9]
The company has 4 manufacturing facilities at Waghodia (Gujarat), Sanand (Gujarat) and 2 at  Pantnagar (Uttarakhand). The company has a manufacturing capacity (CAC) 5 lakh ton and  (AC) 2.7 million units. The company has 5 R&D centres too.
[10]
Expansion
[11]
The company plans to expand its manufacturing facility in Chennai for rooms ACs with a proposed capex of around Rs. 450-500 crores BY FY25. The company  is trying for backward integration of certain products like Heat Exchanger, Cross Flow Fan and Plastic components, and has applied  for PLI provided by the Government for this category.
Distribution Network
[10]
As of FY23, company has 260+EBOs,  25,000+ Touchpoints and 5 Experience Zones.
Business Restructuring
Business Transfer Agreement(BTA)
:
In FY23, company signed BTA for transferring its B2B businesses relating to Projects business comprising Mechanical Electrical and Plumbing (MEP)/Heating, Ventilation and Air-Conditioning (HVAC) and Water projects,
Mining and Construction Equipment (M&CE) business and Textile Machinery Division (TMD) business to its WOS,
Universal MEP Projects & Engineering Services Limited (UMPESL)
w.e.f. Aug22. Through this subsidiary, the Company provides a wide range of engineering solutions.
[12]
International Projects
:
In FY23,the Board decided to transfer its international projects business to its step-down WOS, Universal MEP Projects Pte Limited (UMPPL), Singapore.
[13]
Exceptional Item FY23
[14]
In FY23, company made a provision of Rs.244 crores under exceptional items, relating to the termination of a contract and
encashment of bank guarantees for two overseas projects in Dubai and Qatar, respectively.
Last edited 10 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 5,531 | 5,266 | 5,183 | 5,720 | 6,033 | 6,404 | 7,124 | 7,658 | 7,556 | 7,934 | 9,499 | 12,481 |
| Expenses + | 5,293 | 5,000 | 4,773 | 5,376 | 5,484 | 5,742 | 6,564 | 7,040 | 6,975 | 7,362 | 9,045 | 12,145 |
| Operating Profit | 238 | 266 | 411 | 344 | 549 | 663 | 560 | 618 | 580 | 572 | 454 | 336 |
| OPM % | 4% | 5% | 8% | 6% | 9% | 10% | 8% | 8% | 8% | 7% | 5% | 3% |
| Other Income + | 102 | 121 | 154 | 261 | 212 | 178 | 174 | 179 | 189 | 188 | -77 | 253 |
| Interest | 33 | 23 | 23 | 16 | 16 | 12 | 33 | 21 | 26 | 26 | 30 | 56 |
| Depreciation | 28 | 25 | 28 | 26 | 24 | 24 | 24 | 32 | 34 | 37 | 40 | 48 |
| Profit before tax | 280 | 340 | 514 | 563 | 720 | 805 | 677 | 744 | 709 | 697 | 307 | 486 |
| Tax % | 26% | 28% | 25% | 30% | 28% | 28% | 24% | 30% | 25% | 27% | 56% | 49% |
| Net Profit + | 207 | 246 | 388 | 393 | 520 | 578 | 514 | 521 | 529 | 506 | 136 | 248 |
| EPS in Rs | 6.28 | 7.42 | 11.62 | 11.70 | 15.64 | 17.30 | 15.35 | 15.63 | 15.87 | 15.23 | 4.08 | 7.62 |
| Dividend Payout % | 25% | 25% | 19% | 22% | 22% | 23% | 26% | 26% | 32% | 36% | 110% | 72% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 94% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 4% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Voltbek Home Appliances Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments in Equity shares |  |  |  |  |  |  |  |  | 122 | 109 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 30 | 66 |
| Other Expenses Recovery of expenses |  |  |  |  |  |  |  |  | 39 | 56 |
| Purchases of stockintrade |  |  |  |  |  |  |  |  | 12 | 22 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 1.39 | 3.32 |
| Tata De Mocambique Key Person |  |  |  |  |  |  |  |  |  |  |
| Rendering of Services |  |  |  |  |  |  |  |  | 98 | 100 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 29 | 41 |
| Infiniti Retail Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of Products |  |  |  |  |  |  |  |  | 97 | 99 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 29 | 38 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.06 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.05 |  |
| Others Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 15 | 40 |
| Sale of Products |  |  |  |  |  |  |  |  | 18 | 19 |
| Rendering of Services |  |  |  |  |  |  |  |  | 10 | 11 |
| Credit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 8.69 | 7.19 |
| Dividend Paid |  |  |  |  |  |  |  |  | 6.54 | 5.05 |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 7.84 |
| Remuneration Paid / Payable (including commission and sitting fees) short term bene |  |  |  |  |  |  |  |  | 7.48 |  |
| Construction contract revenue |  |  |  |  |  |  |  |  | 5.39 |  |
| Rental Income |  |  |  |  |  |  |  |  | 2.69 | 2.67 |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 2.99 | 2.37 |
| Construction contract revenue (Includes billed and unbilled revenue) |  |  |  |  |  |  |  |  |  | 4.02 |
| Receiving of Services |  |  |  |  |  |  |  |  | 0.89 | 2.76 |
| Other Expenses Recovery of expenses |  |  |  |  |  |  |  |  | 0.97 | 0.44 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.51 | 0.51 |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  | 0.62 | 0.36 |
| Dividend Income |  |  |  |  |  |  |  |  | 0.38 | 0.38 |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.05 | 0.19 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.10 |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  | 0.03 | 0.02 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.03 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.01 |  |
| Tata Sons Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  |  |  |  |  | 48 | 37 |
| Tata Brand Equity |  |  |  |  |  |  |  |  | 14 | 22 |
| Credit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 9.87 | 16 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 0.13 | 0.51 |
| Tata Consultancy Services Limited |  |  |  |  |  |  |  |  |  |  |
| Rendering of Services |  |  |  |  |  |  |  |  | 29 | 31 |
| Construction contract revenue (Includes billed and unbilled revenue) |  |  |  |  |  |  |  |  |  | 27 |
| Receiving of Services |  |  |  |  |  |  |  |  | 12 | 15 |
| Construction contract revenue |  |  |  |  |  |  |  |  | 16 |  |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  | 3.67 | 0.54 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.72 | 0.72 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.33 | 0.82 |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.70 |  |
| Advance Outstanding at period end |  |  |  |  |  |  |  |  | 0.02 | 0.03 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.01 |  |
| Olayan Voltas Contracting Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Guarantees Outstanding at period end |  |  |  |  |  |  |  |  | 82 |  |
| Impairment in value of Investments at period end |  |  |  |  |  |  |  |  | 20 | 20 |
| Voltas Qatar W.L.L. JV |  |  |  |  |  |  |  |  |  |  |
| Other Expenses -Received / Receivable | 8.73 | 88 |  |  |  |  |  |  |  |  |
| Other Expenses -Paid / Payable | 7.35 | 13 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 2.39 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 1.90 |  |  |  |  |  |  |  |  |  |
| Sale of Products | 0.22 | 0.43 |  |  |  |  |  |  |  |  |
| Service Income | 0.26 |  |  |  |  |  |  |  |  |  |
| Tata Sons Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 16 | 20 |  |  |  |  |  |  |  |  |
| Tata Brand Equity | 6.73 | 7.17 |  |  |  |  |  |  |  |  |
| Credit Balance Oustanding at year end |  | 7.57 |  |  |  |  |  |  |  |  |
| Credit Balance Oustanding | 6.71 |  |  |  |  |  |  |  |  |  |
| Service Income | 0.59 | 0.08 |  |  |  |  |  |  |  |  |
| Consulting Charges Paid | 0.09 | 0.14 |  |  |  |  |  |  |  |  |
| Tata International Limited |  |  |  |  |  |  |  |  |  |  |
| Maturity of Investments in Bonds/Debentures |  |  |  |  |  |  |  |  | 50 |  |
| Interest Income |  |  |  |  |  |  |  |  | 3.91 |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.13 | 0.16 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.22 |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  |  | 0.18 |
| Universal Voltas L.L.C. JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  | 6.85 | 0.19 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 3.38 | 3.64 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 6.81 | 0.05 |
| Debit Balance Outstanding | 2.11 |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.92 |  |  |  |  |  |  |  |  |
| Other Operating Income | 0.86 |  |  |  |  |  |  |  |  |  |
| Service Income |  | 0.61 |  |  |  |  |  |  |  |  |
| Mr. Pradeep Bakshi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term bene |  |  |  |  |  |  |  |  | 7.75 |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 7.21 |
| Voltas Managerial Staff Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 5.73 | 7.23 |
| Tata Housing Development Company Limited |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  |  |  |  |  |  |  |  | 2.79 | 2.98 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 1.27 | 1.27 |
| Tata Capital Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Income |  |  |  |  |  |  |  |  | 3.66 | 3.66 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.76 |
| Mr. Sanjay Johri Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable | 3.05 | 3.90 |  |  |  |  |  |  |  |  |
| Voltas Limited Managerial Staff Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 4.48 | 2.06 |
| Tata Communications Limited |  |  |  |  |  |  |  |  |  |  |
| Receiving of Services |  |  |  |  |  |  |  |  | 2.28 | 2.47 |
| Tata Projects Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  |  | 3.85 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  |  | 0.71 |
| Tata Realty and Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  |  |  |  |  |  |  |  | 1.16 | 1.31 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.53 | 0.53 |
| Tata Unistore Limited |  |  |  |  |  |  |  |  |  |  |
| Receiving of Services |  |  |  |  |  |  |  |  | 3.38 |  |
| Mr. Mukundan C.P. Menon Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 3.19 |
| Naba Diganta Water Management Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 1.38 |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.59 |  |  |  |  |  |  |  |  |
| Terrot GmbH Associate |  |  |  |  |  |  |  |  |  |  |
| Commission Received | 0.83 | 0.91 |  |  |  |  |  |  |  |  |
| Olayan Voltas Contracting Company Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.91 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 0.45 |  |  |  |  |  |  |  |  |  |
| Service Income | 0.18 |  |  |  |  |  |  |  |  |  |
| Universal Weathermaker Factory L.L.C. JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods | 0.63 | 0.52 |  |  |  |  |  |  |  |  |
| Voltas Qatar W.L.L JV |  |  |  |  |  |  |  |  |  |  |
| Sale of Fixed Assets |  | 0.29 |  |  |  |  |  |  |  |  |
| Tata Advanced Systems Limited |  |  |  |  |  |  |  |  |  |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  |  | 0.27 |
| Tata Teleservices Limited |  |  |  |  |  |  |  |  |  |  |
| Advance Outstanding at period end |  |  |  |  |  |  |  |  | 0.10 | 0.10 |
| Tata Capital Housing Finance Limited |  |  |  |  |  |  |  |  |  |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.02 | 0.12 |
| Tata Communications Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  |  | 0.06 |
| Voltas Water Solutions Private Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  | 0.03 |  |  |  |  |  |  |  |  |
| Deposit Received |  | 0.01 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 5,531 | 5,266 | 5,183 | 5,720 | 6,033 | 6,404 | 7,124 | 7,658 | 7,556 | 7,934 | 9,499 | 12,481 |
| Expenses + | 5,293 | 5,000 | 4,773 | 5,376 | 5,484 | 5,742 | 6,564 | 7,040 | 6,975 | 7,362 | 9,045 | 12,145 |
| Operating Profit | 238 | 266 | 411 | 344 | 549 | 663 | 560 | 618 | 580 | 572 | 454 | 336 |
| OPM % | 4% | 5% | 8% | 6% | 9% | 10% | 8% | 8% | 8% | 7% | 5% | 3% |
| Other Income + | 102 | 121 | 154 | 261 | 212 | 178 | 174 | 179 | 189 | 188 | -77 | 253 |
| Interest | 33 | 23 | 23 | 16 | 16 | 12 | 33 | 21 | 26 | 26 | 30 | 56 |
| Depreciation | 28 | 25 | 28 | 26 | 24 | 24 | 24 | 32 | 34 | 37 | 40 | 48 |
| Profit before tax | 280 | 340 | 514 | 563 | 720 | 805 | 677 | 744 | 709 | 697 | 307 | 486 |
| Tax % | 26% | 28% | 25% | 30% | 28% | 28% | 24% | 30% | 25% | 27% | 56% | 49% |
| Net Profit + | 207 | 246 | 388 | 393 | 520 | 578 | 514 | 521 | 529 | 506 | 136 | 248 |
| EPS in Rs | 6.28 | 7.42 | 11.62 | 11.70 | 15.64 | 17.30 | 15.35 | 15.63 | 15.87 | 15.23 | 4.08 | 7.62 |
| Dividend Payout % | 25% | 25% | 19% | 22% | 22% | 23% | 26% | 26% | 32% | 36% | 110% | 72% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 94% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 4% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 84 | 295 | 311 | 219 | 428 | 325 | -321 | 462 | 556 | 584 | 159 | 762 |
| Cash from Investing Activity + | 65 | -285 | -104 | -315 | -73 | -199 | 393 | -210 | -256 | -365 | -82 | -522 |
| Cash from Financing Activity + | -60 | -79 | -236 | 48 | -211 | -181 | -18 | -294 | -122 | -107 | 55 | -116 |
| Net Cash Flow | 89 | -68 | -29 | -47 | 143 | -55 | 53 | -42 | 179 | 113 | 133 | 123 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 90 | 93 | 94 | 87 | 88 | 89 | 92 | 87 | 87 | 97 | 84 | 74 |
| Inventory Days | 86 | 85 | 88 | 65 | 78 | 65 | 76 | 97 | 84 | 103 | 79 | 79 |
| Days Payable | 151 | 154 | 156 | 156 | 172 | 174 | 165 | 177 | 161 | 182 | 149 | 143 |
| Cash Conversion Cycle | 25 | 24 | 26 | -4 | -6 | -19 | 3 | 7 | 9 | 18 | 14 | 10 |
| Working Capital Days | 46 | 42 | 35 | 38 | 36 | 40 | 57 | 59 | 60 | 54 | 54 | 32 |
| ROCE % | 16% | 17% | 22% | 19% | 22% | 22% | 17% | 18% | 15% | 13% | 10% | 9% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% |
| FIIs + | 22.31% | 24.42% | 26.19% | 24.67% | 24.37% | 21.58% | 20.58% | 19.08% | 17.84% | 17.18% | 14.71% | 15.08% |
| DIIs + | 31.61% | 29.76% | 27.83% | 29.44% | 29.43% | 31.46% | 33.14% | 33.63% | 35.82% | 37.00% | 40.36% | 40.19% |
| Government + | 0.24% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% |
| Public + | 15.53% | 15.32% | 15.47% | 15.38% | 15.69% | 16.45% | 15.78% | 16.78% | 15.84% | 15.32% | 14.41% | 14.22% |
| No. of Shareholders | 1,47,941 | 1,56,788 | 1,71,620 | 1,96,519 | 2,24,218 | 2,61,501 | 2,73,047 | 2,99,270 | 2,80,942 | 2,61,009 | 2,41,794 | 2,47,775 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% | 30.30% |
| FIIs + | 20.72% | 19.58% | 13.67% | 9.87% | 14.38% | 26.19% | 20.58% | 14.71% | 15.08% |
| DIIs + | 26.21% | 29.33% | 34.69% | 39.63% | 37.22% | 27.83% | 33.14% | 40.36% | 40.19% |
| Government + | 0.24% | 0.34% | 0.42% | 0.41% | 0.24% | 0.21% | 0.21% | 0.21% | 0.21% |
| Public + | 22.53% | 20.45% | 20.92% | 19.79% | 17.86% | 15.47% | 15.78% | 14.41% | 14.22% |
| No. of Shareholders | 1,08,642 | 1,07,457 | 1,16,403 | 1,21,793 | 1,50,995 | 1,71,620 | 2,73,047 | 2,41,794 | 2,47,775 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/voltas-ltd/voltas/500575/corp-announcements/)
- [Intimation Under Regulation 30 Of SEBI (LODR) Regulations, 2015
16 Jul - Company has received an Order from the Office of the Joint Commissioner State -Tax, Patliputra Circle, Patna Commercial Taxes Department Bihar.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a340836c-ffe8-434f-9f69-bb0f5a8e98b6.pdf)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018
12 Jul - Certificate received from Link Intime India Private Limited, Company''s Registrar and Share Transfer Agent for the quarter ended 30th June, 2024, certifying compliance with Regulation …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28aa11fd-6de3-45f9-9fc5-9c6526888065.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3e20d76-a8ef-42e2-afae-15a4bec2f554.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88d62e9d-bab1-42e9-8b10-73ba170cf34c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57aadcdd-76fe-41e9-83c0-bbf45ef26593.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8727cbfa-a27a-411b-a8b1-56e7e0ed8379.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\7371fe96-bd18-43fe-bbb8-e50003066129.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/73030500575.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/69201500575.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_674_VOLTAS_2012_2013_22072013111246.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500575/5005750311.pdf)

## Credit Ratings
- [Rating update
12 Jan from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=124800)
- [Rating update
4 Oct 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=122742)
- [Rating update
24 Aug 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=113950)
- [Rating update
26 Aug 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=105881)
- [Rating update
11 May 2020 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=94893)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=79100)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=de9d7ba7-5dd8-43ff-ae66-09e1a9cd9445.pdf)
- [REC](https://www.voltas.in/images/Investor/schedule-announcements/audio/Q4FY24InvestorCallRecording.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=30c69141-5f72-484d-8aa0-3dc46f7f7917.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7c53cc6d-09bf-4046-bfc0-450f38528cec.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d91454af-3408-4fc2-a18e-19ec11b52003.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=809d1a07-e507-49b4-8b66-1069f720fbba.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e25b9937-9d75-4ede-b8b0-4efe308b180f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=886dcbd5-2332-4065-867f-0090c329fca7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c67f27b8-0f8b-49c2-9871-e7c0a70b2fbf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8b1f98af-7b82-4c71-96a1-6508653c8b6e.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Voltas | 1483.50 | 49037.15 | 197.52 | 8.43 | 3.93 | 148.38 | 82.98 | 20.70 | 0.37 | 8.51 | 2.23 | 4.40 | 1.12 | 0.13 | 9.70 | 1.91 | 12481.21 | 2.69 | 248.27 | 4202.88 | 110.64 | 42.14 | -22.75 | 7.62 | 743.63 | 30.30 | 0.00 | 1.11 | 82.90 | 0.00 | 31.40 | 2.48 | 48928.46 | 1.25 | -14.51 | 4.90 | 47.58 | 12.37 | 93.76 | 6.09 | 8.22 | -13.61 | -22.07 | 11.87 | 18.21 | 4.42 | 9.67 | 0.88 | 7.62 | -13.61 | 67.09 | 76.25 | 59.69 | 10.09 | 33.09 |
| 2. | Blue Star | 1681.35 | 34572.10 | 82.90 | 13.25 | 3.57 | -417.70 | 48.06 | 35.36 | 0.42 | 25.51 | 6.92 | 21.17 | 1.61 | 0.09 | 10.66 | 2.31 | 9685.36 | 6.90 | 417.04 | 3327.77 | 159.71 | 26.83 | 53.68 | 20.18 | 242.93 | 36.52 | 0.03 | 1.80 | 82.90 | 0.00 | 21.41 | 47.73 | 34437.66 | 1.23 | 4.84 | 16.37 | 58.56 | 58.12 | 114.10 | 21.14 | 18.85 | 17.13 | 77.57 | 13.09 | 31.46 | 24.04 | 25.00 | 0.87 | 20.18 | 15.61 | 58.49 | 58.61 | 51.10 | -17.70 | 19.26 |
| 3. | Johnson Con. Hit | 2057.65 | 5592.07 |  | 9.60 | 2.91 | 402.84 | 630.60 | 5.17 | 0.00 | -7.49 | -2.87 | -7.97 | 1.11 | 0.08 | -3.34 | 2.96 | 1918.70 | -0.07 | -49.47 | 771.81 | 50.14 | 40.94 | 2767.02 | -27.84 | 48.08 | 74.25 | 0.00 | -1.00 | 82.90 | 32.32 | -19.53 | 25.22 | 5568.22 | 1.20 |  | 73.09 | 78.32 | -3.24 | 98.82 | -4.82 | 0.43 |  |  | -3.06 | 5.23 | -9.46 | -9.55 | 0.52 | -27.84 |  | 99.43 | 130.14 | 72.24 | 36.08 | 2.72 |
| 4. | Epack Durable | 266.19 | 2548.52 | 72.05 | 2.86 | 1.80 | -23.98 | 22.87 |  | 0.00 | 8.33 | 2.19 | 5.87 | 0.88 | 0.43 | 2.26 | 1.81 | 1419.56 | 8.08 | 35.37 | 525.70 | 27.83 | -17.74 | -19.29 | 3.69 | 386.09 | 48.14 | 0.03 | 3.12 | 82.90 | 0.00 | -7.75 | 6.86 | 2827.55 | 1.33 |  | 29.00 |  |  |  | 9.39 |  |  | 65.80 |  | 24.46 | 15.20 | 11.20 | 0.83 | 3.69 |  | 30.54 | 30.54 | 30.54 | 43.12 | 5.21 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | Sales | ₹ 12,481 Cr. |
| VOLTAS | OPM | 2.69 % |
| VOLTAS | Profit after tax | ₹ 248 Cr. |
| VOLTAS | Mar Cap | ₹ 49,037 Cr. |
| VOLTAS | Sales Qtr | ₹ 4,203 Cr. |
| VOLTAS | PAT Qtr | ₹ 111 Cr. |
| VOLTAS | Qtr Sales Var | 42.1 % |
| VOLTAS | Qtr Profit Var | -22.8 % |
| VOLTAS | Price to Earning | 198 |
| VOLTAS | Dividend yield | 0.37 % |
| VOLTAS | Price to book value | 8.43 |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | Return on assets | 2.23 % |
| VOLTAS | Debt to equity | 0.13 |
| VOLTAS | Return on equity | 4.40 % |
| VOLTAS | EPS | ₹ 7.62 |
| VOLTAS | Debt | ₹ 744 Cr. |
| VOLTAS | Promoter holding | 30.3 % |
| VOLTAS | Change in Prom Hold | 0.00 % |
| VOLTAS | Earnings yield | 1.11 % |
| VOLTAS | Pledged percentage | 0.00 % |
| VOLTAS | Industry PE | 82.9 |
| VOLTAS | Sales growth | 31.4 % |
| VOLTAS | Profit growth | 2.48 % |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | Price to Sales | 3.93 |
| VOLTAS | CMP / FCF | 148 |
| VOLTAS | EVEBITDA | 83.0 |
| VOLTAS | Enterprise Value | ₹ 48,928 Cr. |
| VOLTAS | Current ratio | 1.25 |
| VOLTAS | Int Coverage | 9.70 |
| VOLTAS | PEG Ratio | -14.5 |
| VOLTAS | Return over 3months | 4.90 % |
| VOLTAS | Return over 6months | 47.6 % |
| VOLTAS | No. Eq. Shares | 33.1 |
| VOLTAS | Sales growth 3Years | 18.2 % |
| VOLTAS | Sales growth 5Years | 11.9 % |
| VOLTAS | Profit Var 3Yrs | -22.1 % |
| VOLTAS | Profit Var 5Yrs | -13.6 % |
| VOLTAS | ROE 5Yr | 8.22 % |
| VOLTAS | ROE 3Yr | 6.09 % |
| VOLTAS | Return over 1year | 93.8 % |
| VOLTAS | Return over 3years | 12.4 % |
| VOLTAS | Return over 5years | 20.7 % |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | Sales last year | ₹ 12,481 Cr. |
| VOLTAS | OP Ann | ₹ 336 Cr. |
| VOLTAS | Other Inc Ann | ₹ 253 Cr. |
| VOLTAS | EBIDT last year | ₹ 590 Cr. |
| VOLTAS | Dep Ann | ₹ 47.6 Cr. |
| VOLTAS | EBIT last year | ₹ 542 Cr. |
| VOLTAS | Interest last year | ₹ 55.9 Cr. |
| VOLTAS | PBT Ann | ₹ 486 Cr. |
| VOLTAS | Tax last year | ₹ 238 Cr. |
| VOLTAS | PAT Ann | ₹ 248 Cr. |
| VOLTAS | Extra Ord Item Ann | ₹ -0.34 Cr. |
| VOLTAS | NP Ann | ₹ 248 Cr. |
| VOLTAS | Dividend last year | ₹ 182 Cr. |
| VOLTAS | Raw Material | 78.6 % |
| VOLTAS | Employee cost | ₹ 779 Cr. |
| VOLTAS | OPM last year | 2.69 % |
| VOLTAS | NPM last year | 1.99 % |
| VOLTAS | Operating profit | ₹ 336 Cr. |
| VOLTAS | Interest | ₹ 55.9 Cr. |
| VOLTAS | Depreciation | ₹ 47.6 Cr. |
| VOLTAS | EPS last year | ₹ 7.62 |
| VOLTAS | EBIT | ₹ 542 Cr. |
| VOLTAS | Net profit | ₹ 248 Cr. |
| VOLTAS | Current Tax | ₹ 220 Cr. |
| VOLTAS | Tax | ₹ 238 Cr. |
| VOLTAS | Other income | ₹ 253 Cr. |
| VOLTAS | Ann Date | 2,02,403 |
| VOLTAS | Sales Prev Ann | ₹ 9,499 Cr. |
| VOLTAS | OP Prev Ann | ₹ 454 Cr. |
| VOLTAS | Other Inc Prev Ann | ₹ -77.3 Cr. |
| VOLTAS | EBIDT Prev Ann | ₹ 622 Cr. |
| VOLTAS | Dep Prev Ann | ₹ 39.6 Cr. |
| VOLTAS | EBIT preceding year | ₹ 582 Cr. |
| VOLTAS | Interest Prev Ann | ₹ 29.6 Cr. |
| VOLTAS | PBT Prev Ann | ₹ 307 Cr. |
| VOLTAS | Tax preceding year | ₹ 171 Cr. |
| VOLTAS | PAT Prev Ann | ₹ 242 Cr. |
| VOLTAS | Extra Ord Prev Ann | ₹ -246 Cr. |
| VOLTAS | NP Prev Ann | ₹ 136 Cr. |
| VOLTAS | Dividend Prev Ann | ₹ 149 Cr. |
| VOLTAS | OPM preceding year | 4.78 % |
| VOLTAS | NPM preceding year | 2.57 % |
| VOLTAS | EPS preceding year | ₹ 4.08 |
| VOLTAS | Sales Prev 12M | ₹ 11,235 Cr. |
| VOLTAS | Profit Prev 12M | ₹ 281 Cr. |
| VOLTAS | Med Sales Gwth 10Yrs | 6.16 % |
| VOLTAS | Med Sales Gwth 5Yrs | 7.50 % |
| VOLTAS | Sales growth 7Years | 10.9 % |
| VOLTAS | Sales Var 10Yrs | 9.01 % |
| VOLTAS | EBIDT growth 3Years | -8.46 % |
| VOLTAS | EBIDT growth 5Years | -4.61 % |
| VOLTAS | EBIDT growth 7Years | -3.58 % |
| VOLTAS | EBIDT Var 10Yrs | 4.89 % |
| VOLTAS | EPS growth 3Years | -22.1 % |
| VOLTAS | EPS growth 5Years | -13.6 % |
| VOLTAS | EPS growth 7Years | -9.96 % |
| VOLTAS | EPS growth 10Years | 0.75 % |
| VOLTAS | Profit Var 7Yrs | -9.96 % |
| VOLTAS | Profit Var 10Yrs | 0.75 % |
| VOLTAS | Chg in Prom Hold 3Yr | 0.00 % |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | OP Qtr | ₹ 152 Cr. |
| VOLTAS | Other Inc Qtr | ₹ 54.4 Cr. |
| VOLTAS | EBIDT Qtr | ₹ 207 Cr. |
| VOLTAS | Dep Qtr | ₹ 11.8 Cr. |
| VOLTAS | EBIT latest quarter | ₹ 195 Cr. |
| VOLTAS | Interest Qtr | ₹ 20.8 Cr. |
| VOLTAS | PBT Qtr | ₹ 174 Cr. |
| VOLTAS | Tax latest quarter | ₹ 63.4 Cr. |
| VOLTAS | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| VOLTAS | NP Qtr | ₹ 111 Cr. |
| VOLTAS | GPM latest quarter | 19.8 % |
| VOLTAS | OPM latest quarter | 3.62 % |
| VOLTAS | NPM latest quarter | 2.63 % |
| VOLTAS | Eq Cap Qtr | ₹ 33.1 Cr. |
| VOLTAS | EPS latest quarter | ₹ 3.52 |
| VOLTAS | OP 2Qtr Bk | ₹ 37.1 Cr. |
| VOLTAS | OP 3Qtr Bk | ₹ 154 Cr. |
| VOLTAS | Sales 2Qtr Bk | ₹ 2,293 Cr. |
| VOLTAS | Sales 3Qtr Bk | ₹ 3,360 Cr. |
| VOLTAS | NP 2Qtr Bk | ₹ 35.6 Cr. |
| VOLTAS | NP 3Qtr Bk | ₹ 129 Cr. |
| VOLTAS | Opert Prft Gwth | -25.8 % |
| VOLTAS | Last result date | 2,02,403 |
| VOLTAS | Exp Qtr Sales Var | 31.9 % |
| VOLTAS | Exp Qtr Sales | ₹ 4,432 Cr. |
| VOLTAS | Exp Qtr OP | ₹ 138 Cr. |
| VOLTAS | Exp Qtr NP | ₹ 98.8 Cr. |
| VOLTAS | Exp Qtr EPS | ₹ 2.99 |
| VOLTAS | Sales Prev Qtr | ₹ 2,626 Cr. |
| VOLTAS | OP Prev Qtr | ₹ -7.67 Cr. |
| VOLTAS | Other Inc Prev Qtr | ₹ 57.9 Cr. |
| VOLTAS | EBIDT Prev Qtr | ₹ 50.2 Cr. |
| VOLTAS | Dep Prev Qtr | ₹ 12.8 Cr. |
| VOLTAS | EBIT Prev Qtr | ₹ 37.4 Cr. |
| VOLTAS | Interest Prev Qtr | ₹ 13.5 Cr. |
| VOLTAS | PBT Prev Qtr | ₹ 23.8 Cr. |
| VOLTAS | Tax Prev Qtr | ₹ 51.4 Cr. |
| VOLTAS | PAT Prev Qtr | ₹ -27.6 Cr. |
| VOLTAS | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| VOLTAS | NP Prev Qtr | ₹ -27.6 Cr. |
| VOLTAS | OPM Prev Qtr | -0.29 % |
| VOLTAS | NPM Prev Qtr | -1.05 % |
| VOLTAS | Eq Cap Prev Qtr | ₹ 33.1 Cr. |
| VOLTAS | EPS Prev Qtr | ₹ -0.92 |
| VOLTAS | Sales PY Qtr | ₹ 2,957 Cr. |
| VOLTAS | OP PY Qtr | ₹ 190 Cr. |
| VOLTAS | Other Inc PY Qtr | ₹ 46.7 Cr. |
| VOLTAS | EBIDT PY Qtr | ₹ 237 Cr. |
| VOLTAS | Dep PY Qtr | ₹ 10.4 Cr. |
| VOLTAS | EBIT PY Qtr | ₹ 226 Cr. |
| VOLTAS | Interest PY Qtr | ₹ 12.4 Cr. |
| VOLTAS | PBT PY Qtr | ₹ 214 Cr. |
| VOLTAS | Tax PY Qtr | ₹ 70.6 Cr. |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | Equity capital | ₹ 33.1 Cr. |
| VOLTAS | Preference capital | ₹ 0.00 Cr. |
| VOLTAS | Reserves | ₹ 5,787 Cr. |
| VOLTAS | Secured loan | ₹ 0.00 Cr. |
| VOLTAS | Unsecured loan | ₹ 744 Cr. |
| VOLTAS | Balance sheet total | ₹ 11,994 Cr. |
| VOLTAS | Gross block | ₹ 965 Cr. |
| VOLTAS | Revaluation reserve | ₹ 0.00 Cr. |
| VOLTAS | Accum Dep | ₹ 418 Cr. |
| VOLTAS | Net block | ₹ 548 Cr. |
| VOLTAS | CWIP | ₹ 368 Cr. |
| VOLTAS | Investments | ₹ 3,508 Cr. |
| VOLTAS | Current assets | ₹ 7,223 Cr. |
| VOLTAS | Current liabilities | ₹ 5,756 Cr. |
| VOLTAS | BV Unq Invest | ₹ 0.00 Cr. |
| VOLTAS | MV Quoted Inv | ₹ 1,148 Cr. |
| VOLTAS | Cont Liab | ₹ 6,115 Cr. |
| VOLTAS | Total Assets | ₹ 11,994 Cr. |
| VOLTAS | Working capital | ₹ 1,961 Cr. |
| VOLTAS | Lease liabilities | ₹ 30.3 Cr. |
| VOLTAS | Inventory | ₹ 2,135 Cr. |
| VOLTAS | Trade receivables | ₹ 2,533 Cr. |
| VOLTAS | Face value | ₹ 1.00 |
| VOLTAS | Cash Equivalents | ₹ 852 Cr. |
| VOLTAS | Adv Cust | ₹ 0.00 Cr. |
| VOLTAS | Trade Payables | ₹ 3,856 Cr. |
| VOLTAS | No. Eq. Shares PY | 33.1 |
| VOLTAS | Debt preceding year | ₹ 651 Cr. |
| VOLTAS | Work Cap PY | ₹ 2,124 Cr. |
| VOLTAS | Net Block PY | ₹ 525 Cr. |
| VOLTAS | Gross Block PY | ₹ 907 Cr. |
| VOLTAS | CWIP PY | ₹ 98.2 Cr. |
| VOLTAS | Work Cap 3Yr | ₹ 1,691 Cr. |
| VOLTAS | Work Cap 5Yr | ₹ 1,441 Cr. |
| VOLTAS | Work Cap 7Yr | ₹ 919 Cr. |
| VOLTAS | Work Cap 10Yr | ₹ 894 Cr. |
| VOLTAS | Debt 3Years back | ₹ 261 Cr. |
| VOLTAS | Debt 5Years back | ₹ 315 Cr. |
| VOLTAS | Debt 7Years back | ₹ 171 Cr. |
| VOLTAS | Debt 10Years back | ₹ 264 Cr. |
| VOLTAS | Net Block 3Yrs Back | ₹ 388 Cr. |
| VOLTAS | Net Block 5Yrs Back | ₹ 343 Cr. |
| VOLTAS | Net Block 7Yrs Back | ₹ 300 Cr. |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | CF Operations | ₹ 762 Cr. |
| VOLTAS | Free Cash Flow | ₹ 473 Cr. |
| VOLTAS | CF Investing | ₹ -522 Cr. |
| VOLTAS | CF Financing | ₹ -116 Cr. |
| VOLTAS | Net CF | ₹ 123 Cr. |
| VOLTAS | Cash Beginning | ₹ 693 Cr. |
| VOLTAS | Cash End | ₹ 852 Cr. |
| VOLTAS | FCF Prev Ann | ₹ -18.1 Cr. |
| VOLTAS | CF Operations PY | ₹ 159 Cr. |
| VOLTAS | CF Investing PY | ₹ -81.6 Cr. |
| VOLTAS | CF Financing PY | ₹ 55.0 Cr. |
| VOLTAS | Net CF PY | ₹ 133 Cr. |
| VOLTAS | Cash Beginning PY | ₹ 561 Cr. |
| VOLTAS | Cash End PY | ₹ 708 Cr. |
| VOLTAS | Free Cash Flow 3Yrs | ₹ 992 Cr. |
| VOLTAS | Free Cash Flow 5Yrs | ₹ 1,909 Cr. |
| VOLTAS | Free Cash Flow 7Yrs | ₹ 1,800 Cr. |
| VOLTAS | Free Cash Flow 10Yrs | ₹ 2,924 Cr. |
| VOLTAS | CF Opr 3Yrs | ₹ 1,505 Cr. |
| VOLTAS | CF Opr 5Yrs | ₹ 2,524 Cr. |
| VOLTAS | CF Opr 7Yrs | ₹ 2,528 Cr. |
| VOLTAS | CF Opr 10Yrs | ₹ 3,485 Cr. |
| VOLTAS | CF Inv 10Yrs | ₹ -1,733 Cr. |
| VOLTAS | CF Inv 7Yrs | ₹ -1,241 Cr. |
| VOLTAS | CF Inv 5Yrs | ₹ -1,435 Cr. |
| VOLTAS | CF Inv 3Yrs | ₹ -969 Cr. |
| VOLTAS | Cash 3Years back | ₹ 459 Cr. |
| VOLTAS | Cash 5Years back | ₹ 321 Cr. |
| VOLTAS | Cash 7Years back | ₹ 331 Cr. |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | No. Eq. Shares | 33.1 |
| VOLTAS | Book value | ₹ 176 |
| VOLTAS | Inven TO | 5.28 |
| VOLTAS | Quick ratio | 0.88 |
| VOLTAS | Exports percentage | 0.00 % |
| VOLTAS | Piotroski score | 6.00 |
| VOLTAS | G Factor | 2.00 |
| VOLTAS | Asset Turnover | 1.12 |
| VOLTAS | Financial leverage | 1.91 |
| VOLTAS | No. of Share Holders | 2,47,775 |
| VOLTAS | Unpledged Prom Hold | 30.3 % |
| VOLTAS | ROIC | 11.0 % |
| VOLTAS | Debtor days | 74.1 |
| VOLTAS | Industry PBV | 9.02 |
| VOLTAS | Credit rating |  |
| VOLTAS | WC Days | 32.4 |
| VOLTAS | Earning Power | 4.52 % |
| VOLTAS | Graham Number | ₹ 174 |
| VOLTAS | Cash Cycle | 10.1 |
| VOLTAS | Days Payable | 143 |
| VOLTAS | Days Receivable | 74.1 |
| VOLTAS | Inventory Days | 79.4 |
| VOLTAS | Public holding | 14.2 % |
| VOLTAS | FII holding | 15.1 % |
| VOLTAS | Chg in FII Hold | 0.37 % |
| VOLTAS | DII holding | 40.2 % |
| VOLTAS | Chg in DII Hold | -0.17 % |
| VOLTAS | B.V. Prev Ann | ₹ 165 |
| VOLTAS | ROCE Prev Yr | 9.67 % |
| VOLTAS | ROA Prev Yr | 2.44 % |
| VOLTAS | ROE Prev Ann | 4.42 % |
| VOLTAS | No. of Share Holders Prev Qtr | 2,41,794 |
| VOLTAS | No. Eq. Shares 10 Yrs | 33.1 |
| VOLTAS | BV 3yrs back | ₹ 151 |
| VOLTAS | BV 5yrs back | ₹ 129 |
| VOLTAS | BV 10yrs back | ₹ 63.5 |
| VOLTAS | Inven TO 3Yr | 4.07 |
| VOLTAS | Inven TO 5Yr | 4.35 |
| VOLTAS | Inven TO 7Yr | 5.32 |
| VOLTAS | Inven TO 10Yr | 4.08 |
| VOLTAS | Export 3Yr | 0.00 % |
| VOLTAS | Export 5Yr | 0.00 % |
| VOLTAS | Div 5Yrs | ₹ 162 Cr. |
| VOLTAS | ROCE 3Yr | 10.4 % |
| VOLTAS | ROCE 5Yr | 12.8 % |
| VOLTAS | ROCE 7Yr | 14.7 % |
| VOLTAS | ROCE 10Yr | 16.6 % |
| VOLTAS | ROE 10Yr | 10.8 % |
| VOLTAS | ROE 7Yr | 9.63 % |
| VOLTAS | ROE 5Yr Var | -19.3 % |
| VOLTAS | OPM 5Year | 5.67 % |
| VOLTAS | OPM 10Year | 6.73 % |
| VOLTAS | No. of Share Holders 1Yr | 2,99,270 |
| VOLTAS | Avg Div Payout 3Yrs | 72.8 % |
| VOLTAS | Debtor days 3yrs | 85.1 |
| VOLTAS | Debtor days 3yrs back | 87.0 |
| VOLTAS | Debtor days 5yrs back | 92.4 |
| VOLTAS | ROA 5Yr | 4.71 % |
| VOLTAS | ROA 3Yr | 3.40 % |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | Avg Vol 1Mth | 11,96,769 |
| VOLTAS | Avg Vol 1Wk | 12,23,447 |
| VOLTAS | Volume | 6,65,750 |
| VOLTAS | High price | ₹ 1,560 |
| VOLTAS | Low price | ₹ 757 |
| VOLTAS | High price all time | ₹ 1,560 |
| VOLTAS | Low price all time | ₹ 21.5 |
| VOLTAS | Return over 1day | 0.02 % |
| VOLTAS | Return over 1week | -2.51 % |
| VOLTAS | Return over 1month | -0.25 % |
| VOLTAS | DMA 50 | ₹ 1,434 |
| VOLTAS | DMA 200 | ₹ 1,200 |
| VOLTAS | DMA 50 previous day | ₹ 1,432 |
| VOLTAS | 200 DMA prev. | ₹ 1,197 |
| VOLTAS | RSI | 52.6 |
| VOLTAS | MACD | 14.2 |
| VOLTAS | MACD Previous Day | 16.0 |
| VOLTAS | MACD Signal | 18.1 |
| VOLTAS | MACD Signal Prev | 19.0 |
| VOLTAS | Avg Vol 1Yr | 16,56,804 |
| VOLTAS | Return over 7years | 16.7 % |
| VOLTAS | Return over 10years | 22.9 % |
| VOLTAS | Market Cap | ₹ 49,037 Cr. |
| VOLTAS | Current Price | ₹ 1,484 |
| VOLTAS | High / Low | ₹ 1,560 / 757 |
| VOLTAS | Stock P/E | 198 |
| VOLTAS | Book Value | ₹ 176 |
| VOLTAS | Dividend Yield | 0.37 % |
| VOLTAS | ROCE | 8.51 % |
| VOLTAS | ROE | 4.40 % |
| VOLTAS | Face Value | ₹ 1.00 |
| VOLTAS | WC to Sales | 15.7 % |
| VOLTAS | QoQ Profits | 501 % |
| VOLTAS | QoQ Sales | 60.1 % |
| VOLTAS | Net worth | ₹ 5,820 Cr. |
| VOLTAS | Market Cap to Sales | 3.93 |
| VOLTAS | Interest Coverage | 9.70 |
| VOLTAS | EV / EBIT | 90.3 |
| VOLTAS | Debt Capacity | 0.11 |
| VOLTAS | Debt To Profit | 3.00 |
| VOLTAS | Capital Employed | ₹ 2,877 Cr. |
| VOLTAS | CROIC | 5.19 % |
| VOLTAS | debtplus | 1.18 |
| VOLTAS | Leverage | ₹ 1.91 |
| VOLTAS | Dividend Payout | 72.2 % |
| VOLTAS | Intrinsic Value | ₹ 155 |
| VOLTAS | CDL | -12.2 % |
| VOLTAS | Cash by market cap | 0.02 |
| VOLTAS | 52w Index | 90.5 % |
| VOLTAS | Down from 52w high | 4.90 % |
| VOLTAS | Up from 52w low | 96.0 % |
| VOLTAS | From 52w high | 0.95 |
| VOLTAS | Mkt Cap To Debt Cap | 7.77 |
| VOLTAS | Dividend Payout | 72.2 % |
| VOLTAS | Graham | ₹ 174 |
| VOLTAS | Price to Cash Flow | 64.5 |
| VOLTAS | ROCE3yr avg | 10.4 % |
| VOLTAS | PB X PE | 1,665 |
| VOLTAS | NCAVPS | ₹ 59.3 |
| VOLTAS | Mar Cap to CF | 64.4 |
| VOLTAS | Altman Z Score | 8.61 |
| VOLTAS | M.Cap / Qtr Profit | 443 |