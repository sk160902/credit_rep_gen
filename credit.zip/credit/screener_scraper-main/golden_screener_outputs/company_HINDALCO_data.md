About
[
edit
]
Incorporated in 1958, Hindalco Industries Ltd. is a flagship company of the Aditya Birla Group. The Co and its subsidiaries are primarily engaged in the production of Aluminium and Copper. It is also
engaged in the manufacturing of aluminium sheet, extrusion and light gauge products for use in packaging markets like beverage and food, can and foil products, etc.
[1]
Key Points
[
edit
]
Business Segments
Aluminum
: The Co. ranks among the top global five aluminium producers based on shipments and is an integrated producer with a low-cost base and a strong presence across the value chain.
[1]
Copper
: The Co’s copper division operates one of the world's largest single-location customs copper smelters. Hindalco produces copper cathodes, and continuous cast copper rods in various sizes.
[2]
Chemicals
: The Co. is also engaged in the manufacturing of Calcined alumina (used in grinding media, wear-resistant ceramic components, etc.) and Alumina hydrates (used in the manufacture of water treatment chemicals like aluminium sulphate, zeolite, etc.)
[3]
Market Leadership
The Co. is the world’s largest aluminium rolling and recycling company. It is also one of Asia’s largest producers of primary aluminium.
[4]
Moreover, it is the largest flat rolled aluminium producer in the world and the largest downstream aluminium player in India.
[5]
Revenue Split FY22
Aluminium - 16%
Copper - 19%
Novelis (Subsidiary) - 65%
[6]
Geographical Split FY22
India - 24%
Outside India - 76%
[7]
Novelis
Novelis is a subsidiary of Hindalco Industries Limited producing automotive and beverage can sheets. It operates an integrated network of technically advanced rolling and recycling facilities across North America, South America, Europe and Asia.
[8]
Manufacturing Capabilities
The Co. has 50 manufacturing units spread across 10 countries. It has 17 units in India, 19 operational bauxite mines, and 33 overseas units of Novelis.
[5]
Production Capacity (in MN MT)
Alumina - 3.6
Specialty Alumina - ~0.4
Primary Aluminium - 1.3
Aluminium VAP - ~0.4
Copper Cathode - 0.4
Copper Rods - 0.5
Novelis Rolling Capacity - 4
Novelis recycling capacity - 2.5
[9]
Expanding Geographical Footprint
The Co. has expanded its scale by acquiring Kuppam facility at Rs. 247 Cr. of enterprise value and Ryker Base Private Limited, now Asoj at an enterprise value of Rs. 323 Cr.
[9]
Capacity Expansion
In FY22, the Co. completed its 500 kt Utkal’s Alumina refinery brownfield capacity expansion which required a capital outlay of Rs. 1,500 crores. Further debottlenecking is planned at Utkal Alumina by 350 kt to take the capacity to around 2.5 Million MT by FY 2023-24.
[10]
[11]
Additionally, it has started to expand the FRP production capacity at Aditya Aluminium and Hirakud plants by 170 KTPA with a planned investment of about Rs. 2,690 Crore. The plants at Aditya and Mahan are due to get an 18-pot expansion each at a cost of Rs. 417 Crore and Rs. 429 Crore.
[9]
Investments
The Co. has invested Rs. 609 Crore in Silvassa to build new extrusions plants with a planned capacity of 34 KTPA.
[9]
The Co. announced certain organic growth investments in India in the businesses of Aluminium, Copper, Specialty Alumina and also Resource Securitisation over the next 5 years in the range of $3.0 - 3.3 billion. Novelis has identified more than $4.5 billion of potential capital investment opportunities in new capacities and facilities. The new facilities will be established in the US, China, South Korea, Germany, and Brazil. Of the estimated range of total investments, ~$3 Billion is expected to be invested in the US.
[11]
Renewable Energy Target
At present, the Co. has a total renewable capacity of 100 MW. It intends to achieve a renewable capacity of 300 MW by FY2024-25, including 100 MW solar power capacity with hybrid storage.
[12]
Fund Raising
In March 2021, Novelis Inc. announced the completion of €500 million aggregate principal amount of 3.375% euro-denominated senior green notes due April 15, 2029, by Novelis Sheet Ingot GmbH, an indirect wholly-owned subsidiary of Novelis.
[13]
Further, in July 2021, Novelis Inc. raised $750M principal amount of its senior notes due in 2026 and $750M aggregate principal amount of its senior notes due in 2031.
[14]
Focus
The Co. continues to focus on its downstream strategy to increase its downstream capacities in the Flat Rolled Products, Extrusions and other flat rolled products.
[10]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright
