About
[
edit
]
JSW Steel is primarily engaged in the business of manufacture and sale of Iron and Steel Products.
[1]
It is the flagship business of the diversified, US$ 23 billion JSW Group.The Group has interests in energy, infrastructure, cement, paints, sports, and venture capital.
[2]
Key Points
[
edit
]
Product Portfolio
The company's diversified portfolio comprises products under hot-rolled, cold-rolled, galvanneal, galvanised/galvalume, pre-painted, tinplate, electrical steel, TMT bar, wire rod, special steel bar, round and bloom categories.
[1]
Revenue Breakup- Client wise Q3FY24
[2]
Retail: 33%
Auto: 14%
Industrial: 16%
Construction & Infra: 37%
Geography Wise
[3]
Domestic - 93%
Exports - 7%
Share of Revenue from Value Added Steel Products
[2]
The revenue share from VASP was 35% in FY16 which has increased to 60% in Q3FY24.
The company aims to maintain this by >50% in future years.
Capacity Utilization
[4]
Average India capacity utilization: 94%
Distribution Network Q3FY24
[5]
The company is present in ~ 17,500 retail stores across more than 530 districts in India. It has a strong distribution channel of 2,475 points including 450 distributors and 2,025 Branded Stores, 706 JSW Shoppe spread across urban areas, and 1,319 JSW Shoppe Connect in semi-urban and rural areas. It has enrolled 82,000+ partners in JSW Privilege Club and 14 Experience Centres across India.
Manufacturing Capabilities
[6]
As of Q3FY24, the company has a total capacity of 28.2mt.
Vijaynagar Works - 23.5 MnTPA
BPSL - 3.5 MnTPA
JISPL - 1.2 MnTPA
Expansion
[6]
The company has plans to expand capacity to 37mt by FY25- 26 and eventually to 50mt vy FY30 through :
1) Brownfield expansion of ~5mt at each of Vijayanagar, Dolvi and BPSL
2) 4mt Green Steel in 2 phases
3) Greenfield growth in Odisha (13mt)
4) Greenfield EAF at Kadapa, Andhra Pradesh.
Approvals
[7]
12 products got approved/graded in Q3FY24. These include Solar Module, Magsure, Seamless Tubes etc.
JSW One
[8]
The company launched JSW One TMT private brand in Nov’23. It is one of India’s leading integrated B2B commerce platforms catering to the buying needs of MSMEs. JSW Steel has a shareholding of 69.01%; Mitsui and Co. have acquired an 8.2% stake in JSW One. As of Q3FY24, the company has ~43,000 registered users, ~155,000 visits on the platform and the repeat customer rate is ~68%. annual GMV is 6,800 crs+.
NCDs
[9]
On Jan,24, the company decided to issue Secured/Un-secured, Redeemable, Non-Convertible Debentures for ~Rs. 2,000 crores, by way of private placement and/or by way of public issuance, in one or more tranches.
Focus
[6]
The company aims to take JSW Steel India's capacity to 37mt and up to 50mt by FY30.
Last edited 5 months, 3 weeks ago
Request an update
© Protected by Copyright
