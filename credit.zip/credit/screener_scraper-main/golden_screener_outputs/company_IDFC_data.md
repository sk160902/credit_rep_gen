About
[
edit
]
IDFC Limited was incorporated in 1997. It is a Non-Banking Finance Company (NBFC) regulated by the Reserve Bank of India.  It continues to hold investments in IDFC FIRST Bank and IDFC AMC. It held 39.98% in IDFC FIRST Bank and 99.96% in IDFC AMC. IDFC’s holding in IDFC FIRST Bank has further reduced to 36.60% post the QIP issue done by the Bank in April 2021.
[1]
[2]
Key Points
[
edit
]
History
It was operating as an Infrastructure Finance Company, i.e. financing infrastructure projects in sectors like energy, telecommunication, commercial and industrial projects, etc. upto 2015. The Company had received in-principle approval from the RBI to set up a new private sector bank in 2014. Since 2015 the company has been operating as NBFC - Investment Company.
IDFC and IDFC First Bank are two listed entities of IDFC Group and the rest of the businesses are conducted through unlisted entities.
[1]
[2]
Business segments FY21
Financing: 16% vs 42% in FY20
Asset management: 84% vs 57% in FY20
Other: 1%
[3]
IDFC First Bank
IDFC First Bank is a bank focused on both retail assets and retail liabilities. Retail constitutes 65% of funded loan assets.
[2]
[4]
IDFC Asset Management Company
IDFC Mutual Fund crossed INR 1 lakh crore AuM milestone and entered the Top 10 within the industry in terms of total AUM.
The AMC’s Neo Equity PMS, a unique machine-learning driven strategy, had steady index beating performance.
IDFC Mutual Fund expanded its existing product suite by launching the ‘Emerging Businesses Fund’.
The Market Share of IDFC AMC increased to 4% from 3.7% in FY20 on the back of more than par growth in Average AuM of 19%
[5]
[6]
Divesting Non-retail business
Infrastructure Debt Fund:
Entire 81% stake sold to National Investment and Infrastructure Funds in two tranches, the first tranche of 51.5% already sold in FY19 whereas the second tranche of balance 30% sold in FY20
IDFC securities:
The agreement was made to sell the business to Dharmesh Mehta and a group of financial investors.
Post divestment of non-retail businesses, IDFC FHCL will continue to hold 40% in IDFC FIRST Bank and 100% in IDFC AMC.
[7]
Merger
The BoD of the Company had approved the
merger of IDFC Alternatives Limited and IDFC Trustee Company Limited with IDFC Limited, Expected by March 31, 2022,
IDFC Trustee Company Limited is a subsidiary of IDFC Limited. It acted as a Trustee of various funds managed by IDFC Alternatives.
IDFC Alternatives Limited is a subsidiary of IDFC Limited. It had sold its Infrastructure asset management business to Global Infrastructure Partner.
Both IDFC Trustee Company Ltd. and IDFC Alternatives Ltd. have not had any business operations since December 2019.
[8]
[9]
The BoD of the Company approved the
merger of IDFC with IDFC FIRST Bank
on July 03, 2023.
[10]
Branch Network
The Branch Network stands at 464 branches and 356 ATMs.
[11]
Loans Repayment
HDFC loan of INR 200 crore has been fully paid off.
[12]
Investments
The co. has an
investment of INR 7386 Cr.
It has investments in various financial services businesses such as Banking, Asset Management, Investment Banking, Institutional Broking & Research, and Infrastructure Debt Fund. It holds all these investments under IDFC Financial Holding Company Limited.
[13]
[8]
IDFC Institute
IDFC Institute has been set up as an independent, economic development focused think tank to investigate the political, economic and spatial dimensions of India’s ongoing transition from a low-income, state-led country to a prosperous market-based economy. It has worked on urbanization, criminal justice, Data governance network, etc.
[14]
Focus
Co. is divesting all its non-retail businesses.
Focus on diversifying its products and capabilities, enhance customer engagement and invest in digital technologies and infrastructure.
[7]
[5]
Last edited 9 months, 2 weeks ago
Request an update
© Protected by Copyright
