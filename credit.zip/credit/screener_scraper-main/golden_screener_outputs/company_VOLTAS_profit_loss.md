# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 5,531 | 5,266 | 5,183 | 5,720 | 6,033 | 6,404 | 7,124 | 7,658 | 7,556 | 7,934 | 9,499 | 12,481 |
| Expenses + | 5,293 | 5,000 | 4,773 | 5,376 | 5,484 | 5,742 | 6,564 | 7,040 | 6,975 | 7,362 | 9,045 | 12,145 |
| Operating Profit | 238 | 266 | 411 | 344 | 549 | 663 | 560 | 618 | 580 | 572 | 454 | 336 |
| OPM % | 4% | 5% | 8% | 6% | 9% | 10% | 8% | 8% | 8% | 7% | 5% | 3% |
| Other Income + | 102 | 121 | 154 | 261 | 212 | 178 | 174 | 179 | 189 | 188 | -77 | 253 |
| Interest | 33 | 23 | 23 | 16 | 16 | 12 | 33 | 21 | 26 | 26 | 30 | 56 |
| Depreciation | 28 | 25 | 28 | 26 | 24 | 24 | 24 | 32 | 34 | 37 | 40 | 48 |
| Profit before tax | 280 | 340 | 514 | 563 | 720 | 805 | 677 | 744 | 709 | 697 | 307 | 486 |
| Tax % | 26% | 28% | 25% | 30% | 28% | 28% | 24% | 30% | 25% | 27% | 56% | 49% |
| Net Profit + | 207 | 246 | 388 | 393 | 520 | 578 | 514 | 521 | 529 | 506 | 136 | 248 |
| EPS in Rs | 6.28 | 7.42 | 11.62 | 11.70 | 15.64 | 17.30 | 15.35 | 15.63 | 15.87 | 15.23 | 4.08 | 7.62 |
| Dividend Payout % | 25% | 25% | 19% | 22% | 22% | 23% | 26% | 26% | 32% | 36% | 110% | 72% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 94% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 4% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Voltbek Home Appliances Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments in Equity shares |  |  |  |  |  |  |  |  | 122 | 109 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 30 | 66 |
| Other Expenses Recovery of expenses |  |  |  |  |  |  |  |  | 39 | 56 |
| Purchases of stockintrade |  |  |  |  |  |  |  |  | 12 | 22 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 1.39 | 3.32 |
| Tata De Mocambique Key Person |  |  |  |  |  |  |  |  |  |  |
| Rendering of Services |  |  |  |  |  |  |  |  | 98 | 100 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 29 | 41 |
| Infiniti Retail Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of Products |  |  |  |  |  |  |  |  | 97 | 99 |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 29 | 38 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.06 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.05 |  |
| Others Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 15 | 40 |
| Sale of Products |  |  |  |  |  |  |  |  | 18 | 19 |
| Rendering of Services |  |  |  |  |  |  |  |  | 10 | 11 |
| Credit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 8.69 | 7.19 |
| Dividend Paid |  |  |  |  |  |  |  |  | 6.54 | 5.05 |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 7.84 |
| Remuneration Paid / Payable (including commission and sitting fees) short term bene |  |  |  |  |  |  |  |  | 7.48 |  |
| Construction contract revenue |  |  |  |  |  |  |  |  | 5.39 |  |
| Rental Income |  |  |  |  |  |  |  |  | 2.69 | 2.67 |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 2.99 | 2.37 |
| Construction contract revenue (Includes billed and unbilled revenue) |  |  |  |  |  |  |  |  |  | 4.02 |
| Receiving of Services |  |  |  |  |  |  |  |  | 0.89 | 2.76 |
| Other Expenses Recovery of expenses |  |  |  |  |  |  |  |  | 0.97 | 0.44 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.51 | 0.51 |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  | 0.62 | 0.36 |
| Dividend Income |  |  |  |  |  |  |  |  | 0.38 | 0.38 |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.05 | 0.19 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.10 |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  | 0.03 | 0.02 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.03 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.01 |  |
| Tata Sons Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  |  |  |  |  | 48 | 37 |
| Tata Brand Equity |  |  |  |  |  |  |  |  | 14 | 22 |
| Credit Balance Outstanding at period end |  |  |  |  |  |  |  |  | 9.87 | 16 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 0.13 | 0.51 |
| Tata Consultancy Services Limited |  |  |  |  |  |  |  |  |  |  |
| Rendering of Services |  |  |  |  |  |  |  |  | 29 | 31 |
| Construction contract revenue (Includes billed and unbilled revenue) |  |  |  |  |  |  |  |  |  | 27 |
| Receiving of Services |  |  |  |  |  |  |  |  | 12 | 15 |
| Construction contract revenue |  |  |  |  |  |  |  |  | 16 |  |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  | 3.67 | 0.54 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.72 | 0.72 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.33 | 0.82 |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.70 |  |
| Advance Outstanding at period end |  |  |  |  |  |  |  |  | 0.02 | 0.03 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 0.01 |  |
| Olayan Voltas Contracting Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Guarantees Outstanding at period end |  |  |  |  |  |  |  |  | 82 |  |
| Impairment in value of Investments at period end |  |  |  |  |  |  |  |  | 20 | 20 |
| Voltas Qatar W.L.L. JV |  |  |  |  |  |  |  |  |  |  |
| Other Expenses -Received / Receivable | 8.73 | 88 |  |  |  |  |  |  |  |  |
| Other Expenses -Paid / Payable | 7.35 | 13 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 2.39 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 1.90 |  |  |  |  |  |  |  |  |  |
| Sale of Products | 0.22 | 0.43 |  |  |  |  |  |  |  |  |
| Service Income | 0.26 |  |  |  |  |  |  |  |  |  |
| Tata Sons Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 16 | 20 |  |  |  |  |  |  |  |  |
| Tata Brand Equity | 6.73 | 7.17 |  |  |  |  |  |  |  |  |
| Credit Balance Oustanding at year end |  | 7.57 |  |  |  |  |  |  |  |  |
| Credit Balance Oustanding | 6.71 |  |  |  |  |  |  |  |  |  |
| Service Income | 0.59 | 0.08 |  |  |  |  |  |  |  |  |
| Consulting Charges Paid | 0.09 | 0.14 |  |  |  |  |  |  |  |  |
| Tata International Limited |  |  |  |  |  |  |  |  |  |  |
| Maturity of Investments in Bonds/Debentures |  |  |  |  |  |  |  |  | 50 |  |
| Interest Income |  |  |  |  |  |  |  |  | 3.91 |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.13 | 0.16 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  | 0.22 |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  |  | 0.18 |
| Universal Voltas L.L.C. JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  | 6.85 | 0.19 |
| Deputation Charges paid |  |  |  |  |  |  |  |  | 3.38 | 3.64 |
| Other Expenses Reimbursement of expenses |  |  |  |  |  |  |  |  | 6.81 | 0.05 |
| Debit Balance Outstanding | 2.11 |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.92 |  |  |  |  |  |  |  |  |
| Other Operating Income | 0.86 |  |  |  |  |  |  |  |  |  |
| Service Income |  | 0.61 |  |  |  |  |  |  |  |  |
| Mr. Pradeep Bakshi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term bene |  |  |  |  |  |  |  |  | 7.75 |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 7.21 |
| Voltas Managerial Staff Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 5.73 | 7.23 |
| Tata Housing Development Company Limited |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  |  |  |  |  |  |  |  | 2.79 | 2.98 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 1.27 | 1.27 |
| Tata Capital Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Income |  |  |  |  |  |  |  |  | 3.66 | 3.66 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  |  | 0.76 |
| Mr. Sanjay Johri Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable | 3.05 | 3.90 |  |  |  |  |  |  |  |  |
| Voltas Limited Managerial Staff Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employee Benet Funds |  |  |  |  |  |  |  |  | 4.48 | 2.06 |
| Tata Communications Limited |  |  |  |  |  |  |  |  |  |  |
| Receiving of Services |  |  |  |  |  |  |  |  | 2.28 | 2.47 |
| Tata Projects Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Contract Revenue in excess of Billing |  |  |  |  |  |  |  |  |  | 3.85 |
| Provision for Debts and Advances at period end |  |  |  |  |  |  |  |  |  | 0.71 |
| Tata Realty and Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  |  |  |  |  |  |  |  | 1.16 | 1.31 |
| Security deposit at the end of the period |  |  |  |  |  |  |  |  | 0.53 | 0.53 |
| Tata Unistore Limited |  |  |  |  |  |  |  |  |  |  |
| Receiving of Services |  |  |  |  |  |  |  |  | 3.38 |  |
| Mr. Mukundan C.P. Menon Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration Paid / Payable (including commission and sitting fees) short term benets # |  |  |  |  |  |  |  |  |  | 3.19 |
| Naba Diganta Water Management Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 1.38 |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.59 |  |  |  |  |  |  |  |  |
| Terrot GmbH Associate |  |  |  |  |  |  |  |  |  |  |
| Commission Received | 0.83 | 0.91 |  |  |  |  |  |  |  |  |
| Olayan Voltas Contracting Company Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding at year end |  | 0.91 |  |  |  |  |  |  |  |  |
| Debit Balance Outstanding | 0.45 |  |  |  |  |  |  |  |  |  |
| Service Income | 0.18 |  |  |  |  |  |  |  |  |  |
| Universal Weathermaker Factory L.L.C. JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods | 0.63 | 0.52 |  |  |  |  |  |  |  |  |
| Voltas Qatar W.L.L JV |  |  |  |  |  |  |  |  |  |  |
| Sale of Fixed Assets |  | 0.29 |  |  |  |  |  |  |  |  |
| Tata Advanced Systems Limited |  |  |  |  |  |  |  |  |  |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  |  | 0.27 |
| Tata Teleservices Limited |  |  |  |  |  |  |  |  |  |  |
| Advance Outstanding at period end |  |  |  |  |  |  |  |  | 0.10 | 0.10 |
| Tata Capital Housing Finance Limited |  |  |  |  |  |  |  |  |  |  |
| Billing in excess of Contract Revenue |  |  |  |  |  |  |  |  | 0.02 | 0.12 |
| Tata Communications Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods / services for execution of contracts |  |  |  |  |  |  |  |  |  | 0.06 |
| Voltas Water Solutions Private Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Rental Income |  | 0.03 |  |  |  |  |  |  |  |  |
| Deposit Received |  | 0.01 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 5,531 | 5,266 | 5,183 | 5,720 | 6,033 | 6,404 | 7,124 | 7,658 | 7,556 | 7,934 | 9,499 | 12,481 |
| Expenses + | 5,293 | 5,000 | 4,773 | 5,376 | 5,484 | 5,742 | 6,564 | 7,040 | 6,975 | 7,362 | 9,045 | 12,145 |
| Operating Profit | 238 | 266 | 411 | 344 | 549 | 663 | 560 | 618 | 580 | 572 | 454 | 336 |
| OPM % | 4% | 5% | 8% | 6% | 9% | 10% | 8% | 8% | 8% | 7% | 5% | 3% |
| Other Income + | 102 | 121 | 154 | 261 | 212 | 178 | 174 | 179 | 189 | 188 | -77 | 253 |
| Interest | 33 | 23 | 23 | 16 | 16 | 12 | 33 | 21 | 26 | 26 | 30 | 56 |
| Depreciation | 28 | 25 | 28 | 26 | 24 | 24 | 24 | 32 | 34 | 37 | 40 | 48 |
| Profit before tax | 280 | 340 | 514 | 563 | 720 | 805 | 677 | 744 | 709 | 697 | 307 | 486 |
| Tax % | 26% | 28% | 25% | 30% | 28% | 28% | 24% | 30% | 25% | 27% | 56% | 49% |
| Net Profit + | 207 | 246 | 388 | 393 | 520 | 578 | 514 | 521 | 529 | 506 | 136 | 248 |
| EPS in Rs | 6.28 | 7.42 | 11.62 | 11.70 | 15.64 | 17.30 | 15.35 | 15.63 | 15.87 | 15.23 | 4.08 | 7.62 |
| Dividend Payout % | 25% | 25% | 19% | 22% | 22% | 23% | 26% | 26% | 32% | 36% | 110% | 72% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 94% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 4% |  |  |  |  |  |  |  |  |  |  |  |

