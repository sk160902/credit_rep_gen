# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 80,193 | 87,695 | 104,281 | 98,759 | 100,184 | 115,183 | 130,542 | 118,144 | 131,985 | 195,059 | 223,202 | 215,962 |
| Expenses + | 72,494 | 79,671 | 95,437 | 90,981 | 87,867 | 101,488 | 115,031 | 103,838 | 114,449 | 166,712 | 200,536 | 192,090 |
| Operating Profit | 7,699 | 8,024 | 8,844 | 7,778 | 12,317 | 13,695 | 15,511 | 14,306 | 17,536 | 28,347 | 22,666 | 23,872 |
| OPM % | 10% | 9% | 8% | 8% | 12% | 12% | 12% | 12% | 13% | 15% | 10% | 11% |
| Other Income + | 1,111 | 677 | -832 | 1,500 | 1,198 | 2,879 | 1,127 | 906 | -964 | 1,253 | 1,307 | 1,519 |
| Interest | 2,079 | 2,702 | 4,178 | 5,134 | 5,742 | 3,911 | 3,778 | 4,197 | 3,738 | 3,768 | 3,646 | 3,858 |
| Depreciation | 2,822 | 3,347 | 3,493 | 4,347 | 4,457 | 4,506 | 4,777 | 5,091 | 6,628 | 6,729 | 7,086 | 7,521 |
| Profit before tax | 3,909 | 2,653 | 340 | -203 | 3,315 | 8,157 | 8,083 | 5,924 | 6,206 | 19,103 | 13,241 | 14,012 |
| Tax % | 23% | 20% | 75% | 245% | 43% | 25% | 32% | 36% | 44% | 28% | 24% | 28% |
| Net Profit + | 3,007 | 2,195 | 259 | -702 | 1,882 | 6,083 | 5,495 | 3,767 | 3,483 | 13,730 | 10,097 | 10,155 |
| EPS in Rs | 15.81 | 10.53 | 4.14 | -1.21 | 8.47 | 27.10 | 24.48 | 16.77 | 15.50 | 61.10 | 44.93 | 45.19 |
| Dividend Payout % | 6% | 9% | 24% | -82% | 13% | 4% | 5% | 6% | 19% | 6% | 7% | 8% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Aluminium Norf GmbH Associate |  |  |  |  |  |  |  |  |  |
| Service Received | 1,598 | 1,519 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 418 | 489 |  |  |  |  |  |  |  |
| Trade and Other Payables | 271 | 317 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits given | 127 | 17 |  |  |  |  |  |  |  |
| Interest and Dividend Received | 4.41 | 4.66 |  |  |  |  |  |  |  |
| Trade and other Receivables | 1.51 | 5.32 |  |  |  |  |  |  |  |
| Aditya Birla Management Corporation Private Limited |  |  |  |  |  |  |  |  |  |
| Services received |  |  |  |  | 429 |  |  |  | 832 |
| Payables |  |  |  |  |  |  |  |  | 98 |
| Loans, Deposits and Advances given |  |  |  |  |  |  |  |  | 94 |
| Credit Balances |  |  |  |  | 32 |  |  |  |  |
| Debit Balances |  |  |  |  | 19 |  |  |  |  |
| Services rendered |  |  |  |  |  |  |  |  | 11 |
| Reimbursement of Expenses from |  |  |  |  |  |  |  |  | 1 |
| Receivable against reimbursement |  |  |  |  |  |  |  |  | 1 |
| Hindalco Employees Provident Fund Institution, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 164 |  | 72 |  |  |  |  |
| Aditya Birla Science and Technology Company Pvt. Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 58 | 58 |  |  |  |  |  |  |  |
| Service Received | 15 | 12 |  |  |  |  |  |  |  |
| Interest and Dividend Received | 5.14 | 5.14 |  |  |  |  |  |  |  |
| Trade and other Receivables | 0.04 |  |  |  |  |  |  |  |  |
| Service Rendered | 0.02 |  |  |  |  |  |  |  |  |
| Aditya Birla Science & Technology Company Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Deposits, Loans and Advances |  |  | 55 |  |  |  |  |  |  |
| Deposits and Loans (given) |  |  |  |  | 51 |  |  |  |  |
| Services received |  |  |  |  | 15 |  |  |  |  |
| Services Received |  |  | 12 |  |  |  |  |  |  |
| Interest and dividend received |  |  | 4.56 |  |  |  |  |  |  |
| Interest received |  |  |  |  | 4 |  |  |  |  |
| Deposits, Loans and Advances received back during the year |  |  | 2.45 |  |  |  |  |  |  |
| Hindalco Industries Limited Employees Provident Fund II |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 51 |  | 58 |  |  |  |  |
| Mr. D. Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration | 23 | 21 | 48 | 6.93 |  |  |  |  |  |
| Hindalco Employees Gratuity Fund, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 41 |  | 43 |  |  |  |  |
| Aditya Birla Science & Technology Company Pvt Ltd Associate |  |  |  |  |  |  |  |  |  |
| Deposits, Loans and Advances |  |  |  | 51 |  |  |  |  |  |
| Services Received |  |  |  | 13 |  |  |  |  |  |
| Deposits, Loans and Advances received back during the year |  |  |  | 4.90 |  |  |  |  |  |
| Interest and dividend received |  |  |  | 3.45 |  |  |  |  |  |
| Payables |  |  |  | 0.26 |  |  |  |  |  |
| Mr. Satish Pai Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration | 13 | 15 | 19 | 21 |  |  |  |  |  |
| Directors Remuneration |  |  |  | 1.06 |  |  |  |  |  |
| Executive Directors Subsidiary |  |  |  |  |  |  |  |  |  |
| Short term employment benefit |  |  |  |  |  |  |  | 52 |  |
| Commission & Sitting Fees |  |  |  |  |  |  |  | 9 |  |
| Post employment benefits |  |  |  |  |  |  |  | 4 |  |
| Aditya Birla Science & Technology Company Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans, Deposits and Advances given |  |  |  |  |  |  |  |  | 29 |
| Services received |  |  |  |  |  |  |  |  | 21 |
| Deposits, Loans and Advances received back from |  |  |  |  |  |  |  |  | 7 |
| Interest received |  |  |  |  |  |  |  |  | 2 |
| Reimbursement of Expenses to |  |  |  |  |  |  |  |  | 1 |
| Idea Cellular Limited Associate |  |  |  |  |  |  |  |  |  |
| Interest and Dividend Received | 10 | 15 |  |  |  |  |  |  |  |
| Interest and dividend received |  |  | 15 |  |  |  |  |  |  |
| Service Received | 3.06 | 3.27 |  |  |  |  |  |  |  |
| Services Received |  |  | 3.16 |  |  |  |  |  |  |
| Trade and other Receivables | 0.40 | 0.39 |  |  |  |  |  |  |  |
| Debit Balances |  |  | 0.40 |  |  |  |  |  |  |
| Trade and Other Payables | 0.11 | 0.10 |  |  |  |  |  |  |  |
| Credit Balances |  |  | 0.10 |  |  |  |  |  |  |
| Service Rendered | 0.06 |  |  |  |  |  |  |  |  |
| Services rendered |  |  | 0.03 |  |  |  |  |  |  |
| Aditya Birla Renewables Solar Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 20 |
| Investments made |  |  |  |  |  |  |  |  | 17 |
| Payables |  |  |  |  |  |  |  |  | 3 |
| Aditya Birla Renewables Subsidiary Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 13 |
| Sales of Goods |  |  |  |  |  |  |  |  | 2 |
| Payables |  |  |  |  |  |  |  |  | 1 |
| Hindalco Superannuation Scheme, Renukoot |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 7.19 |  | 7 |  |  |  |  |
| Hindalco Employees Gratuity Fund, Kolkata |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 13 |  |  |  |  |  |  |
| Aditya Birla Renewables Subsidiary Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investments made during the year |  |  |  |  | 6 |  |  |  |  |
| Purchase of Materials, Capital Equipment and Others |  |  |  |  | 5 |  |  |  |  |
| Credit Balances |  |  |  |  | 1 |  |  |  |  |
| Mr. Kumar Mangalam Birla Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 5.21 | 5.19 |  |  |  |  |  |
| Hindalco Industries Limited Senior Management Staff Pension Fund II |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 4.46 |  | 5 |  |  |  |  |
| Mr. Praveen Maheshwari Key Person |  |  |  |  |  |  |  |  |  |
| Managerial Remuneration |  |  | 3.68 | 4.08 |  |  |  |  |  |
| Vodafone Idea Limited Associate |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  | 3.91 |  |  |  |  |  |
| Interest and dividend received |  |  |  | 0.92 |  |  |  |  |  |
| Services rendered |  |  |  | 0.03 |  |  |  |  |  |
| Aditya Birla Renewables Utkal Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 3 |
| Payables |  |  |  |  |  |  |  |  | 1 |
| Mr. D Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 1.15 | 1.15 |  |  |  |  |  |
| Mr. A.K.Agarwala Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 1.16 | 1.11 |  |  |  |  |  |
| Managing Director Subsidiary |  |  |  |  |  |  |  |  |  |
| Post employment benefits |  |  |  |  |  |  |  | 2 |  |
| Hindalco Industries Limited Office Employees Pension Fund |  |  |  |  |  |  |  |  |  |
| Contribution to Trusts |  |  | 1.09 |  |  |  |  |  |  |
| Hydromine Global Minerals (GMBH) Limited JV |  |  |  |  |  |  |  |  |  |
| Loans, Advances and Deposits | 0.76 | 0.06 |  |  |  |  |  |  |  |
| Loans, Advances and Deposits given | 0.01 | 0.06 |  |  |  |  |  |  |  |
| Mr. M.M. Bhagat Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.23 | 0.24 |  |  |  |  |  |
| Mr. K.N. Bhandari Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.21 | 0.21 |  |  |  |  |  |
| Mr. Y.P. Dandiwala Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.17 | 0.17 |  |  |  |  |  |
| Mr. Jagdish Khattar Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.12 | 0.08 |  |  |  |  |  |
| Smt. Rajashree Birla Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.11 | 0.08 |  |  |  |  |  |
| Mr. Girish Dave Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.07 | 0.10 |  |  |  |  |  |
| Mr. Ram Charan Key Person |  |  |  |  |  |  |  |  |  |
| Directors Remuneration |  |  | 0.03 | 0.09 |  |  |  |  |  |
| Hydromine Global Minerals GMBH Limited JV |  |  |  |  |  |  |  |  |  |
| Receivables |  |  |  | 0.03 |  |  |  |  |  |
| Debit Balances |  |  | 0.03 |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 80,193 | 87,695 | 104,281 | 98,759 | 100,184 | 115,183 | 130,542 | 118,144 | 131,985 | 195,059 | 223,202 | 215,962 |
| Expenses + | 72,494 | 79,671 | 95,437 | 90,981 | 87,867 | 101,488 | 115,031 | 103,838 | 114,449 | 166,712 | 200,536 | 192,090 |
| Operating Profit | 7,699 | 8,024 | 8,844 | 7,778 | 12,317 | 13,695 | 15,511 | 14,306 | 17,536 | 28,347 | 22,666 | 23,872 |
| OPM % | 10% | 9% | 8% | 8% | 12% | 12% | 12% | 12% | 13% | 15% | 10% | 11% |
| Other Income + | 1,111 | 677 | -832 | 1,500 | 1,198 | 2,879 | 1,127 | 906 | -964 | 1,253 | 1,307 | 1,519 |
| Interest | 2,079 | 2,702 | 4,178 | 5,134 | 5,742 | 3,911 | 3,778 | 4,197 | 3,738 | 3,768 | 3,646 | 3,858 |
| Depreciation | 2,822 | 3,347 | 3,493 | 4,347 | 4,457 | 4,506 | 4,777 | 5,091 | 6,628 | 6,729 | 7,086 | 7,521 |
| Profit before tax | 3,909 | 2,653 | 340 | -203 | 3,315 | 8,157 | 8,083 | 5,924 | 6,206 | 19,103 | 13,241 | 14,012 |
| Tax % | 23% | 20% | 75% | 245% | 43% | 25% | 32% | 36% | 44% | 28% | 24% | 28% |
| Net Profit + | 3,007 | 2,195 | 259 | -702 | 1,882 | 6,083 | 5,495 | 3,767 | 3,483 | 13,730 | 10,097 | 10,155 |
| EPS in Rs | 15.81 | 10.53 | 4.14 | -1.21 | 8.47 | 27.10 | 24.48 | 16.77 | 15.50 | 61.10 | 44.93 | 45.19 |
| Dividend Payout % | 6% | 9% | 24% | -82% | 13% | 4% | 5% | 6% | 19% | 6% | 7% | 8% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |

