About
[
edit
]
Incorporated in 1943,RBL Bank is a banking company engaged in providing specialized services under five business verticals namely: Corporate Banking, Commercial Banking, Branch & Business Banking, Retail Assets and Treasury & Financial Markets Operations.
[1]
[2]
Key Points
[
edit
]
Ratios (9MFY24)
Capital Adequacy Ratio - 16.42%
[1]
Net Interest Margin - 5.53%
[2]
Gross NPA - 3.12%
[3]
Net NPA - 0.80%
CASA Ratio - 33.8%
[4]
Branch Network
[5]
The bank operates a network of 538 branches, 388 ATMs and ~1200 business correspondent (microfinance) branches across India. Present in 500 districts and servicing 18,000 pin codes.
Customer Base
[5]
The bank's customer base is above 1.4 Cr across segments. ~6+ lakh customers were added in Q3FY24.
Loan Book 9MFY24
[6]
58% of loan book consists of retail loans the rest 42% consists of wholesale loans
Corporate and Institutional Banking (C&IB) - 31%
Commercial Banking - 11%
Business loans - 9%
Credit Cards - 20%
Personal Loans - 4%
Microfinance - 9%
Housing Loan - 8%
Rural vehicle Finance - 2%
Retail Agri - 2%
Others - 4%
Deposits 9MFY24
[7]
Current Account: 15%
Savings Account: 19%
Term Deposits: 66%
Less than 2cr deposits at 44.5%. 60% of SA and TD acquisition happening digitally.
Exposure 9MFY24
Bank has diversified wholesale loan book with low exposure to a single industry. Top industries with exposure include NBFCs (5.1%), Power (3.9%), Construction (3.5%), Retail/Distribution (3.1%), Engineering (2.3%),  Pharma (2.1%), Metals (1.8%), Auto (1.7%), Professional Services (1.4%) and Cement (1.4%).
[8]
Bank has highest retail loan book exposure in Credit cards (34%) followed by Business Loan (16%), Micro-Banking (15%), Housing Loans (13%), Personal Loans (8%), Other Retail (6%), Agri (4%) and Rural Vehicle Finance (4%).
[9]
5.75 Lakhs credit cards issued in Q3FY24; Total cards outstanding at 50.4 Lakhs.
[10]
Fees Breakup 9MFY24
[11]
Trading- FICC: 6%
Core Fees: 94%
Core Fees Breakup
Processing Fees: 32%
General Banking: 27%
Payment Reated: 22%
FX: 10%
Distribution: 6%
Trade & Others: 4%
Updates
Bank has provided Rs. 115 crore towards contingent provision on AIF investments.
[1]
Future Targets (FY24 - FY26)
[12]
1. Bank wants to grow Advances & Deposits by 20%+ CAGR.
2. Grow granular deposits by 50%+.
3. Average CASA growth of 1.2% p.a.
4. Increase touchpoints to 2600
5. Increase customer count to 2.6 Cr. (Double)
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright
