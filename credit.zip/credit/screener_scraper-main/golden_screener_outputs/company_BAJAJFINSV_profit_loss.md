# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,055 | 6,023 | 11,335 | 20,533 | 24,507 | 32,862 | 42,605 | 54,351 | 60,592 | 68,406 | 82,072 | 110,382 | 118,582 |
| Expenses + | 4,124 | 1,531 | 5,823 | 13,795 | 15,794 | 22,074 | 27,569 | 36,094 | 40,950 | 46,951 | 52,204 | 69,497 | 75,437 |
| Operating Profit | 3,931 | 4,491 | 5,511 | 6,739 | 8,713 | 10,788 | 15,037 | 18,258 | 19,641 | 21,455 | 29,868 | 40,886 | 43,145 |
| OPM % | 49% | 75% | 49% | 33% | 36% | 33% | 35% | 34% | 32% | 31% | 36% | 37% | 36% |
| Other Income + | 2 | 3 | 8 | 0 | 0 | 1 | 2 | 0 | -7 | 8 | 1 | -4 | 9 |
| Interest | 1,204 | 1,562 | 2,230 | 2,877 | 3,716 | 4,531 | 6,657 | 9,500 | 9,274 | 9,629 | 12,380 | 18,607 | 19,971 |
| Depreciation | 22 | 31 | 38 | 58 | 73 | 160 | 226 | 457 | 498 | 563 | 678 | 900 | 965 |
| Profit before tax | 2,708 | 2,902 | 3,251 | 3,804 | 4,925 | 6,099 | 8,155 | 8,302 | 9,862 | 11,271 | 16,811 | 21,375 | 22,218 |
| Tax % | 18% | 24% | 26% | 27% | 30% | 32% | 34% | 28% | 25% | 26% | 27% | 27% |  |
| Net Profit + | 2,214 | 2,191 | 2,409 | 2,775 | 3,450 | 4,176 | 5,374 | 5,994 | 7,367 | 8,314 | 12,210 | 15,595 | 16,095 |
| EPS in Rs | 9.89 | 9.71 | 10.62 | 11.71 | 14.21 | 16.65 | 20.23 | 21.17 | 28.09 | 28.63 | 40.29 | 51.07 | 52.28 |
| Dividend Payout % | 2% | 2% | 2% | 1% | 1% | 1% | 1% | 2% | 1% | 1% | 2% | 2% |  |
| 10 Years: | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Allianz SE Reinsurance, Branch Asia Pacific JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 171 | 432 | 144 |  | 14 | 4.67 | 22 |  |  |  |
| Reinsurance premium paid/payable | 442 | 106 | -4.11 | -9.17 |  |  |  |  |  |  |
| CAT XOL claim recovered | 155 | 18 | 8.09 |  | 2.04 | 0.78 |  |  |  |  |
| Commission on reinsurance received/receivable | 105 | 47 | 2.19 |  |  |  |  |  |  |  |
| CAT XOL premium paid/payable | 12 | 14 | 1.88 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | 29 |  |  | -1.77 |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  | 7.41 | 7.01 | 7.40 |  |  |  |
| Profit commission on reinsurance |  | 5.29 |  |  |  |  |  |  |  |  |
| Balance - Claims recovery on reinsurance | 4.60 |  |  |  |  |  |  |  |  |  |
| Reinsurance profit commssion receivable | 0.91 | 1.74 |  |  |  |  |  |  |  |  |
| CAT XOL premium paid |  |  |  |  | 0.27 | 0.32 | 0.26 |  |  |  |
| Balance - Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -9.17 | -5.50 | 6.96 |  |  |  |
| Bajaj Auto Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  |  |  | 500 |
| Inter-corporate deposit repaid |  |  |  |  |  |  |  |  |  | 500 |
| Fixed deposit repaid |  |  |  |  |  |  | 400 | 100 |  |  |
| Investments held |  | 30 | 35 |  | 36 | 25 | 46 | 46 | 49 | 114 |
| Investment sold | 151 |  |  |  |  |  |  |  |  |  |
| Business support services received | 17 | -0.02 | 21 |  |  |  |  | 27 | 32 | 39 |
| Sale of windpower | 1.67 | 18 | 22 |  | 14 | 15 | 11 | 6.81 | 0.66 |  |
| Insurance premium received by BAGICL/BALICL | 9.29 | 14 | 16 |  | 13 | 12 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 16 |  | 25 | 23 |
| Interest paid on non convertible debentures |  |  |  |  |  |  |  |  | 25 | 25 |
| Interest subsidy | 7.24 | 0.08 | 8.33 |  | 9.85 | 0.04 | 1.72 | 11 | 0.46 | 1.35 |
| Insurance claims paid by BAGICL/BALICL | 7.27 | 19 | 3.14 |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 21 |  |  |
| OA charges reimbursement |  |  |  |  |  |  | 8.14 | 5.20 | 0.52 |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 14 |  |  |
| Bad debts sharing received |  |  |  |  |  |  |  |  | 8.46 | 2.90 |
| Interest accrued on Inter-corporate deposits |  |  |  |  |  |  |  |  | -9.52 | 18 |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.55 |  | 6.75 | 1.06 |
| Dividend income |  |  |  |  | 0.75 | 2.25 |  | 1.75 | 1.75 | 1.75 |
| Business support services rendered | 1.52 | 0.82 | 0.65 |  |  |  | 0.02 | 0.59 | 0.18 | 0.17 |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 2.30 | 1.65 |  |  |  |  |
| Payment towards lease obligation |  |  |  |  |  | 1.06 | 1.29 | 1.34 |  |  |
| Rent and maintenance expenses |  |  |  |  |  |  |  |  | 1.55 | 1.65 |
| Purchase of property, plant and equipment |  |  |  |  |  |  |  |  | 2.27 |  |
| Security deposit paid |  | 0.21 | 0.21 |  | 0.23 | 0.23 | 0.23 | 0.24 | 0.24 | 0.24 |
| Aviation charges paid | 0.54 |  |  |  |  |  |  |  |  |  |
| Revenue expenses reimbursement paid |  |  |  |  |  | 0.10 | 0.08 | 0.04 | 0.05 | 0.04 |
| Balance - Security deposit paid | 0.21 |  |  |  |  |  |  |  |  |  |
| Balance - Interest subsidy | 0.07 |  |  |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  | 0.01 |  |  |  |  |  |
| Inter-corporate deposit accepted |  |  |  |  |  |  |  |  | 500 | 500 |
| Balance - Business support services received | -0.69 |  |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | -0.83 | 0.23 | -0.88 |  |  |  |
| Lease liability recognised at inception |  |  |  |  |  | -1.91 |  |  |  |  |
| Balance - Unallocated premium | -6.46 |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -4.67 | -8.09 |  |  |  |  |
| Fixed deposit interest accrued |  |  |  |  |  | -16 | -10 | 0.90 |  |  |
| Unallocated premium |  | -6.65 | -3.53 |  |  |  | -8.37 | -11 | -12 | 16 |
| Fixed deposit accepted |  |  |  |  |  | 500 | 100 |  |  |  |
| Secured non-convertible debentures issued |  |  |  |  |  |  |  | 500 | 500 |  |
| Mukand Ltd. |  |  |  |  |  |  |  |  |  |  |
| Loan given | 35 | 31 | 34 | 24 | 24 | 25 |  |  |  |  |
| Principal repayment received | 16 | 16 | 22 |  | 18 | 24 | 25 |  |  |  |
| Balance - Loan given | 47 |  |  | 43 |  |  |  |  |  |  |
| Sale of windpower | 40 | 1.99 | 0.63 | 0.29 | 0.29 | 0.44 | 0.52 | 3.87 | 0.25 |  |
| Interest received | 5.59 | 5.14 | 3.63 |  | 4.17 | 4.21 | 1.34 |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 5.85 |  | 7.08 | 5.87 |
| Insurance premium received | 3.97 | 3.85 | 3.61 |  |  |  |  | 6.82 |  |  |
| Security deposit paid |  | 4 | 4 | 4 | 4 | 0.10 | -0.10 |  |  |  |
| Insurance claims paid | 3.07 | 6.98 | 2.13 |  |  |  |  |  |  |  |
| Balance - Security deposit paid | 4 |  |  | 4 |  |  |  |  |  |  |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.98 |  | 4.55 | 1.37 |
| Balance - Sale of windpower | 3.74 |  |  | 1.80 |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 1.02 | 4.18 |  |  |  |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 2.42 |  |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 0.61 | 0.87 |  |  |  |  |
| OA charges reimbursement |  |  |  |  |  |  | 0.55 |  |  |  |
| Rent and other expenses paid | 0.06 | 0.06 | 0.06 |  | 0.06 | 0.05 |  |  |  | 0.24 |
| Balance - Unallocated premium | -0.01 |  |  | -0.02 |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  |  | -0.51 |  |  |  |  |
| Unallocated premium |  | -0.01 | -0.01 |  |  |  | -0.32 | -0.70 | -0.52 | 0.21 |
| Bajaj Allianz Staffing Solutions Ltd. |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges |  | 178 | -3.35 |  |  |  |  | 86 | 98 | 165 |
| Insurance premium received |  | 1.25 | 0.70 |  |  |  |  | 1.30 |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  | 1.30 | 1.65 |
| Business support services received |  |  |  |  |  |  |  | 0.10 | 0.28 | 2.34 |
| Other receipts |  |  |  |  |  |  |  | 0.12 | 0.13 | 0.22 |
| Insurance claim paid |  | 0.43 |  |  |  |  |  |  |  |  |
| Other income |  | 0.20 | 0.12 |  |  |  |  |  |  |  |
| Reimursement of expenses received |  | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Security deposits received |  |  |  |  |  |  |  |  | -0.05 | 0.07 |
| Balance - Unallocated premium |  |  |  | -0.01 |  |  |  |  |  |  |
| Security deposit received |  |  |  |  |  |  |  | -0.05 |  |  |
| Unallocated premium |  | -0.02 | -0.02 | -0.05 |  |  |  | -0.07 | -0.02 | 0.05 |
| AWP P&C SA Saint Ouen Paris JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance paid |  |  |  |  | 104 | 173 | 18 |  |  |  |
| Claims paid on reinsurance accepted |  |  | 0.25 |  | 18 | 72 | 56 |  |  |  |
| Reinsurance premium received/receivable |  |  | -2.40 | 30 |  |  |  |  |  |  |
| Other expenses paid |  |  |  |  |  |  | 5.65 |  |  |  |
| Commission on reinsurance paid/payable |  |  | 4.16 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium received/receivable |  |  |  | -4.58 |  |  |  |  |  |  |
| Reinsurance premium received |  |  |  |  |  |  | -46 |  |  |  |
| Reinsurance premium paid |  |  |  |  | -30 | -17 |  |  |  |  |
| Bajaj Electricals Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 11 |  | 46 | 82 |
| Inter-corporate deposit repaid |  |  |  |  |  |  |  |  |  | 105 |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 7.20 |  | 9.46 | 54 |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 8.41 | 19 |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 22 |  |  |
| Insurance premia received | 4.22 | 4.78 | 5.67 |  |  |  |  |  |  |  |
| Insurance claims paid | 4.98 | 4.46 | 0.52 |  |  |  |  |  |  |  |
| Insurance claims paid by |  |  |  |  |  |  |  | 6.54 |  |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 1.58 | 4.09 |  |  |  |  |
| Interest accrued on Inter-corporate deposits |  |  |  |  |  |  |  |  | -0.48 | 1.46 |
| Purchases | 0.34 | -0.01 | 0.20 | -0.06 | -0.06 |  |  |  |  |  |
| Interest subsidy |  |  |  |  |  | 0.03 | 0.02 | 0.02 | 0.07 | 0.06 |
| Purchase of property, plant and equipment |  |  |  |  |  | -0.08 | -0.12 | 0.01 | 0.20 | 0.19 |
| Other expenses |  |  |  |  |  |  | 0.03 |  |  |  |
| Balance - Purchases |  |  |  | 0.01 |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.09 |  |  | -4.79 |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -0.13 | -6.22 |  |  |  |  |
| Inter-corporate deposit accepted |  |  |  |  |  |  |  |  | 70 | 60 |
| Unallocated premium |  | -0.12 | -0.05 | -0.13 |  |  | -6.67 | -7.62 | -7.86 | 12 |
| Bajaj Allianz Financial Distributors Ltd. |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges | 222 | 67 |  |  |  |  |  |  |  |  |
| Services received | 0.36 | 0.39 | 0.53 |  | 1.05 | 1.76 |  | 1.94 | 2.06 | 2.64 |
| Insurance commission paid/payable | 12 | -0.75 | -0.59 | -1.74 |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | 1.20 | 1.20 |  |  | 1.20 | 1.20 |
| Contribution to Equity |  |  |  | 1.20 |  |  |  | 1.20 |  |  |
| Balance - Contribution to Equity | 1.20 |  |  | 1.20 |  |  |  |  |  |  |
| Contribution to Equity (12,00,000 shares of H 10 each) |  | 1.20 | 1.20 |  |  |  |  |  |  |  |
| Insurance commission paid by BAGIC/BALIC |  |  |  |  |  |  |  | 0.08 | 0.44 | 1.20 |
| Insurance premium received | 0.24 | 0.06 | 0.09 |  |  |  |  | 0.02 |  |  |
| Rental income | 0.28 | 0.05 | 0.04 |  |  |  |  |  |  |  |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 0.11 | 0.10 |  |  |  |  |
| Insurance claim paid |  | 0.16 |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  | 0.04 | 0.06 |
| Benefits paid | 0.03 | 0.02 |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | 0.03 |  |  |  |  |  |
| Unallocated premium |  | -0.01 | -0.05 |  |  |  |  |  | -0.04 | 0.12 |
| Reimursement of expenses received |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  |  | -0.01 |  |  |  |  |
| Security deposit received |  |  |  |  |  | -0.01 |  | -0.01 |  |  |
| Balance - Services received | -0.03 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | 0.01 |  |  | -0.07 |  |  |  |  |  |  |
| Balance - Manpower supply charges | -0.07 |  |  |  |  |  |  |  |  |  |
| Insurance commission paid by BAGICL/BALICL |  |  |  |  | -1.74 | -1.29 |  |  |  |  |
| Balance - Insurance commission paid/payable | -0.65 |  |  | -3.68 |  |  |  |  |  |  |
| Pennant Technologies Pvt. Ltd |  |  |  |  |  |  |  |  |  |  |
| Investment in compulsorily convertible preference shares (Deemed equity) |  |  |  |  |  |  |  |  |  | 154 |
| Investment in equity shares |  |  |  |  |  |  |  |  |  | 114 |
| Information technology design and development charges |  |  |  |  |  |  |  |  |  | 12 |
| Annual maintenance charges paid |  |  |  |  |  |  |  |  |  | 0.82 |
| Bajaj Allianz Staffing Solutions Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Manpower supply charges |  |  |  |  | 103 | 0.01 | 93 |  |  |  |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 1.01 | 0.01 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 1 |  |  |  |
| Business support charges received |  |  |  |  |  | 0.11 | 0.08 |  |  |  |
| Other receipts |  |  |  |  |  |  | 0.11 |  |  |  |
| Claims paid |  |  |  |  |  | 0.05 | 0.05 |  |  |  |
| Unallocated premium |  |  |  |  |  |  | -0.05 |  |  |  |
| Superannuation contribution |  |  |  |  | -0.05 | -0.02 |  |  |  |  |
| Security deposit received |  |  |  |  |  | -0.05 | -0.05 |  |  |  |
| Snapwork Technologies Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Investment in compulsorily convertible preference shares (Deemed equity) |  |  |  |  |  |  |  |  | 64 | 64 |
| Investment in equity shares |  |  |  |  |  |  |  |  | 28 | 28 |
| Information technology design and development charges |  |  |  |  |  |  |  |  | 5.61 | 0.83 |
| Support charges |  |  |  |  |  |  |  |  |  | 0.48 |
| Allianz Global Corporate & Speciality SE, Munich JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 36 | 13 | 48 |  |  |  |
| Reinsurance premium paid/payable |  |  |  | 20 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | 20 | -3.19 | -2.51 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.22 |  | 0.12 |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.03 |  |  |  |  |  |  |
| Billable expenses incurred on behalf |  |  |  | -0.03 | -0.03 |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.28 |  |  |  |  |  |  |
| Allianz Global Risks US Insurance Company JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  | 0.18 |  | 0.01 | 45 | 98 |  |  |  |
| Commission on reinsurance premium | 0.06 | 0.10 | 0.22 |  | 0.02 | 18 | 20 |  |  |  |
| Reinsurance premium paid/payable | 0.53 | 0.16 | -0.29 | -0.04 |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.44 |  |  | -0.03 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.04 | -38 | -15 |  |  |  |
| Bajaj Auto Senior staff Group Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Gratuity contribution |  |  |  |  | 23 | 29 | 4.80 | 22 | 25 | 23 |
| Allianz Global Corporate & Speciality SE - France Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 93 | 1.40 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 3.14 | 1.71 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -9.15 | -9.48 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE Munich Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 59 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 18 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 12 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -8.67 |  |  |  |  |  |  |  |  |  |
| Bajaj Auto Employees Group Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Gratuity contribution |  |  |  |  | 6.02 | 14 | 15 | 14 | 14 | 14 |
| Sanjiv Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  |  |  | 91 |  |  |
| Post-employment benefits |  |  |  |  | 0.63 | 0.91 | 0.91 | 1.26 | 1.63 | 2.04 |
| Deposit paid |  |  |  | 0.39 | 0.39 | 0.41 | 0.41 | 1.08 | 1.08 | 1.08 |
| Remuneration | 1.37 | 1.46 | 1.54 |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  | 0.33 | 0.41 | 0.43 | 0.77 | 1.10 | 1.15 |
| Sitting fees |  | 0.09 | 0.09 |  | 0.09 | 0.22 | 0.25 | 0.42 | 0.37 | 0.39 |
| Sitting Fees | 0.09 |  |  |  |  |  |  |  |  |  |
| Brokerage |  |  |  |  |  |  |  | 0.01 |  |  |
| Short-term employee benefits (including commission) |  |  |  |  |  |  |  | -11 | -14 | 24 |
| Balance - Commission | -2.90 |  |  |  |  |  |  |  |  |  |
| Balance - Short-term employee benefits (including Commission) |  |  |  | -3.57 |  |  |  |  |  |  |
| Commission | 2.90 | -3.24 | -3.42 |  |  |  |  |  |  |  |
| Short-term employee benefits (including Commission) |  |  |  | -5.46 | -5.46 | -7.39 | -8.04 |  |  |  |
| Allianz Risk Transfer AG Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 29 | 33 | -0.03 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.27 | 0.78 | 0.36 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 0.14 |  |  | 0.50 |  |  |  |  |  |
| Bajaj Auto Ltd |  |  |  |  |  |  |  |  |  |  |
| Investments held |  |  |  | 36 |  |  |  |  |  |  |
| Balance - Investments held |  |  |  | 34 |  |  |  |  |  |  |
| Balance - Interest subsidy |  |  |  | 1.87 |  |  |  |  |  |  |
| Security deposit paid |  |  |  | 0.23 |  |  |  |  |  |  |
| Balance - Security deposit paid |  |  |  | 0.21 |  |  |  |  |  |  |
| Balance - Business support services rendered |  |  |  | 0.03 |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.56 |  |  |  |  |  |  |
| Business support services received |  |  |  | -0.83 |  |  |  |  |  |  |
| Balance - Unallocated premium |  |  |  | -3.24 |  |  |  |  |  |  |
| Unallocated premium |  |  |  | -4.67 |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE Munich Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 15 | 44 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 8.74 | 10 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -7.39 | -11 |  |  |  |  |  |  |  |
| Rajeev Jain Individual |  |  |  |  |  |  |  |  |  |  |
| Fair value of stock options granted |  |  |  |  | 11 | 13 | 16 |  |  |  |
| Equity shares issued pursuant to stock option scheme |  |  |  |  | 2.19 | 1.65 | 8.11 |  |  |  |
| ESOPs exercised | 2.86 |  |  |  |  |  |  |  |  |  |
| Remuneration | 5.14 |  |  | -6.36 | -6.36 | 11 | -1.50 |  |  |  |
| Brokerage and service charges received |  |  |  |  |  | 0.03 | 0.09 |  |  |  |
| Balance - Remuneration | -2.28 |  |  | -5.16 |  |  |  |  |  |  |
| AWP Services India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  |  |  |  | 17 | 10 | 18 |  |  |  |
| Claim assisstance fee paid |  |  |  |  | 3.17 |  |  |  |  |  |
| Balance - Other expenses paid/payable |  |  |  | -0.36 |  |  |  |  |  |  |
| Other expenses paid/payable |  |  |  | -2.65 |  |  |  |  |  |  |
| Other expenses paid |  |  |  |  | -2.65 | -0.44 | -0.01 |  |  |  |
| AGA Services (India) Private Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  | 13 | 24 |  |  |  |  |  |  |  |
| Claim assisstance fee paid |  | 2.59 | 3.22 |  |  |  |  |  |  |  |
| Other expenses paid/payable |  | -0.13 | -1.07 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE -France Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 24 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 23 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 2.15 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -9.72 |  |  |  |  |  |  |  |  |  |
| Tapan Singhel Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 3.83 |  |  |  | 9.68 | 12 | 13 |  |  |  |
| AWP Assistance India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid |  |  |  |  | 7.75 | 8.19 | 9.69 |  |  |  |
| Claim assisstance fee paid |  |  |  |  | 5.01 |  |  |  |  |  |
| Benefits paid |  |  |  |  | 3.36 |  |  |  |  |  |
| Insurance commission paid |  |  |  |  | -0.12 | 1.24 | 0.30 |  |  |  |
| Billable expenses incurred on behalf |  |  |  | 0.03 | 0.03 | 0.01 | 0.01 |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | 0.03 |  |  |  |  |  |  |
| Insurance commission paid/payable |  |  |  | -0.12 |  |  |  |  |  |  |
| Balance - Insurance commission paid/payable |  |  |  | -0.20 |  |  |  |  |  |  |
| Balance - Premium received as an agent |  |  |  | -0.32 |  |  |  |  |  |  |
| Premium received as an agent |  |  |  | -0.69 | -0.69 | -0.10 | -0.07 |  |  |  |
| Allianz Global Corporate & Speciality AG, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 2.31 | 28 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 2.94 | 1.42 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -1.11 | -0.79 | 1.51 |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.79 |  |  |  |  |  |  |
| Euler Hermes Deutschland Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 4.22 | 10 | 0.04 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 9.24 | -0.16 | 0.18 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 1.69 | 1.51 |  |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf | 0.85 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.44 |  |  | 0.96 |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 2.48 | 0.99 | 0.54 | -1.85 | -1.85 |  |  |  |  |  |
| Tarun Chugh Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  | 8.45 | 9.86 | 8.22 |  |  |  |
| Euler Hermes Europe, Singapore Branch JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 1.10 | 2.43 |  | 3.78 | 3.93 | 4.21 |  |  |  |
| Commission on reinsurance received/receivable | 0.78 | 2.27 | 1.47 |  |  |  |  |  |  |  |
| Billable expenses recovery |  |  |  |  |  | 2.50 | 2 |  |  |  |
| Other receivables |  |  |  |  |  | 0.40 | 2.07 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.72 | 0.70 | 1.02 |  |  |  |
| Reinsurance premium paid |  |  |  |  | 1.21 | 1.27 | -2.19 |  |  |  |
| Balance - Reinsurance premium paid/payable | -3.09 |  |  | -0.57 |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 3.87 | -4.04 | -4.75 | 1.21 |  |  |  |  |  |  |
| AGA Services (India) Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 20 |  |  |  |  |  |  |  |  |  |
| Other expenses paid/payable | 1.25 |  |  |  |  |  |  |  |  |  |
| Fees received for loss minimisation activity | 0.19 |  |  |  |  |  |  |  |  |  |
| Balance - Other expenses paid/payable | -0.33 |  |  |  |  |  |  |  |  |  |
| Bajaj Allianz Life Insurance Co Ltd Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  |  | 16 |  |  |
| Manish Kejriwal Individual |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  |  | 15 |  |
| Interest paid on non convertible debentures |  |  |  |  |  |  |  |  | 1.07 |  |
| Sitting fees |  |  |  |  | 0.01 | 0.03 | 0.13 | 0.15 | 0.13 | 0.10 |
| Commission |  |  |  | -0.01 | -0.01 | -0.05 | -0.20 | -0.29 | -0.26 | 0.30 |
| Bajaj Allianz Life Insurance Co. Ltd. - Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  | 7.22 | 7.13 |  |  |  |  |
| Allianz Global Corporate and Speciality AG, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 11 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 3.65 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.55 |  |  |  |  |  |  |  |  |  |
| Risk survey fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Risk survey fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -2.10 |  |  |  |  |  |  |  |  |  |
| AGCS Marine Insurance Company Associate |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.99 | 2.38 | 5.51 |  | 0.03 |  |  |  |  |  |
| Reinsurance premium paid/payable | 2.49 | -1.66 | 1.27 | 0.03 | 0.03 |  |  |  |  |  |
| Commission on reinsurance premium | 0.65 | 0.77 | 0.61 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | 0.22 |  |  | 0.05 |  |  |  |  |  |  |
| Poddar Housing and Development Ltd. |  |  |  |  |  |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | 13 |  |  |  |
| Interest Income |  |  |  |  |  |  | 0.02 |  |  |  |
| Hind Musafir Agency Ltd. |  |  |  |  |  |  |  |  |  |  |
| Services received | 23 | -0.78 | -2.25 | -3.18 | -3.18 | -0.41 | -0.04 | -0.17 | -0.20 | 1.33 |
| Service charges paid |  |  |  |  | 0.29 | 0.40 | 0.06 | 0.13 | 0.35 |  |
| Advances |  |  |  |  |  | 0.09 | 0.06 |  | 0.01 |  |
| Other expenses paid/payable | 0.11 | 0.01 |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.02 | 0.03 |  |  |  |  |
| Insurance claims paid |  | 0.01 |  |  |  |  |  |  |  |  |
| Balance - Other expenses paid/payable | -0.01 |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.01 | 0.02 | 0.02 |  |  |  |  | -0.22 |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.04 |  | -3.76 | 2.04 |
| Balance - Services received | -0.46 |  |  | -1.70 |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE, UK JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 12 |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  | -0.01 | 0.01 | 0.02 |  |  |  |
| Reinsurance premium paid |  |  |  |  | 1.51 | -1.36 | -0.23 |  |  |  |
| Allianz CP General Ins Co. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claims paid/payable | 9.65 | 0.53 |  |  |  |  |  |  |  |  |
| Software consultancy fees |  | 0.97 |  |  |  |  |  |  |  |  |
| AGA Assistance (India) Private Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claim assisstance fee paid |  | 4.99 | 3.93 |  |  |  |  |  |  |  |
| Insurance claims paid |  | 1.19 | 1.16 |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf |  | 0.08 | 0.07 |  |  |  |  |  |  |  |
| Unallocated premium |  |  | 0.02 |  |  |  |  |  |  |  |
| Insurance premium received |  |  | 0.01 |  |  |  |  |  |  |  |
| Insurance commission paid/payable |  | -0.04 | -0.06 |  |  |  |  |  |  |  |
| Premium received as an agent |  | -0.05 | -0.23 |  |  |  |  |  |  |  |
| Atul Jain Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 7.51 |  |  |  |
| Fair value of stock options granted |  |  |  |  |  |  | 3.23 |  |  |  |
| Tapan Singhel (MD and CEO - BAGICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 4.01 | 4.99 |  |  |  |  |  |  |  |
| AGA Assistance (India) Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 7.44 |  |  |  |  |  |  |  |  |  |
| Insurance commission paid/payable | 0.54 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.19 |  |  |  |  |  |  |  |  |  |
| Balance - Premium received as an agent | 0.02 |  |  |  |  |  |  |  |  |  |
| Balance - Insurance commission paid/payable | -0.05 |  |  |  |  |  |  |  |  |  |
| Anuj Agarwal (MD and CEO - BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 2.49 | 4.25 |  |  |  |  |  |  |  |
| Bajaj Auto Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | 0.92 | 1.06 | 0.99 | 1.11 | 1.31 | 1.21 |
| Allianz Technlogy SE, India JV |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  | 0.01 | 0.01 | 6.39 |  |  |  |
| Euler Hermes Services India Pvt Ltd. |  |  |  |  |  |  |  |  |  |  |
| Credit risk assessment fees paid |  | 2.11 | -0.17 |  | 2.06 | 2.21 |  |  |  |  |
| Bajaj Allianz Life Insurance Co Ltd. Employees |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  |  |  |  |  |  | 5.79 |  |  |  |
| Allianz Global Corporate & Speciality AG Singapore JV |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | 0.49 | 0.73 | 1.06 |  |  |  |
| Claim recovery on reinsurance |  |  | 0.24 |  | 0.66 | 0.28 | 0.59 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.90 | 0.02 |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.21 | 0.18 |  |  |  |  |  |  |  |
| Risk survey fee |  | 0.18 |  |  |  |  |  |  |  |  |
| Billable expenses reimbursed on behalf |  |  | 0.03 | 0.05 | 0.05 |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.16 | -0.30 | 0.49 |  |  |  |  |  |  |
| Reinsurance premium received/receivable |  | 0.02 |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.45 |  |  |  |  |  |  |
| Indian School of Business |  |  |  |  |  |  |  |  |  |  |
| Training expenses |  |  |  |  |  |  |  |  | 1.39 | 3.21 |
| Reimbursement of expenses paid |  | 0.30 |  |  |  |  |  |  |  |  |
| Jamnalal Sons Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Rent and other expenses |  | 0.08 | 0.22 |  | 0.70 | 0.31 |  | 0.87 |  |  |
| Security deposit |  | 0.09 | 0.09 |  | 0.29 | 0.29 |  | 0.32 | 0.26 | 0.14 |
| Rent and other expenses paid |  |  |  |  |  |  |  |  | 0.61 | 0.37 |
| Dividend paid |  |  |  |  |  |  |  | -0.03 | 0.26 | 0.38 |
| Payment towards lease obligation |  |  |  |  |  | 0.34 |  |  |  |  |
| Security deposit received |  |  |  |  |  |  |  |  |  | 0.13 |
| Interest expense on lease obligation |  |  |  |  |  | 0.10 |  |  |  |  |
| Revenue expenses reimbursement received |  |  |  |  |  |  |  |  | 0.05 | 0.03 |
| Contribution to equity |  |  |  |  |  | -0.03 |  |  | -0.03 | 0.03 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.03 |  |  |
| Lease liability recognised at inception |  |  |  |  |  | -0.97 |  |  |  |  |
| Bajaj Allianz Financial Distributors Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Insurance commission paid by BAGIC/BALIC |  |  |  |  |  |  | 1.72 |  |  |  |
| Services received |  |  |  |  |  |  | 1.72 |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | 1.20 |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.01 |  |  |  |
| Security deposit received |  |  |  |  |  |  | -0.01 |  |  |  |
| Unallocated premium |  |  |  |  |  |  | -0.01 |  |  |  |
| Mukand Engineers Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.35 | 0.26 | 0.35 |  |  |  |  | 0.50 |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.73 | 0.51 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.72 |  | 0.05 |  |
| Insurance claims paid by BAGIC/BALICL |  |  |  |  | 0.33 | 0.26 |  |  |  |  |
| Insurance claims paid | 0.21 | 0.12 | 0.11 |  |  |  |  |  |  |  |
| Annual maintenance charges paid |  |  |  |  |  |  |  |  |  | 0.43 |
| Insurance claims paid by |  |  |  |  |  |  |  | 0.10 |  |  |
| Insurance claims paid by BAGIC/BALIC |  |  |  |  |  |  | 0.10 |  |  |  |
| Balance - Insurance claims paid | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.01 |  |  |  |  |  |  |  |  |  |
| Superannuation contribution |  |  |  |  | -0.01 | -0.30 |  |  |  |  |
| Unallocated premium |  | -0.13 | -0.01 |  |  |  | -0.08 | -0.14 |  |  |
| Allianz Global Corporate and Speciality AG Singapore Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium received/receivable | 2.55 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.62 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium received/receivable | 0.55 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance premium | 0.28 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.21 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.08 |  |  |  |  |  |  |  |  |  |
| Risk survey fee | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Risk survey fee | -0.04 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.23 |  |  |  |  |  |  |  |  |  |
| Euler Hermes Services India Pvt. Ltd. JV |  |  |  |  |  |  |  |  |  |  |
| Credit risk assessment fees paid | 1.89 |  |  |  |  |  | 1.99 |  |  |  |
| Sanjali Family Trust |  |  |  |  |  |  |  |  |  |  |
| Rent paid |  |  |  |  |  | 0.14 | 0.55 | 0.57 | 0.60 | 0.63 |
| Security deposit paid |  |  |  |  |  | 0.14 | 0.14 | 0.14 | 0.14 | 0.14 |
| Revenue expenses reimbursement received |  |  |  |  |  | 0.03 | 0.07 | 0.08 | 0.09 | 0.09 |
| Allianz Global Corporate & Speciality SE, France JV |  |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  | 3.50 | 0.10 | 0.06 |  |  |  |
| Commission on reinsurance received |  |  |  |  | 0.02 | 0.01 |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.61 | -0.39 |  |  |  |  |
| Shefali Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Deposit paid |  |  |  |  |  |  |  | 0.41 | 0.41 | 0.41 |
| Rent paid |  |  |  |  |  |  |  | 0.04 | 0.48 | 0.50 |
| Allianz Investment Management Singapore Pte. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Data provision charges | 3.18 | -0.33 | -0.33 |  |  |  |  |  |  |  |
| Investment management | 0.32 | -0.06 | -0.06 |  |  |  |  |  |  |  |
| Balance - Investment management | -0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Data provision charges | -0.72 |  |  |  |  |  |  |  |  |  |
| Anuj Agarwal Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 1.79 |  |  |  |  |  |  |  |  |  |
| Anami Roy Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.01 | 0.13 | 0.17 | 0.39 | 0.43 | 0.60 |
| Commission |  |  |  | -0.01 | -0.01 | -0.23 | -0.24 | -0.60 | -0.67 | 1.73 |
| Allianz Risk Transfer N.V. Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.60 | 0.91 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  |  | 0.04 |  |  |  |  |  |  |  |
| Pramit Jhaveri Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  |  | 0.08 | 0.29 | 0.40 |
| Commission |  |  |  |  |  |  |  | -0.18 | -0.62 | 1.34 |
| Allianz Belgium Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.47 | 0.37 | -0.12 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.67 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.05 | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Claim recovery on reinsurance |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.28 |  |  | 0.06 |  |  |  |  |  |  |
| Hercules Hoists Ltd. |  |  |  |  |  |  |  |  |  |  |
| Fixed deposits repaid | 3 | 14 | 6.70 |  |  |  |  |  | 6.50 |  |
| Interest paid on fixed deposits | 0.29 | 1.72 | 0.97 |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 0.03 | 0.04 | 0.09 |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.09 | 0.11 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.05 |  |  |
| Interest accrued on fixed deposits | 1.27 | -0.50 | -0.23 |  |  | -0.09 | -0.58 | -1.09 | 0.51 |  |
| Balance - Interest accrued on fixed deposits | -1.27 |  |  |  |  |  |  |  |  |  |
| Fixed deposit accepted |  |  |  |  |  |  | -6.50 |  |  |  |
| Fixed deposits accepted | 14 | -8.37 | -1.67 |  |  | -6.50 |  | -6.50 |  |  |
| Balance - Fixed deposits accepted | -14 |  |  |  |  |  |  |  |  |  |
| Radhika Haribhakti Individual |  |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  |  |  | -0.34 | 1.03 |
| Sitting fees |  |  |  |  |  |  |  |  | 0.16 | 0.31 |
| Dr. Arindam Kumar Bhattacharya Individual |  |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  |  |  |  | 0.76 |
| Sitting fees |  |  |  |  |  |  |  |  |  | 0.32 |
| Allianz Elementar Versicherungs - Austria Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.30 | 0.02 | 0.12 |  |  |  |  |  |  |  |
| Claim recovery on reinsurance |  | 0.26 | 0.14 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.08 | 0.06 | 0.09 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.15 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.17 |  |  |  |  |  |  |  |  |  |
| Bajaj Finserv Charitable Trust |  |  |  |  |  |  |  |  |  |  |
| CSR payment |  |  |  |  | 0.25 | 0.25 |  |  | 0.50 |  |
| Bajaj Auto Credit Ltd. |  |  |  |  |  |  |  |  |  |  |
| Asset sales |  |  |  |  |  |  |  |  |  | 0.94 |
| Allianz Global Corporate & Speciality SE, Switzerland Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.62 |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.22 |  |  |  |  |  |  |  |  |
| Baroda Industries Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 0.24 | 0.35 |
| Divdend paid |  |  |  |  |  |  |  | 0.12 |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.02 | 0.02 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.02 |  |  |
| Allianz Global Corporate & Speciality AG, Spain Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.30 | 0.24 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.06 | 0.06 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Denmark - Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.58 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.01 |  |  |  |  |  |  |  |  |  |
| Dr. Naushad Forbes Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 | 0.17 | 0.24 | 0.30 | 0.33 | 0.37 |
| Commission |  |  |  |  | -0.05 | -0.30 | -0.40 | -0.62 | -0.70 | 1.21 |
| Allianz Managed Operations and Services SE Associate |  |  |  |  |  |  |  |  |  |  |
| Paid towards opus revenue expenditure | 4.02 |  |  |  |  |  |  |  |  |  |
| License and Maintenance fees paid | 1.01 |  |  |  |  |  |  |  |  |  |
| SAS license fees | 0.20 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.08 |  |  |  |  |  |  |  |  |  |
| Income from software consultancy | 0.04 |  |  |  |  |  |  |  |  |  |
| Balance - SAS license fees | -2.09 |  |  |  |  |  |  |  |  |  |
| Balance - Paid towards opus revenue expenditure | -2.67 |  |  |  |  |  |  |  |  |  |
| Jamnalal Sons Pvt. Ltd |  |  |  |  |  |  |  |  |  |  |
| Security deposit |  |  |  | 0.29 |  |  |  |  |  |  |
| Balance - Security deposit |  |  |  | 0.29 |  |  |  |  |  |  |
| Chetak Technology Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  |  |  |  | 0.53 |
| Unallocated premium |  |  |  |  |  |  |  |  |  | 0.04 |
| Late D J Balaji Rao Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  |  |  | 0.21 | 0.17 |
| Commission |  |  |  |  |  |  |  |  | -0.44 | 0.58 |
| Bachhraj Factories Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 0.14 | 0.22 |
| Divdend paid |  |  |  |  |  |  |  | 0.07 |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.01 | 0.01 |
| Contribution to Equity |  |  |  |  |  |  |  | -0.01 |  |  |
| Allianz Insurance Lanka Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Claims paid on reinsurance accepted |  | 0.23 |  |  |  |  |  |  |  |  |
| Reinsurance premium received/receivable | 0.08 | -0.07 | 0.09 |  |  |  |  |  |  |  |
| Commission on reinsurance paid/payable | 0.02 |  | 0.02 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Netherlands Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.22 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.10 |  |  |  |  |  |  |  |  |  |
| Hind Lamps Ltd. |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received by BAGIC/BALICL |  |  |  |  | 0.15 | 0.15 |  |  |  |  |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.04 |  |  |  |
| Balance - Unallocated premium |  |  |  | -0.05 |  |  |  |  |  |  |
| IDS Gmbh Associate |  |  |  |  |  |  |  |  |  |  |
| Legal and professional charges | 0.31 | 0.04 |  |  |  |  |  |  |  |  |
| Balance - Legal and professional charges | -0.07 |  |  |  |  |  |  |  |  |  |
| Allianz Australia Insurance Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | 0.14 | 0.07 |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.03 | 0.02 |  |  |  |  |  |  |  |
| Jamnalal Sons Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Security deposit |  |  |  |  |  |  | 0.29 |  |  |  |
| Rent and other expenses |  |  |  |  |  |  | -0.02 |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.03 |  |  |  |
| Allianz Global Corporate & Speciality SE, Netherlands Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.08 | 0.09 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  |  | 0.04 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.01 | 0.04 |  |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE France Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | 0.82 |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  |  |  | -0.61 |  |  |  |  |  |  |
| Centre for Technology Innovation and Economic Research |  |  |  |  |  |  |  |  |  |  |
| Corporate social responsibility expenses |  |  |  |  |  |  | 0.20 |  |  |  |
| Allianz Managed Operations and Services SE India Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance claims paid | 0.15 |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.06 |  |  |  |  |  |  |  |  |  |
| Balance - Unallocated premium | -0.06 |  |  |  |  |  |  |  |  |  |
| Lila Poonawala (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 | 0.07 |  |  |  |  |  |  |  |
| Sanjali Bajaj Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.09 |  |  |
| Allianz Insurance Management Asia Pacific Pte. JV |  |  |  |  |  |  |  |  |  |  |
| Paid towards revenue expenditure | 0.06 | 0.02 | 0.01 |  | 0.01 |  |  |  |  |  |
| Billable expenses incurred reversed |  |  |  |  |  |  | 0.04 |  |  |  |
| Reimbursement received of revenue expenditure |  | 0.01 | 0.03 |  |  |  |  |  |  |  |
| Billable expenses recovered on behalf |  | 0.01 |  |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred | -0.01 |  |  |  |  |  |  |  |  |  |
| Billable expenses incurred | 0.01 | 0.01 | -0.03 |  | -0.04 | -0.04 |  |  |  |  |
| Allianz Marine and Aviation Versicherungs AG Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.04 |  |  |  |  |  |  |  |  |  |
| Claims recovery on reinsurance | 0.04 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Allianz Global Corporate & Speciality SE, Italy JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.14 | 0.11 |  |  |  |  |  |  |  |
| Claims recovery on reinsurance |  | 0.06 | 0.03 |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  | 0.01 | 0.01 |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.06 |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.01 | -0.01 | -0.06 |  |  |  |  |  |  |
| Reinsurance premium paid |  |  |  |  | -0.06 | -0.08 |  |  |  |  |
| Allianz Global Corporate & Speciality SE, Denmark - Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable |  | 0.21 | 0.14 |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable |  | -0.26 | -0.01 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality AG, Spain Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.09 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.02 |  |  |  |  |  |  |  |  |  |
| Lila Poonawala Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  | 0.07 |  |  |  |
| Sanjay Asher (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 | 0.03 |  |  |  |  |  |  |  |
| Nanoo Pamnani (Vice Chairman - BFL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees and expenses |  | 0.01 | 0.06 |  |  |  |  |  |  |  |
| S Rs. Khan Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.07 |  |  |  |  |  |  |  |  |  |
| Suraj Mehta (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.03 | 0.03 |  |  |  |  |  |  |  |
| Manu Tandon (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.03 | 0.01 |  |  |  |  |  |  |  |
| Late S H Khan (Director-BALICL) Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.04 |  |  |  |  |  |  |  |  |
| Sanjay Asher Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.04 |  |  |  |  |  |  |  |  |  |
| Insurance Joint Stock Company Allianz Russia Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.02 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Allianz Hongkong Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.02 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.01 |  |  |  |  |  |  |  |  |  |
| Manu Tandon Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.03 |  |  |  |  |  |  |  |  |  |
| Suraj Mehta Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees | 0.02 |  |  |  |  |  |  |  |  |  |
| Hindustan Housing Co. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  |  | 0.01 |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.01 | 0.01 |
| Mukand Engineers Ltd |  |  |  |  |  |  |  |  |  |  |
| Unallocated premium |  |  |  | 0.01 |  |  |  |  |  |  |
| Allianz Global Assistance Australia Associate |  |  |  |  |  |  |  |  |  |  |
| Billable expenses recovered on behalf |  | 0.01 |  |  |  |  |  |  |  |  |
| Allianz Managed Operations & Services SE India Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  | 0.06 | 0.03 |  |  |  |  |  |  |  |
| Insurance claims paid |  | 0.01 |  |  |  |  |  |  |  |  |
| Unallocated premium |  | -0.07 | -0.03 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE - Malaysia Associate |  |  |  |  |  |  |  |  |  |  |
| Billabale expenses | 0.01 |  |  |  |  |  |  |  |  |  |
| Balance - Billabale expenses | -0.01 |  |  |  |  |  |  |  |  |  |
| Bachhraj Factories Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.01 |  |  |  |
| Denmark Nordic Region Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.01 |  |  |  |  |  |  |
| Baroda Industries Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  | -0.02 |  |  |  |
| Allianz Global Corporate and Speciality SE, Switzerland Associate |  |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.27 |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.11 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.40 |  |  |  |  |  |  |  |  |  |
| M/s. Allianz Risk Transfer AG Associate |  |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable |  |  |  | -0.04 |  |  |  |  |  |  |
| Devang Mody Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | -0.05 |  |  |  |
| Allianz Insurance Management Asia Associate |  |  |  |  |  |  |  |  |  |  |
| Paid towards revenue expenditure |  |  |  | 0.01 |  |  |  |  |  |  |
| Balance - Paid towards revenue expenditure |  |  |  | 0.01 |  |  |  |  |  |  |
| Billable expenses incurred |  |  |  | -0.04 |  |  |  |  |  |  |
| Balance - Billable expenses incurred |  |  |  | -0.04 |  |  |  |  |  |  |
| Rajiv Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.06 | 0.06 |  | 0.07 | 0.10 | 0.11 | 0.10 | 0.12 | 0.12 |
| Sitting Fees | 0.06 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.06 |  |  | -0.08 |  |  |  |  |  |  |
| Commission | 0.06 | -0.08 | -0.09 | -0.09 | -0.09 | -0.18 | -0.19 | -0.21 | -0.26 | 0.40 |
| Naushad Forbes Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.03 |  |  |  |  |  |  |
| Commission |  |  |  | -0.05 |  |  |  |  |  |  |
| Late Naresh Chandra Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.08 |  |  |  |  |  |  |
| Allianz Cornhill Information Services Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received | 0.01 | 0.05 | 0.03 |  |  |  |  |  |  |  |
| Unallocated premium |  |  | -0.17 |  |  |  |  |  |  |  |
| Rajeev Jain (CEO - BFL) Key Person |  |  |  |  |  |  |  |  |  |  |
| ESOPs exercised |  | 7.10 |  |  |  |  |  |  |  |  |
| Medical reimbursement |  | 0.22 |  |  |  |  |  |  |  |  |
| Remuneration |  | -3.03 | -4.37 |  |  |  |  |  |  |  |
| Dr. Omkar Goswami Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  |  |  | 0.21 |  |  |  |
| Commission |  |  |  |  |  |  | -0.31 |  |  |  |
| Rahul Bajaj (Chairman) Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.11 | 0.08 |  |  |  |  |  |  |  |
| Commission |  | -0.17 | -0.13 |  |  |  |  |  |  |  |
| Allianz Global Corporate and Speciality SE, Italy Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received/receivable | 0.11 |  |  |  |  |  |  |  |  |  |
| Reinsurance premium paid/payable | 0.10 |  |  |  |  |  |  |  |  |  |
| Balance - Reinsurance premium paid/payable | -0.34 |  |  |  |  |  |  |  |  |  |
| Ashwin Vijaykumar Jain Relative |  |  |  |  |  |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | -0.15 |  |  |  |
| Rajendra Lakhotia Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 |  |  |  |  |  |
| Balance - Commission |  |  |  | -0.10 |  |  |  |  |  |  |
| Commission |  |  |  | -0.08 | -0.08 |  |  |  |  |  |
| Madhur Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  | 0.07 | 0.07 |  | 0.07 | 0.08 | 0.12 | 0.13 | 0.08 | 0.07 |
| Sitting Fees | 0.07 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.07 |  |  | -0.11 |  |  |  |  |  |  |
| Commission | 0.07 | -0.11 | -0.10 | -0.10 | -0.10 | -0.14 | -0.20 | -0.27 | -0.17 | 0.21 |
| Dipak Poddar |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 | 0.03 | 0.10 |  |  |  |
| Balance - Commission |  |  |  | -0.09 |  |  |  |  |  |  |
| Commission |  |  |  | -0.09 | -0.09 | -0.06 | -0.19 |  |  |  |
| Rahul Bajaj Individual |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.10 | 0.11 | 0.06 | 0.01 |  |  |
| Sitting Fees | 0.10 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.10 |  |  | -0.17 |  |  |  |  |  |  |
| Commission | 0.10 |  |  | -0.13 | -0.13 | -0.21 | -0.11 | -0.02 |  |  |
| Omkar Goswami Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.06 | 0.12 |  |  |  |  |
| Balance - Commission |  |  |  | -0.12 |  |  |  |  |  |  |
| Commission |  |  |  | -0.11 | -0.11 | -0.24 |  |  |  |  |
| Ranjan Sanghi |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.07 | 0.14 | 0.14 |  |  |  |
| Balance - Commission |  |  |  | -0.15 |  |  |  |  |  |  |
| Commission |  |  |  | -0.12 | -0.12 | -0.26 | -0.26 |  |  |  |
| Rakesh Bhatt Individual |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | -0.74 |  |  |  |
| D J Balaji Rao Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.12 | 0.18 | 0.19 | 0.22 |  |  |
| Balance - Commission |  |  |  | -0.12 |  |  |  |  |  |  |
| Commission |  |  |  | -0.15 | -0.15 | -0.31 | -0.31 | -0.44 |  |  |
| Dr. Gita Piramal Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.13 | 0.21 | 0.21 | 0.20 |  |  |
| Balance - Commission |  |  |  | -0.14 |  |  |  |  |  |  |
| Commission |  |  |  | -0.16 | -0.16 | -0.36 | -0.34 | -0.40 |  |  |
| Radhika Singh Relative |  |  |  |  |  |  |  |  |  |  |
| Fixed deposit interest accrued |  |  |  |  |  | -0.01 | 0.16 |  |  |  |
| Fixed deposit accepted |  |  |  |  |  | 2 | 2 |  |  |  |
| Bajaj Auto Holdings Ltd. |  |  |  |  |  |  |  |  |  |  |
| Non convertible debentures redeemed |  |  | 5 |  |  |  |  |  |  |  |
| Dividend paid |  | 0.07 |  |  | 0.04 | 0.16 |  | 0.06 | 0.08 | 0.17 |
| Purchase of shares by BAHL | 0.10 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  |  |  |  |  | -0.21 | 0.21 |
| Interest on non convertible debentures issued |  | -0.48 | 0.48 |  |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  |  | -0.10 |  |  |
| Purchase of shares by |  |  |  | -0.10 |  |  |  |  |  |  |
| Balance - Purchase of shares by |  |  |  | -0.10 |  |  |  |  |  |  |
| Balance - Purchase of shares by BAHL | -0.10 |  |  |  |  |  |  |  |  |  |
| Purchase of shares by BAHL (209,005 shares of H 5 each) |  | -0.10 | -0.10 |  |  |  |  |  |  |  |
| Shares of BFS held by BAHL |  |  |  |  | -0.10 | -0.10 | -0.10 |  |  |  |
| Non convertible debentures issued |  | 5 |  |  |  |  |  |  |  |  |
| Balance - Non-convertible debentures issued | 5 |  |  |  |  |  |  |  |  |  |
| Nanoo Pamnani Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.18 | 0.32 |  |  |  |  |
| Sitting fees and expenses | 0.09 |  |  |  |  |  |  |  |  |  |
| Balance - Commission | -0.89 |  |  | -1.21 |  |  |  |  |  |  |
| Commission | 0.89 |  |  | -2.24 | -2.24 | -2.46 |  |  |  |  |
| Allianz Managed Operations & Services SE Associate |  |  |  |  |  |  |  |  |  |  |
| Insurance premium received |  | 0.23 | 0.22 |  |  |  |  |  |  |  |
| E-learning service fees |  | 0.34 |  |  |  |  |  |  |  |  |
| Benefits paid |  | 0.02 | 0.01 |  |  |  |  |  |  |  |
| License and Maintenance fees paid |  | 0.93 | -0.95 |  |  |  |  |  |  |  |
| Unallocated premium |  | -0.06 | -0.08 |  |  |  |  |  |  |  |
| SAS license fees |  | -4.07 |  |  |  |  |  |  |  |  |
| Paid towards opus revenue expenditure |  | -4.97 | -2.29 |  |  |  |  |  |  |  |
| Allianz Fire and Marine Insurance Japan Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  | 1.80 |  |  |  |  |
| Claims recovery on reinsurance |  |  |  |  |  | 0.01 |  |  |  |  |
| Reinsurance premium paid |  |  |  |  |  | -15 |  |  |  |  |
| D.S.Mehta Key Person |  |  |  |  |  |  |  |  |  |  |
| Balance - Commission |  |  |  | 0.10 |  |  |  |  |  |  |
| Sitting fees |  |  |  |  | 0.05 |  |  |  |  |  |
| Commission |  |  |  | -0.09 | -0.09 |  |  |  |  |  |
| Balance - Fixed deposit interest accrued |  |  |  | -0.21 |  |  |  |  |  |  |
| Fixed deposit interest accrued |  |  |  | -0.87 | -0.87 |  |  |  |  |  |
| Balance - Fixed deposit accepted |  |  |  | -5.33 |  |  |  |  |  |  |
| Fixed deposit accepted |  |  |  | -8.28 | -8.28 |  |  |  |  |  |
| Allianz Technology SE JV |  |  |  |  |  |  |  |  |  |  |
| Billable expenses recovery |  |  |  |  |  | 0.49 | 0.25 |  |  |  |
| Balance - Unallocated premium |  |  |  | 0.06 |  |  |  |  |  |  |
| Benefits paid |  |  |  |  | 0.01 |  |  |  |  |  |
| Balance - License and maintenance fees paid |  |  |  | -1.16 |  |  |  |  |  |  |
| Information technology expenditure |  |  |  |  |  |  | -2.90 |  |  |  |
| Balance - Paid towards opus revenue expenditure |  |  |  | -5.17 |  |  |  |  |  |  |
| Paid towards opus revenue expenditure |  |  |  | -2.60 | -2.60 | -5.56 |  |  |  |  |
| License and maintenance fees paid |  |  |  | -1.93 | -1.93 | -3.66 | -5.86 |  |  |  |
| Allianz Fire and Marine Insurance Japan Ltd JV |  |  |  |  |  |  |  |  |  |  |
| Commission on reinsurance received |  |  |  |  |  |  | 22 |  |  |  |
| Claims recovery on reinsurance |  |  |  |  |  |  | 1.46 |  |  |  |
| Reinsurance premium paid |  |  |  |  |  |  | -71 |  |  |  |
| Group Gratuity Cum Life Assurance Trust |  |  |  |  |  |  |  |  |  |  |
| Benefits paid |  |  |  |  | 5.66 | 5.39 | 3.61 | 3.57 |  |  |
| Fund reserve |  |  |  |  | 1.96 | 2.90 | 1.96 | 2.03 |  |  |
| Provision for linked liabilities |  |  |  |  |  |  | -39 | -52 |  |  |
| Bajaj Auto Ltd. Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Interest paid on non convertible debentures |  |  |  |  | 4.92 | 4.91 | 4.92 |  | 4.34 | 3.35 |
| Unsecured non convertible debentures redemption |  |  |  |  |  |  | 6 |  | 10 |  |
| Interest paid on non-convertible debentures |  |  |  |  |  |  |  | 4.35 |  |  |
| Balance - Providend fund contribution (Employer's share) |  |  |  | -4.85 |  |  |  |  |  |  |
| Provident fund contribution (Employer's share) |  |  |  |  |  |  | -11 | 1.44 |  |  |
| Providend fund contribution (Employer's share) |  |  |  | -5.82 | -5.82 | -10 |  |  |  |  |
| Unsecured non-convertible debentures issued |  |  |  |  |  |  |  | 46 |  |  |
| Balance - Unsecured non convertible debentures issued |  |  |  | 52 |  |  |  |  |  |  |
| Unsecured non convertible debentures issued |  |  |  | 52 | 52 | -55 | 46 |  | 36 | 36 |
| Bajaj Holdings & Investment Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  |  | 150 | 150 |  |
| Dividend paid | 11 | 22 |  |  | 11 | 47 |  | 19 | 25 | 50 |
| Interest paid on non convertible debentures |  |  |  |  |  |  | 23 | 23 | 13 |  |
| Business support services received | 2.66 | 2.60 | 2.61 |  |  |  |  | -0.05 | 19 | 25 |
| Sale of investments | 35 |  |  |  |  |  |  |  |  |  |
| Business support charges received |  |  |  |  | 0.38 | 0.51 | 16 |  |  |  |
| Business support services rendered | 1.95 | 0.20 | 0.26 |  |  |  | 0.87 | 0.76 | 1.43 | 1.03 |
| Billable expenses reimbursed on behalf |  |  |  |  | 0.06 | 0.52 | 0.58 | 0.10 | 1 | 2.03 |
| Other payments |  |  |  |  | 0.03 | 0.04 | 0.04 | 0.05 | 0.10 | 3.90 |
| Insurance premium received by BAGIC/BALIC |  |  |  |  |  |  | 0.65 |  | 1 | 1.32 |
| Billable expenses reimbursement received |  |  |  |  |  |  |  |  | 0.44 | 1.01 |
| Rent paid |  |  |  |  |  |  |  |  |  | 1.17 |
| Insurance premium received | 0.05 | 0.06 | 0.06 |  |  |  |  | 1 |  |  |
| Security deposit |  |  |  |  |  |  |  |  |  | 0.70 |
| Insurance premium received by BAGICL/BALICL |  |  |  |  | 0.01 | 0.46 |  |  |  |  |
| Employee car transfer |  |  |  |  |  |  |  | 0.06 |  |  |
| Other receipts |  |  |  |  | 0.01 |  |  |  |  |  |
| Balance - Unallocated premium | -0.07 |  |  | -0.02 |  |  |  |  |  |  |
| Unallocated premium |  |  | -0.04 | -0.57 |  |  | -1.17 | -1.25 | 0.04 | 1.70 |
| Superannuation contribution |  |  |  |  | -0.57 | -0.89 |  |  |  |  |
| Purchase of shares by |  |  |  | -31 |  |  |  |  |  |  |
| Balance - Purchase of shares by |  |  |  | -31 |  |  |  |  |  |  |
| Balance - Purchase of shares by BHIL | -31 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -31 | -31 |  |  | -62 | 62 |
| Contribution to Equity |  |  |  |  |  |  | -31 | -31 |  |  |
| Purchase of shares by BHIL (62,314,214 shares of H 5 each) |  | -31 | -31 |  |  |  |  |  |  |  |
| Secured non convertible debentures issued |  |  |  |  |  | -312 | 300 | 150 |  |  |
| Maharashtra Scooters Ltd. |  |  |  |  |  |  |  |  |  |  |
| Secured non convertible debentures redemption |  |  |  |  |  |  | 5 |  | 85 | 100 |
| Dividend paid | 3.69 |  |  |  | 8.24 | 33 |  | 20 | 39 | 60 |
| Secured non-convertible debentures redemption |  |  |  |  | 5 | 110 |  |  |  |  |
| Interest on non-convertible debentures issued |  | 7.25 | 7.20 |  | 10 | 11 | 7.51 | 13 | 17 | 9.94 |
| Business support charges received |  |  |  |  | 1.86 | 0.14 | 0.16 | 0.14 | 0.15 | 0.18 |
| Business support services rendered | 0.08 | 0.02 | 0.03 | 1.86 |  |  |  |  |  |  |
| Balance - Business support services rendered |  |  |  | 1.86 |  |  |  |  |  |  |
| Contribution to Equity |  |  |  |  |  |  |  | -1.86 |  |  |
| Balance - Contribution to equity of BFS |  |  |  | -1.86 |  |  |  |  |  |  |
| Balance - Contribution to Equity | -1.90 |  |  |  |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -1.86 | -1.86 |  |  | -3.79 | 3.79 |
| Contribution to equity of BFS |  |  |  | -1.86 |  |  | -1.86 |  |  |  |
| Contribution to equity of BFS (3,725,740 shares of H 5 each) |  | -1.86 | -1.86 |  |  |  |  |  |  |  |
| Balance - Contribution to equity of BFL |  |  |  | -3.79 |  |  |  |  |  |  |
| Contribution to equity of BFL (18,974,660 shares of H 2 each) |  | -1.90 | -3.79 |  |  |  |  |  |  |  |
| Contribution to equity of BFL |  |  |  | -3.79 |  |  | -3.79 |  | -3.79 | 3.79 |
| Balance - Non-convertible debentures issued | 80 |  |  | 80 |  |  |  |  |  |  |
| Non convertible debentures issued |  |  |  |  | 140 | -96 |  |  |  |  |
| Non-convertible debentures issued |  | 80 | 80 | 140 |  |  | 185 | 260 | 175 | 225 |
| Allianz SE JV |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  | 56 | 56 | 82 |  |  |  |
| Billable expenses recovered on behalf |  | 0.72 | 0.02 |  |  |  |  |  |  |  |
| Billable expenses incurred on behalf | 0.03 | 0.51 | 0.08 |  |  | 0.04 |  |  |  |  |
| Receipt of award |  | 0.15 |  |  |  |  |  |  |  |  |
| Reimbursement of revenue expenses received | 0.02 | 0.01 | 0.03 |  |  |  |  |  |  |  |
| Balance - Billable expenses incurred on behalf |  |  |  | -0.03 |  |  |  |  |  |  |
| Balance - Contribution to equity of BAGICL including premium |  |  |  | -195 |  |  |  |  |  |  |
| Balance - Contribution to Equity | -195 |  |  |  |  |  |  |  |  |  |
| Contribution to equity of BAGICL including premium |  | -195 | -195 | -195 |  |  |  |  |  |  |
| Contribution to equity of BAGIC including premium |  |  |  |  |  |  | -1,099 |  |  |  |
| Balance - Contribution to equity of BALICL including premium |  |  |  | -1,099 |  |  |  |  |  |  |
| Contribution to equity |  |  |  |  | -1,099 | -1,099 |  |  |  |  |
| Contribution to equity of BALICL including premium |  | -1,099 | -1,099 | -1,099 |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,055 | 6,023 | 11,335 | 20,533 | 24,507 | 32,862 | 42,605 | 54,351 | 60,592 | 68,406 | 82,072 | 110,382 | 118,582 |
| Expenses + | 4,124 | 1,531 | 5,823 | 13,795 | 15,794 | 22,074 | 27,569 | 36,094 | 40,950 | 46,951 | 52,204 | 69,497 | 75,437 |
| Operating Profit | 3,931 | 4,491 | 5,511 | 6,739 | 8,713 | 10,788 | 15,037 | 18,258 | 19,641 | 21,455 | 29,868 | 40,886 | 43,145 |
| OPM % | 49% | 75% | 49% | 33% | 36% | 33% | 35% | 34% | 32% | 31% | 36% | 37% | 36% |
| Other Income + | 2 | 3 | 8 | 0 | 0 | 1 | 2 | 0 | -7 | 8 | 1 | -4 | 9 |
| Interest | 1,204 | 1,562 | 2,230 | 2,877 | 3,716 | 4,531 | 6,657 | 9,500 | 9,274 | 9,629 | 12,380 | 18,607 | 19,971 |
| Depreciation | 22 | 31 | 38 | 58 | 73 | 160 | 226 | 457 | 498 | 563 | 678 | 900 | 965 |
| Profit before tax | 2,708 | 2,902 | 3,251 | 3,804 | 4,925 | 6,099 | 8,155 | 8,302 | 9,862 | 11,271 | 16,811 | 21,375 | 22,218 |
| Tax % | 18% | 24% | 26% | 27% | 30% | 32% | 34% | 28% | 25% | 26% | 27% | 27% |  |
| Net Profit + | 2,214 | 2,191 | 2,409 | 2,775 | 3,450 | 4,176 | 5,374 | 5,994 | 7,367 | 8,314 | 12,210 | 15,595 | 16,095 |
| EPS in Rs | 9.89 | 9.71 | 10.62 | 11.71 | 14.21 | 16.65 | 20.23 | 21.17 | 28.09 | 28.63 | 40.29 | 51.07 | 52.28 |
| Dividend Payout % | 2% | 2% | 2% | 1% | 1% | 1% | 1% | 2% | 1% | 1% | 2% | 2% |  |
| 10 Years: | 34% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |

