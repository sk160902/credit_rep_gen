## first two ratio line charts - turnover ratio & roce/roe

import matplotlib.pyplot as plt

def create_line_charts(turnover_data, return_data):
    years = ["FY-20", "FY-21", "FY-22", "FY-23", "FY-24"]

    # Create the first plot (Turnover Ratios)
    plt.figure(figsize=(10, 5)) 
    for label, data in turnover_data.items():
        plt.plot(years, data, label=label)

    plt.title("Turnover Ratio", fontsize=12)
    plt.xlabel("") 
    plt.ylabel("") 
    plt.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=3)
    plt.grid(axis="y", linestyle='--', linewidth=0.5)
    plt.show()

    # Create the second plot (Return Ratios)
    plt.figure(figsize=(10, 5)) 
    for label, data in return_data.items():
        plt.plot(years, data, label=label)

    plt.title("Return Ratio (in %)", fontsize=12)
    plt.xlabel("") 
    plt.ylabel("") 
    plt.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2)
    plt.grid(axis="y", linestyle='--', linewidth=0.5)
    plt.show()

# data (replace with your actual data)
turnover_data = {
    "Fixed Assets Turnover Ratio": [],
    "Asset Turnover": [],
    "Debtors Turnover": [],
    "Inventory Turnover": [],
}

return_data = {
    "RoCE (in %)": [],
    "RoE (in %)": [],
}

# Create the charts
create_line_charts(turnover_data, return_data)


## ratio chart 3 and 4 - leverage ratio / liquidity ratio

import matplotlib.pyplot as plt

def create_financial_charts(leverage_data, liquidity_data):
    years = ["FY-20", "FY-21", "FY-22", "FY-23", "FY-24"]

    # Create the first plot (Leverage Ratios)
    fig, ax1 = plt.subplots(figsize=(10, 5))

    bar_width = 0.2
    ax1.bar(years, leverage_data["Interest Coverage Ratio (RHS)"], 
            width=bar_width, color='gray', label="Interest Coverage Ratio (RHS)")

    ax1.set_ylabel("")
    ax1.tick_params(axis='y')

    ax2 = ax1.twinx()

    for label, data in leverage_data.items():
        if label != "Interest Coverage Ratio (RHS)":
            ax2.plot(years, data, label=label, marker='o')

    ax2.set_ylabel("")
    ax2.tick_params(axis='y')

    plt.title("Leverage Ratio", fontsize=12)
    plt.xticks(years)
    plt.grid(axis="y", linestyle='--', linewidth=0.5)

    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    plt.legend(lines + lines2, labels + labels2, loc="upper center", 
               bbox_to_anchor=(0.5, -0.15), ncol=3)
    plt.show()



    # Create the second plot (Liquidity Ratios)
    plt.figure(figsize=(10, 5))
    for label, data in liquidity_data.items():
        plt.plot(years, data, label=label, marker='o')

    plt.title("Liquidity Ratio", fontsize=12)
    plt.xticks(years)
    plt.ylabel("")
    plt.grid(axis="y", linestyle='--', linewidth=0.5)
    plt.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=2)
    plt.show()

leverage_data = {
    "Interest Coverage Ratio (RHS)": [],
    "Debt to Equity Ratio": [],
    "Debt to Assets Ratio": [],
}

liquidity_data = {
    "Current Ratio": [],
    "Quick Ratio": [],
}

# Create the charts
create_financial_charts(leverage_data, liquidity_data)



#graph 5 for ratio  - investor ratio

import matplotlib.pyplot as plt

def create_investor_ratios_chart(investor_data):

    years = ["FY-20", "FY-21", "FY-22", "FY-23", "FY-24"]

    fig, ax1 = plt.subplots(figsize=(10, 5))

    # Plot bars for specific ratios on primary y-axis
    bar_width = 0.2
    ax1.bar([x - bar_width for x in range(len(years))], 
            investor_data["Earnings Per Share"], 
            width=bar_width, color='gold', label="Earnings Per Share")
    ax1.bar([x + bar_width for x in range(len(years))], 
            investor_data["Dividend Per Share"], 
            width=bar_width, color='royalblue', label="Dividend Per Share")

    ax1.set_ylabel("")
    ax1.tick_params(axis='y')

    # Create secondary y-axis
    ax2 = ax1.twinx()

    # Plot lines for other ratios on secondary y-axis
    for label, data in investor_data.items():
        if label not in ["Earnings Per Share", "Dividend Per Share"]:
            ax2.plot(years, data, label=label, marker='o')

    ax2.set_ylabel("")
    ax2.tick_params(axis='y')

    plt.title("Investor Ratios", fontsize=12)
    plt.xticks(years)
    plt.grid(axis="y", linestyle='--', linewidth=0.5)

    # Combine legends from both axes
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    plt.legend(lines + lines2, labels + labels2, loc="upper center", 
               bbox_to_anchor=(0.5, -0.25), ncol=3)
    plt.show()


investor_data = {
    "Earnings Per Share": [],
    "Dividend Per Share": [],
    "EV / EBITDA (RHS)": [],
    "EV / Net Sales (RHS)": [],
    "Price to Earnings Ratio (RHS)": [],
}

# Create the chart
create_investor_ratios_chart(investor_data)


## working capital chart 

import matplotlib.pyplot as plt

def create_working_capital_chart(working_capital_data):

    years = ["FY-20", "FY-21", "FY-22", "FY-23", "FY-24"]

    plt.figure(figsize=(10, 5))

    # Plot lines for each component of working capital
    for label, data in working_capital_data.items():
        plt.plot(years, data, label=label, marker='o')

    plt.title("Working Capital Days", fontsize=12)
    plt.xticks(years)
    plt.ylabel("") 
    plt.grid(axis="y", linestyle='--', linewidth=0.5)
    plt.legend(loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=4)
    plt.show()


working_capital_data = {
    "Net Cash Cycle days": [],
    "Receivable days": [],
    "Inventory days": [],
    "Payables days": []  
}

# Create the chart
create_working_capital_chart(working_capital_data)



## cash flows chart

import matplotlib.pyplot as plt
import numpy as np

def create_cash_flow_chart(cash_flow_data):
    years = ["FY-20", "FY-21", "FY-22", "FY-23", "FY-24"]
    categories = ["Cash from Operating Activity", "Cash from Investing Activity", 
                  "Cash from Financing Activity"]

    # Create data for stacked bars
    data_for_stack = np.array([cash_flow_data[category] for category in categories])
    data_cum = data_for_stack.cumsum(axis=0)

    fig, ax1 = plt.subplots(figsize=(10, 5))

    # Plot stacked bars
    for i, category in enumerate(categories):
        ax1.bar(years, cash_flow_data[category], bottom=data_cum[i - 1] if i > 0 else None, 
                label=category)

    ax1.set_ylabel("")
    ax1.tick_params(axis='y')

    # Create secondary y-axis
    ax2 = ax1.twinx()

    # Plot net cash flow line
    ax2.plot(years, cash_flow_data["NET CASH FLOW"], label="NET CASH FLOW", 
             color="gold", marker='o', linewidth=3)

    ax2.set_ylabel("")
    ax2.tick_params(axis='y')

    plt.title("Cash Flow Schedule", fontsize=12)
    plt.xticks(years)
    plt.grid(axis="y", linestyle='--', linewidth=0.5)

    # Combine legends from both axes
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    plt.legend(lines + lines2, labels + labels2, loc="upper center", 
               bbox_to_anchor=(0.5, -0.15), ncol=2)
    plt.show()

# Example data (replace with your actual data)
cash_flow_data = {
    "Cash from Operating Activity": [],
    "Cash from Investing Activity": [],
    "Cash from Financing Activity": [],
    "NET CASH FLOW": []
}

# Create the chart
create_cash_flow_chart(cash_flow_data)