# Complete Company Data

## Modal Content
About
[
edit
]
Incorporated in 1948, Hindustan
Motors Ltd manufactures and sells
Vehicles, Spare Parts of Vehicles,
Steel Products and Components.
It also does trading of Spare Parts
of Vehicles

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}

Key Points
[
edit
]
Operational Review:

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}


{reference id: 2
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=22
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}

Company has declared
Suspension of
Work
at its Uttarpara Plant (West Bengal)
from 24th May, 2014, due to low productivity, growing indiscipline, shortage of funds and lack of product demand. The suspension of work is continuing. Management is scouting for tie-ups and potential investment /strategic partners to introduce new products & infuse capital in the company. It is also considering various measures including restructuring and rationalising of its manpower and other fixed costsalternative use of Fixed Assets to generate revenue.
Company's outstanding liabilities are expected to be met by sale proceeds of assets of the Company
Manufacturing Units:

{reference id: 3
source: http://www.hindmotor.com/aboutus.asp
context: Corporate Vehicles Plants Investors Newsroom Careers
‘an Motors Limited

Key Personnel n Motors Limited was established during the pre-Independence era at Port Okha in

Milestones Operations were moved in 1948 to Uttarpara in district Hooghly, West Bengal, where the
' began the production of the iconic Ambassador. Equipped with integrated facilities such
Composition of Board Directors and shop, forge shop, foundry, machine shop, aggregate assembly units for engines, axles etc
Committees rong R&D wing, the company currently manufactures the Ambassador (1500 and 2000 cc
800 cc petrol, CNG and LPG variants) in the passenger car segment and light commercial

Terms and Conditions of Appointment 7! . . > .
-tonne payload mini-truck Winner (2000 cc diesel and CNG) at its Uttarpara and Pithampur

of Independent Directors

pease

The first and only integrated automobile plant in India, the Uttarpara factory, popularly known as
Hind Motor, also manufactures automotive and forged components. View details

The company also has operations in Pithampur near Indore in Madhya Pradesh where it produces
1800 cc CNG and other variants of Winner.

Hindustan Motors is committed to core values of quality, safety, environmental care and holistic
The Birla Building, Kolkata customer orientation.

The plants

e Uttarpara (West Bengal)
The automobile division at Uttarpara is engaged in the manufacture of the iconic
Ambassador and light commercial vehicle Winner. View details

e Pithampur (Madhya Pradesh)
The company produces 1800 cc CNG and other variants of Winner here.

Our offices:

Registered office:

Hindustan Motors Limited,

Birla Building, 10th floor, Western Side
9/1, R. N. Mukherjee Road,

Kolkata - 700001

West Bengal

Tel : 91-33-30533700 / 30410900

Fax : 91-33-22480055

Best viewed in IE5 or higher on 800x600 resolution. All rights reserved. © Copyright Hindustan Motors Ltd.

Designed & Developed by ePagemaker Pvt Ltd.}

The company currently manufactures
the
Ambassador (1500 and 2000 cc diesel, 1800 cc petrol, CNG and LPG variants)
in the passenger car segment and
light commercial vehicle 1-tonne payload mini-truck Winner (2000 cc diesel and CNG)
by the name of Winner, at its Uttarpara and Pithampur plants.
The Co's manufacturing plants were the first
integrated automobile plant
in India, the Uttarpara factory, popularly known as Hind Motor, also manufactures
automotive and forged components
. The plant is equipped
with integrated facilities such as a press shop, forge shop, foundry, machine shop, aggregate assembly units for engines, axles, etc., and an R&D wing. At the Pithampur plant, the company produces
1800 cc CNG
and other variants of Winner.
Automotive components division:

{reference id: 4
source: http://www.hindmotor.com/Automotive-components.asp
context: Corporate Vehicles Plants Investors Newsroom Careers }HM Sites v i

48 Key Personnel 1 Motors’ components division comprises Accu Cast (casting unit) and Accu Forge (forging
milestones provide engines and transmission and axle components for HM vehicle business and also

astablished OEMs.

Composition of Board Directors and
Committees t

Terms and Conditions of Appointment t was established primarily for HM’s internal consumption. Later on, it started catering to
of Independent Directors sll established OEMs. The manufacturing facility includes 2-tonne dual track induction
re ~ Which can melt up to 1500 tonnes of metal per month. Moulding facilities include three
pairs of ARPA 900 machines and three pairs of ARPA 450 machines which have capacity to mould
1200 tonnes of castings per month. Further, the unit possesses automated sand plant and facilities
for fettling and machining. It also has a well-equipped laboratory with spectrometer apart from
full-fledged testing facilities. The unit also possesses well established facility for machining.

The unit currently manufactures all types of grey iron, SG iron, steel and aluminium pressure die
castings for passenger cars, LCVs, HCV and tractor segments. Accu Cast specializes in
manufacturing of intricate castings like 3-cylinder and 4-cylinder blocks, heads, gear box housings,
manifolds, SG iron casings, cover, wheel hubs, aluminium gear box extension, steering arms etc.
The unit can produce grey iron/ SG iron/ steel castings ranging from 5 kg to 500 kg unit weight and
gravity die castings ranging from 1 kg to 25 kg unit weight.

Accu Forge

Accu Forge too was established primarily for the company’s own use. It has now started catering to
well established OEM customers. The manufacturing facility includes 6000 T, 2500 T, 1300 T presses
with induction furnace and 5” upsetter, and can, altogether, forge 1300 tonnes/month. The unit
has in house facility for heat treatment, lab with spectrometer and all other necessary facilities.
The unit has excellent facility for design, simulation and model development. The unit has a well
established die shop with VMCs and all dies are being developed in-house.

The unit, currently, manufactures all types of profile forgings catering to passenger car, LCV, HCV
and tractor segments and specializes in manufacturing intricate forgings like 2- cylinder, 3-cylinder,
4-cylinder crankshafts, camshafts, stub axles, spindles, draw hooks, all types of gears and shafts
for reputed customers. The unit has the capacity to produce forgings ranging from 1 kg to 75 kg
unit weight.

Best viewed in IE5 or higher on 800x600 resolution. All rights reserved. © Copyright Hindustan Motors Ltd.
Designed & Developed by ePagemaker Pvt Ltd.}

The company's components division comprises Accu Cast (casting unit) and
Accu Forge (forging unit) which provide
engines and transmission and axle
components for HM vehicle business
and also cater to established OEMs.
A)
Accu Cast:
This particular unit currently manufactures
all types of grey iron, SG iron, steel, and aluminum pressure die castings for the passenger cars, LCVs, HCV, tractor
segments. Accu Cast specializes in manufacturing intricate castings like
3-cylinder and 4-cylinder blocks,
heads, gearbox housings, manifolds,
SG iron castings, cover, wheel hubs,
aluminum gearbox extension, steering
arms, etc. The unit can produce grey iron
/ SG iron/ steel castings ranging from 5 kg
to 500 kg unit weight and gravity die castings ranging from 1 kg to 25 kg unit weight
B)
Accu Forge:
This unit manufactures all types of profile forgings catering to passenger car, LCV,
HCV, and tractor segments and specializes
in manufacturing intricate forgings like 2- cylinder, 3-cylinder, 4-cylinder crankshafts, camshafts, stub axles, spindles, draw hooks,
all types of gears and shafts for reputed customers. The unit has the capacity to produce forgings ranging from 1
kg to 75 kg unit weight.
MoU:

{reference id: 1
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=16
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

13

14

15

16

16 /95 — 100% +{| ES

HINDUSTAN MOTORS LIMITED

As reported earlier that due to low productivity, growing indiscipline, shortage of funds and lack of demand for products, the Company
was compelled to declare “Suspension of work” at its Uttarpara Plant with effect from 24th May, 2014 and the suspension of work is
continuing due to no change in the situation.

No material changes or commitments or any significant and material adverse orders or rulings passed by the regulators or Courts or
Tribunals impacting the going concern status and Company’s operations in future have occurred between end of the financial year of the
company and date of this report.

A detailed Management Discussion & Analysis Report forms part of this report is annexed as Annexure-1.
Outlook for 2023-24

In an effort to revive operations, the Company has been continuously rationalising the cost, post suspension of work at Uttarpara plant.
It has reduced the fixed cost including employee cost considerably and continuously working on further reducing its fixed cost. The
accumulated losses of the Company was brought down to Rs.14845.52 Lacs as on 31st March, 2023 as compared to Rs.25218.00 Lacs as on
31st March, 2017. The management is putting continuous effort in scouting for tie-ups & Potential investment/strategic partners who can
introduce new products & infuse capital in the company. The Company is considering various measures including alternative use of Fixed
Assets to generate revenue. The particular process has been affected adversely due to the COVID-19 pandemic situation for last two years.
However, the situation is taking a positive turn with recent developments:

>» The Company has entered into a Memorandum of Understanding (MOU) to extend the Electric Vehicle (EV) domain across the
border to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from
Government of West Bengal on resumption of Uttarpara Land.

The Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the
resumption issue is resolved.

Thus, the Company will facilitate and generate additional revenue and realize adequate fund required.
Implication of COVID-19

In view of the outbreak of COVID-19 which has been declared as a pandemic by World Health Organisation and subsequent lockdown
imposed by the Central and State Government(s) in India, the Company is closely monitoring the impact of this pandemic and believes
that there has been no significant adverse impact on its financial position for the financial year ended 31st March, 2023 as its manufacturing
plant located at Uttarpara, West Bengal had already been under “Suspension of Work” prior to imposition of lockdown.

Change in the nature of business, if any :

There was no change in the nature of the business of the Company during the year under report.

Material changes and commitments, if any, affecting the financial position of the company which have occurred between the end of the
financial year of the company to which the financial statements relate and the date of the report :

le
ra |]}


{reference id: 5
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=91
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf

89

90

91

91 / 95 — 100% +{| ES

Notes to Accounts (contd.)

- The Company has signed a MOA (Memorandum of Agreement) with a Company wherein the Company is
handing over part of surplus land at Uttarpara for upcoming project.
The Company has also signed a MOU (Memorandum of Understanding) and is in developed stage of discussion
for a joint venture with a Company involved in EV Segment, however the project is stalled at the moment due to
a notice from W. B. State Govt. on resumption of H M Uttarpara Land.
However, the Company has alternate plans to facilitate and generate additional revenue and realize adequate fund
required, after the resumption issue is resolved. Accordingly, the Company continues to prepare its accounts on a
going concern basis. The Auditors in their audit report for the year 31st March, 2023 have given a separate paragraph,
Material uncertainty related to 'going concern' on above.

. Due to low productivity, growing indiscipline, shortage of funds and lack of demand of products, the management

declared “Suspension of work” at Company’s Uttarpara Plant with effect from 24th May 2014.

Based on legal opinion obtained, the employees and workmen, falling under the purview of “Suspension of work”
at Uttarpara plant, are not entitled to any salary & wages during that period and accordingly the Company has not
provided for such salary & wages.

.. The Government of West Bengal issued an order for resumption of HM Uttarpara land. Application filed before

West Bengal Land Reform and Tenancy Tribunal and matter is pending for final hearing as per guideline of Hon'ble
Calcutta High Court.

. The wholly owned immaterial foreign subsidiary of the Company namely Hindustan Motors Limited, USA was

already dissolved on 16th February, 2017 as per the laws appliacble in USA and as such not in existence since after
dissolution. Further, the application made by the Company to Reserve Bank of India seeking permission for writing
off its entire investment in Hindustan Motors Limited, USA (Capital, Loan and other receivables/payables) for which
necessary provision has been made in the accounts of the Company, is under consideration.

. During the year ended 31st March, 2023, by virtue of Brand Transfer Agreement dated 16th June, 2022 executed
between the Company (The Assignor) and S. G. Corporate Mobility Private Limited (The Assignee), by which the
assignor assigned the “Contessa” Brand and the related Rights thereof to the assignee for a consideration of Rs. 100
lakhs, which has been shown as “Exceptional Item”

le
ra |]}

a)
Company has entered into a  MOU to extend their Electric Vehicle domain to enhance the production of eco-friendly electric vehicle. However, the project is stalled at the moment due to Notice from Govt. of West Bengal on resumption of Uttarpara Land.
b)
Company has alternate plans to facilitate and generate additional revenue and realize adequate fund required, after the resumption issue is resolved
c)  HML has signed a Memorandum
of Agreement with a Company where
HML is handing over part of surplus
land at Uttarpara for upcoming project
Agreement:

{reference id: 6
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/8d0b1739-a36f-4de1-8f13-682fecc26f00.pdf
context: 8d0b1739-a36f-4de1-8f13-682fecc26f00.pdf

1/2 — 100% +{| ES

Hindustan Motors ** j WB1942PLC018967

www. hindmotor.c

orate Relationship Dept.
Limited

RE: Additional Details Required for Corporate Announcement filed under
Regulation 30 of SEBI (LODR) Regulations, 2015.

In reply to your last trailing mail dated 29 December, 2023, regarding announcement
filed by the Company under Regulation 30 of the SEBI (Listing Obligations and Disclosure
Requirements) Regulations, 2015 Annexu 1 - Point 5. Agreements/JV/Family
settlement agreements) not in normal course of business, the point-wise reply are as
follows:-

Name of partie with whom the | Hindustan Motors Limited entered into an
agreement is entered agreement with Indigenous Vanijya Private

| Limited on 6™ October, 2023.

b) Purpose of entering into’ the | t is under suspension of work effective

| agreement May, 2014. The machineries lying at the
Plant are getting deteriorated day by day
due to natural wear and tear. These are
very old machine and equipment which
are obsolete and unserviceable/unusab
As a result of which the same cannot be
further utilized and hence sold as

le
ra |]}

On 6th October 2023, company entered into an agreement with Indigenous Vanijya Private Limited for sale of scrap and obsolete equipment for
Rs. 65.50 Cr
Brand Transfer Agreement:

{reference id: 7
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/5dbb4136-7b39-420b-9009-8a2a47c58b2b.pdf
context: 5dbb4136-7b39-420b-9009-8a2a47c58b2b.pdf

1

[1 — 100% +{| ES

Hindustan Motors  Pesisteres Office :

Hindustan Motors Limited
Birla Building, 13th Floor
9/1, R. N. Mukherjee Road

Kolkata - 700 001

June 21, 2022

The Manager, Listing Department
National Stock Exchange of India Ltd
Exchange Plaza, 5°” floor

Plot No. C/1, G Block

Bandra-Kurla Complex, Bandra (East)
Mumbai - 400 051

(Company Code : HINDMOTORS)

Dear Sirs

CIN-L34103WB1942PLC018967 WV
T +91 033 22420932 (D) F +91 033 22480055 Aw
“1491 033 4082 3700 Hmcosecy@hindmotor.com

1 +91 033 2220 0600 www.hindmotor.com

2 Corporate Relationship Dept.
BSE Limited
1* floor, New Trading Ring
Rotunda Building, P. J. Towers
Dalal Street, Fort
Mumbai - 400 001
(Company Code : 500500)

Sub: Disclosure pursuant to Regulation 30 of SEBI (Listing
Obligations and Disclosure Requirements) Regulations, 2015

Hindustan Motors Limited has executed a Brand Transfer Agreement with
S.G. Corporate Mobility Private Limited on 16" June, 2022 for the transfer of

the Contessa Brand (including the trademarks having application number
5372807) and certain related rights (“Contessa Brand”). The transfer of

the Contessa Brand shall be effective upon fulfilment of the terms &

conditions as prescribed in the said Agreement.

le
ra |]}

On 16th June 2022, company executed a Brand Transfer Agreement with S.G. Corporate Mobility Private Limited for transfer of
Contessa Brand
and certain related rights
Revenue Breakup - FY23:

{reference id: 8
source: https://www.screener.in/company/HINDMOTORS/#profit-loss
context: screeneni! FEED SCREENS TOOLS v Q_ Search for a company A GROWTH v

Hindustan Motors Chart Analysis Peers Quarters Profit & Loss Balance Sheet Cash Flow Ratios Investors Documents &8 Notebook

Profit & Loss

Standalone Figures in Rs. Crores / View Consolidated

RELATED PARTY | | PRODUCT SEGMENTS

Sep 2013 Mar 2014 Mar 2015 Mar 2016 Mar 2017 Mar 2018 Mar 2019 Mar 2020 Mar 2021 Mar 2022 Mar 2023 Mar 2024

Sales + 723 183 15 1 1 -3 1 ie) 1 (e) ie) 3
Expenses + 841 227 53 22 18 13 7 6 5 7 5 4
Operating Profit -118 -44 -38 -21 -16 -16 -6 -6 -4 -7 -5 -1
OPM % -16% -24% -251% -2,632% -1,450% -1,124% -2,757% -331% -36%
Other Income + 91 108 6 2 12 88 36 6 11 28 5 27
Interest 31 56 8 10 10 9 2 0 ie) 0 0 0
Depreciation 22 8 2 2 2 1 1 1 1 1 1 (e)
Profit before tax -80 -1 -42 -32 -16 62 27 -1 6 20 -1 25
Tax % -11% 339% 0% 0% 0% 9% -0% -2% 40% 8% -104% -1%
Net Profit + -71 -3 -42 -32 -16 57 27 -1 4 19 (0) 25
EPS in Rs -3.85 -0.17 -2.01 -1.54 -0.77 2.71 1.28 -0.04 0.18 0.89 0.00 1.22
Dividend Payout % 0% 0% 0% 0% 0% 0% 0% 0% 0% 0% 0% 0%

Compounded Sales Growth Compounded Profit Growth Stock Price CAGR Return on Equity

10 Years: -33% 10 Years: 8% 10 Years: 13% 10 Years: %

RK Vaare: AQ0f RK Vaarec: _40/ RK Vaare: celel' ls RK Vaare: of}


{reference id: 9
source: https://www.bseindia.com/xml-data/corpfiling/AttachHis/c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf#page=80
context: c915c6c3-8e7d-481b-alec-6888115cbc71.pdf 80 / 95 — 100% + Ea] »S

HINDUSTAN MOTORS LIMITED

78 Notes to Accounts (Contd.)

(Amounts in INR Lakhs)
Year ended Year ended
March 31, 2023. March 31, 2022
24. OTHER INCOME

a) Interest on Fixed Deposit with Banks and Others * 37.64 37.98
b) Other Non Operating Income
Unspent Liabilities and Provisions no longer required Written Back 297.07 1,324.51
Rent and Hire Charges (Including Access Fees) 35.30 36.88
Miscellaneous Income -Non Operating 9.03 0.61
79 Profit on Disposal of Property, Plant and Equipment (Net) - 57.79

* Includes : Interest on Income Tax Refund Rs. Nil (Rs. 0.29 Lakhs)
Total other income 1,457.77

. EMPLOYEE BENEFITS EXPENSE
Salaries & Wages
Contribution to Provident and Other Funds
Staff Welfare Expense
Total employee benefits expense

. FINANCE COSTS *
Interest on delayed payment of statutory liabilities & others

Total finance costs

* includes interest on arrear Municipal Tax INR 10.00 Lakhs (Nil).

. DEPRECIATION AND AMORTISATION EXPENSE
Depreciation of property, plant and equipment
Amortisation of intangible assets
Total depreciation and amortisation expense

81 . RATES & TAXES
Municipal & other taxes

le
ra |]}

Company is generating continuous
operational losses and its net worh
has eroded. In FY23, it was unable to
generate any revenue except Other
Income which consists of: Interest
on Fixed Deposit with Banks and
Others ~
10%
, Other Non Operating
Income ~
90%
Last edited 4 months, 1 week ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2006 | Mar 2007 | Mar 2008 | Mar 2009 | Mar 2010 | Mar 2011 | Mar 2012 | Sep 2013 | Mar 2014 | Mar 2015 | Mar 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 428 | 627 | 666 | 603 | 578 | 665 | 500 | 724 | 183 | 15 | 1 |
| Expenses + | 461 | 730 | 802 | 731 | 706 | 781 | 598 | 842 | 227 | 53 | 22 |
| Operating Profit | -34 | -103 | -135 | -129 | -128 | -116 | -98 | -118 | -44 | -38 | -21 |
| OPM % | -8% | -16% | -20% | -21% | -22% | -17% | -20% | -16% | -24% | -251% | -2,632% |
| Other Income + | 23 | 155 | 222 | 122 | 124 | 111 | 92 | 84 | 111 | 6 | 2 |
| Interest | 9 | 17 | 20 | 12 | 11 | 27 | 20 | 30 | 57 | 8 | 10 |
| Depreciation | 18 | 23 | 21 | 21 | 18 | 17 | 22 | 22 | 8 | 2 | 2 |
| Profit before tax | -38 | 12 | 46 | -39 | -32 | -49 | -48 | -86 | 1 | -42 | -32 |
| Tax % | 18% | -4% | 33% | -9% | 57% | -8% | -7% | -10% | 334% | 0% | 0% |
| Net Profit + | -44 | 13 | 38 | -38 | -43 | -32 | -31 | -73 | -2 | -42 | -32 |
| EPS in Rs | -2.75 | 0.79 | 2.36 | -2.34 | -2.66 | -2.00 | -1.82 | -3.98 | -0.11 | -2.01 | -1.52 |
| Dividend Payout % | 0% | 0% | 0% | 0% | 0% | 0% | 0% | 0% | 0% | 0% | 0% |
| 10 Years: | -47% |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -74% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |
| TTM: | -95% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 3% |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 57% |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 123% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |
| Last Year: | % |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2008 | Mar 2009 | Mar 2010 | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales | Amount
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automobiles | 664 | 595 | 577 |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | 2 | 1 | 0 |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: Intersegment | 0 | 0 | 0 |  |  |  |  |  |  |  |  |  |  |  |  |
| Profit before Tax & Int | Amount
Margin %
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automobiles | 10% | -4% | -4% |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | -118% | -104% | -1,186% |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital Employed | Amount
ROCE % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Automobiles | 41% | -19% | -31% |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | -714% | % | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated | -1% | 0% | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -47% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -74% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -95% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 57% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 123% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2006 | Mar 2007 | Mar 2008 | Mar 2009 | Mar 2010 | Mar 2011 | Mar 2012 | Sep 2013 | Mar 2014 | Mar 2015 | Mar 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -29 | -21 | -53 | -45 | 9 | -102 | -101 | -109 | -24 | 33 | 9 |
| Cash from Investing Activity + | -4 | 62 | 101 | 47 | 57 | 76 | 102 | 143 | 78 | 1 | 0 |
| Cash from Financing Activity + | -15 | 12 | -97 | -6 | -35 | 25 | -10 | -47 | -61 | -35 | -9 |
| Net Cash Flow | -48 | 54 | -49 | -3 | 31 | -1 | -9 | -13 | -6 | -1 | -0 |

## Ratios Data
| Unknown | Mar 2006 | Mar 2007 | Mar 2008 | Mar 2009 | Mar 2010 | Mar 2011 | Mar 2012 | Sep 2013 | Mar 2014 | Mar 2015 | Mar 2016 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 44 | 22 | 25 | 10 | 8 | 9 | 14 | 10 | 36 | 31 | 505 |
| Inventory Days | 96 | 78 | 61 | 59 | 59 | 68 | 53 | 50 | 37 | 279 | 774 |
| Days Payable | 187 | 126 | 109 | 101 | 126 | 115 | 75 | 50 | 119 | 674 | 2,785 |
| Cash Conversion Cycle | -47 | -26 | -23 | -33 | -59 | -37 | -8 | 11 | -46 | -364 | -1,506 |
| Working Capital Days | -26 | -18 | -3 | -20 | -62 | -43 | -59 | -46 | -140 | -1,737 | -50,595 |
| ROCE % |  | -16% | -13% | -32% | -39% | -43% | -70% | -115% |  |  |  |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 32.34% | 32.34% | 32.34% | 32.34% | 32.33% | 32.33% | 32.33% | 32.33% | 32.33% | 32.33% | 32.33% | 32.33% |
| FIIs + | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.04% | 0.05% |
| DIIs + | 1.32% | 1.32% | 1.32% | 1.32% | 3.14% | 3.14% | 3.14% | 3.14% | 3.14% | 3.14% | 2.65% | 2.63% |
| Public + | 66.32% | 66.32% | 66.32% | 66.32% | 64.49% | 64.49% | 64.49% | 64.50% | 64.49% | 64.49% | 64.98% | 64.98% |
| No. of Shareholders | 1,21,892 | 1,39,607 | 1,46,625 | 1,86,534 | 2,02,413 | 2,00,280 | 1,97,741 | 1,95,784 | 1,96,306 | 1,99,245 | 2,10,560 | 2,47,511 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 32.34% | 32.34% | 32.34% | 32.34% | 32.34% | 32.34% | 32.33% | 32.33% | 32.33% |
| FIIs + | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.02% | 0.04% | 0.05% |
| DIIs + | 5.85% | 4.89% | 4.89% | 4.89% | 4.88% | 1.32% | 3.14% | 2.65% | 2.63% |
| Public + | 61.79% | 62.76% | 62.76% | 62.76% | 62.76% | 66.32% | 64.49% | 64.98% | 64.98% |
| No. of Shareholders | 1,28,525 | 1,23,839 | 1,19,507 | 1,18,081 | 1,18,075 | 1,46,625 | 1,97,741 | 2,10,560 | 2,47,511 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/hindustan-motors-ltd/hindmotors/500500/corp-announcements/)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=de2568f1-6333-41b6-b8da-53f844e1aef4.pdf)
- [Closure of Trading Window 26 Jun](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=80b61883-1639-4f0c-a534-762dfa15dfba.pdf)
- [Compliances-Reg.24(A)-Annual Secretarial Compliance
24 May - SECRETARIAL COMPLIANCE UNDER REGULATION 24A OF SEBI LODR,2015](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e6d109b-c231-423a-9a7e-6637625f5987.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 22 May](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cdfc95bc-9513-4877-bbe4-14aa3e0faec5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bee88455-5f87-4dde-bf6c-ce06b81ede53.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/75314500500.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/69991500500.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/66436500500.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000913.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_3029_HINDMOTORS_2012_2013_02122013151400.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_HINDMOTORS_2010_2011_21072011122526.zip)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Maruti Suzuki | 12688.00 | 398914.00 | 29.57 | 4.67 | 2.81 | 130.55 | 17.32 | 16.99 | 0.98 | 23.68 | 13.49 | 18.30 | 1.42 | 0.00 | 91.00 | 1.17 | 141858.20 | 13.06 | 13488.20 | 38471.20 | 3952.30 | 19.43 | 47.05 | 429.01 | 118.60 | 58.19 | 0.00 | 4.46 | 30.29 | 0.00 | 20.66 | 100.01 | 396205.20 | 0.87 | 1.67 | -0.53 | 26.79 | 20.47 | 29.38 | 12.38 | 10.78 | 17.70 | 44.88 | 10.51 | 26.32 | 11.52 | 14.50 | 0.67 | 429.01 | 16.76 | 39.25 | 39.92 | 40.18 | -30.88 | 30.21 |
| 2. | M & M | 2815.85 | 350159.07 | 31.07 | 5.29 | 2.52 | -41.66 | 15.85 | 37.61 | 0.76 | 13.58 | 5.59 | 18.39 | 0.63 | 1.64 | 3.13 | 3.32 | 139078.27 | 17.90 | 11268.64 | 35451.73 | 2754.08 | 9.23 | 5.37 | 90.62 | 108647.25 | 18.59 | -0.73 | 5.25 | 30.29 | 0.06 | 14.69 | 20.23 | 446793.57 | 1.12 | 1.85 | 35.36 | 73.79 | 54.79 | 82.45 | 17.11 | 11.80 | 16.80 | 80.02 | 5.84 | 23.25 | 18.11 | 12.69 | 0.87 | 90.62 | 16.79 | 20.93 | 20.65 | 20.84 | -11.31 | 124.35 |
| 3. | Mercury EV-Tech | 72.31 | 1269.39 | 637.88 | 15.72 | 57.65 | -33.81 | 387.14 |  | 0.00 | 2.96 | 1.75 | 3.05 | 0.19 | 0.69 | 14.76 | 1.41 | 22.02 | 13.26 | 1.99 | 5.57 | 0.23 | -20.31 | -23.33 | 0.11 | 55.54 | 62.10 | 0.00 | 0.23 | 30.29 | 0.00 | 36.77 | 55.38 | 1324.01 | 4.22 |  | -11.82 | -28.38 | 376.93 | 197.22 |  |  |  |  |  |  | 4.99 | 4.35 | 3.81 | 0.11 |  | 632.05 | 632.05 | 632.05 | 204.69 | 16.69 |
| 4. | Hindustan Motors | 31.40 | 655.19 |  |  | 808.88 | 29.27 | -35.76 | 39.01 | 0.00 |  | -51.84 |  | 0.01 |  | -2.05 | -0.65 | 0.81 | -2632.10 | -31.64 |  |  |  |  | -1.52 | 37.88 | 32.34 | 0.00 | -3.07 | 30.29 | 0.00 | -94.64 | 24.61 | 693.02 | 0.15 |  | 32.49 | 67.91 | 57.41 | 122.70 |  |  | 10.06 |  | -73.87 |  |  |  | 0.10 | -1.52 | 11.23 |  |  |  | -1506.13 | 20.87 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | Sales | ₹ 0.81 Cr. |
| HINDMOTORS | OPM | -2,632 % |
| HINDMOTORS | Profit after tax | ₹ -31.6 Cr. |
| HINDMOTORS | Mar Cap | ₹ 655 Cr. |
| HINDMOTORS | Sales Qtr | ₹ Cr. |
| HINDMOTORS | PAT Qtr | ₹ Cr. |
| HINDMOTORS | Qtr Sales Var | % |
| HINDMOTORS | Qtr Profit Var | % |
| HINDMOTORS | Price to Earning |  |
| HINDMOTORS | Dividend yield | 0.00 % |
| HINDMOTORS | Price to book value |  |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | Return on assets | -51.8 % |
| HINDMOTORS | Debt to equity |  |
| HINDMOTORS | Return on equity | % |
| HINDMOTORS | EPS | ₹ -1.52 |
| HINDMOTORS | Debt | ₹ 37.9 Cr. |
| HINDMOTORS | Promoter holding | 32.3 % |
| HINDMOTORS | Change in Prom Hold | 0.00 % |
| HINDMOTORS | Earnings yield | -3.07 % |
| HINDMOTORS | Pledged percentage | 0.00 % |
| HINDMOTORS | Industry PE | 30.3 |
| HINDMOTORS | Sales growth | -94.6 % |
| HINDMOTORS | Profit growth | 24.6 % |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | Price to Sales | 809 |
| HINDMOTORS | CMP / FCF | 29.3 |
| HINDMOTORS | EVEBITDA | -35.8 |
| HINDMOTORS | Enterprise Value | ₹ 693 Cr. |
| HINDMOTORS | Current ratio | 0.15 |
| HINDMOTORS | Int Coverage | -2.05 |
| HINDMOTORS | PEG Ratio |  |
| HINDMOTORS | Return over 3months | 32.5 % |
| HINDMOTORS | Return over 6months | 67.9 % |
| HINDMOTORS | No. Eq. Shares | 20.9 |
| HINDMOTORS | Sales growth 3Years | % |
| HINDMOTORS | Sales growth 5Years | -73.9 % |
| HINDMOTORS | Profit Var 3Yrs | % |
| HINDMOTORS | Profit Var 5Yrs | 10.1 % |
| HINDMOTORS | ROE 5Yr | % |
| HINDMOTORS | ROE 3Yr | % |
| HINDMOTORS | Return over 1year | 123 % |
| HINDMOTORS | Return over 3years | 57.4 % |
| HINDMOTORS | Return over 5years | 39.0 % |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | Sales last year | ₹ 0.81 Cr. |
| HINDMOTORS | OP Ann | ₹ -21.3 Cr. |
| HINDMOTORS | Other Inc Ann | ₹ 1.91 Cr. |
| HINDMOTORS | EBIDT last year | ₹ -19.4 Cr. |
| HINDMOTORS | Dep Ann | ₹ 1.89 Cr. |
| HINDMOTORS | EBIT last year | ₹ -21.3 Cr. |
| HINDMOTORS | Interest last year | ₹ 10.4 Cr. |
| HINDMOTORS | PBT Ann | ₹ -31.7 Cr. |
| HINDMOTORS | Tax last year | ₹ 0.00 Cr. |
| HINDMOTORS | PAT Ann | ₹ -31.6 Cr. |
| HINDMOTORS | Extra Ord Item Ann | ₹ -0.03 Cr. |
| HINDMOTORS | NP Ann | ₹ -31.7 Cr. |
| HINDMOTORS | Dividend last year | ₹ 0.00 Cr. |
| HINDMOTORS | Raw Material | 407 % |
| HINDMOTORS | Employee cost | ₹ 14.2 Cr. |
| HINDMOTORS | OPM last year | -2,632 % |
| HINDMOTORS | NPM last year | -3,906 % |
| HINDMOTORS | Operating profit | ₹ -21.3 Cr. |
| HINDMOTORS | Interest | ₹ 10.4 Cr. |
| HINDMOTORS | Depreciation | ₹ 1.89 Cr. |
| HINDMOTORS | EPS last year | ₹ -1.52 |
| HINDMOTORS | EBIT | ₹ -21.3 Cr. |
| HINDMOTORS | Net profit | ₹ -31.7 Cr. |
| HINDMOTORS | Current Tax | ₹ 0.00 Cr. |
| HINDMOTORS | Tax | ₹ 0.00 Cr. |
| HINDMOTORS | Other income | ₹ 1.91 Cr. |
| HINDMOTORS | Ann Date | 2,01,603 |
| HINDMOTORS | Sales Prev Ann | ₹ 15.1 Cr. |
| HINDMOTORS | OP Prev Ann | ₹ -37.9 Cr. |
| HINDMOTORS | Other Inc Prev Ann | ₹ 5.88 Cr. |
| HINDMOTORS | EBIDT Prev Ann | ₹ -32.0 Cr. |
| HINDMOTORS | Dep Prev Ann | ₹ 2.10 Cr. |
| HINDMOTORS | EBIT preceding year | ₹ -34.2 Cr. |
| HINDMOTORS | Interest Prev Ann | ₹ 7.82 Cr. |
| HINDMOTORS | PBT Prev Ann | ₹ -41.9 Cr. |
| HINDMOTORS | Tax preceding year | ₹ 0.00 Cr. |
| HINDMOTORS | PAT Prev Ann | ₹ -42.0 Cr. |
| HINDMOTORS | Extra Ord Prev Ann | ₹ 0.07 Cr. |
| HINDMOTORS | NP Prev Ann | ₹ -41.9 Cr. |
| HINDMOTORS | Dividend Prev Ann | ₹ 0.00 Cr. |
| HINDMOTORS | OPM preceding year | -251 % |
| HINDMOTORS | NPM preceding year | -278 % |
| HINDMOTORS | EPS preceding year | ₹ -2.01 |
| HINDMOTORS | Sales Prev 12M | ₹ Cr. |
| HINDMOTORS | Profit Prev 12M | ₹ Cr. |
| HINDMOTORS | Med Sales Gwth 10Yrs | -9.57 % |
| HINDMOTORS | Med Sales Gwth 5Yrs | -91.7 % |
| HINDMOTORS | Sales growth 7Years | -61.1 % |
| HINDMOTORS | Sales Var 10Yrs | -46.6 % |
| HINDMOTORS | EBIDT growth 3Years | % |
| HINDMOTORS | EBIDT growth 5Years | 10.6 % |
| HINDMOTORS | EBIDT growth 7Years | 7.83 % |
| HINDMOTORS | EBIDT Var 10Yrs | -0.02 % |
| HINDMOTORS | EPS growth 3Years | % |
| HINDMOTORS | EPS growth 5Years | 11.2 % |
| HINDMOTORS | EPS growth 7Years | 8.25 % |
| HINDMOTORS | EPS growth 10Years | 4.31 % |
| HINDMOTORS | Profit Var 7Yrs | 7.56 % |
| HINDMOTORS | Profit Var 10Yrs | 3.32 % |
| HINDMOTORS | Chg in Prom Hold 3Yr | 0.00 % |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | OP Qtr | ₹ Cr. |
| HINDMOTORS | Other Inc Qtr | ₹ Cr. |
| HINDMOTORS | EBIDT Qtr | ₹ Cr. |
| HINDMOTORS | Dep Qtr | ₹ Cr. |
| HINDMOTORS | EBIT latest quarter | ₹ Cr. |
| HINDMOTORS | Interest Qtr | ₹ Cr. |
| HINDMOTORS | PBT Qtr | ₹ Cr. |
| HINDMOTORS | Tax latest quarter | ₹ Cr. |
| HINDMOTORS | Extra Ord Item Qtr | ₹ Cr. |
| HINDMOTORS | NP Qtr | ₹ Cr. |
| HINDMOTORS | GPM latest quarter | % |
| HINDMOTORS | OPM latest quarter | % |
| HINDMOTORS | NPM latest quarter | % |
| HINDMOTORS | Eq Cap Qtr | ₹ Cr. |
| HINDMOTORS | EPS latest quarter | ₹ |
| HINDMOTORS | OP 2Qtr Bk | ₹ Cr. |
| HINDMOTORS | OP 3Qtr Bk | ₹ Cr. |
| HINDMOTORS | Sales 2Qtr Bk | ₹ Cr. |
| HINDMOTORS | Sales 3Qtr Bk | ₹ Cr. |
| HINDMOTORS | NP 2Qtr Bk | ₹ Cr. |
| HINDMOTORS | NP 3Qtr Bk | ₹ Cr. |
| HINDMOTORS | Opert Prft Gwth | 43.7 % |
| HINDMOTORS | Last result date | 2,01,603 |
| HINDMOTORS | Exp Qtr Sales Var | % |
| HINDMOTORS | Exp Qtr Sales | ₹ Cr. |
| HINDMOTORS | Exp Qtr OP | ₹ Cr. |
| HINDMOTORS | Exp Qtr NP | ₹ Cr. |
| HINDMOTORS | Exp Qtr EPS | ₹ |
| HINDMOTORS | Sales Prev Qtr | ₹ Cr. |
| HINDMOTORS | OP Prev Qtr | ₹ Cr. |
| HINDMOTORS | Other Inc Prev Qtr | ₹ Cr. |
| HINDMOTORS | EBIDT Prev Qtr | ₹ Cr. |
| HINDMOTORS | Dep Prev Qtr | ₹ Cr. |
| HINDMOTORS | EBIT Prev Qtr | ₹ Cr. |
| HINDMOTORS | Interest Prev Qtr | ₹ Cr. |
| HINDMOTORS | PBT Prev Qtr | ₹ Cr. |
| HINDMOTORS | Tax Prev Qtr | ₹ Cr. |
| HINDMOTORS | PAT Prev Qtr | ₹ Cr. |
| HINDMOTORS | Extra Ord Prev Qtr | ₹ Cr. |
| HINDMOTORS | NP Prev Qtr | ₹ Cr. |
| HINDMOTORS | OPM Prev Qtr | % |
| HINDMOTORS | NPM Prev Qtr | % |
| HINDMOTORS | Eq Cap Prev Qtr | ₹ Cr. |
| HINDMOTORS | EPS Prev Qtr | ₹ |
| HINDMOTORS | Sales PY Qtr | ₹ Cr. |
| HINDMOTORS | OP PY Qtr | ₹ Cr. |
| HINDMOTORS | Other Inc PY Qtr | ₹ Cr. |
| HINDMOTORS | EBIDT PY Qtr | ₹ Cr. |
| HINDMOTORS | Dep PY Qtr | ₹ Cr. |
| HINDMOTORS | EBIT PY Qtr | ₹ Cr. |
| HINDMOTORS | Interest PY Qtr | ₹ Cr. |
| HINDMOTORS | PBT PY Qtr | ₹ Cr. |
| HINDMOTORS | Tax PY Qtr | ₹ Cr. |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | Equity capital | ₹ 104 Cr. |
| HINDMOTORS | Preference capital | ₹ 0.00 Cr. |
| HINDMOTORS | Reserves | ₹ -198 Cr. |
| HINDMOTORS | Secured loan | ₹ 20.0 Cr. |
| HINDMOTORS | Unsecured loan | ₹ 17.9 Cr. |
| HINDMOTORS | Balance sheet total | ₹ 51.6 Cr. |
| HINDMOTORS | Gross block | ₹ 237 Cr. |
| HINDMOTORS | Revaluation reserve | ₹ 7.28 Cr. |
| HINDMOTORS | Accum Dep | ₹ 210 Cr. |
| HINDMOTORS | Net block | ₹ 27.2 Cr. |
| HINDMOTORS | CWIP | ₹ 0.00 Cr. |
| HINDMOTORS | Investments | ₹ 0.19 Cr. |
| HINDMOTORS | Current assets | ₹ 19.9 Cr. |
| HINDMOTORS | Current liabilities | ₹ 135 Cr. |
| HINDMOTORS | BV Unq Invest | ₹ 0.00 Cr. |
| HINDMOTORS | MV Quoted Inv | ₹ 0.00 Cr. |
| HINDMOTORS | Cont Liab | ₹ 146 Cr. |
| HINDMOTORS | Total Assets | ₹ 51.6 Cr. |
| HINDMOTORS | Working capital | ₹ -112 Cr. |
| HINDMOTORS | Lease liabilities | ₹ 0.00 Cr. |
| HINDMOTORS | Inventory | ₹ 7.00 Cr. |
| HINDMOTORS | Trade receivables | ₹ 1.12 Cr. |
| HINDMOTORS | Face value | ₹ 5.00 |
| HINDMOTORS | Cash Equivalents | ₹ 0.05 Cr. |
| HINDMOTORS | Adv Cust | ₹ 0.00 Cr. |
| HINDMOTORS | Trade Payables | ₹ 25.2 Cr. |
| HINDMOTORS | No. Eq. Shares PY | 20.9 |
| HINDMOTORS | Debt preceding year | ₹ 40.8 Cr. |
| HINDMOTORS | Work Cap PY | ₹ -71.6 Cr. |
| HINDMOTORS | Net Block PY | ₹ 29.3 Cr. |
| HINDMOTORS | Gross Block PY | ₹ 239 Cr. |
| HINDMOTORS | CWIP PY | ₹ 0.00 Cr. |
| HINDMOTORS | Work Cap 3Yr | ₹ Cr. |
| HINDMOTORS | Work Cap 5Yr | ₹ -46.6 Cr. |
| HINDMOTORS | Work Cap 7Yr | ₹ -22.3 Cr. |
| HINDMOTORS | Work Cap 10Yr | ₹ -20.9 Cr. |
| HINDMOTORS | Debt 3Years back | ₹ Cr. |
| HINDMOTORS | Debt 5Years back | ₹ 125 Cr. |
| HINDMOTORS | Debt 7Years back | ₹ 124 Cr. |
| HINDMOTORS | Debt 10Years back | ₹ 159 Cr. |
| HINDMOTORS | Net Block 3Yrs Back | ₹ Cr. |
| HINDMOTORS | Net Block 5Yrs Back | ₹ 128 Cr. |
| HINDMOTORS | Net Block 7Yrs Back | ₹ 154 Cr. |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | CF Operations | ₹ 8.52 Cr. |
| HINDMOTORS | Free Cash Flow | ₹ 8.70 Cr. |
| HINDMOTORS | CF Investing | ₹ 0.36 Cr. |
| HINDMOTORS | CF Financing | ₹ -8.97 Cr. |
| HINDMOTORS | Net CF | ₹ -0.08 Cr. |
| HINDMOTORS | Cash Beginning | ₹ 0.13 Cr. |
| HINDMOTORS | Cash End | ₹ 0.05 Cr. |
| HINDMOTORS | FCF Prev Ann | ₹ 33.8 Cr. |
| HINDMOTORS | CF Operations PY | ₹ 33.2 Cr. |
| HINDMOTORS | CF Investing PY | ₹ 0.70 Cr. |
| HINDMOTORS | CF Financing PY | ₹ -34.5 Cr. |
| HINDMOTORS | Net CF PY | ₹ -0.66 Cr. |
| HINDMOTORS | Cash Beginning PY | ₹ 0.79 Cr. |
| HINDMOTORS | Cash End PY | ₹ 0.24 Cr. |
| HINDMOTORS | Free Cash Flow 3Yrs | ₹ 67.2 Cr. |
| HINDMOTORS | Free Cash Flow 5Yrs | ₹ Cr. |
| HINDMOTORS | Free Cash Flow 7Yrs | ₹ Cr. |
| HINDMOTORS | Free Cash Flow 10Yrs | ₹ Cr. |
| HINDMOTORS | CF Opr 3Yrs | ₹ 17.6 Cr. |
| HINDMOTORS | CF Opr 5Yrs | ₹ Cr. |
| HINDMOTORS | CF Opr 7Yrs | ₹ Cr. |
| HINDMOTORS | CF Opr 10Yrs | ₹ Cr. |
| HINDMOTORS | CF Inv 10Yrs | ₹ Cr. |
| HINDMOTORS | CF Inv 7Yrs | ₹ Cr. |
| HINDMOTORS | CF Inv 5Yrs | ₹ Cr. |
| HINDMOTORS | CF Inv 3Yrs | ₹ 79.4 Cr. |
| HINDMOTORS | Cash 3Years back | ₹ Cr. |
| HINDMOTORS | Cash 5Years back | ₹ 31.4 Cr. |
| HINDMOTORS | Cash 7Years back | ₹ 11.0 Cr. |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | No. Eq. Shares | 20.9 |
| HINDMOTORS | Book value | ₹ -4.47 |
| HINDMOTORS | Inven TO | 0.40 |
| HINDMOTORS | Quick ratio | 0.10 |
| HINDMOTORS | Exports percentage | 0.00 % |
| HINDMOTORS | Piotroski score | 3.00 |
| HINDMOTORS | G Factor | 0.00 |
| HINDMOTORS | Asset Turnover | 0.01 |
| HINDMOTORS | Financial leverage | -0.65 |
| HINDMOTORS | No. of Share Holders | 2,47,511 |
| HINDMOTORS | Unpledged Prom Hold | 32.3 % |
| HINDMOTORS | ROIC | % |
| HINDMOTORS | Debtor days | 505 |
| HINDMOTORS | Industry PBV | 10.7 |
| HINDMOTORS | Credit rating |  |
| HINDMOTORS | WC Days | -50,595 |
| HINDMOTORS | Earning Power | -41.2 % |
| HINDMOTORS | Graham Number | ₹ |
| HINDMOTORS | Cash Cycle | -1,506 |
| HINDMOTORS | Days Payable | 2,785 |
| HINDMOTORS | Days Receivable | 505 |
| HINDMOTORS | Inventory Days | 774 |
| HINDMOTORS | Public holding | 65.0 % |
| HINDMOTORS | FII holding | 0.05 % |
| HINDMOTORS | Chg in FII Hold | 0.01 % |
| HINDMOTORS | DII holding | 2.63 % |
| HINDMOTORS | Chg in DII Hold | -0.02 % |
| HINDMOTORS | B.V. Prev Ann | ₹ -2.96 |
| HINDMOTORS | ROCE Prev Yr | % |
| HINDMOTORS | ROA Prev Yr | -32.4 % |
| HINDMOTORS | ROE Prev Ann | % |
| HINDMOTORS | No. of Share Holders Prev Qtr | 2,10,560 |
| HINDMOTORS | No. Eq. Shares 10 Yrs | 16.1 |
| HINDMOTORS | BV 3yrs back | ₹ |
| HINDMOTORS | BV 5yrs back | ₹ 1.51 |
| HINDMOTORS | BV 10yrs back | ₹ 7.59 |
| HINDMOTORS | Inven TO 3Yr |  |
| HINDMOTORS | Inven TO 5Yr | 5.45 |
| HINDMOTORS | Inven TO 7Yr | 6.36 |
| HINDMOTORS | Inven TO 10Yr | 5.27 |
| HINDMOTORS | Export 3Yr | % |
| HINDMOTORS | Export 5Yr | 0.00 % |
| HINDMOTORS | Div 5Yrs | ₹ Cr. |
| HINDMOTORS | ROCE 3Yr | 0.00 % |
| HINDMOTORS | ROCE 5Yr | -70.0 % |
| HINDMOTORS | ROCE 7Yr | -50.5 % |
| HINDMOTORS | ROCE 10Yr | -35.3 % |
| HINDMOTORS | ROE 10Yr | % |
| HINDMOTORS | ROE 7Yr | % |
| HINDMOTORS | ROE 5Yr Var | % |
| HINDMOTORS | OPM 5Year | % |
| HINDMOTORS | OPM 10Year | % |
| HINDMOTORS | No. of Share Holders 1Yr | 1,95,784 |
| HINDMOTORS | Avg Div Payout 3Yrs | 0.00 % |
| HINDMOTORS | Debtor days 3yrs | 191 |
| HINDMOTORS | Debtor days 3yrs back |  |
| HINDMOTORS | Debtor days 5yrs back | 9.44 |
| HINDMOTORS | ROA 5Yr | % |
| HINDMOTORS | ROA 3Yr | % |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | Avg Vol 1Mth | 16,04,301 |
| HINDMOTORS | Avg Vol 1Wk | 10,43,148 |
| HINDMOTORS | Volume | 7,83,694 |
| HINDMOTORS | High price | ₹ 48.7 |
| HINDMOTORS | Low price | ₹ 12.6 |
| HINDMOTORS | High price all time | ₹ 94.8 |
| HINDMOTORS | Low price all time | ₹ 2.51 |
| HINDMOTORS | Return over 1day | -0.25 % |
| HINDMOTORS | Return over 1week | -0.79 % |
| HINDMOTORS | Return over 1month | -10.9 % |
| HINDMOTORS | DMA 50 | ₹ 32.9 |
| HINDMOTORS | DMA 200 | ₹ 25.5 |
| HINDMOTORS | DMA 50 previous day | ₹ 32.9 |
| HINDMOTORS | 200 DMA prev. | ₹ 25.4 |
| HINDMOTORS | RSI | 40.0 |
| HINDMOTORS | MACD | -0.83 |
| HINDMOTORS | MACD Previous Day | -0.80 |
| HINDMOTORS | MACD Signal | -0.75 |
| HINDMOTORS | MACD Signal Prev | -0.74 |
| HINDMOTORS | Avg Vol 1Yr | 28,70,908 |
| HINDMOTORS | Return over 7years | 21.6 % |
| HINDMOTORS | Return over 10years | 13.3 % |
| HINDMOTORS | Market Cap | ₹ 655 Cr. |
| HINDMOTORS | Current Price | ₹ 31.4 |
| HINDMOTORS | High / Low | ₹ 48.7 / 12.6 |
| HINDMOTORS | Stock P/E |  |
| HINDMOTORS | Book Value | ₹ -4.47 |
| HINDMOTORS | Dividend Yield | 0.00 % |
| HINDMOTORS | ROCE | % |
| HINDMOTORS | ROE | % |
| HINDMOTORS | Face Value | ₹ 5.00 |
| HINDMOTORS | WC to Sales | -13,856 % |
| HINDMOTORS | QoQ Profits | % |
| HINDMOTORS | QoQ Sales | % |
| HINDMOTORS | Net worth | ₹ -93.4 Cr. |
| HINDMOTORS | Market Cap to Sales | 809 |
| HINDMOTORS | Interest Coverage | -2.05 |
| HINDMOTORS | EV / EBIT | -32.6 |
| HINDMOTORS | Debt Capacity |  |
| HINDMOTORS | Debt To Profit | -1.20 |
| HINDMOTORS | Capital Employed | ₹ -85.0 Cr. |
| HINDMOTORS | CROIC | -58.7 % |
| HINDMOTORS | debtplus | -1.97 |
| HINDMOTORS | Leverage | ₹ -0.65 |
| HINDMOTORS | Dividend Payout | 0.00 % |
| HINDMOTORS | Intrinsic Value | ₹ |
| HINDMOTORS | CDL | -28.0 % |
| HINDMOTORS | Cash by market cap | 0.00 |
| HINDMOTORS | 52w Index | 52.0 % |
| HINDMOTORS | Down from 52w high | 35.5 % |
| HINDMOTORS | Up from 52w low | 148 % |
| HINDMOTORS | From 52w high | 0.64 |
| HINDMOTORS | Mkt Cap To Debt Cap |  |
| HINDMOTORS | Dividend Payout | 0.00 % |
| HINDMOTORS | Graham | ₹ |
| HINDMOTORS | Price to Cash Flow | 76.9 |
| HINDMOTORS | ROCE3yr avg | 0.00 % |
| HINDMOTORS | PB X PE |  |
| HINDMOTORS | NCAVPS | ₹ -5.38 |
| HINDMOTORS | Mar Cap to CF | 76.9 |
| HINDMOTORS | Altman Z Score | 13.8 |
| HINDMOTORS | M.Cap / Qtr Profit |  |