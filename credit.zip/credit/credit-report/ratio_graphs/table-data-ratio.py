# req_data - data-req.json
# formulae - formula-ratio.json
import json , time
file_path = '/Users/Shreyas2/Desktop/Onfinance/credit/credit-report/ratio_graphs/data-req.json'
file_path2 = '/Users/Shreyas2/Desktop/Onfinance/credit/credit-report/ratio_graphs/formula-ratio.json'
# Open and load the JSON file
def validate_json(file_path):
    try:
        with open(file_path, 'r') as file:
            json_data = json.load(file)
        print("JSON is valid")
        return json_data
    except json.JSONDecodeError as e:
        print(f"JSONDecodeError: {e}")
    except Exception as e:
        print(f"Error: {e}")

req_data = validate_json(file_path)
formulae = validate_json(file_path2)
from openai import AzureOpenAI

openAIClient_novis = AzureOpenAI(
    api_key = "add2ae8844844d55bd3e1300ccbc9bc2",  
    api_version = "2023-05-15",
    azure_endpoint = "https://openai-service-onfi.openai.azure.com/" 
)
table_data = """| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Maruti Suzuki | 12688.00 | 398914.00 | 29.57 | 4.67 | 2.81 | 130.55 | 17.32 | 16.99 | 0.98 | 23.68 | 13.49 | 18.30 | 1.42 | 0.00 | 91.00 | 1.17 | 141858.20 | 13.06 | 13488.20 | 38471.20 | 3952.30 | 19.43 | 47.05 | 429.01 | 118.60 | 58.19 | 0.00 | 4.46 | 30.29 | 0.00 | 20.66 | 100.01 | 396205.20 | 0.87 | 1.67 | -0.53 | 26.79 | 20.47 | 29.38 | 12.38 | 10.78 | 17.70 | 44.88 | 10.51 | 26.32 | 11.52 | 14.50 | 0.67 | 429.01 | 16.76 | 39.25 | 39.92 | 40.18 | -30.88 | 30.21 |
| 2. | M & M | 2815.85 | 350159.07 | 31.07 | 5.29 | 2.52 | -41.66 | 15.85 | 37.61 | 0.76 | 13.58 | 5.59 | 18.39 | 0.63 | 1.64 | 3.13 | 3.32 | 139078.27 | 17.90 | 11268.64 | 35451.73 | 2754.08 | 9.23 | 5.37 | 90.62 | 108647.25 | 18.59 | -0.73 | 5.25 | 30.29 | 0.06 | 14.69 | 20.23 | 446793.57 | 1.12 | 1.85 | 35.36 | 73.79 | 54.79 | 82.45 | 17.11 | 11.80 | 16.80 | 80.02 | 5.84 | 23.25 | 18.11 | 12.69 | 0.87 | 90.62 | 16.79 | 20.93 | 20.65 | 20.84 | -11.31 | 124.35 |
| 3. | Mercury EV-Tech | 72.31 | 1269.39 | 637.88 | 15.72 | 57.65 | -33.81 | 387.14 |  | 0.00 | 2.96 | 1.75 | 3.05 | 0.19 | 0.69 | 14.76 | 1.41 | 22.02 | 13.26 | 1.99 | 5.57 | 0.23 | -20.31 | -23.33 | 0.11 | 55.54 | 62.10 | 0.00 | 0.23 | 30.29 | 0.00 | 36.77 | 55.38 | 1324.01 | 4.22 |  | -11.82 | -28.38 | 376.93 | 197.22 |  |  |  |  |  |  | 4.99 | 4.35 | 3.81 | 0.11 |  | 632.05 | 632.05 | 632.05 | 204.69 | 16.69 |
| 4. | Hindustan Motors | 31.40 | 655.19 |  |  | 808.88 | 29.27 | -35.76 | 39.01 | 0.00 |  | -51.84 |  | 0.01 |  | -2.05 | -0.65 | 0.81 | -2632.10 | -31.64 |  |  |  |  | -1.52 | 37.88 | 32.34 | 0.00 | -3.07 | 30.29 | 0.00 | -94.64 | 24.61 | 693.02 | 0.15 |  | 32.49 | 67.91 | 57.41 | 122.70 |  |  | 10.06 |  | -73.87 |  |  |  | 0.10 | -1.52 | 11.23 |  |  |  | -1506.13 | 20.87 |"""
def generate_ratio_data(
openAIClient_novis,
data_type,
req_data,
formulae,
systemPrompt = """
You are a helpful AI assistant that can calculate and return the required data from the given list - {req_data} for generating financial graphs.
You will be provided with the data in the following format:

* A list of the required data - {req_data} you will need to calculate the {table_data}.
* The formulae - {formulae} using which you have to calculate the required {table_data}.

Instructions : 
1. Your task is to CORRECTLY CALCULATE THE REQUIRED FINANCIAL METRIC GIVEN THE FORMULAE.
2. DO NOT RETURN THE STEPS FOR CALCULATION AS PART OF THE OUTPUT. RETURN ONLY THE FINAL LIST OR DICTIONARY.
3. If you are given only a single value for a corresponding list of values, that means THE SINGLE VALUE WILL REMAIN CONSTANT FOR ALL CALCULATIONS, with the other values being taken from the list.
For example - 
In the case of EV/Sales calculation : 
You will be given only the latest EV value, and a list of Sales values. To calculate EV/Sales :
Output = [EV/Sales[0] , EV/Sales[1], ... ]

4. If there is no formulae for a particular metric (e.g Inventory Turnover Ratio), then return the input list of data AS IT IS. 


For example:
If the user wants to plot a chart of data_type = 'Fixed Asset Turnover Ratio' over the years, you will be given :
1.  A dictionary consisting of the data required to calculate the financial metric.
2.  The formula to calculate the metric.
3.  Return one list:
    *   `Fixed Asset Turnover Ratio`: Containing all values of the FINAL calculated fixed assets, using the data values from the list given to you.  
    *   `Fiscal Years`: Containing all values of the fiscal years. This will remain constant - FY 21 ; FY 22 ; FY 23; FY 24

Output Format:
Example : 
```json
{
  "Fixed Asset Turnover Ratio" : [1.44, 2.56, 3.39, 2.56, 1.63]
}
""",
userPrompt = """

Input -
Required Data - 
{req_data}
---
Data Type - 
{data_type}
---
Formulae - 
{formulae}

Output-
ONLY ONE LIST OF THE FINAL CALCULATED DATA
---
#
""",
useGPT4 = True,
verbose = True
):
    def openAICallStream(openAIClient_novis, message, temperature = 0, verbose = True, useGPT4=True):

        query_answer = ''

        answer = ''
        start_time = time.time()
        if useGPT4:
            model = "onfiGPT-4"
        else:
            model = "onfi-gpt35-16k"

        response = openAIClient_novis.chat.completions.create(
            messages=message,
            model=model,
            temperature=temperature,
            stream = True
        )

        for event in response:
            # STREAM THE ANSWER
            if verbose:
                print(answer, end='', flush=True) # Print the response
            # RETRIEVE THE TEXT FROM THE RESPONSE
            event_text = event.choices[0].delta # EVENT DELTA RESPONSE
            answer = event_text.content # RETRIEVE CONTENT
            if answer is None:
                answer = ''
            query_answer += answer

        # if verbose:
        #     print("\n\n--- %s seconds ---\n" % (time.time() - start_time))

        return query_answer
    #==========================================================================
    message = [
        {"role":"system", "content":systemPrompt},
        {"role":"user", "content":userPrompt.format(data_type=data_type, req_data=req_data , formulae=formulae)}
    ]
    # if verbose:

    #     print(f"Question: {question}\n\nAnswer: ", end='')

    query_answer = openAICallStream(openAIClient_novis, message, verbose=verbose, useGPT4=useGPT4)
    if verbose:
        print("-----------------------------------------------\n\n")

data_type_ratio = "Assets Turnover Ratio"
generate_ratio_data(openAIClient_novis, req_data, formulae, data_type_ratio )
