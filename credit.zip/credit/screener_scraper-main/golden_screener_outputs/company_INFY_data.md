About
[
edit
]
Infosys Ltd provides consulting, technology, outsourcing and next-generation digital services to enable clients to execute strategies for their digital transformation.
[1]
It is the 2nd largest Information Technology company in India behind TCS.
[2]
Key Points
[
edit
]
Digital Services (~57% of revenues)
[1]
It comprises of services and solution offerings of the group that enables clients to transform their businesses. It includes offerings that enhance customer experience, leverage AI-based analytics and big data, engineer digital products and IoT, modernize legacy tech systems, migrate to cloud applications and implement advanced cyber-security systems.
[2]
Core Services (~43% of revenues)
It comprises of traditional offerings of the group that include application management services, proprietary application development services, independent validation solutions, product engineering and management, infrastructure management services, traditional enterprise application implementation and support and integration services.
[2]
Products and Platforms
The company also offers various services through its key products and platforms viz. Infosys Finacle, Infosys McCamish, Panaya, Infosys Meridian, Helix, Equinox, Wingspan, Edgeverve, Stater and others.
[3]
Revenue Breakup
Vertical-wise :-
Financial services- 32%
Retail - ~15%
Communication, telecom & Media - ~13%
Energy, Utility, etc. - ~12%
Manufacturing - 11%
Hi-tech - 8%
Life Sciences & Healthcare - 7%
Others - 3%
[1]
Geography-wise :-
North America - 62%
Europe - 25%
ROW - 10%
India - 3%
[1]
Clientele Overview
As present, the company caters to ~185 of Fortune 500 companies.
[4]
It has 38 of 100+ million USD clients, 64 50+ million USD clients, 275 10+ million USD clients, ~850 1+ million USD clients.
[3]
Its clients include companies/ organizations like ICICI Bank, Daimler Mercedes-Benz, HSBC Bank, Goldman Sachs, J&J, Accenture, US Army, US Navy, Lockheed Martin, IBM Corporation, Deutsche Bank and others.
[5]
Employee Base
As per FY22, the company has an employee base of ~3,15,000 employees.
[3]
In FY22, over 1,40,000 employees joined the company out of which 80,000 were directly recruited from colleges.
[6]
Attrition Rate -
In FY22, the company witnessed a heavy employee attrition rate of ~28% compared to ~11% in FY21 and ~17% in FY20.
[7]
Leading Subsidiaries
The group's businesses are also handled through some of its leading subsidiaries :-
1. Infosys BPM Ltd (~5.5% of revenues)
[8]
- It is the business process management (BPM) subsidiary of the Infosys Group engaged in providing end-to-end transformative Digital BPM services for global clients across various industries and service lines.
[9]
2. EdgeVerve Systems Ltd (~2.5% of revenues)
- It is a global leader in AI, Automation and Analytics which helps businesses with their business processes, documents and supply chain.
[10]
Futures
1. Consulting-led End-to-End Solutions: Infosys aims to focus on opportunities arising from consulting-led end-to-end solutions. This approach allows them to provide comprehensive services to clients across various domains.
2. Leveraging Technology for Higher Margins: The company plans to leverage technology to enhance its margins. By adopting innovative solutions and efficient processes, Infosys aims to optimize its operations and financial performance.
3. Intellectual Property-Based Solutions: Infosys intends to develop intellectual property-based solutions. These solutions can help delink revenues from effort, creating sustainable growth and value for the company.
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright
