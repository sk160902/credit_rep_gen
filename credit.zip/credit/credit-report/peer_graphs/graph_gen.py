# GENERATING ALL PEERS TABLES

import matplotlib.pyplot as plt

def plot_financial_data(companies, values, title, y_label, file_name):
    plt.figure(figsize=(12, 8))
    plt.plot(companies, values, marker='o', linestyle='-', color='b', label=y_label)

    # Adding labels and title
    plt.title(title)
    plt.xlabel('Companies')
    plt.ylabel(y_label)
    plt.xticks(rotation=45, ha='right')
    plt.legend()

    # Removing gridlines
    plt.grid(False)

    # Display the plot
    plt.tight_layout()
    plt.savefig(file_name, dpi=200)
    # plt.show()

# List of peer companies (constant)
companies = ["Maruti Suzuki" , "M&M", "Mercury EV-Tech", "Hindustan Motors"]

# Data for each financial metric (empty lists as placeholders)
metrics_data = {

  "EV/EBITDA": [13.49, 5.59, 1.75, -51.84],
  "P/E": [29.57, 31.07, 637.88, 808.88],
  "CMP/BV": [4.67, 5.29, 15.72, 0.00],
  "CMP/FCF": [130.55, -41.66, -33.81, 29.27],
  "CMP/Sales": [2.81, 2.52, 57.65, 0.01],
  "5Yrs return %": [23.68, 13.58, 2.96, 0.00],
  "Dividend Yield": [1.17, 3.32, 1.41, -0.65],
  "ROCE": [18.30, 18.39, 3.05, 0.00],
  "ROA": [13.49, 5.59, 1.75, -51.84],
  "Asset Turnover": [1.42, 0.63, 0.19, 0.01],
  "Debt/Equity": [0.00, 1.64, 0.69, 0.00],
  "Interest Coverage": [91.00, 3.13, 14.76, -2.05],
  "Current Ratio": [1.17, 3.32, 1.41, -0.65],
  "Quick Ratio": [1.17, 3.32, 1.41, -0.65],
  "Inventory Turnover": [10.78, 11.80, 0.00, 0.00],
  "Cash Cycle Days": [30.21, 124.35, 16.69, 20.87]

}

# Titles and axis labels for each financial metric
metrics_info = {
    "EV/EBITDA": ("EV/EBITDA Comparison", "EV/EBITDA", "EV_EBITDA.png"),
    "P/E": ("P/E Ratio Comparison", "P/E Ratio", "PE_Ratio.png"),
    "CMP/BV": ("CMP/BV Ratio Comparison", "CMP/BV Ratio", "CMP_BV_Ratio.png"),
    "CMP/FCF": ("CMP/FCF Ratio Comparison", "CMP/FCF Ratio", "CMP_FCF_Ratio.png"),
    "CMP/Sales": ("CMP/Sales Ratio Comparison", "CMP/Sales Ratio", "CMP_Sales_Ratio.png"),
    "5Yrs return %": ("5-Year Return % Comparison", "5-Yrs Return %", "5Yrs_Return.png"),
    "Dividend Yield": ("Dividend Yield Comparison", "Dividend Yield", "Dividend_Yield.png"),
    "ROCE": ("ROCE Comparison", "ROCE", "ROCE.png"),
    "ROA": ("ROA Comparison", "ROA", "ROA.png"),
    "Asset Turnover": ("Asset Turnover Comparison", "Asset Turnover", "Asset_Turnover.png"),
    "Debt/Equity": ("Debt/Equity Comparison", "Debt/Equity", "Debt_Equity.png"),
    "Interest Coverage": ("Interest Coverage Comparison", "Interest Coverage", "Interest_Coverage.png"),
    "Current Ratio": ("Current Ratio Comparison", "Current Ratio", "Current_Ratio.png"),
    "Quick Ratio": ("Quick Ratio Comparison", "Quick Ratio", "Quick_Ratio.png"),
    "Inventory Turnover": ("Inventory Turnover Comparison", "Inventory Turnover", "Inventory_Turnover.png"),
    "Cash Cycle Days": ("Cash Cycle Days Comparison", "Cash Cycle Days", "Cash_Cycle_Days.png"),
}

# Generate graphs for each financial metric
for metric, (title, y_label, file_name) in metrics_info.items():
    plot_financial_data(companies, metrics_data[metric], title, y_label, file_name)



## market cap bar graph

def plot_market_cap():
    # Data
    companies = ["Maruti Suzuki" , "M&M", "Mercury EV-Tech", "Hindustan Motors"]
    market_caps = [398914, 350159.07, 1269.39, 655.19]
    file_name = "Market_Cap.png"
    
    # Plotting the bar chart
    fig, ax = plt.subplots()
    ax.bar(companies, market_caps, color='blue')
    
    # Adding labels and title
    plt.xlabel('Companies')
    plt.ylabel('Market Cap (Rs. Cr.)')
    plt.title('Market Capitalization Comparison')
    
    # Rotating x-axis labels
    plt.xticks(rotation=45, ha='right')
    
    # Removing gridlines
    plt.grid(False)

    # Display the plot
    plt.tight_layout()
    plt.savefig(file_name, dpi=200)

# Call the function to plot the chart
plot_market_cap()




## SHAREHOLDING PATTERN PIE CHARTS

import matplotlib.pyplot as plt

# def plot_shareholding_donut_chart(values, year, output_file):
#     # Fixed data
#     labels = ['Promoters', 'FIIs', 'DIIs', 'Government', 'Public']
#     colors = ['#ff9999','#66b3ff','#99ff99','#ffcc99','#c2c2f0']
#     title = f'Shareholding Data for {year}'

#     # Create a pie chart
#     fig, ax = plt.subplots()
#     wedges, texts = ax.pie(values, colors=colors, startangle=90, pctdistance=0.85)

#     # Draw a circle at the center to make it a donut chart
#     centre_circle = plt.Circle((0,0),0.70,fc='white')
#     fig.gca().add_artist(centre_circle)

#     # Equal aspect ratio ensures that pie is drawn as a circle.
#     ax.axis('equal')  

#     # Set title
#     plt.title(title)

#     # Add legend
#     ax.legend(wedges, labels, title="Categories", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))

#     # Display the pie chart
#     plt.tight_layout()

#     # Save the graph as an image
#     plt.savefig(output_file, dpi=200)
#     plt.show()

# Example usage
# values_2022 = []
# values_2024 = []
# output_file_2022 = 'shareholding-2022.png'
# output_file_2024 = 'shareholding-2024.png'

# plot_shareholding_donut_chart(values_2022, 2022, output_file_2022)
# plot_shareholding_donut_chart(values_2024, 2024, output_file_2024)