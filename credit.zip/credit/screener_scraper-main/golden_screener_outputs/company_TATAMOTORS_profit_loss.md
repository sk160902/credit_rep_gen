# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 188,793 | 232,834 | 263,159 | 273,046 | 269,693 | 291,550 | 301,938 | 261,068 | 249,795 | 278,454 | 345,967 | 437,928 |
| Expenses + | 164,197 | 197,980 | 223,920 | 234,650 | 240,104 | 260,093 | 277,274 | 243,081 | 217,507 | 253,734 | 314,151 | 378,389 |
| Operating Profit | 24,596 | 34,853 | 39,239 | 38,395 | 29,589 | 31,458 | 24,664 | 17,987 | 32,287 | 24,720 | 31,816 | 59,538 |
| OPM % | 13% | 15% | 15% | 14% | 11% | 11% | 8% | 7% | 13% | 9% | 9% | 14% |
| Other Income + | 213 | -157 | 714 | -2,670 | 1,869 | 5,933 | -26,686 | 102 | -11,118 | 2,424 | 6,664 | 5,673 |
| Interest | 3,560 | 4,749 | 4,861 | 4,889 | 4,238 | 4,682 | 5,759 | 7,243 | 8,097 | 9,312 | 10,225 | 9,986 |
| Depreciation | 7,601 | 11,078 | 13,389 | 16,711 | 17,905 | 21,554 | 23,591 | 21,425 | 23,547 | 24,836 | 24,860 | 27,270 |
| Profit before tax | 13,647 | 18,869 | 21,703 | 14,126 | 9,315 | 11,155 | -31,371 | -10,580 | -10,474 | -7,003 | 3,394 | 27,955 |
| Tax % | 28% | 25% | 35% | 21% | 35% | 39% | -8% | 4% | 24% | 60% | 21% | -14% |
| Net Profit + | 9,976 | 14,050 | 14,073 | 11,678 | 7,557 | 9,091 | -28,724 | -11,975 | -13,395 | -11,309 | 2,690 | 31,807 |
| EPS in Rs | 34.62 | 48.46 | 48.44 | 40.11 | 25.82 | 31.13 | -99.84 | -39.08 | -40.51 | -34.46 | 7.27 | 94.47 |
| Dividend Payout % | 6% | 5% | 0% | 1% | 0% | 0% | 0% | 0% | 0% | 0% | 32% | 15% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 93% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 128% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1266% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 49% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 69% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 49% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tata Sons Pvt. Ltd., its subsidiaries and joint ventures |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  |  |  |  | 5,494 | 3,149 |  |  |  |  |
| Finance taken (including loans and equity) |  |  |  |  |  | 4,561 |  |  |  |  |
| Services received |  |  |  |  | 1,867 | 1,560 |  |  |  |  |
| Sale of products |  |  |  |  | 828 | 848 |  |  |  |  |
| Finance taken, paid back (including loans and equity) |  |  |  |  |  | 858 |  |  |  |  |
| Sale of Investments |  |  |  |  | 533 |  |  |  |  |  |
| Trade payables |  |  |  |  | 373 | 158 |  |  |  |  |
| Trade and other receivables |  |  |  |  | 199 | 189 |  |  |  |  |
| Purchase of products |  |  |  |  | 203 | 43 |  |  |  |  |
| Services rendered |  |  |  |  | 116 | 81 |  |  |  |  |
| Acceptances |  |  |  |  | 69 | 77 |  |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  | 95 |  |  |  |  |
| Interest (income)/expense, dividend (income)/paid.(net) |  |  |  |  |  | 29 |  |  |  |  |
| Interest (income)/expense, dividend (income)/ paid, (net) |  |  |  |  | 23 |  |  |  |  |  |
| Amounts payable in respect of loans and interest thereon |  |  |  |  | 3.60 | 1.93 |  |  |  |  |
| Amount receivable in respect of Loans and interest thereon |  |  |  |  |  | 4.18 |  |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  |  |  |  | 3.80 |  |  |  |  |  |
| Finance given, taken back (including loans and equity) |  |  |  |  |  | 3.50 |  |  |  |  |
| Purchase of property, plant and equipment |  |  |  |  | 0.80 | 2.37 |  |  |  |  |
| Tata Sons Ltd |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  | 2,902 | 3,203 |  |  |  |  |  |  |  |
| Services received | 1.94 | 1,850 | 1,970 |  |  |  |  |  |  |  |
| Loans taken/repaid |  | 918 | 1,217 |  |  |  |  |  |  |  |
| Proceeds from issue of shares |  | 1,967 |  |  |  |  |  |  |  |  |
| Sale of products |  | 757 | 462 |  |  |  |  |  |  |  |
| Trade payables |  | 163 | 471 |  |  |  |  |  |  |  |
| Trade and other receivables |  | 455 | 160 |  |  |  |  |  |  |  |
| Services rendered |  | 112 | 130 |  |  |  |  |  |  |  |
| Loans given/repaid |  | 125 | 91 |  |  |  |  |  |  |  |
| Amounts payable in respect of loans and interest thereon |  | 106 | 106 |  |  |  |  |  |  |  |
| Purchase of products |  | 67 | 67 |  |  |  |  |  |  |  |
| Interest income dividend income(net) |  | 38 | 64 |  |  |  |  |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  | 35 | 9.33 |  |  |  |  |  |  |  |
| Sale of Investments |  | 7.15 |  |  |  |  |  |  |  |  |
| Deposit given as security |  | 3 | 3 |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  | 0.92 | 0.11 |  |  |  |  |  |  |  |
| Dividend received | -0.99 |  |  |  |  |  |  |  |  |  |
| Tata Sons Pvt Ltd, its subsidiaries and joint ventures |  |  |  |  |  |  |  |  |  |  |
| Bills discounted |  |  |  |  |  |  | 5,947 |  |  |  |
| Finance taken - including loans and equity |  |  |  |  |  |  | 2,603 |  |  |  |
| Services received |  |  |  |  |  |  | 1,425 |  |  |  |
| Sale of products |  |  |  |  |  |  | 946 |  |  |  |
| Acceptances |  |  |  |  |  |  | 929 |  |  |  |
| Trade and other receivables |  |  |  |  |  |  | 348 |  |  |  |
| Trade payables |  |  |  |  |  |  | 222 |  |  |  |
| Services rendered |  |  |  |  |  |  | 170 |  |  |  |
| Interest expense, dividend /paid, - net |  |  |  |  |  |  | 59 |  |  |  |
| Finance given - including loans and equity |  |  |  |  |  |  | 41 |  |  |  |
| Sale of property, plant and equipment |  |  |  |  |  |  | 34 |  |  |  |
| Purchase of products |  |  |  |  |  |  | 28 |  |  |  |
| Amounts payable in respect of loans and interest thereon |  |  |  |  |  |  | 6.07 |  |  |  |
| Amounts receivable in respect of loans and interest thereon |  |  |  |  |  |  | 4.59 |  |  |  |
| Purchase of property, plant and equipment |  |  |  |  |  |  | 3.72 |  |  |  |
| Tata Capital |  |  |  |  |  |  |  |  |  |  |
| Vendor bills discounting |  |  |  |  |  |  | 5,947 |  |  |  |
| Bill discounted |  |  |  | 4,135 |  |  |  |  |  |  |
| Chery Jaguar Land Rover Automotive Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Services rendered | 11 |  |  | 1,208 | 765 | 960 | 1,077 |  |  |  |
| Sale of goods (inclusive of sales tax) | 74 |  |  |  |  |  |  |  |  |  |
| Tata Sons Pvt. Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Preferential allotment |  |  |  |  |  | 3,892 |  |  |  |  |
| Tata Sons Pvt Ltd Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Converstion of Warrant/ Preferential allotment |  |  |  |  |  |  | 2,603 |  |  |  |
| Fiat India Automobiles Private Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 150 |  |  |  |  |  |  |  |  |  |
| Sale of goods (inclusive of sales tax) | 53 |  |  |  |  |  |  |  |  |  |
| Interest received | -1.30 |  |  |  |  |  |  |  |  |  |
| Tata Cummins Private Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 117 |  |  |  |  |  |  |  |  |  |
| Tata AutoComp Systems Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 117 |  |  |  |  |  |  |  |  |  |
| Dividend received | -1.05 |  |  |  |  |  |  |  |  |  |
| Automobile Corporation of Goa Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 38 |  |  |  |  |  |  |  |  |  |
| Inter-corporate deposits | 6.40 |  |  |  |  |  |  |  |  |  |
| Nita Company Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods (inclusive of sales tax) | 14 |  |  |  |  |  |  |  |  |  |
| Spark 44 (JV) Limited Key Person |  |  |  |  |  |  |  |  |  |  |
| Services received | 4.58 |  |  |  |  |  |  |  |  |  |
| Tata Hitachi Construction Machinery Company Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Services rendered | 0.79 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 188,793 | 232,834 | 263,159 | 273,046 | 269,693 | 291,550 | 301,938 | 261,068 | 249,795 | 278,454 | 345,967 | 437,928 |
| Expenses + | 164,197 | 197,980 | 223,920 | 234,650 | 240,104 | 260,093 | 277,274 | 243,081 | 217,507 | 253,734 | 314,151 | 378,389 |
| Operating Profit | 24,596 | 34,853 | 39,239 | 38,395 | 29,589 | 31,458 | 24,664 | 17,987 | 32,287 | 24,720 | 31,816 | 59,538 |
| OPM % | 13% | 15% | 15% | 14% | 11% | 11% | 8% | 7% | 13% | 9% | 9% | 14% |
| Other Income + | 213 | -157 | 714 | -2,670 | 1,869 | 5,933 | -26,686 | 102 | -11,118 | 2,424 | 6,664 | 5,673 |
| Interest | 3,560 | 4,749 | 4,861 | 4,889 | 4,238 | 4,682 | 5,759 | 7,243 | 8,097 | 9,312 | 10,225 | 9,986 |
| Depreciation | 7,601 | 11,078 | 13,389 | 16,711 | 17,905 | 21,554 | 23,591 | 21,425 | 23,547 | 24,836 | 24,860 | 27,270 |
| Profit before tax | 13,647 | 18,869 | 21,703 | 14,126 | 9,315 | 11,155 | -31,371 | -10,580 | -10,474 | -7,003 | 3,394 | 27,955 |
| Tax % | 28% | 25% | 35% | 21% | 35% | 39% | -8% | 4% | 24% | 60% | 21% | -14% |
| Net Profit + | 9,976 | 14,050 | 14,073 | 11,678 | 7,557 | 9,091 | -28,724 | -11,975 | -13,395 | -11,309 | 2,690 | 31,807 |
| EPS in Rs | 34.62 | 48.46 | 48.44 | 40.11 | 25.82 | 31.13 | -99.84 | -39.08 | -40.51 | -34.46 | 7.27 | 94.47 |
| Dividend Payout % | 6% | 5% | 0% | 1% | 0% | 0% | 0% | 0% | 0% | 0% | 32% | 15% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 93% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 128% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1266% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 49% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 69% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 49% |  |  |  |  |  |  |  |  |  |  |  |

