from unittest.mock import Base
from openai import AzureOpenAI
import weaviate
from litellm import completion
import requests
import instructor
from pydantic import BaseModel, Field
from duckduckgo_search import DDGS
from typing import List, Optional


vector_db = weaviate.Client("http://52.249.216.32:8081")
llm_client = instructor.from_litellm(completion)

def search_web_plain(query):
    return DDGS().text(query, max_results=10)

def bing_engine(ques):
    try:
        response = requests.get(
            "https://api.bing.microsoft.com/v7.0/search", 
            headers={"Ocp-Apim-Subscription-Key" : '1344549ecdc5471abf4e5eb9f49e629b'},
            params={"q": ques, "textDecorations": True, "textFormat": "HTML"}
        )
        return response.json()["webPages"]["value"][0]["url"]
    except Exception as err:
        print(f"Error: {err}")
        return []


def search_web(query):
    query_1 = query + "risks"
    results_1 = DDGS().text(query_1, max_results=10)

    query_2 = query + "financials and growth"
    results_2 = DDGS().text(query_2, max_results=10)

    results= results_1 + results_2
    return results

class Risks(BaseModel):
    sources : List[str] = Field(...,description="List of sources you got this from, should be urls which should be picked from websources json, this shouldnt be empty, use some links in websearch result i provided")
    risk : str = Field(...,description="Risk identified with s with numerics and all long answers, these should be as descriptive as possible")

class IndustryRisks(BaseModel):
    risks : List[Risks] = Field(...,description="List of industry risks with numerics and all long answers and sources")


def generate_vector(query):
    oai_client = AzureOpenAI(
    azure_endpoint="https://openai-service-onfi.openai.azure.com/",
        api_version="2023-05-15",
        api_key="add2ae8844844d55bd3e1300ccbc9bc2"
    )
    vector = oai_client.embeddings.create(input=[query], model="onfi-embedding-model").data[0].embedding
    return vector


def run_search(keyword, n=10):
    vector = generate_vector(keyword)
    response = vector_db.query.get(
        "MEGH", ["question", "context", "page_number","doc_url","source"]
    ).with_near_vector({
        "vector": vector
    }).with_limit(n).do()
    results = response['data']['Get']['MEGH']
    unique_contexts = set(item['context'] for item in results)
    context = '\n\n\n'.join(unique_contexts)
    return context

def llm_call(messages, model):
    response = llm_client.chat.completions.create(
        model="azure/gpt4o-dev",
        api_key="c0c736e92d0047ad94d66aea592c1e29",
        api_version="2024-02-01",
        api_base="https://harshith-gpt4o.openai.azure.com/",
        messages=messages,
        response_model=model,
        temperature=0.0
    )
    return response


def llm_call_nomodel(messages):
    oai_client = AzureOpenAI(
        api_key="c0c736e92d0047ad94d66aea592c1e29",
        api_version="2024-02-01",
        azure_endpoint="https://harshith-gpt4o.openai.azure.com/",
    )
    response = oai_client.chat.completions.create(
        model="gpt4o-dev",
        messages=messages,
        temperature=0.0
    )
    return response.choices[0].message.content

class Promoter(BaseModel):
    name: str = Field(description="The name of the promoter")
    experience: str = Field(description="The experience history of the promoter")
     
class PromotersList(BaseModel):
    promoters: List[Promoter] = Field(description="The list of all the significant promoters")

class Pointer(BaseModel):
    point_header: str = Field(description="The header of the point")
    point_content: str = Field(description="The content of the point")

class KeyStrengths(BaseModel):
    strengths: List[Pointer] = Field(description="Each point should be returned as a heading and text content within the heading, which highlight the key strengths of Meghmani Organics Ltd. ")

class KeyIssues(BaseModel):
    issues: List[Pointer] = Field(description="Each point should be returned as a heading and text content within the heading, which highlight the key issues or weaknessed of Meghmani Organics Ltd. ")



def parse_jina(url):
    url = "https://r.jina.ai/" + url
    response = requests.get(url)
    return response.text


class CompanyData(BaseModel):
    company_name: str
    pe_ratio: str
    market_cap: str
    dividend_yield: str
    netprofits_quarterly: str
    sales_quarterly: str
    roce: str


class DataPoint(BaseModel):
    year: Optional[str] = Field(description="The financial year corresponding to the datapoint in the format of FY-20, FY-21 and so on")
    value: Optional[str] = Field(description="The value of the data point for that financial year")

class BriefFinancials(BaseModel):
    sales: List[DataPoint] = Field(description="The sales data for the company. This is normally mentioned in the {balance sheet or income statement} of the company")
    EBITDA: List[DataPoint] = Field(description="The EBITDA data for the company. This is normally mentioned in the {balance sheet or income statement} of the company")
    PAT: List[DataPoint] = Field(description="The PAT data for the company. This is normally mentioned in the {balance sheet or income statement} of the company")
    total_equity_capital: List[DataPoint] = Field(description="The total equity capital data for the company. This is normally mentioned in the {balance sheet} of the company")
    non_current_liabilities: List[DataPoint] = Field(description="The non current liabilities data for the company. This is normally mentioned in the {balance sheet} of the company")
    current_liabilities: List[DataPoint] = Field(description="The current liabilities data for the company. This is normally mentioned in the {balance sheet} of the company")
    ebt_margin: List[DataPoint] = Field(description="The EBT margin data for the company. This is normally mentioned in the {balance sheet} of the company")
    non_current_assets: List[DataPoint] = Field(description="The non current assets data for the company. This is normally mentioned in the {balance sheet} of the company")
    current_assets: List[DataPoint] = Field(description="The current assets data for the company. This is normally mentioned in the {balance sheet} of the company")
    total_assets: List[DataPoint] = Field(description="The total assets data for the company. This is normally mentioned in the {balance sheet} of the company")
    return_on_equity: List[DataPoint] = Field(description="The return on equity data for the company. This is normally mentioned in the {balance sheet} of the company")
    current_ratio: List[DataPoint] = Field(description="The current ratio data for the company. This is normally mentioned in the {balance sheet} of the company")
    ebt_margin_percent: List[DataPoint] = Field(description="The EBT margin percent data for the company. This is normally mentioned in the {balance sheet} of the company")

class Peers(BaseModel):
    peer_names_list: List[str] = Field(description="The list of names of all the peer companies of Meghmani Organics mentioned in the context")
    
class CompanyRating(BaseModel):
    company_name: str = Field(description="The name of the peer company")
    long_term_rating: str = Field(description="The long term rating of the peer company. This normally comes from the first 2/3 of the ratings value. For example: If the total rating is CRISIL AAA/Stable/CRISIL A1+ , the long term rating is CRISIL AAA/Stable", default="N/A")
    short_term_rating: str = Field(description="The short term rating of the peer company. This normally comes from the last 1/3 of the ratings value. For example: If the total rating is CRISIL AAA/Stable/CRISIL A1+ , the short term rating is CRISIL A1+", default="N/A")

class CRISILModel(BaseModel):
    ratings: List[CompanyRating] = Field(description="The ratings of the peer companies of Meghmani Organics mentioned in the context")
    commentary: List[str] = Field(description="The commentary on the ratings of the peer companies of Meghmani Organics mentioned in the context")

# RAW MD, GENERATE PYTHON CODE, RENDER CHART AND YOU PUSH TO DRIVE AND RETURN DRIVE LINK
# chart_data:{"ev/ebitda": {"url": "url", "commentary": ["", "", ""]}}
def plot_graph(dataframe):
    pass

if __name__ == "__main__":
    peers_question = "Provide insights into the overall performance and market sentiment of the chemical sector based on the data provided in the table."
    # what is the crisil rating of meghmani group after:2024-02-21
    # promoters = llm_call_nomodel(
    #     [
    #         {"role": "system", "content": "Return the output as an unordered list."},
    #         {"role": "user", "content": f"Context:\n{run_search(promoters_question)}\n\n\nQuestion:\n{promoters_question}"}
    #     ]
    # )
    # print(promoters)
    # promoters_data = parse_jina("https://meghmani.com/about/board-of-directors/")
    # print(promoters_data)
    # print(promoters_parsed_profiles.model_dump_json())
    
    # print(run_search("What are the key strengths of Meghmani Organics Ltd.?"))
    # print(run_search("What are the key weaknesses of Meghmani Organics Ltd.?"))