# Complete Company Data

## Modal Content
About
[
edit
]
Incorporated in 1943,RBL Bank is a banking company engaged in providing specialized services under five business verticals namely: Corporate Banking, Commercial Banking, Branch & Business Banking, Retail Assets and Treasury & Financial Markets Operations.
[1]
[2]
Key Points
[
edit
]
Ratios (9MFY24)
Capital Adequacy Ratio - 16.42%
[1]
Net Interest Margin - 5.53%
[2]
Gross NPA - 3.12%
[3]
Net NPA - 0.80%
CASA Ratio - 33.8%
[4]
Branch Network
[5]
The bank operates a network of 538 branches, 388 ATMs and ~1200 business correspondent (microfinance) branches across India. Present in 500 districts and servicing 18,000 pin codes.
Customer Base
[5]
The bank's customer base is above 1.4 Cr across segments. ~6+ lakh customers were added in Q3FY24.
Loan Book 9MFY24
[6]
58% of loan book consists of retail loans the rest 42% consists of wholesale loans
Corporate and Institutional Banking (C&IB) - 31%
Commercial Banking - 11%
Business loans - 9%
Credit Cards - 20%
Personal Loans - 4%
Microfinance - 9%
Housing Loan - 8%
Rural vehicle Finance - 2%
Retail Agri - 2%
Others - 4%
Deposits 9MFY24
[7]
Current Account: 15%
Savings Account: 19%
Term Deposits: 66%
Less than 2cr deposits at 44.5%. 60% of SA and TD acquisition happening digitally.
Exposure 9MFY24
Bank has diversified wholesale loan book with low exposure to a single industry. Top industries with exposure include NBFCs (5.1%), Power (3.9%), Construction (3.5%), Retail/Distribution (3.1%), Engineering (2.3%),  Pharma (2.1%), Metals (1.8%), Auto (1.7%), Professional Services (1.4%) and Cement (1.4%).
[8]
Bank has highest retail loan book exposure in Credit cards (34%) followed by Business Loan (16%), Micro-Banking (15%), Housing Loans (13%), Personal Loans (8%), Other Retail (6%), Agri (4%) and Rural Vehicle Finance (4%).
[9]
5.75 Lakhs credit cards issued in Q3FY24; Total cards outstanding at 50.4 Lakhs.
[10]
Fees Breakup 9MFY24
[11]
Trading- FICC: 6%
Core Fees: 94%
Core Fees Breakup
Processing Fees: 32%
General Banking: 27%
Payment Reated: 22%
FX: 10%
Distribution: 6%
Trade & Others: 4%
Updates
Bank has provided Rs. 115 crore towards contingent provision on AIF investments.
[1]
Future Targets (FY24 - FY26)
[12]
1. Bank wants to grow Advances & Deposits by 20%+ CAGR.
2. Grow granular deposits by 50%+.
3. Average CASA growth of 1.2% p.a.
4. Increase touchpoints to 2600
5. Increase customer count to 2.6 Cr. (Double)
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 3,713 | 4,561 | 6,302 | 8,779 | 8,676 | 8,445 | 9,677 | 12,394 | 13,035 |
| Interest | 2,492 | 2,741 | 3,761 | 4,885 | 4,539 | 4,148 | 4,679 | 6,350 | 6,713 |
| Expenses + | 1,234 | 1,827 | 2,559 | 4,919 | 5,129 | 6,674 | 6,071 | 7,520 | 8,058 |
| Financing Profit | -12 | -6 | -17 | -1,025 | -993 | -2,378 | -1,073 | -1,477 | -1,735 |
| Financing Margin % | -0% | -0% | -0% | -12% | -11% | -28% | -11% | -12% | -13% |
| Other Income + | 755 | 1,069 | 1,441 | 1,918 | 1,875 | 2,352 | 2,507 | 3,060 | 3,141 |
| Depreciation | 62 | 89 | 126 | 146 | 170 | 180 | 213 | 235 | 0 |
| Profit before tax | 681 | 974 | 1,298 | 747 | 712 | -206 | 1,221 | 1,349 | 1,406 |
| Tax % | 35% | 34% | 34% | 33% | 26% | -20% | 25% | 7% |  |
| Net Profit + | 447 | 633 | 861 | 500 | 529 | -166 | 920 | 1,260 | 1,291 |
| EPS in Rs | 11.91 | 15.05 | 20.10 | 9.83 | 8.85 | -2.77 | 15.34 | 20.82 | 21.38 |
| Dividend Payout % | 15% | 14% | 13% | 15% | 0% | 0% | 10% | 7% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | -13% |  |  |  |  |  |  |  |  |
| 3 Years: | 5% |  |  |  |  |  |  |  |  |
| 1 Year: | -1% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 5% |  |  |  |  |  |  |  |  |
| 3 Years: | 5% |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transactions |  |  |  |  |  |  |  |  |
| Dividend Paid |  | 2.67 | 3.21 | 6.42 |  |  |  | 0.76 |
| Remuneration | 0.19 | 4.57 | 4.51 | 4.52 | 5.18 | 4.23 | 4.49 | 7.53 |
| Deposit outstanding |  |  |  |  |  |  | 23 | 9.63 |
| Deposits placed |  |  |  | 1.09 |  |  | 3.20 | 1.38 |
| Advances outstanding |  |  |  |  |  |  | 0.18 | 0.17 |
| Interest paid | 0.02 | 0.68 | 0.86 | 1.48 | 2.89 | 2.51 | 0.59 | 0.61 |
| Interest payable | 0.01 | 0.13 | 0.16 | 0.30 | 1.10 | 1.14 | 0.34 | 0.13 |
| Deposit | 1.43 | 14 | 19 | 28 | 91 | 82 |  |  |
| Deposits Placed |  | 0.69 | 0.65 |  | 1.59 | 0.88 |  |  |
| Advances | 0.08 | 0.76 | 0.94 | 0.78 | 0.87 | 0.46 |  |  |
| Advances repaid |  | 0.09 | 0.10 |  | 0.10 | 0.38 |  |  |
| Interest received |  | 0.07 | 0.06 | 0.05 | 0.04 | 0.02 |  |  |
| Others payments |  |  |  | 0.01 | 0.05 |  |  |  |
| Interest receivable |  |  |  | 0.01 | 0.01 |  |  |  |
| Advance repaid |  |  |  | 0.09 |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 3,713 | 4,561 | 6,302 | 8,779 | 8,676 | 8,445 | 9,677 | 12,394 | 13,035 |
| Interest | 2,492 | 2,741 | 3,761 | 4,885 | 4,539 | 4,148 | 4,679 | 6,350 | 6,713 |
| Expenses + | 1,234 | 1,827 | 2,559 | 4,919 | 5,129 | 6,674 | 6,071 | 7,520 | 8,058 |
| Financing Profit | -12 | -6 | -17 | -1,025 | -993 | -2,378 | -1,073 | -1,477 | -1,735 |
| Financing Margin % | -0% | -0% | -0% | -12% | -11% | -28% | -11% | -12% | -13% |
| Other Income + | 755 | 1,069 | 1,441 | 1,918 | 1,875 | 2,352 | 2,507 | 3,060 | 3,141 |
| Depreciation | 62 | 89 | 126 | 146 | 170 | 180 | 213 | 235 | 0 |
| Profit before tax | 681 | 974 | 1,298 | 747 | 712 | -206 | 1,221 | 1,349 | 1,406 |
| Tax % | 35% | 34% | 34% | 33% | 26% | -20% | 25% | 7% |  |
| Net Profit + | 447 | 633 | 861 | 500 | 529 | -166 | 920 | 1,260 | 1,291 |
| EPS in Rs | 11.91 | 15.05 | 20.10 | 9.83 | 8.85 | -2.77 | 15.34 | 20.82 | 21.38 |
| Dividend Payout % | 15% | 14% | 13% | 15% | 0% | 0% | 10% | 7% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |
| TTM: | 27% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | -13% |  |  |  |  |  |  |  |  |
| 3 Years: | 5% |  |  |  |  |  |  |  |  |
| 1 Year: | -1% |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |
| 5 Years: | 5% |  |  |  |  |  |  |  |  |
| 3 Years: | 5% |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 3,434 | -2,556 | 78 | -5,173 | 7,631 | 6,449 | -11,031 | 4,955 |
| Cash from Investing Activity + | -142 | -165 | -202 | -223 | -174 | -264 | -234 | -193 |
| Cash from Financing Activity + | -1,656 | 2,994 | 2,567 | 7,698 | -4,207 | -109 | 2,235 | 843 |
| Net Cash Flow | 1,635 | 273 | 2,443 | 2,302 | 3,251 | 6,076 | -9,030 | 5,604 |

## Ratios Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % |  | 11% | 12% | 6% | 5% | -1% | 7% | 9% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 31.59% | 31.31% | 30.59% | 28.50% | 29.59% | 28.92% | 24.66% | 28.27% | 30.00% | 28.27% | 25.14% | 28.47% |
| DIIs + | 22.34% | 19.68% | 19.05% | 11.64% | 13.83% | 19.85% | 19.77% | 17.91% | 19.12% | 19.34% | 20.12% | 20.28% |
| Government + | 0.36% | 0.36% | 0.36% | 0.36% | 0.36% | 0.38% | 0.42% | 0.42% | 0.41% | 0.42% | 0.42% | 0.42% |
| Public + | 45.70% | 48.64% | 50.00% | 59.50% | 56.22% | 50.84% | 55.14% | 53.38% | 50.45% | 51.98% | 54.32% | 50.83% |
| No. of Shareholders | 4,08,351 | 4,73,495 | 4,67,415 | 5,37,178 | 4,94,291 | 4,16,592 | 4,04,438 | 3,79,536 | 3,51,119 | 3,44,856 | 3,58,110 | 3,64,380 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FIIs + | 11.84% | 18.93% | 22.15% | 28.35% | 34.25% | 30.59% | 24.66% | 25.14% | 28.47% |
| DIIs + | 9.71% | 13.54% | 21.27% | 27.22% | 22.74% | 19.05% | 19.77% | 20.12% | 20.28% |
| Government + | 0.01% | 0.03% | 0.15% | 0.43% | 0.36% | 0.36% | 0.42% | 0.42% | 0.42% |
| Public + | 78.44% | 67.50% | 56.42% | 44.01% | 42.64% | 50.00% | 55.14% | 54.32% | 50.83% |
| No. of Shareholders | 1,65,802 | 1,93,760 | 1,64,007 | 2,08,045 | 3,22,472 | 4,67,415 | 4,04,438 | 3,58,110 | 3,64,380 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/rbl-bank-ltd/rblbank/540065/corp-announcements/)
- [Disclosure Under Regulation 30 Of The SEBI For Approval Granted By The Board Subject To The Approval Of The RBI And The Members For Increase In Authorised Capital. 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=40bb0688-4b09-4785-983f-8de80b274628.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e4a61193-5e48-4c15-baf1-7ad39c84cada.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Outcome
2d - RBL Bank Limited has informed about Transcript of Earnings Call held on July 20, 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6105f18e-a05a-40e4-84e5-1921c99a38d0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a68e5176-6887-4c3b-8716-ff3a85c1ca4c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2908140f-5554-46bb-b838-ff263ed2c74b.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9ba1ece3-94c4-497b-8ba4-7164374038e8.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\70c31d6f-39ea-4737-b02a-482b1dd11e72.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/540065/74743540065.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/540065/69937540065.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/540065/5400650320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/540065/5400650319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/540065/5400650318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/540065/5400650317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/540065/5400650316.pdf)
- [](https://www.bseindia.com/HIS_ANN_RPT/HISTANNR/2015/RBL_BANKLTD-540065-MARCH-2015.PDF)
- [](https://www.bseindia.com/HIS_ANN_RPT/HISTANNR/2014/RBL_BANKLTD-540065-MARCH-2014.PDF)
- [](https://www.bseindia.com/HIS_ANN_RPT/HISTANNR/2013/RBL_BANKLTD-540065-MARCH-2013.PDF)
- [](https://www.bseindia.com/HIS_ANN_RPT/HISTANNR/2012/RBL_BANKLTD-540065-MARCH-2012.PDF)
- [DRHP](https://www.sebi.gov.in/filings/public-issues/aug-2016/rbl-bank-limited_33102.html)

## Credit Ratings
- [Rating update
21 Mar from care](https://www.careratings.com/upload/CompanyFiles/PR/202403140340_RBL_Bank_Limited.pdf)
- [Rating update
27 Sep 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202309120952_RBL_Bank_Limited.pdf)
- [Rating update
16 Aug 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=121560)
- [Rating update
3 Oct 2022 from care](https://www.careratings.com/upload/CompanyFiles/PR/03102022060201_RBL_Bank_Limited.pdf)
- [Rating update
14 Sep 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=114410)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=112285)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a5dff3f-030d-42ad-bfc7-6dddbe3c73bf.pdf)
- [Transcript](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_24_Edited.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4fa79941-7dfa-444d-8aac-58ad13a96e9f.pdf)
- [REC](https://ir.rblbank.com/pdfs/financial-highlights/earnings-audio-call-q4-fy24.mp3)
- [Transcript](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_24_Edited.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d0a87b1a-cc59-4489-8b88-c512ed724973.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a4cd11c-0546-4d40-b387-22446785e9fc.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4a08abee-f1b8-46c7-b32d-189dba5fef20.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0f92efe8-844b-4d0a-aa8e-0804de6a5545.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_24_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b1b23560-d2c9-47e8-8009-b86094520090.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_23_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5a89291e-5e5b-44a3-9d51-0b1a3d28434c.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_23_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=476cb10c-4483-47a3-bd36-4509ae8c9c16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3d6cf23-dfed-4622-921f-55ebc713d161.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q2_FY_23_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=989bdcd4-9770-430e-a2ce-f0613d6f36aa.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_23_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=669d29ad-6235-4293-9ca0-8edcab90adcb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=60c7326e-aa02-4805-a9b7-617a1657eef4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bda8f46f-5d06-44dd-8309-84f9216ae9d3.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_22_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=280df5c7-22c3-4513-923b-27d550fcbf45.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8c1eabac-2da8-4de9-ad70-39585a0e15a4.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_22_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=26b0aaa0-9c70-4df0-a2ac-6ab6da249dd6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=18a7c6ff-11c9-4891-a6d4-59df57db3efc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a871c23e-e7aa-43ab-9bb8-9404e5d1a487.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q2_FY_22_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=162e3976-9295-4da1-9802-11ad57a55581.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_22_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=90e1d469-f703-49ae-b05a-f938e21d1e31.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_21_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d733bd56-ffc4-4146-aa9d-b39b65002d9b.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_21_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e588d3a-0a82-4bbf-ac1d-001cddfb9852.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q2_FY_21_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e829acbf-5a54-4037-8216-a3bbf709afa0.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_21_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6f9df630-c3fd-45d5-a775-70b3b0585e97.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_20_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2e169c84-10c1-4ead-a93a-b6033906fbe7.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_20_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d2c11891-2e91-4d95-81e8-148389e415a5.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q2_FY_20_Edited.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bd77e083-c7fa-4120-8053-300b38c69cad.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d8fa4db4-9369-4d3d-b50c-cfd4d6bb68a0.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c8d6bb31-ba53-49b2-8c90-48e79f109d86.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_FY_19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4d734c96-eb91-446f-bbb1-85f62c68be6d.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q2_FY_19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3b8c9dc1-fc72-4ce3-8616-873dd46abab5.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q1_FY_19.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q4_FY_18.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Call_Transcript_Q3_9M_FY18.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Earnings_Call_Transcript_Q2_FY18.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Earnings_Call_Transcript_Q1_FY18.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Earnings_Call_Transcript_Q4_FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=54976b89-fa62-46f4-be0c-592abab6d3fc.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Earnings_Call_Transcript_Q3_FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91732398_2E3C_42EF_A018_AC550B0549B3_155934.pdf)
- [](https://ir.rblbank.com/pdfs/financial-highlights/Earnings_Call_Transcript_Q2_FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=92DF1573_8E0D_4823_A146_02B899ECAD41_172414.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | HDFC Bank | 1616.00 | 1229472.57 | 18.03 | 2.69 | 3.92 | 203.82 | 16.08 | 7.26 | 1.22 | 7.67 | 1.99 | 17.14 | 0.09 | 6.81 | 1.48 | 7.19 | 314027.08 | 33.60 | 68166.51 | 81546.20 | 16474.85 | 59.37 | 33.18 | 89.75 | 3107502.74 | 0.00 | 0.00 | 6.22 | 12.00 | 0.00 | 70.07 | 39.72 | 4108140.80 | 2.50 | 0.77 | 7.07 | 12.66 | 3.94 | -3.38 | 16.99 | 16.85 | 23.42 | 26.19 | 21.95 | 30.19 | 17.11 | 6.24 | 2.50 | 84.33 | 15.48 | 21.14 | 19.93 | 24.91 | 0.00 | 557.97 |
| 2. | ICICI Bank | 1204.85 | 848010.35 | 19.09 | 3.95 | 5.32 | 12.47 | 15.57 | 23.57 | 0.83 | 8.37 | 2.35 | 20.63 | 0.08 | 6.53 | 1.83 | 9.13 | 159515.92 | 36.37 | 44256.37 | 42606.72 | 11671.52 | 23.72 | 18.46 | 63.02 | 1399893.96 | 0.00 | 0.00 | 6.44 | 12.00 | 0.00 | 31.76 | 30.17 | 2111447.82 | 2.20 | 0.32 | 8.12 | 18.61 | 20.92 | 20.97 | 17.74 | 15.61 | 59.74 | 34.01 | 17.25 | 21.40 | 17.15 | 6.32 | 2.20 | 63.02 | 57.03 | 22.48 | 19.58 | 22.46 | 0.00 | 698.28 |
| 3. | Axis Bank | 1177.90 | 364084.55 | 13.59 | 2.33 | 3.09 | 27.65 | 15.38 | 10.01 | 0.09 | 7.06 | 1.85 | 18.40 | 0.08 | 8.25 | 1.55 | 9.12 | 117671.83 | 62.96 | 26731.28 | 31158.52 | 6436.43 | 18.72 | 5.67 | 86.63 | 1295301.95 | 8.31 | 0.09 | 6.50 | 12.00 | 0.00 | 24.52 | 17.09 | 1542893.32 | 2.68 | 0.35 | 4.03 | 12.82 | 17.13 | 22.50 | 13.57 | 10.97 | 39.18 | 54.17 | 15.01 | 20.53 | 8.73 | 5.12 | 2.68 | 85.49 | 34.19 | 20.56 | 14.40 | 30.77 | 0.00 | 307.69 |
| 4. | Kotak Mah. Bank | 1812.95 | 360405.66 | 19.39 | 2.75 | 6.09 | 53.89 | 16.70 | 3.26 | 0.11 | 7.86 | 2.62 | 15.06 | 0.08 | 4.00 | 1.99 | 5.34 | 59204.49 | 15.88 | 18642.68 | 15836.79 | 4579.66 | 23.06 | 10.35 | 108.22 | 520374.37 | 25.89 | -0.01 | 6.04 | 12.00 | 0.00 | 29.11 | 14.23 | 815573.64 | 1.97 | 0.95 | 10.36 | 0.38 | 1.49 | -5.26 | 14.32 | 14.06 | 20.42 | 22.27 | 13.52 | 19.66 | 14.31 | 6.86 | 1.97 | 91.62 | 19.45 | 29.26 | 26.25 | 34.60 | 0.00 | 198.66 |
| 5. | IndusInd Bank | 1399.75 | 109002.10 | 12.14 | 1.95 | 2.38 | -23.04 | 11.81 | -0.52 | 1.20 | 8.42 | 1.95 | 16.39 | 0.10 | 7.06 | 1.48 | 8.38 | 45748.21 | 60.52 | 8949.78 | 12198.53 | 2346.84 | 21.73 | 15.01 | 114.99 | 385449.37 | 15.79 | -0.02 | 8.50 | 12.00 | 45.48 | 25.79 | 21.08 | 437940.33 | 4.57 | 0.55 | -4.65 | -8.79 | 12.22 | -2.58 | 13.85 | 12.76 | 22.07 | 46.69 | 15.50 | 16.41 | 14.45 | 6.91 | 4.57 | 114.99 | 15.98 | 15.48 | 14.42 | 19.35 | 0.00 | 77.59 |
| 6. | IDBI Bank | 99.13 | 106588.52 | 16.92 | 2.11 | 4.06 | 744.63 | 17.15 | 26.64 | 1.47 | 6.23 | 1.65 | 11.77 | 0.08 | 5.77 | 1.71 | 6.81 | 26251.87 | 68.52 | 6293.17 | 6669.84 | 1734.32 | -2.82 | 41.09 | 5.85 | 294448.21 | 94.71 | 0.00 | 5.79 | 12.00 | 0.00 | 15.06 | 51.03 | 375027.25 | 2.23 | 0.89 | 14.51 | 21.51 | 38.73 | 75.54 | 8.98 | 0.32 | 18.98 | 55.84 | 3.65 | 9.84 | 8.34 | 4.79 | 2.23 | 5.38 | 17.89 | 17.67 | 17.02 | 17.67 | 0.00 | 1075.24 |
| 7. | Yes Bank | 24.90 | 78025.74 | 53.72 | 1.73 | 2.70 | 43.95 | 18.16 | -23.83 | 0.00 | 5.83 | 0.34 | 3.18 | 0.07 | 8.41 | 1.09 | 9.24 | 28885.91 | 58.49 | 1454.52 | 7725.41 | 516.00 | 19.86 | 48.84 | 0.49 | 346737.14 | 0.00 | 0.00 | 5.52 | 12.00 | 0.00 | 20.30 | 89.30 | 405444.43 | 4.42 | -9.73 | -5.85 | -0.93 | 23.56 | 45.25 | 2.79 | -10.37 | -5.52 | 33.31 | -1.40 | 11.27 | 1.99 | 4.94 | 4.42 | 0.45 | -42.92 | 50.33 | 52.98 | 27.25 | 0.00 | 2875.48 |
| 8. | RBL Bank | 233.00 | 14129.53 | 10.92 | 0.93 | 1.08 | -133.13 | 14.46 | -12.80 | 0.66 | 6.30 | 0.99 | 8.88 | 0.10 | 7.93 | 1.21 | 8.57 | 13035.34 | 38.19 | 1291.45 | 3496.94 | 351.05 | 22.47 | 9.88 | 21.38 | 117655.69 | 0.00 | 0.00 | 6.93 | 12.00 | 0.00 | 26.79 | 25.34 | 117361.80 | 3.99 | 1.37 | -13.26 | -9.78 | 5.48 | -1.03 | 5.06 | 5.03 | 7.98 | 33.41 | 14.48 | 12.62 | 7.06 | 5.50 | 3.99 | 20.82 | 0.70 | 14.46 | 12.63 | 20.10 | 0.00 | 59.96 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| RBLBANK | Market Cap | ₹ 14,120 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | Sales | ₹ 13,035 Cr. |
| RBLBANK | OPM | 38.2 % |
| RBLBANK | Profit after tax | ₹ 1,291 Cr. |
| RBLBANK | Mar Cap | ₹ 14,120 Cr. |
| RBLBANK | Sales Qtr | ₹ 3,497 Cr. |
| RBLBANK | PAT Qtr | ₹ 351 Cr. |
| RBLBANK | Qtr Sales Var | 22.5 % |
| RBLBANK | Qtr Profit Var | 9.88 % |
| RBLBANK | Price to Earning | 10.9 |
| RBLBANK | Dividend yield | 0.66 % |
| RBLBANK | Price to book value | 0.93 |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | Return on assets | 0.99 % |
| RBLBANK | Debt to equity | 7.93 |
| RBLBANK | Return on equity | 8.88 % |
| RBLBANK | EPS | ₹ 21.4 |
| RBLBANK | Debt | ₹ 1,17,656 Cr. |
| RBLBANK | Promoter holding | 0.00 % |
| RBLBANK | Change in Prom Hold | 0.00 % |
| RBLBANK | Earnings yield | 6.93 % |
| RBLBANK | Pledged percentage | 0.00 % |
| RBLBANK | Industry PE | 12.0 |
| RBLBANK | Sales growth | 26.8 % |
| RBLBANK | Profit growth | 25.3 % |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | Price to Sales | 1.08 |
| RBLBANK | CMP / FCF | -133 |
| RBLBANK | EVEBITDA | 14.4 |
| RBLBANK | Enterprise Value | ₹ 1,17,353 Cr. |
| RBLBANK | Current ratio | 3.99 |
| RBLBANK | Int Coverage | 1.21 |
| RBLBANK | PEG Ratio | 1.37 |
| RBLBANK | Return over 3months | -13.3 % |
| RBLBANK | Return over 6months | -9.78 % |
| RBLBANK | No. Eq. Shares | 60.6 |
| RBLBANK | Sales growth 3Years | 12.6 % |
| RBLBANK | Sales growth 5Years | 14.5 % |
| RBLBANK | Profit Var 3Yrs | 33.4 % |
| RBLBANK | Profit Var 5Yrs | 7.98 % |
| RBLBANK | ROE 5Yr | 5.03 % |
| RBLBANK | ROE 3Yr | 5.06 % |
| RBLBANK | Return over 1year | -1.03 % |
| RBLBANK | Return over 3years | 5.48 % |
| RBLBANK | Return over 5years | -12.8 % |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | Sales last year | ₹ 12,394 Cr. |
| RBLBANK | OP Ann | ₹ 4,873 Cr. |
| RBLBANK | Other Inc Ann | ₹ 3,060 Cr. |
| RBLBANK | EBIDT last year | ₹ 7,933 Cr. |
| RBLBANK | Dep Ann | ₹ 235 Cr. |
| RBLBANK | EBIT last year | ₹ 7,698 Cr. |
| RBLBANK | Interest last year | ₹ 6,350 Cr. |
| RBLBANK | PBT Ann | ₹ 1,349 Cr. |
| RBLBANK | Tax last year | ₹ 88.8 Cr. |
| RBLBANK | PAT Ann | ₹ 1,259 Cr. |
| RBLBANK | Extra Ord Item Ann | ₹ 0.48 Cr. |
| RBLBANK | NP Ann | ₹ 1,260 Cr. |
| RBLBANK | Dividend last year | ₹ 90.8 Cr. |
| RBLBANK | Raw Material | 0.00 % |
| RBLBANK | Employee cost | ₹ 1,860 Cr. |
| RBLBANK | OPM last year | 39.3 % |
| RBLBANK | NPM last year | 10.2 % |
| RBLBANK | Operating profit | ₹ 4,978 Cr. |
| RBLBANK | Interest | ₹ 6,713 Cr. |
| RBLBANK | Depreciation | ₹ 0.00 Cr. |
| RBLBANK | EPS last year | ₹ 20.8 |
| RBLBANK | EBIT | ₹ 8,119 Cr. |
| RBLBANK | Net profit | ₹ 1,291 Cr. |
| RBLBANK | Current Tax | ₹ 114 Cr. |
| RBLBANK | Tax | ₹ 114 Cr. |
| RBLBANK | Other income | ₹ 3,141 Cr. |
| RBLBANK | Ann Date | 2,02,403 |
| RBLBANK | Sales Prev Ann | ₹ 9,677 Cr. |
| RBLBANK | OP Prev Ann | ₹ 3,606 Cr. |
| RBLBANK | Other Inc Prev Ann | ₹ 2,507 Cr. |
| RBLBANK | EBIDT Prev Ann | ₹ 6,113 Cr. |
| RBLBANK | Dep Prev Ann | ₹ 213 Cr. |
| RBLBANK | EBIT preceding year | ₹ 5,900 Cr. |
| RBLBANK | Interest Prev Ann | ₹ 4,679 Cr. |
| RBLBANK | PBT Prev Ann | ₹ 1,221 Cr. |
| RBLBANK | Tax preceding year | ₹ 302 Cr. |
| RBLBANK | PAT Prev Ann | ₹ 920 Cr. |
| RBLBANK | Extra Ord Prev Ann | ₹ -0.38 Cr. |
| RBLBANK | NP Prev Ann | ₹ 920 Cr. |
| RBLBANK | Dividend Prev Ann | ₹ 89.9 Cr. |
| RBLBANK | OPM preceding year | 37.3 % |
| RBLBANK | NPM preceding year | 9.51 % |
| RBLBANK | EPS preceding year | ₹ 15.3 |
| RBLBANK | Sales Prev 12M | ₹ 12,394 Cr. |
| RBLBANK | Profit Prev 12M | ₹ 1,260 Cr. |
| RBLBANK | Med Sales Gwth 10Yrs | 22.8 % |
| RBLBANK | Med Sales Gwth 5Yrs | 14.6 % |
| RBLBANK | Sales growth 7Years | 18.8 % |
| RBLBANK | Sales Var 10Yrs | % |
| RBLBANK | EBIDT growth 3Years | 13.5 % |
| RBLBANK | EBIDT growth 5Years | 8.88 % |
| RBLBANK | EBIDT growth 7Years | 13.7 % |
| RBLBANK | EBIDT Var 10Yrs | % |
| RBLBANK | EPS growth 3Years | 32.9 % |
| RBLBANK | EPS growth 5Years | 0.70 % |
| RBLBANK | EPS growth 7Years | 8.33 % |
| RBLBANK | EPS growth 10Years | % |
| RBLBANK | Profit Var 7Yrs | 16.0 % |
| RBLBANK | Profit Var 10Yrs | % |
| RBLBANK | Chg in Prom Hold 3Yr | 0.00 % |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | OP Qtr | ₹ 1,497 Cr. |
| RBLBANK | Other Inc Qtr | ₹ 775 Cr. |
| RBLBANK | EBIDT Qtr | ₹ 2,272 Cr. |
| RBLBANK | Dep Qtr | ₹ 0.00 Cr. |
| RBLBANK | EBIT latest quarter | ₹ 2,272 Cr. |
| RBLBANK | Interest Qtr | ₹ 1,796 Cr. |
| RBLBANK | PBT Qtr | ₹ 475 Cr. |
| RBLBANK | Tax latest quarter | ₹ 124 Cr. |
| RBLBANK | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| RBLBANK | NP Qtr | ₹ 351 Cr. |
| RBLBANK | GPM latest quarter | 100 % |
| RBLBANK | OPM latest quarter | 42.8 % |
| RBLBANK | NPM latest quarter | 10.0 % |
| RBLBANK | Eq Cap Qtr | ₹ 606 Cr. |
| RBLBANK | EPS latest quarter | ₹ 5.79 |
| RBLBANK | OP 2Qtr Bk | ₹ 1,187 Cr. |
| RBLBANK | OP 3Qtr Bk | ₹ 945 Cr. |
| RBLBANK | Sales 2Qtr Bk | ₹ 3,191 Cr. |
| RBLBANK | Sales 3Qtr Bk | ₹ 3,008 Cr. |
| RBLBANK | NP 2Qtr Bk | ₹ 245 Cr. |
| RBLBANK | NP 3Qtr Bk | ₹ 331 Cr. |
| RBLBANK | Opert Prft Gwth | 30.3 % |
| RBLBANK | Last result date | 2,02,406 |
| RBLBANK | Exp Qtr Sales Var | 26.9 % |
| RBLBANK | Exp Qtr Sales | ₹ 3,816 Cr. |
| RBLBANK | Exp Qtr OP | ₹ 1,365 Cr. |
| RBLBANK | Exp Qtr NP | ₹ -432 Cr. |
| RBLBANK | Exp Qtr EPS | ₹ -7.13 |
| RBLBANK | Sales Prev Qtr | ₹ 3,339 Cr. |
| RBLBANK | OP Prev Qtr | ₹ 1,349 Cr. |
| RBLBANK | Other Inc Prev Qtr | ₹ 876 Cr. |
| RBLBANK | EBIDT Prev Qtr | ₹ 2,225 Cr. |
| RBLBANK | Dep Prev Qtr | ₹ 0.00 Cr. |
| RBLBANK | EBIT Prev Qtr | ₹ 2,225 Cr. |
| RBLBANK | Interest Prev Qtr | ₹ 1,739 Cr. |
| RBLBANK | PBT Prev Qtr | ₹ 486 Cr. |
| RBLBANK | Tax Prev Qtr | ₹ 121 Cr. |
| RBLBANK | PAT Prev Qtr | ₹ 364 Cr. |
| RBLBANK | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| RBLBANK | NP Prev Qtr | ₹ 364 Cr. |
| RBLBANK | OPM Prev Qtr | 40.4 % |
| RBLBANK | NPM Prev Qtr | 10.9 % |
| RBLBANK | Eq Cap Prev Qtr | ₹ Cr. |
| RBLBANK | EPS Prev Qtr | ₹ 6.02 |
| RBLBANK | Sales PY Qtr | ₹ 2,855 Cr. |
| RBLBANK | OP PY Qtr | ₹ 1,158 Cr. |
| RBLBANK | Other Inc PY Qtr | ₹ 694 Cr. |
| RBLBANK | EBIDT PY Qtr | ₹ 1,852 Cr. |
| RBLBANK | Dep PY Qtr | ₹ 0.00 Cr. |
| RBLBANK | EBIT PY Qtr | ₹ 1,852 Cr. |
| RBLBANK | Interest PY Qtr | ₹ 1,434 Cr. |
| RBLBANK | PBT PY Qtr | ₹ 418 Cr. |
| RBLBANK | Tax PY Qtr | ₹ 98.7 Cr. |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | Equity capital | ₹ 605 Cr. |
| RBLBANK | Preference capital | ₹ 0.00 Cr. |
| RBLBANK | Reserves | ₹ 14,232 Cr. |
| RBLBANK | Secured loan | ₹ 14,185 Cr. |
| RBLBANK | Unsecured loan | ₹ 1,03,470 Cr. |
| RBLBANK | Balance sheet total | ₹ 1,38,454 Cr. |
| RBLBANK | Gross block | ₹ 1,722 Cr. |
| RBLBANK | Revaluation reserve | ₹ 0.50 Cr. |
| RBLBANK | Accum Dep | ₹ 1,131 Cr. |
| RBLBANK | Net block | ₹ 591 Cr. |
| RBLBANK | CWIP | ₹ 7.33 Cr. |
| RBLBANK | Investments | ₹ 29,478 Cr. |
| RBLBANK | Current assets | ₹ 23,809 Cr. |
| RBLBANK | Current liabilities | ₹ 5,961 Cr. |
| RBLBANK | BV Unq Invest | ₹ 183 Cr. |
| RBLBANK | MV Quoted Inv | ₹ 0.00 Cr. |
| RBLBANK | Cont Liab | ₹ 97,213 Cr. |
| RBLBANK | Total Assets | ₹ 1,38,454 Cr. |
| RBLBANK | Working capital | ₹ 17,849 Cr. |
| RBLBANK | Lease liabilities | ₹ 0.00 Cr. |
| RBLBANK | Inventory | ₹ 0.00 Cr. |
| RBLBANK | Trade receivables | ₹ 0.00 Cr. |
| RBLBANK | Face value | ₹ 10.0 |
| RBLBANK | Cash Equivalents | ₹ 14,423 Cr. |
| RBLBANK | Adv Cust | ₹ 0.00 Cr. |
| RBLBANK | Trade Payables | ₹ 722 Cr. |
| RBLBANK | No. Eq. Shares PY | 60.0 |
| RBLBANK | Debt preceding year | ₹ 98,206 Cr. |
| RBLBANK | Work Cap PY | ₹ 11,611 Cr. |
| RBLBANK | Net Block PY | ₹ 594 Cr. |
| RBLBANK | Gross Block PY | ₹ 1,574 Cr. |
| RBLBANK | CWIP PY | ₹ 45.3 Cr. |
| RBLBANK | Work Cap 3Yr | ₹ 14,301 Cr. |
| RBLBANK | Work Cap 5Yr | ₹ 6,005 Cr. |
| RBLBANK | Work Cap 7Yr | ₹ 3,625 Cr. |
| RBLBANK | Work Cap 10Yr | ₹ Cr. |
| RBLBANK | Debt 3Years back | ₹ 84,281 Cr. |
| RBLBANK | Debt 5Years back | ₹ 70,190 Cr. |
| RBLBANK | Debt 7Years back | ₹ 42,568 Cr. |
| RBLBANK | Debt 10Years back | ₹ Cr. |
| RBLBANK | Net Block 3Yrs Back | ₹ 511 Cr. |
| RBLBANK | Net Block 5Yrs Back | ₹ 416 Cr. |
| RBLBANK | Net Block 7Yrs Back | ₹ 224 Cr. |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | CF Operations | ₹ 4,955 Cr. |
| RBLBANK | Free Cash Flow | ₹ 4,762 Cr. |
| RBLBANK | CF Investing | ₹ -193 Cr. |
| RBLBANK | CF Financing | ₹ 843 Cr. |
| RBLBANK | Net CF | ₹ 5,604 Cr. |
| RBLBANK | Cash Beginning | ₹ 8,522 Cr. |
| RBLBANK | Cash End | ₹ 14,423 Cr. |
| RBLBANK | FCF Prev Ann | ₹ -11,265 Cr. |
| RBLBANK | CF Operations PY | ₹ -11,031 Cr. |
| RBLBANK | CF Investing PY | ₹ -234 Cr. |
| RBLBANK | CF Financing PY | ₹ 2,235 Cr. |
| RBLBANK | Net CF PY | ₹ -9,030 Cr. |
| RBLBANK | Cash Beginning PY | ₹ 17,552 Cr. |
| RBLBANK | Cash End PY | ₹ 8,527 Cr. |
| RBLBANK | Free Cash Flow 3Yrs | ₹ -318 Cr. |
| RBLBANK | Free Cash Flow 5Yrs | ₹ 1,744 Cr. |
| RBLBANK | Free Cash Flow 7Yrs | ₹ -1,101 Cr. |
| RBLBANK | Free Cash Flow 10Yrs | ₹ Cr. |
| RBLBANK | CF Opr 3Yrs | ₹ 373 Cr. |
| RBLBANK | CF Opr 5Yrs | ₹ 2,832 Cr. |
| RBLBANK | CF Opr 7Yrs | ₹ 354 Cr. |
| RBLBANK | CF Opr 10Yrs | ₹ Cr. |
| RBLBANK | CF Inv 10Yrs | ₹ Cr. |
| RBLBANK | CF Inv 7Yrs | ₹ -1,455 Cr. |
| RBLBANK | CF Inv 5Yrs | ₹ -1,088 Cr. |
| RBLBANK | CF Inv 3Yrs | ₹ -691 Cr. |
| RBLBANK | Cash 3Years back | ₹ 13,443 Cr. |
| RBLBANK | Cash 5Years back | ₹ 6,649 Cr. |
| RBLBANK | Cash 7Years back | ₹ 4,194 Cr. |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | No. Eq. Shares | 60.6 |
| RBLBANK | Book value | ₹ 245 |
| RBLBANK | Inven TO |  |
| RBLBANK | Quick ratio | 3.99 |
| RBLBANK | Exports percentage | 0.00 % |
| RBLBANK | Piotroski score | 7.00 |
| RBLBANK | G Factor | 4.00 |
| RBLBANK | Asset Turnover | 0.10 |
| RBLBANK | Financial leverage | 8.57 |
| RBLBANK | No. of Share Holders | 3,64,380 |
| RBLBANK | Unpledged Prom Hold | 0.00 % |
| RBLBANK | ROIC | 6.30 % |
| RBLBANK | Debtor days | 0.00 |
| RBLBANK | Industry PBV | 1.87 |
| RBLBANK | Credit rating |  |
| RBLBANK | WC Days | 101 |
| RBLBANK | Earning Power | 5.86 % |
| RBLBANK | Graham Number | ₹ 343 |
| RBLBANK | Cash Cycle | 0.00 |
| RBLBANK | Days Payable |  |
| RBLBANK | Days Receivable | 0.00 |
| RBLBANK | Inventory Days |  |
| RBLBANK | Public holding | 50.8 % |
| RBLBANK | FII holding | 28.5 % |
| RBLBANK | Chg in FII Hold | 3.33 % |
| RBLBANK | DII holding | 20.3 % |
| RBLBANK | Chg in DII Hold | 0.16 % |
| RBLBANK | B.V. Prev Ann | ₹ 226 |
| RBLBANK | ROCE Prev Yr | 5.50 % |
| RBLBANK | ROA Prev Yr | 0.83 % |
| RBLBANK | ROE Prev Ann | 7.06 % |
| RBLBANK | No. of Share Holders Prev Qtr | 3,58,110 |
| RBLBANK | No. Eq. Shares 10 Yrs |  |
| RBLBANK | BV 3yrs back | ₹ 212 |
| RBLBANK | BV 5yrs back | ₹ 208 |
| RBLBANK | BV 10yrs back | ₹ |
| RBLBANK | Inven TO 3Yr |  |
| RBLBANK | Inven TO 5Yr |  |
| RBLBANK | Inven TO 7Yr |  |
| RBLBANK | Inven TO 10Yr |  |
| RBLBANK | Export 3Yr | 0.00 % |
| RBLBANK | Export 5Yr | 0.00 % |
| RBLBANK | Div 5Yrs | ₹ 51.4 Cr. |
| RBLBANK | ROCE 3Yr | 5.25 % |
| RBLBANK | ROCE 5Yr | 5.69 % |
| RBLBANK | ROCE 7Yr | 6.11 % |
| RBLBANK | ROCE 10Yr | 6.11 % |
| RBLBANK | ROE 10Yr | % |
| RBLBANK | ROE 7Yr | 6.20 % |
| RBLBANK | ROE 5Yr Var | -5.95 % |
| RBLBANK | OPM 5Year | 36.8 % |
| RBLBANK | OPM 10Year | % |
| RBLBANK | No. of Share Holders 1Yr | 3,79,536 |
| RBLBANK | Avg Div Payout 3Yrs | 5.66 % |
| RBLBANK | Debtor days 3yrs | 0.00 |
| RBLBANK | Debtor days 3yrs back | 0.00 |
| RBLBANK | Debtor days 5yrs back | 0.00 |
| RBLBANK | ROA 5Yr | 0.56 % |
| RBLBANK | ROA 3Yr | 0.55 % |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | Avg Vol 1Mth | 1,00,48,845 |
| RBLBANK | Avg Vol 1Wk | 2,54,24,167 |
| RBLBANK | Volume | 7,82,04,520 |
| RBLBANK | High price | ₹ 301 |
| RBLBANK | Low price | ₹ 209 |
| RBLBANK | High price all time | ₹ 717 |
| RBLBANK | Low price all time | ₹ 74.2 |
| RBLBANK | Return over 1day | 1.13 % |
| RBLBANK | Return over 1week | -4.22 % |
| RBLBANK | Return over 1month | -10.6 % |
| RBLBANK | DMA 50 | ₹ 251 |
| RBLBANK | DMA 200 | ₹ 245 |
| RBLBANK | DMA 50 previous day | ₹ 251 |
| RBLBANK | 200 DMA prev. | ₹ 245 |
| RBLBANK | RSI | 33.0 |
| RBLBANK | MACD | -5.51 |
| RBLBANK | MACD Previous Day | -4.73 |
| RBLBANK | MACD Signal | -3.43 |
| RBLBANK | MACD Signal Prev | -2.91 |
| RBLBANK | Avg Vol 1Yr | 1,01,88,887 |
| RBLBANK | Return over 7years | -11.3 % |
| RBLBANK | Return over 10years | % |
| RBLBANK | Market Cap | ₹ 14,130 Cr. |
| RBLBANK | Current Price | ₹ 233 |
| RBLBANK | High / Low | ₹ 301 / 209 |
| RBLBANK | Stock P/E | 10.9 |
| RBLBANK | Book Value | ₹ 245 |
| RBLBANK | Dividend Yield | 0.66 % |
| RBLBANK | ROCE | 6.30 % |
| RBLBANK | ROE | 8.88 % |
| RBLBANK | Face Value | ₹ 10.0 |
| RBLBANK | WC to Sales | 137 % |
| RBLBANK | QoQ Profits | -3.67 % |
| RBLBANK | QoQ Sales | 4.72 % |
| RBLBANK | Net worth | ₹ 14,837 Cr. |
| RBLBANK | Market Cap to Sales | 1.08 |
| RBLBANK | Interest Coverage | 1.21 |
| RBLBANK | EV / EBIT | 14.5 |
| RBLBANK | Debt Capacity | -5.10 |
| RBLBANK | Debt To Profit | 93.4 |
| RBLBANK | Capital Employed | ₹ 18,447 Cr. |
| RBLBANK | CROIC | -0.09 % |
| RBLBANK | debtplus | 14.4 |
| RBLBANK | Leverage | ₹ 8.57 |
| RBLBANK | Dividend Payout | 7.20 % |
| RBLBANK | Intrinsic Value | ₹ 339 |
| RBLBANK | CDL | -1,419 % |
| RBLBANK | Cash by market cap | 0.81 |
| RBLBANK | 52w Index | 26.1 % |
| RBLBANK | Down from 52w high | 22.5 % |
| RBLBANK | Up from 52w low | 11.5 % |
| RBLBANK | From 52w high | 0.77 |
| RBLBANK | Mkt Cap To Debt Cap | 2.00 |
| RBLBANK | Dividend Payout | 7.20 % |
| RBLBANK | Graham | ₹ 343 |
| RBLBANK | Price to Cash Flow | 2.85 |
| RBLBANK | ROCE3yr avg | 5.25 % |
| RBLBANK | PB X PE | 10.2 |
| RBLBANK | NCAVPS | ₹ 294 |
| RBLBANK | Mar Cap to CF | 2.85 |
| RBLBANK | Altman Z Score | 0.76 |
| RBLBANK | M.Cap / Qtr Profit | 40.2 |