# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/hindustan-motors-ltd/hindmotors/500500/corp-announcements/)
- [Compliances-Certificate under Reg. 74 (5) of SEBI (DP) Regulations, 2018 4 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=de2568f1-6333-41b6-b8da-53f844e1aef4.pdf)
- [Closure of Trading Window 26 Jun](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=80b61883-1639-4f0c-a534-762dfa15dfba.pdf)
- [Compliances-Reg.24(A)-Annual Secretarial Compliance
24 May - SECRETARIAL COMPLIANCE UNDER REGULATION 24A OF SEBI LODR,2015](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e6d109b-c231-423a-9a7e-6637625f5987.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 22 May](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cdfc95bc-9513-4877-bbe4-14aa3e0faec5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bee88455-5f87-4dde-bf6c-ce06b81ede53.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\c915c6c3-8e7d-481b-a1ec-6888115cbc71.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/75314500500.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/69991500500.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/66436500500.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000913.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_3029_HINDMOTORS_2012_2013_02122013151400.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500500/5005000311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_HINDMOTORS_2010_2011_21072011122526.zip)

