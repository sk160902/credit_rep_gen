# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 31,618 | 35,306 | 38,817 | 39,192 | 42,768 | 43,449 | 48,340 | 49,388 | 49,257 | 60,645 | 70,919 | 70,866 |
| Expenses + | 20,398 | 22,227 | 24,566 | 24,661 | 27,298 | 26,928 | 29,802 | 30,044 | 32,193 | 40,021 | 45,215 | 44,634 |
| Operating Profit | 11,221 | 13,080 | 14,252 | 14,531 | 15,470 | 16,521 | 18,537 | 19,344 | 17,065 | 20,623 | 25,704 | 26,233 |
| OPM % | 35% | 37% | 37% | 37% | 36% | 38% | 38% | 39% | 35% | 34% | 36% | 37% |
| Other Income + | 852 | 966 | 1,229 | 1,483 | 1,759 | 2,240 | 2,080 | 2,417 | 2,577 | 1,910 | 2,098 | 2,804 |
| Interest | 108 | 29 | 91 | 78 | 49 | 115 | 71 | 81 | 58 | 60 | 78 | 80 |
| Depreciation | 859 | 965 | 1,028 | 1,077 | 1,153 | 1,236 | 1,397 | 1,645 | 1,646 | 1,732 | 1,809 | 1,816 |
| Profit before tax | 11,106 | 13,052 | 14,362 | 14,859 | 16,026 | 17,409 | 19,150 | 20,035 | 17,938 | 20,740 | 25,915 | 27,140 |
| Tax % | 31% | 31% | 32% | 36% | 35% | 34% | 33% | 22% | 25% | 25% | 25% | 24% |
| Net Profit + | 7,704 | 9,001 | 9,779 | 9,501 | 10,477 | 11,493 | 12,836 | 15,593 | 13,383 | 15,503 | 19,477 | 20,751 |
| EPS in Rs | 6.42 | 7.45 | 8.04 | 7.74 | 8.47 | 9.24 | 10.27 | 12.45 | 10.69 | 12.37 | 15.44 | 16.39 |
| Dividend Payout % | 55% | 54% | 52% | 73% | 56% | 56% | 56% | 82% | 101% | 93% | 100% | 84% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tobacco Manufacturers (India) Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments |  |  |  |  |  |  |  |  | 3,648 | 4,691 |
| British American Tobacco (GLP) Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 1,352 | 1,071 |
| Adjustment / Payment towards Refund of Advances |  |  |  |  |  |  |  |  | 1,325 | 1,035 |
| Advances Received during the year |  |  |  |  |  |  |  |  | 1,153 | 882 |
| Advances taken |  |  |  |  |  |  |  |  | 521 | 368 |
| Receivables |  |  |  |  |  |  |  |  | 36 | 24 |
| Expenses Recovered |  |  |  |  |  |  |  |  | 22 | 4.86 |
| Tobacco Manufacturers (India) Limited, UK Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments | 1,191 | 1,241 | 1,688 |  | 1,534 | 1,713 |  |  |  |  |
| JSC ‘British American Tobacco-SPb’ Associate |  |  |  |  |  |  |  |  |  |  |
| Advances Received during the year |  |  |  |  |  |  |  |  | 651 | 100 |
| Adjustment / Payment towards Refund of Advances |  |  |  |  |  |  |  |  | 452 | 299 |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 447 | 299 |
| ITC Essentra Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods/Services | 303 |  |  |  | 272 | 243 |  |  |  |  |
| Purchase of Goods / Services |  | 291 | 253 |  |  |  |  |  |  |  |
| Sale of Goods/Services | 9.84 |  |  |  | 42 | 26 |  |  |  |  |
| Payables | 4.56 | 5.78 | 0.87 |  | 16 | 8.49 |  |  |  |  |
| Sale of Goods / Services |  | 9.30 | 6.88 |  |  |  |  |  |  |  |
| Dividend Income | 2.02 | 2.02 | 2.03 |  | 2.70 | 6.75 |  |  |  |  |
| Receivables |  |  | 1.22 |  | 0.20 | 5.68 |  |  |  |  |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 0.55 | 0.73 |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.60 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.52 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.18 | 0.06 |  |  |  |  |
| Expenses Reimbursed | 0.08 |  |  |  |  |  |  |  |  |  |
| Myddleton Investment Company Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Payments |  |  |  |  |  |  |  |  | 596 | 766 |
| ITC Filtrona Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 438 | 639 |
| Dividend Income |  |  |  |  |  |  |  |  | 18 | 22 |
| Payables |  |  |  |  |  |  |  |  | 21 | 9.65 |
| British American Shared Services (GSD) Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of Goods / Services |  |  |  |  |  |  |  |  | 219 | 392 |
| Receivables |  |  |  |  |  |  |  |  | 56 | 179 |
| International Travel House Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  | 89 | 85 |  |  |  |  |  | 87 | 122 |
| Purchase of Goods/Services | 93 |  |  |  | 99 | 110 |  |  |  |  |
| Payables | 11 | 7.14 | 6.16 |  | 4.75 | 3.34 |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 1.54 | 2.02 |  |  |  |  |  | 4.06 | 3.54 |
| Receivables |  |  | 5.20 |  | 0.60 | 2.83 |  |  |  |  |
| Sale of Goods/Services | 1.77 |  |  |  | 3.45 | 3.02 |  |  |  |  |
| Dividend Income | 1.66 | 1.66 | 1.66 |  | 1.66 | 0.98 |  |  |  |  |
| Rent Received | 1.41 | 1.17 | 1.02 |  | 1.05 | 1.08 |  |  | 0.87 | 0.88 |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 2.84 | 2.59 |  |  |  |  |
| Sale of Goods / Services |  | 2.47 | 2.77 |  |  |  |  |  |  |  |
| Deposits Taken | 0.67 | 0.67 | 0.63 |  | 0.63 | 0.63 |  |  | 0.60 | 0.60 |
| Reimbursement for Share Based Payments |  |  |  |  | 0.99 | 0.12 |  |  | 1.46 | 0.57 |
| Capital Contribution for Share Based |  |  | 2.58 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 2.58 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 2.27 |  |  |  |  |  |  |  |
| Expenses Recovered | 0.71 | 0.18 | 0.36 |  | 0.23 | 0.22 |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 1.45 |  |  |  |  |  |  |  |  |  |
| Adjustment/Receipt towards Refund of Advances | 0.02 |  |  |  |  | 1.12 |  |  |  |  |
| Advances Given during the year |  |  |  |  | 0.26 | 0.68 |  |  |  |  |
| Advances Given |  |  |  |  | 0.49 | 0.05 |  |  |  |  |
| Expenses Reimbursed | 0.13 | 0.17 | 0.03 |  |  |  |  |  |  |  |
| Adjustment / Payment towards Refund of Deposit |  |  | 0.04 |  |  |  |  |  |  |  |
| Deposit Received |  |  |  |  | 0.01 |  |  |  |  |  |
| IATC Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 24 | 23 | 25 |  |  | 36 |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 39 | 43 |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 30 |  |  |  |  |  |
| ITC Pension Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 41 | 21 | 37 |  |  | 22 |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 21 | 56 |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 21 |  |  |  |  |  |
| Employee Trust - Gratuity Funds |  |  |  |  |  |  |  |  |  |  |
| Payables | 38 |  |  |  |  | 30 |  |  | 25 | 46 |
| Advances Given |  |  |  |  | 18 |  |  |  |  |  |
| Employee Trust - Pension Funds |  |  |  |  |  |  |  |  |  |  |
| Advances Given |  |  |  |  | 42 |  |  |  |  | 31 |
| Payables |  |  | 6.44 |  |  | 61 |  |  |  |  |
| ITC Management Staff Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 23 | 17 | 15 |  |  |  |  |  |  |  |
| Contribution to Employees’ Benefit Plans |  |  |  |  |  |  |  |  | 24 | 30 |
| ITC Defined Contribution Pension Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 15 | 16 | 18 |  |  | 16 |  |  |  |  |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 22 |  |  |  |  |  |
| S. Puri Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 6.16 | 10 |  |  | 12 | 13 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 10 | 13 |
| Gujarat Hotels Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 3.20 | 3.49 | 3.74 |  | 4.36 | 4.42 |  |  | 4.32 | 4.06 |
| Remuneration of Managers on Deputation reimbursed |  | 3.93 | 5.05 |  | 0.59 | 0.67 |  |  | 7.06 | 6.45 |
| Payables |  |  |  |  | 2.09 | 2.01 |  |  |  |  |
| Remuneration of Managers on Deputation Reimbursed | 3.44 |  |  |  |  |  |  |  |  |  |
| Dividend Income | 0.61 | 0.61 | 0.61 |  | 0.61 | 0.61 |  |  |  |  |
| Expenses Reimbursed | 0.08 | 0.06 | 0.09 |  | 0.22 | 0.25 |  |  | 0.25 | 0.27 |
| Remuneration of Managers on Deputation recovered |  |  | 0.62 |  |  |  |  |  |  |  |
| Employees Trust - Pension Funds |  |  |  |  |  |  |  |  |  |  |
| Advances Given | 48 | 13 |  |  |  |  |  |  |  |  |
| ITC Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contribution to Employees Benefit Plans | 3.30 | 21 | 11 |  |  | 13 |  |  |  |  |
| Contribution to Employees Rs Benefit Plans |  |  |  |  | 10 |  |  |  |  |  |
| Sproutlife Foods Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in Associates |  |  |  |  |  |  |  |  |  | 50 |
| Remuneration of Managers on Deputation recovered |  |  |  |  |  |  |  |  |  | 1.97 |
| Reimbursement for Share Based Payments |  |  |  |  |  |  |  |  |  | 0.25 |
| ATC Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 1.88 | 1.81 |  |  |  |  |  | 3.11 | 2.99 |
| Loans Given | 4.20 | 2.80 | 1.40 |  |  |  |  |  |  |  |
| Payables |  |  |  |  | 3.16 | 2.39 |  |  |  |  |
| Receivables | 0.78 | 0.11 | 2.21 |  | 1.15 | 0.52 |  |  |  |  |
| Remuneration of Managers on Deputation reimbursed |  |  |  |  | 2.19 | 2.30 |  |  |  |  |
| Receipt towards Loan Repayment | 1.40 | 1.40 | 1.40 |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 3.12 |  |  |  |  |  |  |  |  |  |
| Expenses Reimbursed | 0.33 | 0.38 | 0.62 |  |  |  |  |  |  |  |
| Interest Income | 0.59 | 0.42 | 0.24 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.48 | 0.17 |  |  | 0.35 | 0.14 |
| Capital Contribution for Share Based |  |  | 0.63 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.63 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.57 |  |  |  |  |  |  |  |
| Sale of Fixed Assets/Scraps | 0.53 |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipments etc./ Scraps |  | 0.27 | 0.05 |  |  |  |  |  |  |  |
| Mr. Y.C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  | 14 | 19 |  |  |  |  |  |  |  |
| N. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 3.74 | 5.65 |  |  | 5.96 | 4.81 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 4.47 | 7.41 |
| Adjustment / Receipt towards Refund of Deposit |  |  |  |  |  |  |  |  |  | 0.05 |
| Deposits Given |  |  |  |  |  | 0.05 |  |  |  |  |
| B. Sumant Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 1.17 | 4.95 |  |  | 5.35 | 5.74 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 5.04 | 6.69 |
| Sale of Property, Plant and Equipment |  |  |  |  |  |  |  |  |  | 0.09 |
| ITC Sangeet Research Academy |  |  |  |  |  |  |  |  |  |  |
| Expenditure towards Corporate Social Responsibility | 24 |  |  |  |  |  |  |  |  |  |
| Remuneration of Managers on Deputation Reimbursed | 0.19 |  |  |  |  |  |  |  |  |  |
| Employees Trust - Gratuity Funds |  |  |  |  |  |  |  |  |  |  |
| Payables |  | 21 | 1.56 |  |  |  |  |  |  |  |
| Y.C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 16 | 5.12 |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.10 |  |  |  |  |
| Maharaja Heritage Resorts Limited JV |  |  |  |  |  |  |  |  |  |  |
| Receivables | 3.33 | 2.73 | 3.32 |  | 3.33 | 2.30 |  |  |  |  |
| Remuneration of Managers on Deputation recovered |  | 0.95 | 0.96 |  |  |  |  |  |  |  |
| Expenses Recovered | 0.36 | 0.35 | 0.29 |  | 0.31 | 0.20 |  |  |  |  |
| Remuneration of Managers on Deputation Recovered | 0.92 |  |  |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for previous period |  |  | 0.53 |  |  |  |  |  |  |  |
| Reimbursement for Capital Contribution for Share Based Payment for current period |  |  | 0.44 |  |  |  |  |  |  |  |
| Reimbursement for Share Based Payments |  |  |  |  | 0.23 | 0.03 |  |  |  |  |
| Russell Investments Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Loans Taken |  |  | 18 |  |  |  |  |  |  |  |
| Interest Paid |  |  | 0.43 |  |  |  |  |  |  |  |
| S. Dutta Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  |  |  |  |  | 4.31 | 5.08 |
| Other long-term incentives |  |  |  |  |  |  |  |  | 2.51 | 4.15 |
| Sale of Property, Plant and Equipment |  |  |  |  |  |  |  |  |  | 0.12 |
| Deposits Given |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Mr. Y. C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration to | 14 |  |  |  |  |  |  |  |  |  |
| Deposits Given | 0.05 | 0.05 | 0.05 |  |  |  |  |  |  |  |
| Logix Developers Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Impairment of investment in |  |  |  |  | 4.82 | 4.67 |  |  |  |  |
| Investment in | 3.87 |  |  |  |  |  |  |  |  |  |
| Mother Sparsh Baby Care Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in Associates |  |  |  |  |  |  |  |  |  | 12 |
| R. Tandon Key Person |  |  |  |  |  |  |  |  |  |  |
| Short term benefits |  |  |  |  | 3.20 | 4.92 |  |  |  |  |
| Deposits Given |  |  |  |  | 0.03 | 0.03 |  |  |  |  |
| Mrs. B. Deveshwar Relative |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.66 | 0.66 | 0.72 |  |  |  |  |  |  |  |
| Deposits Given | 0.30 | 0.30 | 0.30 |  |  |  |  |  |  |  |
| M. Shankar Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.81 |  |  |  |  |
| S. Banerjee Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.72 | 0.81 |  |  |  |  |
| S. B. Mathur Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.80 |  |  |  |  |
| A. Duggal Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.73 | 0.78 |  |  |  |  |
| British American Tobacco Exports Limited |  |  |  |  |  |  |  |  |  |  |
| Expenses Recovered |  |  |  |  |  |  |  |  |  | 1.31 |
| H. Bhargava Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.48 | 0.80 |  |  |  |  |
| B. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Rent Paid |  |  |  |  | 0.75 | 0.13 |  |  |  |  |
| Deposits Given |  |  |  |  | 0.38 |  |  |  |  |  |
| S. S. H. Rehman Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  |  |  |  | 0.78 | 0.41 |  |  |  |  |
| Mr. S. B. Mathur Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.31 | 0.51 |  |  |  |  |  |  |  |
| Ms. M. Shankar Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.30 | 0.51 |  |  |  |  |  |  |  |
| Mr. S. S. H. Rehman Key Person |  |  |  |  |  |  |  |  |  |  |
| Other Remuneration |  | 0.30 | 0.51 |  |  |  |  |  |  |  |
| Classic Infrastructure & Development Limited |  |  |  |  |  |  |  |  |  |  |
| Acquisition cost of Property, Plant and Equipments etc. |  | 0.37 |  |  |  |  |  |  |  |  |
| Deposits Given | 0.10 |  |  |  |  |  |  |  |  |  |
| N. Singhi Relative |  |  |  |  |  |  |  |  |  |  |
| Deposits Given |  |  |  |  | 0.03 | 0.03 |  |  | 0.03 | 0.03 |
| K.S. Suresh Key Person |  |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipment |  |  |  |  |  | 0.11 |  |  |  |  |
| T. Anand Relative |  |  |  |  |  |  |  |  |  |  |
| Adjustment / Receipt towards Refund of Deposit |  |  |  |  |  |  |  |  |  | 0.05 |
| Deposits Given |  |  |  |  |  | 0.05 |  |  |  |  |
| R. K. Singhi Key Person |  |  |  |  |  |  |  |  |  |  |
| Sale of Property, Plant and Equipment |  |  |  |  |  | 0.07 |  |  |  |  |
| Y. C. Deveshwar Key Person |  |  |  |  |  |  |  |  |  |  |
| Deposits Given |  |  |  |  | 0.05 |  |  |  |  |  |
| Mr. R. Tandon Relative |  |  |  |  |  |  |  |  |  |  |
| Deposits Given during the year | 0.02 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 31,618 | 35,306 | 38,817 | 39,192 | 42,768 | 43,449 | 48,340 | 49,388 | 49,257 | 60,645 | 70,919 | 70,866 |
| Expenses + | 20,398 | 22,227 | 24,566 | 24,661 | 27,298 | 26,928 | 29,802 | 30,044 | 32,193 | 40,021 | 45,215 | 44,634 |
| Operating Profit | 11,221 | 13,080 | 14,252 | 14,531 | 15,470 | 16,521 | 18,537 | 19,344 | 17,065 | 20,623 | 25,704 | 26,233 |
| OPM % | 35% | 37% | 37% | 37% | 36% | 38% | 38% | 39% | 35% | 34% | 36% | 37% |
| Other Income + | 852 | 966 | 1,229 | 1,483 | 1,759 | 2,240 | 2,080 | 2,417 | 2,577 | 1,910 | 2,098 | 2,804 |
| Interest | 108 | 29 | 91 | 78 | 49 | 115 | 71 | 81 | 58 | 60 | 78 | 80 |
| Depreciation | 859 | 965 | 1,028 | 1,077 | 1,153 | 1,236 | 1,397 | 1,645 | 1,646 | 1,732 | 1,809 | 1,816 |
| Profit before tax | 11,106 | 13,052 | 14,362 | 14,859 | 16,026 | 17,409 | 19,150 | 20,035 | 17,938 | 20,740 | 25,915 | 27,140 |
| Tax % | 31% | 31% | 32% | 36% | 35% | 34% | 33% | 22% | 25% | 25% | 25% | 24% |
| Net Profit + | 7,704 | 9,001 | 9,779 | 9,501 | 10,477 | 11,493 | 12,836 | 15,593 | 13,383 | 15,503 | 19,477 | 20,751 |
| EPS in Rs | 6.42 | 7.45 | 8.04 | 7.74 | 8.47 | 9.24 | 10.27 | 12.45 | 10.69 | 12.37 | 15.44 | 16.39 |
| Dividend Payout % | 55% | 54% | 52% | 73% | 56% | 56% | 56% | 82% | 101% | 93% | 100% | 84% |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |

