# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/ashok-leyland-ltd/ashokley/500477/corp-announcements/)
- [Shareholder Meeting / Postal Ballot-Outcome of AGM 16h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c84c0b30-38b2-426a-bacf-35e9fd3d95c7.pdf)
- [Announcement under Regulation 30 (LODR)-Change in Directorate 22h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=229b7896-5a48-4cae-affc-fb0d3471574a.pdf)
- [Contact Details Of Key Managerial Personnel, To Determine Materiality Of An Event Or Information Under Regulation 30 Of SEBI Listing Regulations 22h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b2d84eb-8dde-4f73-958c-69ab16b2eca3.pdf)
- [Announcement Under Regn 30 (LODR)](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6e8e76fe-6b5c-49b4-ac44-23c6e74dc420.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0206ce4c-a83b-4946-8d59-b5f0196cd0f8.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2ff1a8a1-f253-4fdb-afc0-2b9544fd5094.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\81c97bce-6af2-475d-a4c3-5c76934179e1.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/73509500477.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/69484500477.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ASHOKLEY_2009_2010_18082010121500.zip)

## Credit Ratings
- [Rating update
12 Oct 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=122895)
- [Rating update
4 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310131050_Ashok_Leyland_Limited.pdf)
- [Rating update
7 Nov 2022 from care](https://www.careratings.com/upload/CompanyFiles/PR/07112022061800_Ashok_Leyland_Limited.pdf)
- [Rating update
31 Oct 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=115495)
- [Rating update
28 Jan 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=109614)
- [](https://www.careratings.com/upload/CompanyFiles/PR/07012022074329_Ashok_Leyland_Limited.pdf)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3996a258-24c9-4356-8908-044b1b41c146.pdf)
- [REC](https://al-website-uat-contents.s3.ap-south-1.amazonaws.com/uploads/2024/05/ENA0820240524153357.mp3?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAZC5D6DIGERJ3UP44%2F20240528%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20240528T072712Z&X-Amz-SignedHeaders=host&X-Amz-Expires=28800&X-Amz-Signature=4f155a79340d9e47dda07fda06c0f0d0eed17eb4a8cb859351affbadc026067d)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da8d4f9c-cfc2-44cb-b7b3-c6518c2f3606.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5a8dd3ba-1c6b-4a4d-9310-30fb3e600e91.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81d9af88-f09b-46cf-9d71-911fe2dbbb91.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba8fba79-a510-4e87-aa8d-c3b3d3f33079.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a0568a85-cfd2-4097-823f-d2014223dea7.pdf)
- [Transcript](https://www.ashokleyland.com/backend/in/conference-call-transcripts/conference-call-transcript-q3-fy-23-2nd-feb-23-clean-v3/#toolbar=0)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2022/02/Emkay-AshokLeyland-15Nov-20211.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/08/AL-Q1-FY-22-Con-call-trasncript-13-08-2021-clean-version.docx)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c9130dd-6378-404a-aea0-57d36a920527.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/07/AL-con-call-transcript-25th-June-21-Clean.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/05/Q-3-FY-21-analyst-call-transcript-Final.doc)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0f6527a1-a0b1-43d0-8d15-a86953d0196d.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q2-FY-21-Analyst-conference-call-transcript.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q1-FY-21-Analyst-call-transcript.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q4-conference-call-transcriptJun26-2020.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q3-2020-Analyst-call-transcript-clean-version.docx)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q-2-Transcript-clean-version-1.doc)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9a005e7d-6379-4853-874a-64c4408bb613.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/MOSL-AL-Transcript-clean-version.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/BK-Sec-Concall-Transcript-Q4-FY-2019-May24-2019-Clean.docx)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/AxisCap-AshokeLeyland-15Feb-2019-Rajan-v2.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q2-FY19-Concall-Transcript.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/BKSec-AsholLeyland-Nov09-2017-V2.pdf)

