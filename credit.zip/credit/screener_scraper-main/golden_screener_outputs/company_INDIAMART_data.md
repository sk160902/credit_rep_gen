About
[
edit
]
IndiaMART, the first and largest B2B digital marketplace in the country, today stands out as a game-changer on the B2B landscape. It focuses on integrating the Small and Medium Businesses (SMEs) into the new paradigm with speed and ease, we are constantly pushing the frontiers of innovation to make the online marketplace more accessible, visible and engaging to them.
[1]
Key Points
[
edit
]
Largest in the industry
[1]
The company commands nearly
60% market share
of the online B2B classifieds space which makes it the largest player in the industry. It has a portfolio of ~7.9 million supplier storefronts, ~2,14,000 paying subscription suppliers,~108 mn live product listings, ~24 mn unique business enquiries & a total traffic of 252 million repeated users. The company has ~194 mn registered buyers with a repeat of 53%. CRM has ~136Mn replies & callbacks. 37% suppliers are buyers.
Well Diversified Marketplace
[2]
As of FY24, their website has ~108 million product listings from 56 different industries, making them one of the most diversified marketplaces in Indian. No single industry accounts for >8% of total paying suppliers. Construction & Building Raw Material is the largest category in the marketplace and covers ~8% of it. There are ~98,000 product categories.
Geographical Presence
[3]
As of FY24, the buyers and paying subscription suppliers are spread across as under:
Metro cities: Buyers(30%) Sellers (54%)
Tier II cities: Buyers(25%) Sellers (27%)
Rest of India: Buyers(45%) Sellers (19%)
As of FY23, company has access to 1000+ cities in India through 150+ Channel Sales Partners, Field, Tele and Online Sales and 4,400+ Inhouse Sales Supervision & Client Servicing team (Renewal & Upsell).
[4]
The company's sales and distribution costs are 20% of the revenue.
[5]
Customer Profile
The business for the company largely comes from small and medium enterprises (SMEs). The platform makes it easier for buyers & suppliers through its offerings which include the marketplace, convenient price discovery, intelligent connect & easy and secure payments.
[6]
Subscription based revenue Model
[7]
The company has subscription based revenue model and RFQ quota. Their top 10% subscribers generate 47% of the revenue with ARPU of Rs. 2,61,000 and top 1% generate 16% of the revenue with ARPU of Rs. 9,05,000.
Logistics Partner
[8]
Commercial Vehicles - Tata Motors, Mahindra, Piaggio, Atul Auto, TVS.
Accounting Space Investments
In FY23, company invested ~650 crs in accounting space to increase its business in the segment.
[9]
The company has made some strategic investments in equities as : Vyapar (27.5%), Real Books (26%), Busy (100%), around ~6mn in Live Keeping (65.97%)
[10]
. Live Keeping is Tally on Mobile - Integration with Tally software to provide Value Added Services with Mobile and Cloud first approach.
[11]
In May,24, invested further Rs. 13.39 crs. in Live keeping to make it to 65.97%.
[10]
Other Strategic Investments
[12]
As of FY24, company's strategic investments in equities are: Bizom( 25.1%), Shipway(26%), Aerchain(26.2%), Easyecom (26%), Superprocure (27.4%), PM(13%), industrybuying (26.6%), Legistify(15.4%), Fleetx (16.5%), M1(9.3%), Zimyo(10%).
~95% of revenue contributed by IndiaMART standalone business.
[13]
Merger of Subsidiaries
[14]
In March,24, the company merged the WOS Hello Trade Online Private Limited and Tolexo Online Private Limited into Busy Infotech Private Limited.
Last edited 2 months ago
Request an update
© Protected by Copyright
