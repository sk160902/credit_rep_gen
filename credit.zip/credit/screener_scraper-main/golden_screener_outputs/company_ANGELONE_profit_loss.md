# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 450 | 451 | 440 | 770 | 778 | 748 | 1,289 | 2,292 | 3,002 | 4,272 | 4,870 |
| Expenses + | 339 | 362 | 437 | 516 | 575 | 570 | 828 | 1,366 | 1,708 | 2,579 | 3,028 |
| Operating Profit | 112 | 90 | 3 | 254 | 203 | 178 | 460 | 926 | 1,294 | 1,693 | 1,842 |
| OPM % | 25% | 20% | 1% | 33% | 26% | 24% | 36% | 40% | 43% | 40% | 38% |
| Other Income + | 11 | 11 | 112 | 14 | 11 | 7 | 10 | 5 | 18 | 7 | 9 |
| Interest | 38 | 36 | 54 | 95 | 70 | 50 | 42 | 76 | 91 | 137 | 173 |
| Depreciation | 10 | 13 | 14 | 15 | 20 | 21 | 18 | 19 | 30 | 50 | 64 |
| Profit before tax | 74 | 52 | 48 | 159 | 124 | 114 | 410 | 836 | 1,192 | 1,514 | 1,614 |
| Tax % | 37% | 39% | 35% | 32% | 36% | 28% | 28% | 25% | 25% | 26% |  |
| Net Profit + | 47 | 32 | 31 | 108 | 80 | 82 | 297 | 625 | 890 | 1,126 | 1,197 |
| EPS in Rs | 32.69 | 22.08 | 21.59 | 14.99 | 11.09 | 11.44 | 36.28 | 75.41 | 106.68 | 133.98 | 140.27 |
| Dividend Payout % | 13% | 25% | 31% | 91% | 24% | 24% | 35% | 36% | 37% | 26% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 49% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 56% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 70% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 34% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 42% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 43% |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2017 | Mar 2018 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Dinesh Thakkar Individual |  |  |  |  |  |  |  |
| Dividend paid | 2.28 | 4.56 |  | 8.47 | 41 | 60 | 81 |
| Remuneration Paid | 1.43 | 1.84 |  | 3.16 | 4.26 | 5.74 | 7.21 |
| Other Receivables |  |  |  | 0.75 | 0.75 | 0.75 | 0.75 |
| Repayment of Loan from Directors |  | 2.40 |  |  |  |  |  |
| Loan from Directors | 2.40 |  |  |  |  |  |  |
| Long-term loans and advances | 0.75 | 0.75 |  |  |  |  |  |
| Lease income from furnished property |  |  |  | 0.15 | 0.13 | 0.15 | 0.16 |
| Short term loans and advances |  | 0.50 |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  |  | 0.45 |
| Rent Received | 0.05 | 0.06 |  |  |  |  |  |
| Income from broking and allied activities |  |  |  |  |  |  | 0.09 |
| Personal training fees | 0.02 | 0.02 |  |  |  |  |  |
| Income from broking |  | 0.02 |  |  |  |  |  |
| Nirwan Monetary Services Private Limited |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 3.06 | 15 | 22 | 29 |
| Trade Payables to |  |  |  |  |  | 14 | 3.14 |
| DIVIDEND PAID |  |  | 1.64 |  |  |  |  |
| Income from broking and allied activities |  |  |  |  |  | 0.01 | 0.14 |
| Income from broking activities |  |  |  |  | 0.01 |  |  |
| Ashok Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.44 | 0.87 |  | 0.98 | 6.40 | 9.23 | 13 |
| Remuneration Paid | 0.36 | 0.36 |  | 0.43 |  |  |  |
| Income from broking | 0.01 | 0.02 |  |  |  |  |  |
| Nirwan Monetary Service Private Limited |  |  |  |  |  |  |  |
| Loans Given | 3.41 | 8.75 |  |  |  |  |  |
| Loan Repaid | 3.41 | 8.75 |  |  |  |  |  |
| Dividend paid | 0.82 | 1.65 |  |  |  |  |  |
| Purchase of property |  |  |  | 2.41 |  |  |  |
| Interest Received | 0.01 | 0.01 |  |  |  |  |  |
| Mr. Dinesh Thakkar Parent Co. |  |  |  |  |  |  |  |
| DIVIDEND PAID |  |  | 4.53 |  |  |  |  |
| REMUNERATION PAID |  |  | 2.52 |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.75 |  |  |  |  |
| LEASE INCOME FROM FURNISHED PROPERTY |  |  | 0.08 |  |  |  |  |
| INCOME FROM BROKING ACTIVITIES |  |  | 0.04 |  |  |  |  |
| Lalit Thakkar Individual |  |  |  |  |  |  |  |
| Dividend paid | 1.23 | 2.45 |  |  |  |  |  |
| Remuneration Paid | 0.80 | 0.94 |  |  |  |  |  |
| Loan from Directors | 0.85 | 0.85 |  |  |  |  |  |
| Vinay Agrawal Key Person |  |  |  |  |  |  |  |
| Remuneration Paid | 1.58 | 1.58 |  | 2.67 | 0.19 |  |  |
| Dividend paid | 0.01 | 0.01 |  | 0.11 | 0.15 |  |  |
| Dinesh Dariyanumal Thakkar HUF Relative |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  | 2.19 | 2.98 |
| Trade Payables to |  |  |  |  |  |  | 0.21 |
| Kanta Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  | 3.10 | 0.06 |
| Income from broking and allied activities |  |  |  |  |  | 0.03 | 0.06 |
| Dividend paid |  |  |  |  | 0.01 | 0.02 | 0.03 |
| Narayan Gangadhar Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  |  | 3.20 |  |  |
| Vineet Agrawal Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  | 1.24 | 1.43 |  |  |
| Dividend paid |  |  |  |  | 0.15 |  |  |
| Dinesh Thakkar HUF Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.08 | 0.17 |  | 0.31 | 1.52 |  |  |
| DIVIDEND PAID |  |  | 0.17 |  |  |  |  |
| Vinay Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  | 0.45 | 1.25 |
| Remuneration Paid |  |  |  |  |  | 0.16 | 0.19 |
| Income from broking and allied activities |  |  |  |  |  |  | 0.02 |
| Mr. Vinay Agrawal Key Person |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 1.91 |  |  |  |  |
| DIVIDEND PAID |  |  | 0.06 |  |  |  |  |
| Ketan Shah Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  |  | 1.50 |  |  |
| Dividend paid |  |  |  |  | 0.07 |  |  |
| Deepak Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.48 | 0.94 |  |  |  |  |  |
| Income from broking | 0.01 | 0.01 |  |  |  |  |  |
| Mr. Ashok Thakkar Relative |  |  |  |  |  |  |  |
| DIVIDEND PAID |  |  | 0.86 |  |  |  |  |
| REMUNERATION PAID |  |  | 0.38 |  |  |  |  |
| Vinay Agarwal Key Person |  |  |  |  |  |  |  |
| Short term loans and advances |  | 0.75 |  |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.03 |  |  |  |  |
| Tarachand Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  | 0.30 | 0.41 |
| Vijay Thakkar Key Person |  |  |  |  |  |  |  |
| Remuneration Paid | 0.25 | 0.27 |  | 0.12 |  |  |  |
| Income from cafeteria |  | 0.01 |  |  |  |  |  |
| Naheed Patel Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  | 0.22 | 0.27 |  |  |
| VijayThakkar Relative |  |  |  |  |  |  |  |
| Professional Fees |  |  |  |  |  | 0.05 | 0.08 |
| Professional fees paid |  |  |  | 0.12 |  |  |  |
| Remuneration Paid |  |  |  |  |  |  | 0.08 |
| Trade Payables to |  |  |  |  |  | 0.01 | 0.04 |
| Other Payables |  |  |  |  |  | 0.05 |  |
| Income from broking and allied activities |  |  |  |  |  |  | 0.02 |
| Mr. Vijay Thakkar Relative |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 0.32 |  |  |  |  |
| Sunita Magnani Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.10 | 0.20 |  |  |  |  |  |
| Ms. Naheed Patel Key Person |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 0.21 |  |  |  |  |
| Kamalji Jagat Bhushan Sahay Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.12 |  |  |
| Directors' setting fees |  |  |  | 0.08 |  |  |  |
| Uday Sankar Roy Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.11 |  |  |
| Directors' setting fees |  |  |  | 0.08 |  |  |  |
| Anisha Motwani Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.06 |  |  |
| Directors' setting fees |  |  |  | 0.06 |  |  |  |
| Angel Insurance Brokers and Advisors Private Limited |  |  |  |  |  |  |  |
| Repayment of Loan Given |  |  |  |  |  | 0.03 |  |
| Other Payables |  |  |  |  | 0.02 |  |  |
| Other Receivables |  |  |  | 0.02 |  |  |  |
| Loan Given |  |  |  |  |  | 0.01 |  |
| LOAN GIVEN |  |  | 0.01 |  |  |  |  |
| REPAYMENT OF LOAN GIVEN |  |  | 0.01 |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.01 |  |  |  |  |
| Mr. Kamalji Jagat Bhushan Sahay Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.07 |  |  |  |  |
| Mr. Uday Sankar Roy Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.07 |  |  |  |  |
| Krishna Iyer Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.05 |  |  |
| Ms. Anisha Motwani Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.05 |  |  |  |  |
| Muralidharan Ramachandran Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.04 |  |  |
| Mala Todarwal Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.03 |  |  |
| Shalini Agrawal Relative |  |  |  |  |  |  |  |
| Income from broking activities |  |  |  |  | 0.02 |  |  |
| Poonam Vijay Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  |  | 0.01 |
| Anuradhal Thakkar Individual |  |  |  |  |  |  |  |
| Income from broking |  | 0.01 |  |  |  |  |  |
| Rahul Thakkar Relative |  |  |  |  |  |  |  |
| Income from broking |  | 0.01 |  |  |  |  |  |
| Hema Thakkar Individual |  |  |  |  |  |  |  |
| Personal training fees |  | 0.01 |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 450 | 451 | 440 | 770 | 778 | 748 | 1,289 | 2,292 | 3,002 | 4,272 | 4,870 |
| Expenses + | 339 | 362 | 437 | 516 | 575 | 570 | 828 | 1,366 | 1,708 | 2,579 | 3,028 |
| Operating Profit | 112 | 90 | 3 | 254 | 203 | 178 | 460 | 926 | 1,294 | 1,693 | 1,842 |
| OPM % | 25% | 20% | 1% | 33% | 26% | 24% | 36% | 40% | 43% | 40% | 38% |
| Other Income + | 11 | 11 | 112 | 14 | 11 | 7 | 10 | 5 | 18 | 7 | 9 |
| Interest | 38 | 36 | 54 | 95 | 70 | 50 | 42 | 76 | 91 | 137 | 173 |
| Depreciation | 10 | 13 | 14 | 15 | 20 | 21 | 18 | 19 | 30 | 50 | 64 |
| Profit before tax | 74 | 52 | 48 | 159 | 124 | 114 | 410 | 836 | 1,192 | 1,514 | 1,614 |
| Tax % | 37% | 39% | 35% | 32% | 36% | 28% | 28% | 25% | 25% | 26% |  |
| Net Profit + | 47 | 32 | 31 | 108 | 80 | 82 | 297 | 625 | 890 | 1,126 | 1,197 |
| EPS in Rs | 32.69 | 22.08 | 21.59 | 14.99 | 11.09 | 11.44 | 36.28 | 75.41 | 106.68 | 133.98 | 140.27 |
| Dividend Payout % | 13% | 25% | 31% | 91% | 24% | 24% | 35% | 36% | 37% | 26% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 49% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 56% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 70% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 34% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 42% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 43% |  |  |  |  |  |  |  |  |  |  |

