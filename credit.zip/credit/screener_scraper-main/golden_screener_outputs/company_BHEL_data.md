About
[
edit
]
Bharat Heavy Electricals Ltd is an integrated power plant equipment manufacturer engaged in design, engineering, manufacture, erection, testing, commissioning and servicing of a wide range of products and services for the core sectors of the economy, viz. Power, transmission, Industry, transportation, renewable energy, Oil & Gas and defence.
[1]
It is the flagship engineering and manufacturing company of India owned and controlled by the Govt. of India.
[2]
Key Points
[
edit
]
Power Sector (~76% of revenues)
[1]
The company has capabilities to manufacture the entire range of power plant equipment including thermal, gas, hydro and nuclear power projects.
[2]
Execution Record -
It has executed ~1,000
coal, hydro, gas and nuclear based utility sets since its inception in 1964.
It accounts for ~53% of India's total capacity of utility power projects.
[3]
As per FY22, the total capacity of company's electricity utility installed base is ~164 GW out of which ~132 GW is from coal based power projects.
[4]
Industry Sector (~24% of revenues)
Under this segment, the company offers various products/ solutions for various sectors viz. transportation, renewables, defence & aerospace, energy storage solutions & other business areas, captive power & process plants, transmission and industrial products.
[5]
Product Profile -
The company's product profile for both its sectors can be found here.
[6]
Order Book Position
As per FY22, the company has an outstanding order book of ~102,500 crores. It received ~23,690 crores of orders in FY22 out of which 76% is from Power Sector.
[7]
For Power Sector, out of the total order from 2017-2022 which was 16,320MW, BHEL accounted for ~75%, 12,180MW and commands 100% market share in Nuclear Power
[8]
International Presence
The company has its footprint in 88 countries across 6 continents in the world.
[9]
In FY22, exports accounted for ~8% revenues compared to 11% in FY21.
[10]
Manufacturing Capabilities
As per FY22, the company operates 16, manufacturing units and 2 repair units across the nation.
[11]
R&D Capabilities
The company has 14 R&D centers established across India. It also has 5 specialized research institutes for pollution control, welding, ceramic technology, electric transportation and amorphous silicon solar cell across various cities.
[12]
It has consistently spent ~2.5% of total sales towards R&D over years.
[13]
Intense Competition
The company operates in an increasingly competitive market as several domestic companies have entered into the boiler-turbine-generator space through JVs with international players.
[14]
Last edited 1 year, 8 months ago
Request an update
© Protected by Copyright
