# Complete Company Data

## Modal Content
About
[
edit
]
Asian Paints is the
largest
home decor company in India. The 80+yyr old company has major brands like Asian Paints, Berger, Apco, etc under its umbrella. The co. is into wall paints, wall coverings, waterproofing, texture painting, wall stickers, mechanized tools, adhesives, modular kitchens, sanitaryware, lightings, soft furnishings, and uPVC windows.
Key Points
[
edit
]
Brand
[1]
The Asian Paints group has some of the leading brands under its umbrella like Asian Paints, Sleek, Berger, Weather Seal, Apco, Taubman, Kadisco, Scib etc. In FY23, 25 patents were filed and 10 were granted. 22 new products were launched in FY23.
[2]
The company has total 49 patents in its name till FY23.
[3]
Revenue Breakup FY23
[4]
Decorative Business - 84%
Home Decor Business - 4%
Industrial Coatings - 3%
International Operations - 9%
Geographical Revenue FY23
[5]
Asia : 44%
Middle East : 29%
Africa : 22%
South pacific: 4%
Leadership
[1]
<h1>1 paint company in India</h1>
<h1>2 paint company in Asia</h1>
<h1>7 paint company in the world.</h1>
50+ Years of Market Leadership in India.
Leading wallpaper manufacturer under the brand NILAYA.
3x of the nearest Competitor in India.
Business Segments
[4]
Decorative Business
Asian Paints is India's leading paint and décor company, with the largest of its kind painting
service in the world, available in 600+ towns. This includes Interior wall finishes, Exterior wall finishes, Waterproofing, Wood finishes,  Enamels, Adhesives, Tools, Undercoats
Home Decor Business
Under this segment, the company tries to provide a complete one-stop home décor solution to customers. This includes Modular Kitchens, Sanitaryware, lighting, uPVC windows, Wall coverings, Furniture, soft Furnishing
Industrial Business
In this segment, the company provides high-quality custom formulated products for the automotive and industrial coatings business in India. This includes Automotive, Marine, and Packaging Coatings, Industrial Protective
coatings, Powder coatings, Floor coatings
and Road markings.
Sales & Distribution
The company has 150,000+ retail touchpoints in India. It has 42 Beautiful Home stores. It serves 60+ countries.
[1]
The company has 240,000+ Business influencers
and 20,000+ Supplier base.
[2]
Manufacturing Facilities **
The company has total
11 manufacturing facilities in India and 17 outside India
.
[5]
The company's Ankleshwar plant reached BBS
Generative Stage (First in the world in coatings sector)
[6]
The company also has
27 outsourced processing centres**.
[2]
Capex
[7]
The company has planned investments of ₹ 8,750 Crores over the next 3 years on various capacity enhancements as well as a few critical backward integration projects.
1. The company plans to set up a manufacturing facility for VAE (Vinyl Acetate Ethylene Emulsion) and VAM (Vinyl Acetate Monomer) in India for a proposed investment of approx ₹ 2,100 Crores over a period of 3 years. The installed capacity of the manufacturing facility would be 1 Lakhs TPA for VAM and 1.5 Lakhs TPA for VAE. VAE is the Next-Gen environment-friendly emulsion, based on a unique VAM technology, which will provide a robust competitive edge to Asian Paints in the coatings business.
2. The company has entered into a JV to establish a 2.65 Lakhs MTPA manufacturing facility of white cement in Fujairah, UAE. In addition, clinker grinding units would be set up in India as well. The overall investment would be approximately ₹ 550 Crores, to be invested over the next 2 years.
3. Brownfield expansions at the existing decorative paint plants at Kasna, Khandala, Ankleshwar, and Mysuru, along with other regular capex will entail an outflow of ₹ 3,400
Crs supporting the growth plan over the next 3 years which will add 5.40 Lakhs KL per annum to the existing capacity.
4. The company has plans to set up a new water-based paint manufacturing facility with a capacity of 4 Lakhs KLPA at an approximate investment of ₹ 2,000 Crores. This facility is expected to commission 3 years after the acquisition of the land.
5. The company has signed a definitive agreement to acquire a majority stake in a specialty chemical and next-generation nanotechnology player, which will enhance the company's technological capabilities across all the products.
Associates / Subsidiaries
1. PPG Asian Paints Private Limited :
50% stake held
[8]
2. Obgenix Software Private Limited : 49% stake held.
3. The company has 24 subsidiaries in total.
[9]
Focus
The company is in the process of reinventing itself by strategically shifting its focus from ‘share of surface’ to ‘share of space’. This strategic shift is part of its plan to transform into a premier décor consultant and service provider.
[10]
Last edited 1 year ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 10,504 | 12,220 | 13,615 | 14,271 | 15,062 | 16,825 | 19,240 | 20,211 | 21,713 | 29,101 | 34,489 | 35,495 | 35,282 |
| Expenses + | 8,767 | 10,217 | 11,372 | 11,546 | 12,068 | 13,621 | 15,475 | 16,054 | 16,857 | 24,298 | 28,229 | 27,910 | 28,125 |
| Operating Profit | 1,737 | 2,004 | 2,243 | 2,725 | 2,994 | 3,204 | 3,765 | 4,157 | 4,856 | 4,804 | 6,260 | 7,585 | 7,157 |
| OPM % | 17% | 16% | 16% | 19% | 20% | 19% | 20% | 21% | 22% | 17% | 18% | 21% | 20% |
| Other Income + | 114 | 124 | 142 | 213 | 338 | 336 | 274 | 355 | 332 | 296 | 431 | 821 | 786 |
| Interest | 42 | 48 | 42 | 49 | 37 | 41 | 110 | 102 | 92 | 95 | 144 | 205 | 215 |
| Depreciation | 155 | 246 | 266 | 276 | 335 | 360 | 622 | 780 | 791 | 816 | 858 | 853 | 882 |
| Profit before tax | 1,655 | 1,834 | 2,077 | 2,614 | 2,960 | 3,138 | 3,306 | 3,629 | 4,304 | 4,188 | 5,689 | 7,348 | 6,846 |
| Tax % | 30% | 31% | 31% | 32% | 32% | 33% | 33% | 24% | 26% | 26% | 26% | 24% |  |
| Net Profit + | 1,160 | 1,263 | 1,427 | 1,803 | 2,016 | 2,098 | 2,208 | 2,774 | 3,207 | 3,085 | 4,195 | 5,558 | 5,170 |
| EPS in Rs | 11.61 | 12.71 | 14.54 | 18.19 | 20.22 | 21.26 | 22.48 | 28.20 | 32.73 | 31.59 | 42.81 | 56.92 | 52.96 |
| Dividend Payout % | 40% | 42% | 42% | 41% | 51% | 41% | 47% | 43% | 55% | 61% | 60% | 58% |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Others Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 142 | 528 | 579 | 769 |
| Dividend Paid |  |  | 318 | 411 | 355 | 722 |  |  |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 240 | 260 |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 42 | 58 | 73 | 84 |  |  |  |  |
| Purchase of goods | 57 | 50 |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.11 | 13 | 0.28 | 0.18 |  |  |  |  |
| Commission to |  |  |  |  | 2.08 | 1.90 |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 2.08 |  |  |  |  |  |  |
| Remuneration | 0.48 | 0.36 | 0.35 | 0.42 |  |  |  |  |  |  |
| Sale of goods | 0.96 | 0.48 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.46 | 0.44 |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.50 |  |  |  |  |  |  |
| Other non operating income |  |  |  | 0.15 | 0.17 | 0.16 |  |  |  |  |
| Reimbursement of Expenses Paid |  |  |  | 0.08 |  |  |  |  |  |  |
| Security Deposits paid | 0.01 |  |  |  |  |  |  |  |  |  |
| Security Deposits refunded | 0.01 |  |  |  |  |  |  |  |  |  |
| Hitech Corporation Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  | 267 | 342 | 351 | 2.24 | 2.44 |  |  |
| Hitech Plast Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 261 | 238 |  |  |  |  |  |  |  |  |
| PPG Asian Paints Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend received |  |  |  |  |  |  |  |  | 43 | 108 |
| Revenue from sale of products |  |  | 9.50 | 15 |  |  |  |  |  |  |
| Processing of Goods (Income) |  |  |  | 24 |  |  |  |  |  |  |
| Other non operating income |  |  | 8.50 | 11 |  |  |  |  |  |  |
| Processing Income |  |  |  |  |  |  | 13 | -0.13 | 2.86 | 1.98 |
| Processing and service income |  |  | 17 |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 2.59 | 1.67 | 1.04 | 2.67 |
| Purchase of Goods |  |  | 0.12 |  |  |  | 0.38 | 2.06 | 1.23 | 2.15 |
| Royalty Income |  |  |  | 3.94 |  |  | 0.40 | 0.50 | 0.32 | 0.29 |
| Royalty Received |  |  | 3.99 |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  | 0.71 | 0.93 | 0.25 | 0.14 |
| Reimbursement of Expenses Paid |  |  | 0.17 | 1.73 |  |  |  |  |  |  |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  | 0.30 | 0.87 |
| Reimbursement of Expenses - paid |  |  |  |  |  |  | 0.45 |  |  |  |
| Purchase of Assets |  |  |  |  |  |  |  | 0.42 |  | 0.01 |
| Reimbursement of Expenses Received |  |  | 0.19 | 0.24 |  |  |  |  |  |  |
| Reimbursement of Expenses - received |  |  |  |  |  |  | 0.23 |  |  |  |
| Sale of Assets |  |  |  |  |  |  |  |  |  | 0.18 |
| Processing charges |  |  |  |  |  |  | 0.14 | 0.01 |  |  |
| Processing Charges |  |  | 0.11 |  |  |  |  |  |  |  |
| Reimbursement for Expenses incurred by the Group on behalf of the related party |  |  |  |  |  |  |  | 0.08 |  |  |
| Reimbursement of Expenses Paid |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Reimbursement for Expenses incurred by related party on behalf of the Group |  |  |  |  |  |  |  | 0.02 |  |  |
| Smiti Holding And Trading Company Pvt Ltd Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 110 | 146 |
| Sattva Holding and Trading Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 109 | 145 |
| Parekhplast India Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  | 123 | 120 |  |  |  |  |
| Hitech Plast Limited. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 234 |  |  |  |  |  |  |  |
| Hitech Corporation Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 106 | 111 |
| Smiti Holding And Trading Company Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  | 56 | 48 | 99 |  |  |  |  |
| Asian Paints Office Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 9.17 | 10 | 31 |  | 51 | 36 |  | 4.14 | 4.53 | 5.77 |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 33 |  |  | 3.57 |  |  |  |
| Parekh Plast India Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 88 | 96 |  |  |  |  |  |  |  |  |
| Sattva Holding and Trading Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 27 | 102 |  |  |
| Dividend Paid |  |  |  | 54 |  |  |  |  |  |  |
| Parekh Plast India Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  | 110 |  |  | 69 |  |  |  |
| Smiti Holding and Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 100 |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 32 | 35 |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | -0.10 |  |  |
| Sattva Holding and Trading Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 47 | 98 |  |  |  |  |
| Asian Paints Factory Employees Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 5.26 | 5.52 | 20 |  | 35 | 29 |  | 2.88 |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 22 |  |  |  |  |  |  |
| PPG Asian Paints Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Processing of Goods (Income) |  |  |  |  | 20 | 17 |  |  |  |  |
| Revenue from sale of products |  |  |  |  | 18 | 12 |  |  |  |  |
| Other non operating income |  |  |  |  | 11 | 11 |  |  |  |  |
| Royalty Income |  |  |  |  | 3.78 | 3.61 |  |  |  |  |
| Reimbursement oF Expenses-Received |  |  |  |  | 0.33 | 0.92 |  |  |  |  |
| Sale of Assets |  |  |  |  | 0.27 | 0.48 |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  | 0.45 |  |  |  |  |  |
| Reimbursement oF Expenses-Paid |  |  |  |  | 0.12 | 0.13 |  |  |  |  |
| Parekhplast India Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 93 |  |  |  |  |  |  |  |
| Smiti Holding And Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 43 |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 27 |  |  |  |
| ISIS Holding and Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 32 | 34 |  |  |  |  |  |  |  |  |
| Late Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 51 |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.34 |  |  |
| Nehal Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.42 | 25 | 15 |
| Remuneration |  |  |  |  |  |  |  | 0.03 | 0.42 | 0.42 |
| Asian Paints (I) Limited |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 24 | 19 |
| Shri. K.B.S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 9.72 |  | 12 | 14 |  |  |  |  |
| Retiral Benefits |  |  |  |  |  | 6.36 |  |  |  |  |
| ISIS Holding And Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 42 |  |  |  |  |  |  |  |
| Varun Vakil Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.05 | 15 | 20 |
| Remuneration |  |  |  |  |  |  |  | 0.82 | 0.93 | 1.07 |
| Asian Paints (I) Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  | 38 |  |  |
| Asian Paints (I) Ltd. Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 25 | 10 |  |  |  |  |  |  |  |  |
| Asian Paints (India) Ltd. Employees' Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  | 7 | 26 |  |  |  |  |
| Asian Paints (India) Limited Employees' Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  |  |  |  | 17 |  |  |  |
| Contributions during the year |  |  | 10 |  |  |  |  |  |  |  |
| Amit Syngle Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 6.66 | 10 | 8.82 |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  |  | 0.01 |
| Resins and Plastics Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 8.75 | 14 |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.02 | 0.01 |
| Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 6 | 6.58 | 8.90 |
| Remuneration |  |  |  |  |  |  |  | 0.36 | 0.44 | 0.45 |
| Ricinash Renewable Materials Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.58 | 20 |  |  |
| Resins and Plastics Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 6.09 | 10 |  |  |
| Sale of goods | 1.34 | 0.77 |  |  |  |  |  |  |  |  |
| Sale of assets | 0.28 | 0.24 |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | 0.14 |  |  |
| Shri. Jayesh Merchant Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.22 |  | 5.10 | 5.99 |  |  |  |  |
| Retiral Benefits |  |  |  |  |  | 4.18 |  |  |  |  |
| Amrita Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.66 | 5.11 | 6.78 |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.43 |
| Shri. Manish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.06 | 3.48 | 2.80 | 1.75 | 0.38 |  |  |  |
| Retiral Benefits |  |  |  |  | 3.50 |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.16 |  |  |  |
| Commission to |  |  |  |  | 0.22 | 0.29 |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 0.28 |  |  |  |
| Manish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.34 | 4.75 | 6.31 |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.46 | 0.46 |
| Late Shri. Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 14 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Retiral benefits |  |  |  |  |  |  | 0.07 |  |  |  |
| Jigish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.62 | 3.97 | 5.27 |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.42 |
| Shri K.B.S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 6.10 | 7.77 |  |  |  |  |  |  |  |  |
| Piramal Swasthya Management and Research Institute |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  |  | 1.55 | 2.30 | 2.46 | 3.21 | 3.51 |
| Asian Paints Management Cadres Superannuation Scheme |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 1.98 | 2.28 | 2.52 |  | 2.20 | 1.08 |  | 0.03 |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 2.47 |  |  | 0.06 |  |  |  |
| Ricinash Renewable Materials Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.95 | 12 |
| R J Jeyamurugan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 3.06 | 3.69 | 4.31 |
| Shri K. B. S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  | 11 |  |  |  |  |  |  |
| ELF Trading And Chemical Manufacturing Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 4.20 | 5.57 |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.24 | 0.03 |
| Shri Jayesh Merchant Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.54 | 2.83 |  | 3.85 |  |  |  |  |  |  |
| Late Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 3.92 | 4.49 |
| Remuneration |  |  |  |  |  |  |  |  | 0.42 | 0.21 |
| Retiral benefits |  |  |  |  |  |  |  |  | 0.07 | 0.04 |
| RupalAnant Bhat Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 3.83 | 5.08 |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.07 | 0.02 |
| Asian Paints Factory Employees’ Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 3.27 | 3.68 |
| Paladin Paints And Chemicals Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 5.82 | 0.24 |
| Services Received |  |  |  |  |  |  |  |  | 0.09 | 0.02 |
| Shri. Jalaj Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.03 | 0.60 |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 2.32 |  |  |  |  |  |  |
| Shri Manish Choksi Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.56 | 2.92 |  |  |  |  |  |  |  |  |
| Shri Jalaj Dani Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.37 | 2.77 |  |  |  |  |  |  |  |  |
| Addverb Technologies Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Assets |  |  |  |  | 3.73 |  |  |  |  |  |
| Other Services Paid |  |  |  |  |  | 1.38 |  |  |  |  |
| Shri Amit Syngle Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 4.58 |  |  |  |
| Vikatmev Containers Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 2.23 | 1.53 |  |  |
| Dividend paid |  |  |  |  |  |  |  | 0.20 |  |  |
| Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.58 |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.36 |  |  |
| ELF Trading and Chemical Manufacturing Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.83 |  |  |
| Ankleshwar Industrial Development Society |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  | 3.17 | 0.21 | 0.27 |  |  | 0.01 |
| Services Received |  |  |  |  |  |  |  | -0.01 | -0.01 | 0.15 |
| Stack Pack Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 2.41 | 1.08 |
| Shri R J Jeyamurugan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  | 0.61 | 2.58 |  |  |  |
| Shri. Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.60 |  |  |  |
| Commission to |  |  |  |  | 0.30 | 0.27 |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.30 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.28 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Vikatmev Containers Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 1.02 | 1.59 |
| Dividend paid |  |  |  |  |  |  |  |  | 0.22 | 0.29 |
| Shri. Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 0.96 |  |  |  |
| Commission to |  |  |  |  | 0.35 | 0.32 |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.42 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.32 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.30 |  |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.07 | 0.07 |  |  |  |  |
| Retiral benefits |  |  | 0.07 |  |  |  | 0.07 |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.05 |  |  |  |  |  |  |  |
| Asian Paints Factory Employees' Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  |  |  |  | 2.78 |  |  |  |
| Port Villa Hardware Ltd Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 1.15 | 1.63 |  |  |  |  |  |  |  |  |
| Shri. Varun Vakil Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  | 0.45 | 0.54 | 0.64 |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.08 |  |  |  |
| Obgenix Software Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  |  |  | 0.26 | 0.62 |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.71 | 0.03 |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  | 0.18 | 0.26 |
| Royalty Income |  |  |  |  |  |  |  |  | 0.13 | 0.03 |
| Al Hasan Engineering Co. SAOG Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 1.42 | 0.78 |  |  |  |  |  |  |  |  |
| Hitech Specialities Solutions Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.18 | 1.86 |  |  |
| Ms. Amrita Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.24 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Shardul Amarchand Mangaldas & Co. |  |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  |  |  |  |  | 0.76 |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.70 |  |  |  |
| Other Services Paid |  |  |  |  |  | 0.29 |  |  |  |  |
| Stack Pack Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.34 | 1.40 |  |  |
| Santo Hardware Ltd Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 0.95 | 0.75 |  |  |  |  |  |  |  |  |
| Shri. Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.28 | 0.25 |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.08 | 0.07 |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.07 | 0.06 |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.07 |  |  |  |  |  |  |
| Retiral benefits |  |  | 0.07 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.06 |  |  |  |  |  |  |  |
| Paladin Paints and Chemicals Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  | 1.02 |  |  |
| Services Received |  |  |  |  |  |  |  | 0.56 |  |  |
| Shri. Jigish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 0.97 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Commission to |  |  |  |  |  | 0.25 |  |  |  |  |
| PPG Industries Securities LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Other Recoveries | 1.03 | 0.19 |  |  |  |  |  |  |  |  |
| Purchase of Assets | 0.03 | 0.19 |  |  |  |  |  |  |  |  |
| Ms. Amrita Amar Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.26 |  |  | 0.28 | 0.25 |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.04 | 0.05 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Addverb Technologies Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Advance given |  |  |  | 0.88 |  |  |  |  |  |  |
| Purchase of Assets |  |  |  | 0.44 |  |  |  |  |  |  |
| Suresh Narayanan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.46 | 0.46 |
| R Seshasayee Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.44 | 0.47 |
| Asian Paints Industrial Coatings Limited |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 0.26 | 0.99 |
| Vibha Paul Rishi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.35 | 0.44 | 0.45 |
| Santo Hardware Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.21 |  |  |  |  |  |  |  |
| Orasscom Construction Industries |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 0.38 | 0.51 |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 0.32 |  |  |  |  |  |  |  |
| Pallavi Shroff Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.42 |
| Port Villa Hardware Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.18 |  |  |  |  |  |  |  |
| Deepak Satwalekar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.40 | 0.50 | 0.25 |
| Milind Sarwate Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.14 | 0.48 | 0.48 |
| Paladin Paints And Chemicals Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.55 |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.52 |  |  |  |
| Navbharat Packaging Industries Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.57 | 0.39 |  |  |
| Shri. Mahendra Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.28 |  |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.06 |  |  |  |  |  |  |  |
| Shri Thakur Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.41 | 0.43 |  |  |  |  |  |  |  |  |
| Shri Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.28 | 0.34 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.07 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.03 | 0.04 |  |  |  |  |  |  |  |  |
| Shri Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.26 | 0.30 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.07 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.06 |  |  |  |  |  |  |  |  |
| Shri Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.26 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.08 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.08 |  |  |  |  |  |  |  |  |
| Shardul Amarchand Mangaldas & Co |  |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  |  |  |  |  |  | 0.44 | 0.31 |
| Late Shri. Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.36 |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.18 |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.03 |  |  |  |  |  |
| Shri Mahendra C Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.24 | 0.27 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.06 |  |  |  |  |  |  |  |  |
| Shri Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.27 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.04 | 0.05 |  |  |  |  |  |  |  |  |
| Dr. S. Sivaram Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 | 0.18 |  |  |
| Navbharat Packaging Industries Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.30 | 0.22 |
| Shri. Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.34 |  |  |  |  |  |  |  |
| Retiral benefits |  |  | 0.08 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Mr Thakur Ahuja |  |  |  |  |  |  |  |  |  |  |
| Rent Paid |  |  | 0.45 |  |  |  |  |  |  |  |
| Riash Renewable Materials Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.88 | 1.31 |
| Addverb Technologies Pvt Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.39 |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 0.03 |  |  |  |
| M.K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.40 |  |  |
| Shri. M.K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.40 |  |  |  |
| Shri. Suresh Narayanan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.38 |  |  |  |
| Shri. R Seshasayee Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 |  |  |  |
| Shri Rajesh T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 | 0.18 |  |  |  |  |  |  |  |  |
| Shri Monesh T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 | 0.18 |  |  |  |  |  |  |  |  |
| Shri. Deepak Satwalekar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Mrs. Pallavi Shroff Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Mrs. Vibha Paul Rishi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| LKP Hardware |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 0.32 |  |  |  |  |  |  |  |
| Ireena Vittal Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  |  |  | 0.28 |
| AR Intertect Design Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other services - Paid | 0.11 | 0.17 |  |  |  |  |  |  |  |  |
| Pratham Education Foundation |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  |  | 0.22 | 0.03 |  |  |  |
| Addverb Technologies Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  |  | 0.20 |
| Services Received |  |  |  |  |  |  |  |  |  | 0.03 |
| Shri Thakur T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 |  |  |  |  |  |  |  |  |  |
| Other services - Paid | 0.05 |  |  |  |  |  |  |  |  |  |
| Soumitra Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  |  |  | 0.18 |
| ARI Designs LLP |  |  |  |  |  |  |  |  |  |  |
| Other Services Paid |  |  | 0.10 | 0.04 | 0.03 |  |  |  |  |  |
| Resins & Plastics Limited. |  |  |  |  |  |  |  |  |  |  |
| Sale of Asset |  |  | 0.15 |  |  |  |  |  |  |  |
| Smiti Holding And Trading Company Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.14 |  |
| Addverb Technologies Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | 0.07 |  |  |
| Services Received |  |  |  |  |  |  |  | 0.07 |  |  |
| Shri M K Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.08 | 0.06 |  |  |  |  |
| Gujarat Organics Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of assets | 0.12 |  |  |  |  |  |  |  |  |  |
| Hydra Trading Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.11 |  |
| Pragati Chemicals Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.10 |  |  |  |
| Sale of assets | 0.01 |  |  |  |  |  |  |  |  |  |
| M/s. MRJ Industries Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.05 | 0.01 |  |  |  |  |  |  |  |  |
| Security Deposits refunded | 0.02 | 0.02 |  |  |  |  |  |  |  |  |
| Shri. M. K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.08 |  |  |  |  |  |  |
| M/s. Ess Ess Industries Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of assets |  | 0.08 |  |  |  |  |  |  |  |  |
| Ricinash Oil Mills Ltd. |  |  |  |  |  |  |  |  |  |  |
| Sale of assets | 0.08 |  |  |  |  |  |  |  |  |  |
| Shri Mahendra Shah Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.07 |  |  |  |  |  |
| Shri. Mahendra Shah Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.06 |  |  |  |  |  |  |
| Asian Paints Management Cadres’ Superannuation Scheme |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 0.04 |  |
| Shri Amar A Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.03 |  |  |  |  |  |  |  |  |  |
| Revocoat India Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  |  | 0.02 | -0.02 | 0.01 |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  |  | 0.01 |
| Hitech Specialities Solutions Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Hydra Trading Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | -0.14 |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 10,504 | 12,220 | 13,615 | 14,271 | 15,062 | 16,825 | 19,240 | 20,211 | 21,713 | 29,101 | 34,489 | 35,495 | 35,282 |
| Expenses + | 8,767 | 10,217 | 11,372 | 11,546 | 12,068 | 13,621 | 15,475 | 16,054 | 16,857 | 24,298 | 28,229 | 27,910 | 28,125 |
| Operating Profit | 1,737 | 2,004 | 2,243 | 2,725 | 2,994 | 3,204 | 3,765 | 4,157 | 4,856 | 4,804 | 6,260 | 7,585 | 7,157 |
| OPM % | 17% | 16% | 16% | 19% | 20% | 19% | 20% | 21% | 22% | 17% | 18% | 21% | 20% |
| Other Income + | 114 | 124 | 142 | 213 | 338 | 336 | 274 | 355 | 332 | 296 | 431 | 821 | 786 |
| Interest | 42 | 48 | 42 | 49 | 37 | 41 | 110 | 102 | 92 | 95 | 144 | 205 | 215 |
| Depreciation | 155 | 246 | 266 | 276 | 335 | 360 | 622 | 780 | 791 | 816 | 858 | 853 | 882 |
| Profit before tax | 1,655 | 1,834 | 2,077 | 2,614 | 2,960 | 3,138 | 3,306 | 3,629 | 4,304 | 4,188 | 5,689 | 7,348 | 6,846 |
| Tax % | 30% | 31% | 31% | 32% | 32% | 33% | 33% | 24% | 26% | 26% | 26% | 24% |  |
| Net Profit + | 1,160 | 1,263 | 1,427 | 1,803 | 2,016 | 2,098 | 2,208 | 2,774 | 3,207 | 3,085 | 4,195 | 5,558 | 5,170 |
| EPS in Rs | 11.61 | 12.71 | 14.54 | 18.19 | 20.22 | 21.26 | 22.48 | 28.20 | 32.73 | 31.59 | 42.81 | 56.92 | 52.96 |
| Dividend Payout % | 40% | 42% | 42% | 41% | 51% | 41% | 47% | 43% | 55% | 61% | 60% | 58% |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 1,187 | 1,402 | 1,188 | 2,243 | 1,527 | 2,113 | 2,470 | 3,038 | 3,683 | 986 | 4,193 | 6,104 |
| Cash from Investing Activity + | -463 | -586 | -465 | -866 | -681 | -1,556 | -918 | -518 | -541 | -317 | -1,282 | -2,548 |
| Cash from Financing Activity + | -601 | -626 | -576 | -849 | -756 | -1,379 | -1,117 | -2,871 | -650 | -1,808 | -2,140 | -2,982 |
| Net Cash Flow | 123 | 190 | 147 | 528 | 90 | -822 | 434 | -351 | 2,492 | -1,138 | 771 | 573 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 34 | 33 | 32 | 30 | 35 | 38 | 36 | 32 | 44 | 49 | 49 | 50 |
| Inventory Days | 122 | 121 | 123 | 108 | 138 | 117 | 119 | 127 | 134 | 142 | 121 | 122 |
| Days Payable | 96 | 102 | 84 | 84 | 101 | 95 | 90 | 80 | 119 | 96 | 71 | 79 |
| Cash Conversion Cycle | 60 | 52 | 70 | 54 | 72 | 60 | 65 | 79 | 59 | 94 | 99 | 93 |
| Working Capital Days | 13 | 11 | 20 | 21 | 35 | 32 | 30 | 43 | 46 | 69 | 66 | 62 |
| ROCE % | 47% | 45% | 42% | 42% | 38% | 36% | 33% | 33% | 34% | 29% | 34% | 38% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 52.79% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% | 52.63% |
| FIIs + | 20.96% | 20.48% | 19.45% | 18.51% | 18.56% | 18.11% | 17.02% | 17.48% | 17.65% | 17.32% | 15.89% | 15.27% |
| DIIs + | 6.84% | 7.15% | 7.57% | 8.42% | 8.74% | 9.16% | 9.96% | 10.01% | 10.01% | 10.52% | 11.61% | 12.30% |
| Government + | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.05% | 0.05% | 0.05% | 0.06% | 0.06% | 0.06% |
| Public + | 19.35% | 19.68% | 20.29% | 20.37% | 19.99% | 20.02% | 20.32% | 19.82% | 19.64% | 19.44% | 19.78% | 19.68% |
| Others + | 0.02% | 0.02% | 0.02% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.04% | 0.06% |
| No. of Shareholders | 5,77,153 | 7,12,261 | 9,46,876 | 10,11,447 | 9,11,680 | 9,79,331 | 10,82,650 | 9,97,455 | 9,85,216 | 9,75,319 | 11,05,326 | 11,11,601 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 52.79% | 52.79% | 52.79% | 52.79% | 52.79% | 52.63% | 52.63% | 52.63% | 52.63% |
| FIIs + | 18.07% | 15.08% | 16.33% | 17.21% | 20.38% | 19.45% | 17.02% | 15.89% | 15.27% |
| DIIs + | 7.60% | 11.76% | 9.51% | 9.81% | 7.27% | 7.57% | 9.96% | 11.61% | 12.30% |
| Government + | 0.11% | 0.09% | 0.05% | 0.14% | 0.08% | 0.04% | 0.05% | 0.06% | 0.06% |
| Public + | 21.43% | 20.27% | 21.32% | 20.04% | 19.48% | 20.29% | 20.32% | 19.78% | 19.68% |
| Others + | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.02% | 0.04% | 0.04% | 0.06% |
| No. of Shareholders | 2,02,914 | 1,85,307 | 2,11,792 | 3,00,307 | 4,99,185 | 9,46,876 | 10,82,650 | 11,05,326 | 11,11,601 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/asian-paints-ltd/asianpaint/500820/corp-announcements/)
- [Minutes Of The 78Th Annual General Meeting Of The Company
2m - Minutes of the 78th Annual General Meeting of the Company held on Tuesday, 25th June 2024 through video conference.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1ae7ec65-2a4e-4c98-9153-24cbfc8c7d7d.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b0a30efb-336e-4d66-8dcc-1072f2086e8d.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
22 Jul - Transcript of the Investor Conference held on Wednesday, 17th July 2024, with regard to the business and financial performance of the Company for the quarter …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b275848-7e65-4cf0-acbc-33cc7acb975c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8aed4d0c-d3fa-46b2-ba02-a508887506d9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa64a601-c78f-4fca-ad0f-e3487d2f2c20.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=218b2e64-6a82-4ecf-8d19-f92bd77518c7.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\e874970f-8a7b-41de-88f2-40928e65f3e7.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/73104500820.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/68521500820.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ASIANPAINT_2011_2012_12062012100812.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500820/5008200311.pdf)

## Credit Ratings
- [Rating update
29 Dec 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_December%2029,%202023_RR_333603.html)
- [Rating update
15 Mar 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_March%2015,%202023_RR_314716.html)
- [Rating update
12 Jan 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_January%2012,%202023_RR_308786.html)
- [Rating update
17 Feb 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_February%2017,%202022_RR_288245.html)
- [Rating update
12 Jan 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_January%2012,%202022_RR_282669.html)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AsianPaintsLimited_April%2027,%202021_RR_269705.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b275848-7e65-4cf0-acbc-33cc7acb975c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa64a601-c78f-4fca-ad0f-e3487d2f2c20.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac9fe29f-3099-4479-b4f2-fdf0fa79e540.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=63a2696f-f94d-4133-a636-a33645aaa4f3.pdf)
- [REC](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2023-2024/Q4/Asian%20Paints_Q4FY24_Investor_Meet_Audio.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c705fd48-5088-4c70-afcc-6682ec00599c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a5eaa80-a911-4359-bcb0-751cc13df837.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1065d24c-707c-4f1a-b20b-b3fc7a34c21c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=87247a2b-5033-467c-a324-39a5e9078c96.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fe292159-09dd-40b9-bffa-99741a5afe41.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bbae2dec-20ce-4c3c-bc4b-b0f3ed44eefd.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0aed4336-c50d-41f6-9b03-b0a9a8782f52.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1b118116-bed8-4b48-949a-c971c4193498.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6c84bd13-b939-4a77-be76-b3e928f26fd8.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/2022-2023/InvestorconferencepresentationQ3FY2023.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1f4a1b3b-0856-4953-b0f5-d4f2d34a893d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=156f8864-8ba9-4478-ad02-53bbb64d5f75.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4dfd9d49-2613-4f74-b98f-ea894035b797.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=38584fe3-d8fb-437a-934b-3d817f9d6d32.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3efac0b-aa64-499a-8995-169c380ff169.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3afe6ef-9fd6-483a-8a3e-3e6688186001.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9831cb5d-0b3f-46cb-af1e-2a67e454b670.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8f9c8791-eb61-48c1-962e-3a40aa25291d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a8d58ecd-a454-41b4-817c-c47031eb51a4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5f9dad5-bea9-458d-bfdf-2a87f5e1923a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e44ccf37-a913-4a69-bdb2-6adc0ee6ce26.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf03acdc-e12b-4034-84cc-761add1d66fa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7d68aa83-491b-4115-873c-f13d94ae4474.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f6909a8-5fff-44e6-80c3-434071aeddad.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=18b3d1ed-eede-4646-9ae4-e92369037d59.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bc8c670-ab6e-47a9-b3cf-bbb04de5f611.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9087e9e2-2c0c-4aa7-be5a-0be45259b3ee.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Conference%20call%20transcript%20-%20Q3FY21%20results.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0d8ef75-f7f7-4246-98ff-7f2a8bf042fd.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Q2-FY21%20results%20Investor%20call%20transcript%20(1).pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c50ac146-5f10-420f-9500-8a3653e07f3b.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2020-2021/Q1FY21%20results%20-%20Earnings%20call%20transcript.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Q2FY20%20Investor%20call%20transcript.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Motilal%20Oswal%20conference%20presentation.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Citi%20conference%20presentation.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94090c14-b57f-45bd-8c24-b9dc9b8c6eb8.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Investor%20call%20transcript%20-%20Q3FY19%20results..pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Q3FY18%20results%20-%20Investor%20conference%20call.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a72e312f-754d-4f71-ae33-da718f992bcb.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/financial-results-2/2017-2018/Asian%20Paints%20Q2%20FY%202018%20Result.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/UBS%20conference%20presentation%20-%20Nov%202017.pdf)
- [](https://www.asianpaints.com/content/dam/asianpaints/website/secondary-navigation/investors/analyst-presentations-2/Investor%20conference%20call%20Q2-FY18%20results.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1695b666-469d-40b5-874c-543f846661e9.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Asian Paints | 2945.10 | 282493.29 | 55.61 | 14.99 | 8.01 | 123.51 | 35.74 | 13.71 | 1.15 | 37.50 | 19.96 | 31.44 | 1.27 | 0.13 | 32.87 | 1.49 | 35282.15 | 20.29 | 5079.84 | 8969.73 | 1169.98 | -2.32 | -24.54 | 52.96 | 2474.38 | 52.62 | 0.00 | 2.52 | 49.77 | 7.15 | 0.62 | 9.06 | 283883.66 | 1.69 | 2.71 | 2.01 | -1.62 | -1.42 | -13.89 | 27.81 | 27.67 | 20.52 | 20.42 | 13.03 | 17.80 | 27.74 | 34.37 | 0.99 | 56.92 | 20.52 | 76.86 | 77.62 | 66.19 | 93.24 | 95.92 |
| 2. | Berger Paints | 541.65 | 63145.37 | 54.29 | 11.75 | 5.64 | 139.38 | 32.39 | 14.18 | 0.65 | 27.51 | 14.26 | 23.54 | 1.37 | 0.14 | 20.80 | 1.52 | 11198.92 | 16.62 | 1162.19 | 2520.28 | 222.10 | 3.14 | 19.61 | 10.02 | 753.29 | 74.99 | 0.00 | 2.62 | 49.77 | 0.00 | 5.97 | 35.02 | 63448.01 | 1.79 | 2.84 | 5.41 | -4.40 | -8.97 | -5.59 | 22.23 | 22.89 | 19.10 | 17.59 | 13.06 | 17.99 | 20.44 | 23.75 | 0.87 | 10.02 | 19.09 | 75.69 | 67.99 | 67.06 | 73.25 | 116.57 |
| 3. | Kansai Nerolac | 274.75 | 22210.21 | 34.38 | 3.91 | 2.85 | 87.67 | 20.61 | 0.41 | 0.91 | 16.56 | 9.43 | 12.79 | 1.14 | 0.05 | 30.40 | 1.23 | 7801.44 | 13.17 | 646.70 | 1769.39 | 114.29 | 2.07 | 21.88 | 14.66 | 276.42 | 74.99 | 0.00 | 3.99 | 49.77 | 0.00 | 3.43 | 39.72 | 22226.68 | 2.25 | 4.12 | -1.75 | -17.36 | -12.49 | -15.51 | 10.70 | 11.76 | 8.35 | 7.79 | 7.54 | 15.42 | 10.68 | 14.26 | 1.14 | 14.66 | 8.35 | 55.84 | 54.96 | 55.11 | 110.20 | 80.84 |
| 4. | Akzo Nobel | 2869.55 | 13068.00 | 30.61 | 9.81 | 3.30 | 48.54 | 18.84 | 10.17 | 2.63 | 42.29 | 15.15 | 32.33 | 1.40 | 0.05 | 46.94 | 2.12 | 3961.60 | 15.98 | 427.51 | 973.40 | 108.80 | 2.31 | 14.05 | 93.70 | 60.40 | 74.76 | 0.00 | 4.77 | 49.77 | 0.00 | 4.20 | 27.27 | 12605.20 | 1.35 | 1.78 | 14.74 | 7.99 | 7.35 | 2.16 | 27.12 | 23.69 | 17.15 | 26.84 | 6.30 | 17.83 | 26.10 | 34.71 | 0.92 | 93.70 | 17.15 | 33.87 | 31.19 | 35.58 | -10.42 | 4.55 |
| 5. | Indigo Paints | 1493.65 | 7112.95 | 48.00 | 7.74 | 5.67 | -248.65 | 28.91 |  | 0.23 | 23.18 | 12.98 | 17.52 | 1.10 | 0.02 | 125.37 | 1.25 | 1254.86 | 18.54 | 148.19 | 366.14 | 53.52 | 12.50 | 9.94 | 31.22 | 16.84 | 53.94 | 0.00 | 2.84 | 49.77 | 0.00 | 16.91 | 12.93 | 7097.12 | 1.59 | 1.19 | 11.52 | 1.91 | -16.97 | -3.71 | 16.79 | 17.92 | 40.36 | 27.87 | 18.56 | 20.16 | 18.40 | 21.55 | 0.98 | 31.22 | 26.97 | 74.29 | 54.15 | 74.29 | 29.08 | 4.76 |
| 6. | Shalimar Paints | 144.20 | 1207.12 |  | 3.07 | 2.26 | -22.39 | -27.29 | 14.61 | 0.00 | -12.28 | -11.42 | -19.81 | 0.83 | 0.27 | -4.70 | 1.64 | 534.91 | -10.13 | -73.85 | 144.26 | -26.42 | 6.58 | -174.64 | -8.82 | 105.88 | 75.73 | 0.00 | -4.93 | 49.77 | 66.16 | 10.17 | -104.34 | 1256.82 | 1.41 |  | -16.07 | -30.09 | 9.35 | -8.64 | -16.11 | -16.65 | -2.49 | -19.36 | 13.21 | 18.00 | -10.28 | -4.00 | 0.94 | -8.82 | 5.11 |  |  | 163.48 | 57.78 | 7.22 |
| 7. | MCON Rasayan | 185.65 | 117.01 | 52.24 | 7.48 | 2.78 | -18.52 | 23.12 |  | 0.00 | 21.29 | 7.39 | 16.75 | 1.39 | 1.02 | 3.06 | 2.27 | 42.13 | 12.58 | 2.24 | 24.88 | 0.23 |  |  | 3.55 | 15.95 | 66.65 | 0.00 | 3.67 | 49.77 | 0.00 | 35.90 | 98.23 | 132.26 | 1.22 | 0.58 | 28.29 | 26.32 |  | 26.32 | 16.58 | 16.12 | 90.20 | 127.60 | 43.27 | 67.47 | 14.33 | 14.54 | 0.76 | 3.55 | 14.57 | 61.61 | 61.61 | 61.61 | 81.18 | 0.63 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| ASIANPAINT | Market Cap | ₹ 2,82,714 Cr. |
| ASIANPAINT | Current Price | ₹ 2,947 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | Sales | ₹ 35,282 Cr. |
| ASIANPAINT | OPM | 20.3 % |
| ASIANPAINT | Profit after tax | ₹ 5,080 Cr. |
| ASIANPAINT | Mar Cap | ₹ 2,82,714 Cr. |
| ASIANPAINT | Sales Qtr | ₹ 8,970 Cr. |
| ASIANPAINT | PAT Qtr | ₹ 1,170 Cr. |
| ASIANPAINT | Qtr Sales Var | -2.32 % |
| ASIANPAINT | Qtr Profit Var | -24.5 % |
| ASIANPAINT | Price to Earning | 55.6 |
| ASIANPAINT | Dividend yield | 1.15 % |
| ASIANPAINT | Price to book value | 15.0 |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | Return on assets | 20.0 % |
| ASIANPAINT | Debt to equity | 0.13 |
| ASIANPAINT | Return on equity | 31.4 % |
| ASIANPAINT | EPS | ₹ 53.0 |
| ASIANPAINT | Debt | ₹ 2,474 Cr. |
| ASIANPAINT | Promoter holding | 52.6 % |
| ASIANPAINT | Change in Prom Hold | 0.00 % |
| ASIANPAINT | Earnings yield | 2.52 % |
| ASIANPAINT | Pledged percentage | 7.15 % |
| ASIANPAINT | Industry PE | 49.8 |
| ASIANPAINT | Sales growth | 0.62 % |
| ASIANPAINT | Profit growth | 9.06 % |
| ASIANPAINT | Current Price | ₹ 2,947 |
| ASIANPAINT | Price to Sales | 8.01 |
| ASIANPAINT | CMP / FCF | 124 |
| ASIANPAINT | EVEBITDA | 35.8 |
| ASIANPAINT | Enterprise Value | ₹ 2,84,104 Cr. |
| ASIANPAINT | Current ratio | 1.69 |
| ASIANPAINT | Int Coverage | 32.9 |
| ASIANPAINT | PEG Ratio | 2.71 |
| ASIANPAINT | Return over 3months | 2.01 % |
| ASIANPAINT | Return over 6months | -1.62 % |
| ASIANPAINT | No. Eq. Shares | 95.9 |
| ASIANPAINT | Sales growth 3Years | 17.8 % |
| ASIANPAINT | Sales growth 5Years | 13.0 % |
| ASIANPAINT | Profit Var 3Yrs | 20.4 % |
| ASIANPAINT | Profit Var 5Yrs | 20.5 % |
| ASIANPAINT | ROE 5Yr | 27.7 % |
| ASIANPAINT | ROE 3Yr | 27.8 % |
| ASIANPAINT | Return over 1year | -13.9 % |
| ASIANPAINT | Return over 3years | -1.42 % |
| ASIANPAINT | Return over 5years | 13.7 % |
| ASIANPAINT | Market Cap | ₹ 2,82,714 Cr. |
| ASIANPAINT | Current Price | ₹ 2,947 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | Sales last year | ₹ 35,495 Cr. |
| ASIANPAINT | OP Ann | ₹ 7,585 Cr. |
| ASIANPAINT | Other Inc Ann | ₹ 821 Cr. |
| ASIANPAINT | EBIDT last year | ₹ 8,404 Cr. |
| ASIANPAINT | Dep Ann | ₹ 853 Cr. |
| ASIANPAINT | EBIT last year | ₹ 7,551 Cr. |
| ASIANPAINT | Interest last year | ₹ 205 Cr. |
| ASIANPAINT | PBT Ann | ₹ 7,348 Cr. |
| ASIANPAINT | Tax last year | ₹ 1,790 Cr. |
| ASIANPAINT | PAT Ann | ₹ 5,459 Cr. |
| ASIANPAINT | Extra Ord Item Ann | ₹ 2.08 Cr. |
| ASIANPAINT | NP Ann | ₹ 5,558 Cr. |
| ASIANPAINT | Dividend last year | ₹ 3,194 Cr. |
| ASIANPAINT | Raw Material | 50.1 % |
| ASIANPAINT | Employee cost | ₹ 2,335 Cr. |
| ASIANPAINT | OPM last year | 21.4 % |
| ASIANPAINT | NPM last year | 15.6 % |
| ASIANPAINT | Operating profit | ₹ 7,157 Cr. |
| ASIANPAINT | Interest | ₹ 215 Cr. |
| ASIANPAINT | Depreciation | ₹ 882 Cr. |
| ASIANPAINT | EPS last year | ₹ 56.9 |
| ASIANPAINT | EBIT | ₹ 7,061 Cr. |
| ASIANPAINT | Net profit | ₹ 5,170 Cr. |
| ASIANPAINT | Current Tax | ₹ 1,671 Cr. |
| ASIANPAINT | Tax | ₹ 1,677 Cr. |
| ASIANPAINT | Other income | ₹ 786 Cr. |
| ASIANPAINT | Ann Date | 2,02,403 |
| ASIANPAINT | Sales Prev Ann | ₹ 34,489 Cr. |
| ASIANPAINT | OP Prev Ann | ₹ 6,260 Cr. |
| ASIANPAINT | Other Inc Prev Ann | ₹ 431 Cr. |
| ASIANPAINT | EBIDT Prev Ann | ₹ 6,728 Cr. |
| ASIANPAINT | Dep Prev Ann | ₹ 858 Cr. |
| ASIANPAINT | EBIT preceding year | ₹ 5,870 Cr. |
| ASIANPAINT | Interest Prev Ann | ₹ 144 Cr. |
| ASIANPAINT | PBT Prev Ann | ₹ 5,689 Cr. |
| ASIANPAINT | Tax preceding year | ₹ 1,494 Cr. |
| ASIANPAINT | PAT Prev Ann | ₹ 4,133 Cr. |
| ASIANPAINT | Extra Ord Prev Ann | ₹ -37.2 Cr. |
| ASIANPAINT | NP Prev Ann | ₹ 4,195 Cr. |
| ASIANPAINT | Dividend Prev Ann | ₹ 2,460 Cr. |
| ASIANPAINT | OPM preceding year | 18.2 % |
| ASIANPAINT | NPM preceding year | 12.2 % |
| ASIANPAINT | EPS preceding year | ₹ 42.8 |
| ASIANPAINT | Sales Prev 12M | ₹ 35,495 Cr. |
| ASIANPAINT | Profit Prev 12M | ₹ 5,558 Cr. |
| ASIANPAINT | Med Sales Gwth 10Yrs | 7.43 % |
| ASIANPAINT | Med Sales Gwth 5Yrs | 7.43 % |
| ASIANPAINT | Sales growth 7Years | 13.0 % |
| ASIANPAINT | Sales Var 10Yrs | 11.2 % |
| ASIANPAINT | EBIDT growth 3Years | 17.6 % |
| ASIANPAINT | EBIDT growth 5Years | 15.9 % |
| ASIANPAINT | EBIDT growth 7Years | 14.1 % |
| ASIANPAINT | EBIDT Var 10Yrs | 14.8 % |
| ASIANPAINT | EPS growth 3Years | 20.4 % |
| ASIANPAINT | EPS growth 5Years | 20.5 % |
| ASIANPAINT | EPS growth 7Years | 15.9 % |
| ASIANPAINT | EPS growth 10Years | 16.2 % |
| ASIANPAINT | Profit Var 7Yrs | 15.9 % |
| ASIANPAINT | Profit Var 10Yrs | 16.2 % |
| ASIANPAINT | Chg in Prom Hold 3Yr | -0.17 % |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | OP Qtr | ₹ 1,694 Cr. |
| ASIANPAINT | Other Inc Qtr | ₹ 193 Cr. |
| ASIANPAINT | EBIDT Qtr | ₹ 1,887 Cr. |
| ASIANPAINT | Dep Qtr | ₹ 228 Cr. |
| ASIANPAINT | EBIT latest quarter | ₹ 1,659 Cr. |
| ASIANPAINT | Interest Qtr | ₹ 55.4 Cr. |
| ASIANPAINT | PBT Qtr | ₹ 1,604 Cr. |
| ASIANPAINT | Tax latest quarter | ₹ 417 Cr. |
| ASIANPAINT | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| ASIANPAINT | NP Qtr | ₹ 1,187 Cr. |
| ASIANPAINT | GPM latest quarter | 42.5 % |
| ASIANPAINT | OPM latest quarter | 18.9 % |
| ASIANPAINT | NPM latest quarter | 13.2 % |
| ASIANPAINT | Eq Cap Qtr | ₹ 95.9 Cr. |
| ASIANPAINT | EPS latest quarter | ₹ 12.2 |
| ASIANPAINT | OP 2Qtr Bk | ₹ 2,056 Cr. |
| ASIANPAINT | OP 3Qtr Bk | ₹ 1,716 Cr. |
| ASIANPAINT | Sales 2Qtr Bk | ₹ 9,103 Cr. |
| ASIANPAINT | Sales 3Qtr Bk | ₹ 8,479 Cr. |
| ASIANPAINT | NP 2Qtr Bk | ₹ 1,475 Cr. |
| ASIANPAINT | NP 3Qtr Bk | ₹ 1,232 Cr. |
| ASIANPAINT | Opert Prft Gwth | 4.87 % |
| ASIANPAINT | Last result date | 2,02,406 |
| ASIANPAINT | Exp Qtr Sales Var | 0.70 % |
| ASIANPAINT | Exp Qtr Sales | ₹ 8,538 Cr. |
| ASIANPAINT | Exp Qtr OP | ₹ 1,730 Cr. |
| ASIANPAINT | Exp Qtr NP | ₹ 1,457 Cr. |
| ASIANPAINT | Exp Qtr EPS | ₹ 15.0 |
| ASIANPAINT | Sales Prev Qtr | ₹ 8,731 Cr. |
| ASIANPAINT | OP Prev Qtr | ₹ 1,691 Cr. |
| ASIANPAINT | Other Inc Prev Qtr | ₹ 212 Cr. |
| ASIANPAINT | EBIDT Prev Qtr | ₹ 1,904 Cr. |
| ASIANPAINT | Dep Prev Qtr | ₹ 226 Cr. |
| ASIANPAINT | EBIT Prev Qtr | ₹ 1,678 Cr. |
| ASIANPAINT | Interest Prev Qtr | ₹ 54.1 Cr. |
| ASIANPAINT | PBT Prev Qtr | ₹ 1,624 Cr. |
| ASIANPAINT | Tax Prev Qtr | ₹ 349 Cr. |
| ASIANPAINT | PAT Prev Qtr | ₹ 1,257 Cr. |
| ASIANPAINT | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| ASIANPAINT | NP Prev Qtr | ₹ 1,275 Cr. |
| ASIANPAINT | OPM Prev Qtr | 19.4 % |
| ASIANPAINT | NPM Prev Qtr | 14.6 % |
| ASIANPAINT | Eq Cap Prev Qtr | ₹ 95.9 Cr. |
| ASIANPAINT | EPS Prev Qtr | ₹ 13.1 |
| ASIANPAINT | Sales PY Qtr | ₹ 9,182 Cr. |
| ASIANPAINT | OP PY Qtr | ₹ 2,121 Cr. |
| ASIANPAINT | Other Inc PY Qtr | ₹ 228 Cr. |
| ASIANPAINT | EBIDT PY Qtr | ₹ 2,349 Cr. |
| ASIANPAINT | Dep PY Qtr | ₹ 198 Cr. |
| ASIANPAINT | EBIT PY Qtr | ₹ 2,151 Cr. |
| ASIANPAINT | Interest PY Qtr | ₹ 45.8 Cr. |
| ASIANPAINT | PBT PY Qtr | ₹ 2,105 Cr. |
| ASIANPAINT | Tax PY Qtr | ₹ 530 Cr. |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | Equity capital | ₹ 95.9 Cr. |
| ASIANPAINT | Preference capital | ₹ 0.00 Cr. |
| ASIANPAINT | Reserves | ₹ 18,632 Cr. |
| ASIANPAINT | Secured loan | ₹ 195 Cr. |
| ASIANPAINT | Unsecured loan | ₹ 2,279 Cr. |
| ASIANPAINT | Balance sheet total | ₹ 29,901 Cr. |
| ASIANPAINT | Gross block | ₹ 11,622 Cr. |
| ASIANPAINT | Revaluation reserve | ₹ 0.00 Cr. |
| ASIANPAINT | Accum Dep | ₹ 4,381 Cr. |
| ASIANPAINT | Net block | ₹ 7,147 Cr. |
| ASIANPAINT | CWIP | ₹ 2,698 Cr. |
| ASIANPAINT | Investments | ₹ 4,588 Cr. |
| ASIANPAINT | Current assets | ₹ 14,334 Cr. |
| ASIANPAINT | Current liabilities | ₹ 8,501 Cr. |
| ASIANPAINT | BV Unq Invest | ₹ 0.00 Cr. |
| ASIANPAINT | MV Quoted Inv | ₹ 4,000 Cr. |
| ASIANPAINT | Cont Liab | ₹ 898 Cr. |
| ASIANPAINT | Total Assets | ₹ 29,901 Cr. |
| ASIANPAINT | Working capital | ₹ 7,157 Cr. |
| ASIANPAINT | Lease liabilities | ₹ 1,367 Cr. |
| ASIANPAINT | Inventory | ₹ 5,923 Cr. |
| ASIANPAINT | Trade receivables | ₹ 4,889 Cr. |
| ASIANPAINT | Face value | ₹ 1.00 |
| ASIANPAINT | Cash Equivalents | ₹ 1,084 Cr. |
| ASIANPAINT | Adv Cust | ₹ 154 Cr. |
| ASIANPAINT | Trade Payables | ₹ 3,831 Cr. |
| ASIANPAINT | No. Eq. Shares PY | 95.9 |
| ASIANPAINT | Debt preceding year | ₹ 1,933 Cr. |
| ASIANPAINT | Work Cap PY | ₹ 7,070 Cr. |
| ASIANPAINT | Net Block PY | ₹ 5,770 Cr. |
| ASIANPAINT | Gross Block PY | ₹ 9,676 Cr. |
| ASIANPAINT | CWIP PY | ₹ 1,020 Cr. |
| ASIANPAINT | Work Cap 3Yr | ₹ 3,351 Cr. |
| ASIANPAINT | Work Cap 5Yr | ₹ 2,020 Cr. |
| ASIANPAINT | Work Cap 7Yr | ₹ 2,234 Cr. |
| ASIANPAINT | Work Cap 10Yr | ₹ 603 Cr. |
| ASIANPAINT | Debt 3Years back | ₹ 1,093 Cr. |
| ASIANPAINT | Debt 5Years back | ₹ 1,320 Cr. |
| ASIANPAINT | Debt 7Years back | ₹ 560 Cr. |
| ASIANPAINT | Debt 10Years back | ₹ 249 Cr. |
| ASIANPAINT | Net Block 3Yrs Back | ₹ 5,859 Cr. |
| ASIANPAINT | Net Block 5Yrs Back | ₹ 6,497 Cr. |
| ASIANPAINT | Net Block 7Yrs Back | ₹ 3,304 Cr. |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | CF Operations | ₹ 6,104 Cr. |
| ASIANPAINT | Free Cash Flow | ₹ 3,613 Cr. |
| ASIANPAINT | CF Investing | ₹ -2,548 Cr. |
| ASIANPAINT | CF Financing | ₹ -2,982 Cr. |
| ASIANPAINT | Net CF | ₹ 573 Cr. |
| ASIANPAINT | Cash Beginning | ₹ 3,054 Cr. |
| ASIANPAINT | Cash End | ₹ 1,084 Cr. |
| ASIANPAINT | FCF Prev Ann | ₹ 2,774 Cr. |
| ASIANPAINT | CF Operations PY | ₹ 4,193 Cr. |
| ASIANPAINT | CF Investing PY | ₹ -1,282 Cr. |
| ASIANPAINT | CF Financing PY | ₹ -2,140 Cr. |
| ASIANPAINT | Net CF PY | ₹ 771 Cr. |
| ASIANPAINT | Cash Beginning PY | ₹ 2,283 Cr. |
| ASIANPAINT | Cash End PY | ₹ 844 Cr. |
| ASIANPAINT | Free Cash Flow 3Yrs | ₹ 6,862 Cr. |
| ASIANPAINT | Free Cash Flow 5Yrs | ₹ 12,962 Cr. |
| ASIANPAINT | Free Cash Flow 7Yrs | ₹ 15,003 Cr. |
| ASIANPAINT | Free Cash Flow 10Yrs | ₹ 18,054 Cr. |
| ASIANPAINT | CF Opr 3Yrs | ₹ 11,284 Cr. |
| ASIANPAINT | CF Opr 5Yrs | ₹ 18,005 Cr. |
| ASIANPAINT | CF Opr 7Yrs | ₹ 22,588 Cr. |
| ASIANPAINT | CF Opr 10Yrs | ₹ 27,546 Cr. |
| ASIANPAINT | CF Inv 10Yrs | ₹ -9,692 Cr. |
| ASIANPAINT | CF Inv 7Yrs | ₹ -7,680 Cr. |
| ASIANPAINT | CF Inv 5Yrs | ₹ -5,206 Cr. |
| ASIANPAINT | CF Inv 3Yrs | ₹ -4,148 Cr. |
| ASIANPAINT | Cash 3Years back | ₹ 611 Cr. |
| ASIANPAINT | Cash 5Years back | ₹ 445 Cr. |
| ASIANPAINT | Cash 7Years back | ₹ 801 Cr. |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | No. Eq. Shares | 95.9 |
| ASIANPAINT | Book value | ₹ 195 |
| ASIANPAINT | Inven TO | 2.95 |
| ASIANPAINT | Quick ratio | 0.99 |
| ASIANPAINT | Exports percentage | 0.00 % |
| ASIANPAINT | Piotroski score | 6.00 |
| ASIANPAINT | G Factor | 3.00 |
| ASIANPAINT | Asset Turnover | 1.27 |
| ASIANPAINT | Financial leverage | 1.49 |
| ASIANPAINT | No. of Share Holders | 11,11,601 |
| ASIANPAINT | Unpledged Prom Hold | 48.9 % |
| ASIANPAINT | ROIC | 39.9 % |
| ASIANPAINT | Debtor days | 50.3 |
| ASIANPAINT | Industry PBV | 7.41 |
| ASIANPAINT | Credit rating |  |
| ASIANPAINT | WC Days | 62.4 |
| ASIANPAINT | Earning Power | 23.6 % |
| ASIANPAINT | Graham Number | ₹ 482 |
| ASIANPAINT | Cash Cycle | 93.2 |
| ASIANPAINT | Days Payable | 78.7 |
| ASIANPAINT | Days Receivable | 50.3 |
| ASIANPAINT | Inventory Days | 122 |
| ASIANPAINT | Public holding | 19.7 % |
| ASIANPAINT | FII holding | 15.3 % |
| ASIANPAINT | Chg in FII Hold | -0.62 % |
| ASIANPAINT | DII holding | 12.3 % |
| ASIANPAINT | Chg in DII Hold | 0.69 % |
| ASIANPAINT | B.V. Prev Ann | ₹ 167 |
| ASIANPAINT | ROCE Prev Yr | 34.4 % |
| ASIANPAINT | ROA Prev Yr | 17.3 % |
| ASIANPAINT | ROE Prev Ann | 27.7 % |
| ASIANPAINT | No. of Share Holders Prev Qtr | 11,05,326 |
| ASIANPAINT | No. Eq. Shares 10 Yrs | 95.9 |
| ASIANPAINT | BV 3yrs back | ₹ 134 |
| ASIANPAINT | BV 5yrs back | ₹ 106 |
| ASIANPAINT | BV 10yrs back | ₹ 49.4 |
| ASIANPAINT | Inven TO 3Yr | 2.90 |
| ASIANPAINT | Inven TO 5Yr | 3.01 |
| ASIANPAINT | Inven TO 7Yr | 3.17 |
| ASIANPAINT | Inven TO 10Yr | 3.17 |
| ASIANPAINT | Export 3Yr | 0.00 % |
| ASIANPAINT | Export 5Yr | 0.00 % |
| ASIANPAINT | Div 5Yrs | ₹ 2,071 Cr. |
| ASIANPAINT | ROCE 3Yr | 33.6 % |
| ASIANPAINT | ROCE 5Yr | 33.4 % |
| ASIANPAINT | ROCE 7Yr | 33.7 % |
| ASIANPAINT | ROCE 10Yr | 35.8 % |
| ASIANPAINT | ROE 10Yr | 27.5 % |
| ASIANPAINT | ROE 7Yr | 27.1 % |
| ASIANPAINT | ROE 5Yr Var | 5.54 % |
| ASIANPAINT | OPM 5Year | 19.6 % |
| ASIANPAINT | OPM 10Year | 19.4 % |
| ASIANPAINT | No. of Share Holders 1Yr | 9,97,455 |
| ASIANPAINT | Avg Div Payout 3Yrs | 59.7 % |
| ASIANPAINT | Debtor days 3yrs | 49.3 |
| ASIANPAINT | Debtor days 3yrs back | 43.7 |
| ASIANPAINT | Debtor days 5yrs back | 36.2 |
| ASIANPAINT | ROA 5Yr | 17.3 % |
| ASIANPAINT | ROA 3Yr | 17.3 % |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | Avg Vol 1Mth | 17,60,829 |
| ASIANPAINT | Avg Vol 1Wk | 15,96,787 |
| ASIANPAINT | Volume | 12,54,410 |
| ASIANPAINT | High price | ₹ 3,423 |
| ASIANPAINT | Low price | ₹ 2,670 |
| ASIANPAINT | High price all time | ₹ 3,590 |
| ASIANPAINT | Low price all time | ₹ 36.2 |
| ASIANPAINT | Return over 1day | 1.52 % |
| ASIANPAINT | Return over 1week | -1.52 % |
| ASIANPAINT | Return over 1month | 1.33 % |
| ASIANPAINT | DMA 50 | ₹ 2,915 |
| ASIANPAINT | DMA 200 | ₹ 2,980 |
| ASIANPAINT | DMA 50 previous day | ₹ 2,916 |
| ASIANPAINT | 200 DMA prev. | ₹ 2,981 |
| ASIANPAINT | RSI | 46.0 |
| ASIANPAINT | MACD | 4.07 |
| ASIANPAINT | MACD Previous Day | 7.32 |
| ASIANPAINT | MACD Signal | 12.1 |
| ASIANPAINT | MACD Signal Prev | 14.2 |
| ASIANPAINT | Avg Vol 1Yr | 11,83,666 |
| ASIANPAINT | Return over 7years | 14.1 % |
| ASIANPAINT | Return over 10years | 16.4 % |
| ASIANPAINT | Market Cap | ₹ 2,82,536 Cr. |
| ASIANPAINT | Current Price | ₹ 2,946 |
| ASIANPAINT | High / Low | ₹ 3,423 / 2,670 |
| ASIANPAINT | Stock P/E | 55.6 |
| ASIANPAINT | Book Value | ₹ 195 |
| ASIANPAINT | Dividend Yield | 1.15 % |
| ASIANPAINT | ROCE | 37.5 % |
| ASIANPAINT | ROE | 31.4 % |
| ASIANPAINT | Face Value | ₹ 1.00 |
| ASIANPAINT | WC to Sales | 20.3 % |
| ASIANPAINT | QoQ Profits | -6.94 % |
| ASIANPAINT | QoQ Sales | 2.74 % |
| ASIANPAINT | Net worth | ₹ 18,728 Cr. |
| ASIANPAINT | Market Cap to Sales | 8.01 |
| ASIANPAINT | Interest Coverage | 32.9 |
| ASIANPAINT | EV / EBIT | 40.2 |
| ASIANPAINT | Debt Capacity | 0.05 |
| ASIANPAINT | Debt To Profit | 0.45 |
| ASIANPAINT | Capital Employed | ₹ 17,002 Cr. |
| ASIANPAINT | CROIC | 11.4 % |
| ASIANPAINT | debtplus | 0.18 |
| ASIANPAINT | Leverage | ₹ 1.49 |
| ASIANPAINT | Dividend Payout | 58.5 % |
| ASIANPAINT | Intrinsic Value | ₹ 694 |
| ASIANPAINT | CDL | -0.81 % |
| ASIANPAINT | Cash by market cap | 0.00 |
| ASIANPAINT | 52w Index | 36.6 % |
| ASIANPAINT | Down from 52w high | 14.0 % |
| ASIANPAINT | Up from 52w low | 10.3 % |
| ASIANPAINT | From 52w high | 0.86 |
| ASIANPAINT | Mkt Cap To Debt Cap | 6.28 |
| ASIANPAINT | Dividend Payout | 58.5 % |
| ASIANPAINT | Graham | ₹ 482 |
| ASIANPAINT | Price to Cash Flow | 46.3 |
| ASIANPAINT | ROCE3yr avg | 33.6 % |
| ASIANPAINT | PB X PE | 834 |
| ASIANPAINT | NCAVPS | ₹ 74.6 |
| ASIANPAINT | Mar Cap to CF | 46.3 |
| ASIANPAINT | Altman Z Score | 18.2 |
| ASIANPAINT | M.Cap / Qtr Profit | 241 |