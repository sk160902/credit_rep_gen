from utils import bing_engine

# def get_promoters_data(ticker):
ticker = "VOLTAS"
print(bing_engine(f"'{ticker}' board of directors"))