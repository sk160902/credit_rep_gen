About
[
edit
]
Tata Motors Group is a leading global automobile manufacturer. Part of the illustrious multi-national conglomerate, the Tata group, it offers a wide and diverse portfolio of cars, sports utility vehicles, trucks, buses and defence vehicles to the world.
It has operations in India, the UK, South Korea, South Africa, China, Brazil, Austria and Slovakia through a strong global network of subsidiaries, associate companies and Joint Ventures (JVs), including Jaguar Land Rover in the UK and Tata Daewoo in South Korea.
[1]
Key Points
[
edit
]
Revenue Mix(FY24)
Jaguar Land Rover - 69.1%
Tata Commercial Vehicles - 18%
Tata Passenger Vehicles - 12%
Vehicles financing - 0.8%
Jaguar Land Rover Ltd.
Tata Motors Ltd (TML) bought British iconic brands Jaguar & Land Rover from Ford in 2008 and merged them together in 2013 to form one unified company.
[1]
. In H1FY24, order book remained strong with ~168k units, 77% of which are for RR, RRS & Defender.
[2]
New Range Rover & Range Rover Sport production continues to grow through new body shop in Solihull to be live in Q3FY24 and is expected to increase capacity by 30% over time.
[3]
Tata Commercial Vehicles
This includes Tata CV India, Tata Cummins and Tata CV International. The company has ~42% market share in FY23.
[4]
. In FY24, 223+ variants have been introduced.
[5]
Tata Passenger Vehicles
[6]
This includes  Tata PV, EV India,  FIAPL JO results and International business (PV + EV). VAHAN Domestic Market share in H1FY24 was 13.5%. The company has 287 dealers for EVs in 190+ cities in H1FY24 and ~75% market share in EV market. The charging infra also reached to ~77800 in H1FY24.
[7]
Capex
The company spent Rs. ~3781 crs. in H1FY24. Major expenditure was done on PV + EV segment. FY24 capex estimated at ~ Rs. 8,000 crs. as electrification investments step up.
[8]
Expansion
[9]
The company is expanding its manufacturing capacity after acquiring the facility from Ford in Sanand. The annual capacity of 300,000 units - scalable to 420,000 units. Industrialization of Sanand plant to begin in CY2024.
TPEM + JLR strategic collaboration
EMA platform to underpin the next generation of ‘pure electric’ mid-sized SUVs of JLR to be launched from 2025 onwards. JLR and TPEM have entered into an MOU for access to the EMA platform, including the E&E architecture, EDU, battery assembly and manufacturing
know-how for a royalty fee.
[10]
Robust Infrastructure.
The Group owns 10 manufacturing facilities in India, 5 in UK, 2 in Europe, and has also set up a manufacturing facility in China in a Joint Venture with Chery Automobiles. It also operates various R&D centres from UK, North America, Europe and India.
[11]
Acquisition in Freight Tiger
TaMo acquired ~27% stake in Freight Tiger in H1FY24 for Rs. 150 crs. Fleet Edge + Freight Tiger to provide an end-to-end solution by integrating the truck and trip eco-systems. In next 2-3 years, TaMo plans to invest an additional Rs. 100 Cr and buy out other investors by FY29 .
[12]
IPO of Tata Technologies
[13]
In Nov,23, Tata Technologies (a subsidiary of Tata Motors) issued its IPO at offer price of Rs. 500/-. IPO aggregated to ~Rs. 30,000 mn, comprising of an offer for sale of 46,275,000 Equity Shares by the Company amounting to Rs. 23,137.50 mn, 9,716,853 Equity Shares by Alpha TC Holdings Pte. Ltd. amounting to Rs. 4,858.43 mn and 4,858,425 Equity Shares by Tata Capital Growth Fund I amounting to Rs. 2,429.21 mn. Consequently, Company’s shareholding in Tata Technologies Limited reduced
from 64.79% to 53.39%.
[14]
Last edited 1 month ago
Request an update
© Protected by Copyright
