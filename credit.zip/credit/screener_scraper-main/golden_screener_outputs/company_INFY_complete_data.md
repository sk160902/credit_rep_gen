# Complete Company Data

## Modal Content
About
[
edit
]
Infosys Ltd provides consulting, technology, outsourcing and next-generation digital services to enable clients to execute strategies for their digital transformation.
[1]
It is the 2nd largest Information Technology company in India behind TCS.
[2]
Key Points
[
edit
]
Digital Services (~57% of revenues)
[1]
It comprises of services and solution offerings of the group that enables clients to transform their businesses. It includes offerings that enhance customer experience, leverage AI-based analytics and big data, engineer digital products and IoT, modernize legacy tech systems, migrate to cloud applications and implement advanced cyber-security systems.
[2]
Core Services (~43% of revenues)
It comprises of traditional offerings of the group that include application management services, proprietary application development services, independent validation solutions, product engineering and management, infrastructure management services, traditional enterprise application implementation and support and integration services.
[2]
Products and Platforms
The company also offers various services through its key products and platforms viz. Infosys Finacle, Infosys McCamish, Panaya, Infosys Meridian, Helix, Equinox, Wingspan, Edgeverve, Stater and others.
[3]
Revenue Breakup
Vertical-wise :-
Financial services- 32%
Retail - ~15%
Communication, telecom & Media - ~13%
Energy, Utility, etc. - ~12%
Manufacturing - 11%
Hi-tech - 8%
Life Sciences & Healthcare - 7%
Others - 3%
[1]
Geography-wise :-
North America - 62%
Europe - 25%
ROW - 10%
India - 3%
[1]
Clientele Overview
As present, the company caters to ~185 of Fortune 500 companies.
[4]
It has 38 of 100+ million USD clients, 64 50+ million USD clients, 275 10+ million USD clients, ~850 1+ million USD clients.
[3]
Its clients include companies/ organizations like ICICI Bank, Daimler Mercedes-Benz, HSBC Bank, Goldman Sachs, J&J, Accenture, US Army, US Navy, Lockheed Martin, IBM Corporation, Deutsche Bank and others.
[5]
Employee Base
As per FY22, the company has an employee base of ~3,15,000 employees.
[3]
In FY22, over 1,40,000 employees joined the company out of which 80,000 were directly recruited from colleges.
[6]
Attrition Rate -
In FY22, the company witnessed a heavy employee attrition rate of ~28% compared to ~11% in FY21 and ~17% in FY20.
[7]
Leading Subsidiaries
The group's businesses are also handled through some of its leading subsidiaries :-
1. Infosys BPM Ltd (~5.5% of revenues)
[8]
- It is the business process management (BPM) subsidiary of the Infosys Group engaged in providing end-to-end transformative Digital BPM services for global clients across various industries and service lines.
[9]
2. EdgeVerve Systems Ltd (~2.5% of revenues)
- It is a global leader in AI, Automation and Analytics which helps businesses with their business processes, documents and supply chain.
[10]
Futures
1. Consulting-led End-to-End Solutions: Infosys aims to focus on opportunities arising from consulting-led end-to-end solutions. This approach allows them to provide comprehensive services to clients across various domains.
2. Leveraging Technology for Higher Margins: The company plans to leverage technology to enhance its margins. By adopting innovative solutions and efficient processes, Infosys aims to optimize its operations and financial performance.
3. Intellectual Property-Based Solutions: Infosys intends to develop intellectual property-based solutions. These solutions can help delink revenues from effort, creating sustainable growth and value for the company.
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 40,352 | 50,133 | 53,319 | 62,441 | 68,484 | 70,522 | 82,675 | 90,791 | 100,472 | 121,641 | 146,767 | 153,670 | 155,053 |
| Expenses + | 28,814 | 36,743 | 38,436 | 45,362 | 49,880 | 51,700 | 62,505 | 68,524 | 72,583 | 90,150 | 111,637 | 117,245 | 118,255 |
| Operating Profit | 11,538 | 13,390 | 14,883 | 17,079 | 18,604 | 18,822 | 20,170 | 22,267 | 27,889 | 31,491 | 35,130 | 36,425 | 36,798 |
| OPM % | 29% | 27% | 28% | 27% | 27% | 27% | 24% | 25% | 28% | 26% | 24% | 24% | 24% |
| Other Income + | 2,365 | 2,664 | 3,430 | 3,120 | 3,050 | 3,311 | 2,882 | 2,803 | 2,201 | 2,295 | 2,701 | 4,711 | 4,988 |
| Interest | 5 | 9 | 12 | 0 | 0 | 0 | 0 | 170 | 195 | 200 | 284 | 470 | 484 |
| Depreciation | 1,099 | 1,317 | 1,017 | 1,459 | 1,703 | 1,863 | 2,011 | 2,893 | 3,267 | 3,476 | 4,225 | 4,678 | 4,654 |
| Profit before tax | 12,799 | 14,728 | 17,284 | 18,740 | 19,951 | 20,270 | 21,041 | 22,007 | 26,628 | 30,110 | 33,322 | 35,988 | 36,648 |
| Tax % | 26% | 28% | 28% | 28% | 28% | 21% | 27% | 24% | 27% | 26% | 28% | 27% |  |
| Net Profit + | 9,429 | 10,656 | 12,372 | 13,489 | 14,353 | 16,029 | 15,410 | 16,639 | 19,423 | 22,146 | 24,108 | 26,248 | 26,677 |
| EPS in Rs | 20.52 | 23.31 | 26.93 | 29.36 | 31.24 | 36.69 | 35.26 | 38.96 | 45.42 | 52.56 | 58.08 | 63.20 | 64.22 |
| Dividend Payout % | 25% | 34% | 55% | 41% | 41% | 59% | 60% | 45% | 59% | 59% | 58% | 73% |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 35% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 32% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Infosys Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 68,017 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 13,818 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 18 |  |  |  |  |  |  |  |
| Infosys BPO Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 3,995 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 552 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 4 |  |  |  |  |  |  |  |
| Infosys Shanghai Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 765 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 27 |  |  |  |  |  |  |  |
| Infosys Poland Sp Z.o.o Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 439 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 102 |  |  |  |  |  |  |  |
| Infosys Public Services Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 387 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 126 |  |  |  |  |  |  |  |
| Infosys McCamish Systems LLC Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 127 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 75 |  |  |  |  |  |  |  |
| Kallidus Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 133 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 60 |  |  |  |  |  |  |  |
| Infosys Mexico Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 128 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 41 |  |  |  |  |  |  |  |
| Controlled Trusts Associate |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 122 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 19 |  |  |  |  |  |  |  |
| Infosys Lodestone Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 217 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 81 |  |  |  |  |  |  |  |
| Portland Group Pty Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 106 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 6 |  |  |  |  |  |  |  |
| Infosys Brasil Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 103 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 2 |  |  |  |  |  |  |  |
| Infosys Nova Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 98 |  |  |  |  |  |  |  |
| Skava Systems Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 73 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 8 |  |  |  |  |  |  |  |
| Panaya Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 68 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 4 |  |  |  |  |  |  |  |
| Infosys (Czech Republic) Limited s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 58 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 12 |  |  |  |  |  |  |  |
| Infosys Consulting AG Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 64 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 5 |  |  |  |  |  |  |  |
| Infosys China Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 105 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 58 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Inc. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 28 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 11 |  |  |  |  |  |  |  |
| Inly Consulting B V Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 25 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 12 |  |  |  |  |  |  |  |
| Infosys Australia Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 36 |  |  |  |  |  |  |  |
| S.C. Infosys Consulting S R. L. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 6 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Infosys Consulting s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 4 |  |  |  |  |  |  |  |
| Infy Consulting Company Lid. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Infosys Americas Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Infosys BPO Americas Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 4 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Sweden Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 17 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 18 |  |  |  |  |  |  |  |
| PanayaJapan Co. Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Lodestone Management Consultants GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 2 |  |  |  |  |  |  |  |
| Panaya Gmbh Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting SAS Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Net Assets |  |  | 6 |  |  |  |  |  |  |  |
| Infosys Consulting p. Z.o.o Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 5 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Portugal. Unipessoal, Lda. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting S.R.L. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting Pte Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 2 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 11 |  |  |  |  |  |  |  |
| Noah Canada Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 2 |  |  |  |  |  |  |  |
| Net Assets |  |  | 14 |  |  |  |  |  |  |  |
| Infosys Management Consulting Pty Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 20 |  |  |  |  |  |  |  |
| Infosys Consulting (Belgium) NV Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 22 |  |  |  |  |  |  |  |
| DWA Nova LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 26 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 30 |  |  |  |  |  |  |  |
| Infosys Consulting Ltda. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 20 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 60 |  |  |  |  |  |  |  |
| Infosys Consulting GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 30 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 65 |  |  |  |  |  |  |  |
| Noah Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 23 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 90 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Co., Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 56 |  |  |  |  |  |  |  |
| Net Assets |  |  | 58 |  |  |  |  |  |  |  |
| Panaya Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 161 |  |  |  |  |  |  |  |
| Net Assets |  |  | 283 |  |  |  |  |  |  |  |
| Edge Verve Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 245 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 1,715 |  |  |  |  |  |  |  |
| Adjustment arising out of consolidation |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 78 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 257 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3,869 |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 40,352 | 50,133 | 53,319 | 62,441 | 68,484 | 70,522 | 82,675 | 90,791 | 100,472 | 121,641 | 146,767 | 153,670 | 155,053 |
| Expenses + | 28,814 | 36,743 | 38,436 | 45,362 | 49,880 | 51,700 | 62,505 | 68,524 | 72,583 | 90,150 | 111,637 | 117,245 | 118,255 |
| Operating Profit | 11,538 | 13,390 | 14,883 | 17,079 | 18,604 | 18,822 | 20,170 | 22,267 | 27,889 | 31,491 | 35,130 | 36,425 | 36,798 |
| OPM % | 29% | 27% | 28% | 27% | 27% | 27% | 24% | 25% | 28% | 26% | 24% | 24% | 24% |
| Other Income + | 2,365 | 2,664 | 3,430 | 3,120 | 3,050 | 3,311 | 2,882 | 2,803 | 2,201 | 2,295 | 2,701 | 4,711 | 4,988 |
| Interest | 5 | 9 | 12 | 0 | 0 | 0 | 0 | 170 | 195 | 200 | 284 | 470 | 484 |
| Depreciation | 1,099 | 1,317 | 1,017 | 1,459 | 1,703 | 1,863 | 2,011 | 2,893 | 3,267 | 3,476 | 4,225 | 4,678 | 4,654 |
| Profit before tax | 12,799 | 14,728 | 17,284 | 18,740 | 19,951 | 20,270 | 21,041 | 22,007 | 26,628 | 30,110 | 33,322 | 35,988 | 36,648 |
| Tax % | 26% | 28% | 28% | 28% | 28% | 21% | 27% | 24% | 27% | 26% | 28% | 27% |  |
| Net Profit + | 9,429 | 10,656 | 12,372 | 13,489 | 14,353 | 16,029 | 15,410 | 16,639 | 19,423 | 22,146 | 24,108 | 26,248 | 26,677 |
| EPS in Rs | 20.52 | 23.31 | 26.93 | 29.36 | 31.24 | 36.69 | 35.26 | 38.96 | 45.42 | 52.56 | 58.08 | 63.20 | 64.22 |
| Dividend Payout % | 25% | 34% | 55% | 41% | 41% | 59% | 60% | 45% | 59% | 59% | 58% | 73% |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 35% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 32% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 7,373 | 9,825 | 8,353 | 10,028 | 11,531 | 13,218 | 14,841 | 17,003 | 23,224 | 23,885 | 22,467 | 25,210 |
| Cash from Investing Activity + | -2,922 | -2,563 | 999 | -885 | -14,664 | 4,533 | -632 | -331 | -7,373 | -6,485 | -1,071 | -5,093 |
| Cash from Financing Activity + | -3,210 | -3,144 | -4,935 | -6,813 | -6,939 | -20,505 | -14,512 | -17,591 | -9,786 | -24,642 | -26,695 | -17,504 |
| Net Cash Flow | 1,241 | 4,118 | 4,417 | 2,330 | -10,072 | -2,754 | -303 | -919 | 6,065 | -7,242 | -5,299 | 2,613 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 64 | 61 | 66 | 66 | 66 | 68 | 65 | 74 | 70 | 68 | 63 | 72 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 64 | 61 | 66 | 66 | 66 | 68 | 65 | 74 | 70 | 68 | 63 | 72 |
| Working Capital Days | 33 | 15 | 3 | 34 | 38 | 50 | 36 | 44 | 38 | 31 | 34 | 59 |
| ROCE % | 37% | 36% | 36% | 33% | 30% | 30% | 32% | 32% | 35% | 37% | 40% | 40% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 13.12% | 13.12% | 13.11% | 13.11% | 15.16% | 15.11% | 15.14% | 14.94% | 14.89% | 14.78% | 14.71% | 14.61% |
| FIIs + | 33.46% | 33.17% | 33.30% | 31.72% | 36.20% | 36.29% | 35.09% | 33.44% | 33.60% | 33.70% | 34.11% | 32.74% |
| DIIs + | 15.66% | 16.31% | 17.10% | 18.88% | 32.13% | 32.50% | 33.59% | 34.58% | 35.19% | 35.51% | 35.62% | 37.28% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.18% | 0.19% | 0.19% | 0.20% | 0.19% | 0.20% | 0.21% | 0.21% |
| Public + | 37.41% | 37.06% | 36.16% | 35.98% | 15.93% | 15.53% | 15.67% | 16.52% | 15.83% | 15.52% | 15.06% | 14.91% |
| Others + | 0.35% | 0.34% | 0.33% | 0.31% | 0.35% | 0.34% | 0.33% | 0.32% | 0.31% | 0.30% | 0.29% | 0.27% |
| No. of Shareholders | 18,17,779 | 18,97,185 | 21,28,827 | 26,64,564 | 28,93,209 | 27,36,975 | 28,01,574 | 31,44,613 | 30,09,448 | 28,97,030 | 27,73,406 | 28,20,740 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 12.75% | 12.90% | 12.84% | 13.15% | 12.95% | 13.11% | 15.14% | 14.71% | 14.61% |
| FIIs + | 38.31% | 35.24% | 34.04% | 31.01% | 32.67% | 33.30% | 35.09% | 34.11% | 32.74% |
| DIIs + | 20.31% | 21.55% | 22.87% | 24.68% | 23.10% | 17.10% | 33.59% | 35.62% | 37.28% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.19% | 0.21% | 0.21% |
| Public + | 28.14% | 29.82% | 29.78% | 30.73% | 30.92% | 36.16% | 15.67% | 15.06% | 14.91% |
| Others + | 0.49% | 0.49% | 0.47% | 0.43% | 0.36% | 0.33% | 0.33% | 0.29% | 0.27% |
| No. of Shareholders | 7,11,129 | 7,53,025 | 9,19,720 | 11,34,263 | 14,09,782 | 21,28,827 | 28,01,574 | 27,73,406 | 28,20,740 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/infosys-ltd/infy/500209/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Acquisition 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ea219bb0-e2ee-4ed9-ab6d-6ab7a26b6c9e.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25353afa-0919-47a5-bd94-d149fef7d700.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=98e837de-fd40-4151-b61d-acf3aa6dd057.pdf)
- [Auditors Report With UDIN For The Quarter Ended June 30, 2024 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d4997946-6db9-415b-9305-3df118cfa658.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4bc2fca6-c0ba-447c-bb1a-5a7260667b32.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25cc7fbc-154b-4463-928d-c95f2d8c5c9c.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\3ba3c011-0411-49ba-a250-f746a5b9d940.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500209/73015500209_29_06_22.pdf)
- [Financial Year 2021
from web](https://www.infosys.com/investors/reports-filings/annual-report/annual/documents/infosys-ar-21.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500209/68476500209_09_06_21.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090311.pdf)

## Credit Ratings
- [Rating update
28 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_June%2028_%202024_RR_346454.html)
- [Rating update
4 Jul 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_July%2004,%202023_RR_322119.html)
- [Rating update
20 Jul 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_July%2020,%202022_RR_288283.html)
- [Rating update
23 Nov 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_November%2023,%202021_RR_278951.html)
- [Rating update
5 Jan 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_January%2005,%202021_RR.html)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/Infosys_Limited_January_21_2020_RR.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25353afa-0919-47a5-bd94-d149fef7d700.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=77f16d60-73b2-4877-80fb-c641f2529a70.pdf)
- [REC](https://www.infosys.com/investors/reports-filings/quarterly-results/2023-2024/q4/earningscall.html)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c3e2ca9-f0a0-4aa3-a03f-01864f720f74.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5bbf010d-5cd7-4d88-a75f-28e72e22c6ab.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=318c3091-9847-46ea-b9ae-1a54441e99e6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e7de8466-119e-4bdc-b3c4-bd706d87f104.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c94d45c5-a44a-49d9-89af-6ef6532c4a30.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01712d63-9662-4355-8b54-0534f66678d8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48580c91-e22d-4d3c-aa9f-56c255914c14.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=55d91053-dd92-4ca3-bd1d-4e419043f37a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c07b78e8-687e-47ef-a212-41f9057b81ea.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28eec8d6-de9e-4e4d-92d8-beff066c9b25.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=32e14b77-f2f7-486b-b01f-1b64ab965d41.pdf)
- [](https://www.infosys.com/investors/reports-filings/quarterly-results/2021-2022/q1/documents/transcripts/press-conference.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b4351d41-294f-4958-918d-8aadbe7d85fa.pdf)
- [](https://www.infosys.com/investors/reports-filings/quarterly-results/2020-2021/q3/documents/transcripts/earningscall.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6d098032-b341-4fb0-afdd-ef1f4c7a2993.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d206ef44-722a-428e-b305-0ff3ae64627f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1186b66a-e330-4893-85d3-e0d1cf3651d7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51df047f-a5f4-433e-9590-85f7e4eb3e1e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=099b31b8-af67-4383-abaf-57f0586a9fc9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f4f9e6fe-28aa-4c0e-a8c9-391529bb8470.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f22533cc-2858-4970-87e5-d73ee33be876.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d248deb8-646e-421e-98a9-19786e4b5e7c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f39ce20f-2791-447f-8b82-6bf8cb2d824a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=47dce35f-9841-4e10-a7b7-873a36b66c96.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d55691d6-ecda-4bef-8154-e9f900d04ff6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fac181a4-d43d-43f5-9938-10ea02cf513b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b397865-58d5-471b-b18b-7334bc82b8f8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=34fecc7f-e976-4e26-99e7-724f6661edd7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06638C47_0BFD_4015_976A_B02AAF0995E0_153112.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B2AA21F4_3755_4750_82B7_15DDF1FDA788_174755.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | TCS | 4387.00 | 1587254.98 | 33.38 | 17.50 | 6.50 | 40.50 | 22.62 | 15.43 | 1.27 | 64.28 | 32.46 | 51.51 | 1.67 | 0.09 | 82.47 | 1.59 | 244125.00 | 27.02 | 47588.38 | 62613.00 | 12040.00 | 5.44 | 8.72 | 129.20 | 8021.00 | 71.77 | 0.00 | 4.17 | 33.64 | 0.28 | 5.19 | 8.79 | 1581989.98 | 1.77 | 4.07 | 13.11 | 13.44 | 10.74 | 27.25 | 47.40 | 43.77 | 8.21 | 11.84 | 10.46 | 13.63 | 46.92 | 58.67 | 1.77 | 126.88 | 9.00 | 30.33 | 30.75 | 28.69 | 81.18 | 365.91 |
| 2. | Infosys | 1873.55 | 777903.39 | 29.11 | 9.29 | 5.02 | 36.11 | 18.15 | 18.32 | 2.06 | 39.99 | 19.98 | 31.83 | 1.18 | 0.10 | 76.72 | 1.48 | 155053.00 | 23.73 | 26655.00 | 39315.00 | 6368.00 | 3.64 | 7.12 | 64.21 | 8361.00 | 14.61 | -0.10 | 5.03 | 33.64 | 0.00 | 3.21 | 8.00 | 758207.39 | 1.89 | 2.59 | 27.59 | 9.33 | 4.43 | 34.86 | 30.90 | 29.19 | 11.24 | 10.48 | 13.20 | 15.22 | 31.82 | 40.48 | 1.89 | 63.20 | 12.38 | 26.65 | 27.60 | 23.51 | 71.72 | 414.86 |
| 3. | HCL Technologies | 1631.15 | 442639.54 | 26.96 | 6.50 | 3.96 | 24.89 | 15.93 | 25.96 | 3.22 | 29.60 | 16.21 | 23.30 | 1.14 | 0.08 | 34.40 | 1.41 | 111674.00 | 22.05 | 16425.00 | 28057.00 | 4257.00 | 6.70 | 20.56 | 60.53 | 5758.00 | 60.81 | 0.00 | 5.44 | 33.64 | 0.00 | 7.08 | 8.81 | 428247.54 | 2.30 | 2.91 | 7.72 | 2.41 | 16.97 | 42.09 | 22.79 | 22.36 | 9.28 | 12.31 | 12.71 | 13.40 | 23.00 | 28.26 | 2.29 | 57.86 | 9.27 | 20.69 | 22.39 | 19.02 | 84.75 | 271.37 |
| 4. | Wipro | 525.20 | 274704.38 | 24.47 | 3.60 | 3.09 | 21.84 | 14.35 | 13.97 | 0.20 | 16.93 | 9.46 | 14.31 | 0.78 | 0.22 | 12.72 | 1.55 | 88893.10 | 19.01 | 11178.30 | 21963.80 | 3003.20 | -3.80 | 4.64 | 21.39 | 16464.90 | 72.82 | -0.07 | 5.97 | 33.64 | 0.00 | -3.16 | -4.02 | 281473.98 | 1.34 | 6.31 | 9.09 | 7.84 | -5.02 | 26.73 | 16.59 | 17.25 | 3.88 | 0.29 | 8.75 | 13.17 | 15.86 | 17.69 | 1.34 | 21.14 | 6.91 | 19.73 | 20.57 | 19.12 | 46.96 | 548.79 |
| 5. | LTIMindtree | 5794.45 | 171610.41 | 37.62 | 8.53 | 4.77 | 56.00 | 23.88 | 30.18 | 1.11 | 31.17 | 17.97 | 25.03 | 1.39 | 0.10 | 25.34 | 1.27 | 35957.50 | 17.68 | 4564.40 | 9142.60 | 1133.80 | 5.06 | -1.54 | 154.18 | 2070.60 | 68.60 | 0.00 | 3.81 | 33.64 | 0.00 | 5.01 | 2.47 | 170865.01 | 2.11 | 1.52 | 16.91 | 1.88 | 8.78 | 15.13 | 29.05 | 29.25 | 24.77 | 33.26 | 30.33 | 42.13 | 28.55 | 36.35 | 2.11 | 154.72 | 12.11 | 31.60 | 33.46 | 27.05 | 58.64 | 29.58 |
| 6. | Tech Mahindra | 1534.35 | 150048.21 | 59.64 | 5.60 | 2.89 | 30.64 | 26.36 | 18.91 | 2.58 | 11.88 | 5.38 | 8.63 | 1.17 | 0.10 | 10.97 | 1.67 | 51842.00 | 9.11 | 2516.80 | 13005.50 | 851.50 | -1.17 | 22.96 | 25.77 | 2536.70 | 35.05 | -0.04 | 2.56 | 33.64 | 0.00 | -3.53 | -42.55 | 147849.41 | 1.64 | -5.31 | 19.65 | 15.73 | 10.93 | 39.10 | 15.82 | 16.80 | -11.24 | -18.50 | 8.40 | 11.16 | 17.62 | 22.14 | 1.63 | 24.14 | -11.12 | 22.15 | 27.06 | 19.34 | 80.03 | 97.41 |
| 7. | Persistent Sys | 4765.00 | 73404.81 | 62.65 | 14.81 | 7.17 | 114.06 | 38.46 | 75.65 | 0.54 | 29.17 | 15.24 | 23.99 | 1.40 | 0.09 | 32.95 | 1.42 | 10237.59 | 17.16 | 1171.14 | 2737.17 | 306.42 | 17.92 | 33.94 | 76.06 | 451.13 | 31.02 | 0.00 | 2.20 | 33.64 | 0.00 | 16.42 | 21.98 | 72833.05 | 1.76 | 2.33 | 38.84 | 12.60 | 43.94 | 99.86 | 23.74 | 21.14 | 26.93 | 35.94 | 23.88 | 32.86 | 25.32 | 30.30 | 1.76 | 70.98 | 27.89 | 38.70 | 46.75 | 32.22 | 62.29 | 15.29 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| INFY | Market Cap | ₹ 7,77,488 Cr. |
| INFY | Current Price | ₹ 1,873 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | Sales | ₹ 1,55,053 Cr. |
| INFY | OPM | 23.7 % |
| INFY | Profit after tax | ₹ 26,655 Cr. |
| INFY | Mar Cap | ₹ 7,77,488 Cr. |
| INFY | Sales Qtr | ₹ 39,315 Cr. |
| INFY | PAT Qtr | ₹ 6,368 Cr. |
| INFY | Qtr Sales Var | 3.64 % |
| INFY | Qtr Profit Var | 7.12 % |
| INFY | Price to Earning | 29.1 |
| INFY | Dividend yield | 2.06 % |
| INFY | Price to book value | 9.29 |
| INFY | ROCE | 40.0 % |
| INFY | Return on assets | 20.0 % |
| INFY | Debt to equity | 0.10 |
| INFY | Return on equity | 31.8 % |
| INFY | EPS | ₹ 64.2 |
| INFY | Debt | ₹ 8,361 Cr. |
| INFY | Promoter holding | 14.6 % |
| INFY | Change in Prom Hold | -0.10 % |
| INFY | Earnings yield | 5.03 % |
| INFY | Pledged percentage | 0.00 % |
| INFY | Industry PE | 33.6 |
| INFY | Sales growth | 3.21 % |
| INFY | Profit growth | 8.00 % |
| INFY | Current Price | ₹ 1,873 |
| INFY | Price to Sales | 5.01 |
| INFY | CMP / FCF | 36.1 |
| INFY | EVEBITDA | 18.1 |
| INFY | Enterprise Value | ₹ 7,57,792 Cr. |
| INFY | Current ratio | 1.89 |
| INFY | Int Coverage | 76.7 |
| INFY | PEG Ratio | 2.59 |
| INFY | Return over 3months | 27.6 % |
| INFY | Return over 6months | 9.33 % |
| INFY | No. Eq. Shares | 415 |
| INFY | Sales growth 3Years | 15.2 % |
| INFY | Sales growth 5Years | 13.2 % |
| INFY | Profit Var 3Yrs | 10.5 % |
| INFY | Profit Var 5Yrs | 11.2 % |
| INFY | ROE 5Yr | 29.2 % |
| INFY | ROE 3Yr | 30.9 % |
| INFY | Return over 1year | 34.9 % |
| INFY | Return over 3years | 4.43 % |
| INFY | Return over 5years | 18.3 % |
| INFY | Market Cap | ₹ 7,77,488 Cr. |
| INFY | Current Price | ₹ 1,873 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | Sales last year | ₹ 1,53,670 Cr. |
| INFY | OP Ann | ₹ 36,425 Cr. |
| INFY | Other Inc Ann | ₹ 4,711 Cr. |
| INFY | EBIDT last year | ₹ 40,851 Cr. |
| INFY | Dep Ann | ₹ 4,678 Cr. |
| INFY | EBIT last year | ₹ 36,173 Cr. |
| INFY | Interest last year | ₹ 470 Cr. |
| INFY | PBT Ann | ₹ 35,988 Cr. |
| INFY | Tax last year | ₹ 9,740 Cr. |
| INFY | PAT Ann | ₹ 26,025 Cr. |
| INFY | Extra Ord Item Ann | ₹ 285 Cr. |
| INFY | NP Ann | ₹ 26,248 Cr. |
| INFY | Dividend last year | ₹ 19,053 Cr. |
| INFY | Raw Material | 0.00 % |
| INFY | Employee cost | ₹ 82,636 Cr. |
| INFY | OPM last year | 23.7 % |
| INFY | NPM last year | 17.0 % |
| INFY | Operating profit | ₹ 36,798 Cr. |
| INFY | Interest | ₹ 484 Cr. |
| INFY | Depreciation | ₹ 4,654 Cr. |
| INFY | EPS last year | ₹ 63.2 |
| INFY | EBIT | ₹ 37,132 Cr. |
| INFY | Net profit | ₹ 26,677 Cr. |
| INFY | Current Tax | ₹ 9,081 Cr. |
| INFY | Tax | ₹ 9,971 Cr. |
| INFY | Other income | ₹ 4,988 Cr. |
| INFY | Ann Date | 2,02,403 |
| INFY | Sales Prev Ann | ₹ 1,46,767 Cr. |
| INFY | OP Prev Ann | ₹ 35,130 Cr. |
| INFY | Other Inc Prev Ann | ₹ 2,701 Cr. |
| INFY | EBIDT Prev Ann | ₹ 37,683 Cr. |
| INFY | Dep Prev Ann | ₹ 4,225 Cr. |
| INFY | EBIT preceding year | ₹ 33,458 Cr. |
| INFY | Interest Prev Ann | ₹ 284 Cr. |
| INFY | PBT Prev Ann | ₹ 33,322 Cr. |
| INFY | Tax preceding year | ₹ 9,214 Cr. |
| INFY | PAT Prev Ann | ₹ 23,988 Cr. |
| INFY | Extra Ord Prev Ann | ₹ 148 Cr. |
| INFY | NP Prev Ann | ₹ 24,108 Cr. |
| INFY | Dividend Prev Ann | ₹ 14,069 Cr. |
| INFY | OPM preceding year | 23.9 % |
| INFY | NPM preceding year | 16.4 % |
| INFY | EPS preceding year | ₹ 58.1 |
| INFY | Sales Prev 12M | ₹ 1,53,671 Cr. |
| INFY | Profit Prev 12M | ₹ 26,248 Cr. |
| INFY | Med Sales Gwth 10Yrs | 9.82 % |
| INFY | Med Sales Gwth 5Yrs | 10.7 % |
| INFY | Sales growth 7Years | 12.2 % |
| INFY | Sales Var 10Yrs | 11.8 % |
| INFY | EBIDT growth 3Years | 10.8 % |
| INFY | EBIDT growth 5Years | 12.3 % |
| INFY | EBIDT growth 7Years | 9.66 % |
| INFY | EBIDT Var 10Yrs | 9.79 % |
| INFY | EPS growth 3Years | 11.4 % |
| INFY | EPS growth 5Years | 12.4 % |
| INFY | EPS growth 7Years | 10.6 % |
| INFY | EPS growth 10Years | 10.4 % |
| INFY | Profit Var 7Yrs | 9.06 % |
| INFY | Profit Var 10Yrs | 9.34 % |
| INFY | Chg in Prom Hold 3Yr | 1.66 % |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | OP Qtr | ₹ 9,437 Cr. |
| INFY | Other Inc Qtr | ₹ 838 Cr. |
| INFY | EBIDT Qtr | ₹ 10,275 Cr. |
| INFY | Dep Qtr | ₹ 1,149 Cr. |
| INFY | EBIT latest quarter | ₹ 9,126 Cr. |
| INFY | Interest Qtr | ₹ 105 Cr. |
| INFY | PBT Qtr | ₹ 9,021 Cr. |
| INFY | Tax latest quarter | ₹ 2,647 Cr. |
| INFY | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| INFY | NP Qtr | ₹ 6,374 Cr. |
| INFY | GPM latest quarter | 100 % |
| INFY | OPM latest quarter | 24.0 % |
| INFY | NPM latest quarter | 16.2 % |
| INFY | Eq Cap Qtr | ₹ 2,072 Cr. |
| INFY | EPS latest quarter | ₹ 15.3 |
| INFY | OP 2Qtr Bk | ₹ 9,137 Cr. |
| INFY | OP 3Qtr Bk | ₹ 9,440 Cr. |
| INFY | Sales 2Qtr Bk | ₹ 38,821 Cr. |
| INFY | Sales 3Qtr Bk | ₹ 38,994 Cr. |
| INFY | NP 2Qtr Bk | ₹ 6,113 Cr. |
| INFY | NP 3Qtr Bk | ₹ 6,215 Cr. |
| INFY | Opert Prft Gwth | 1.29 % |
| INFY | Last result date | 2,02,406 |
| INFY | Exp Qtr Sales Var | 3.26 % |
| INFY | Exp Qtr Sales | ₹ 40,264 Cr. |
| INFY | Exp Qtr OP | ₹ 9,618 Cr. |
| INFY | Exp Qtr NP | ₹ 8,282 Cr. |
| INFY | Exp Qtr EPS | ₹ 19.9 |
| INFY | Sales Prev Qtr | ₹ 37,923 Cr. |
| INFY | OP Prev Qtr | ₹ 8,784 Cr. |
| INFY | Other Inc Prev Qtr | ₹ 2,729 Cr. |
| INFY | EBIDT Prev Qtr | ₹ 11,513 Cr. |
| INFY | Dep Prev Qtr | ₹ 1,163 Cr. |
| INFY | EBIT Prev Qtr | ₹ 10,350 Cr. |
| INFY | Interest Prev Qtr | ₹ 110 Cr. |
| INFY | PBT Prev Qtr | ₹ 10,240 Cr. |
| INFY | Tax Prev Qtr | ₹ 2,265 Cr. |
| INFY | PAT Prev Qtr | ₹ 7,969 Cr. |
| INFY | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| INFY | NP Prev Qtr | ₹ 7,975 Cr. |
| INFY | OPM Prev Qtr | 23.2 % |
| INFY | NPM Prev Qtr | 21.0 % |
| INFY | Eq Cap Prev Qtr | ₹ 2,070 Cr. |
| INFY | EPS Prev Qtr | ₹ 19.2 |
| INFY | Sales PY Qtr | ₹ 37,933 Cr. |
| INFY | OP PY Qtr | ₹ 9,064 Cr. |
| INFY | Other Inc PY Qtr | ₹ 561 Cr. |
| INFY | EBIDT PY Qtr | ₹ 9,625 Cr. |
| INFY | Dep PY Qtr | ₹ 1,173 Cr. |
| INFY | EBIT PY Qtr | ₹ 8,452 Cr. |
| INFY | Interest PY Qtr | ₹ 90.0 Cr. |
| INFY | PBT PY Qtr | ₹ 8,362 Cr. |
| INFY | Tax PY Qtr | ₹ 2,417 Cr. |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | Equity capital | ₹ 2,072 Cr. |
| INFY | Preference capital | ₹ 0.00 Cr. |
| INFY | Reserves | ₹ 80,997 Cr. |
| INFY | Secured loan | ₹ 0.00 Cr. |
| INFY | Unsecured loan | ₹ 8,359 Cr. |
| INFY | Balance sheet total | ₹ 1,44,019 Cr. |
| INFY | Gross block | ₹ 49,195 Cr. |
| INFY | Revaluation reserve | ₹ 12,104 Cr. |
| INFY | Accum Dep | ₹ 21,573 Cr. |
| INFY | Net block | ₹ 27,275 Cr. |
| INFY | CWIP | ₹ 395 Cr. |
| INFY | Investments | ₹ 19,936 Cr. |
| INFY | Current assets | ₹ 96,055 Cr. |
| INFY | Current liabilities | ₹ 50,751 Cr. |
| INFY | BV Unq Invest | ₹ 8,071 Cr. |
| INFY | MV Quoted Inv | ₹ 0.00 Cr. |
| INFY | Cont Liab | ₹ 3,583 Cr. |
| INFY | Total Assets | ₹ 1,44,019 Cr. |
| INFY | Working capital | ₹ 47,491 Cr. |
| INFY | Lease liabilities | ₹ 8,361 Cr. |
| INFY | Inventory | ₹ 0.00 Cr. |
| INFY | Trade receivables | ₹ 30,930 Cr. |
| INFY | Face value | ₹ 5.00 |
| INFY | Cash Equivalents | ₹ 28,057 Cr. |
| INFY | Adv Cust | ₹ 0.00 Cr. |
| INFY | Trade Payables | ₹ 3,693 Cr. |
| INFY | No. Eq. Shares PY | 415 |
| INFY | Debt preceding year | ₹ 8,299 Cr. |
| INFY | Work Cap PY | ₹ 26,028 Cr. |
| INFY | Net Block PY | ₹ 29,225 Cr. |
| INFY | Gross Block PY | ₹ 48,877 Cr. |
| INFY | CWIP PY | ₹ 288 Cr. |
| INFY | Work Cap 3Yr | ₹ 35,264 Cr. |
| INFY | Work Cap 5Yr | ₹ 27,613 Cr. |
| INFY | Work Cap 7Yr | ₹ 29,722 Cr. |
| INFY | Work Cap 10Yr | ₹ 28,023 Cr. |
| INFY | Debt 3Years back | ₹ 5,325 Cr. |
| INFY | Debt 5Years back | ₹ 0.00 Cr. |
| INFY | Debt 7Years back | ₹ 0.00 Cr. |
| INFY | Debt 10Years back | ₹ 0.00 Cr. |
| INFY | Net Block 3Yrs Back | ₹ 25,505 Cr. |
| INFY | Net Block 5Yrs Back | ₹ 15,710 Cr. |
| INFY | Net Block 7Yrs Back | ₹ 14,179 Cr. |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | CF Operations | ₹ 25,210 Cr. |
| INFY | Free Cash Flow | ₹ 23,009 Cr. |
| INFY | CF Investing | ₹ -5,093 Cr. |
| INFY | CF Financing | ₹ -17,504 Cr. |
| INFY | Net CF | ₹ 2,613 Cr. |
| INFY | Cash Beginning | ₹ 12,173 Cr. |
| INFY | Cash End | ₹ 14,786 Cr. |
| INFY | FCF Prev Ann | ₹ 19,888 Cr. |
| INFY | CF Operations PY | ₹ 22,467 Cr. |
| INFY | CF Investing PY | ₹ -1,071 Cr. |
| INFY | CF Financing PY | ₹ -26,695 Cr. |
| INFY | Net CF PY | ₹ -5,299 Cr. |
| INFY | Cash Beginning PY | ₹ 17,472 Cr. |
| INFY | Cash End PY | ₹ 12,173 Cr. |
| INFY | Free Cash Flow 3Yrs | ₹ 64,621 Cr. |
| INFY | Free Cash Flow 5Yrs | ₹ 99,434 Cr. |
| INFY | Free Cash Flow 7Yrs | ₹ 1,23,050 Cr. |
| INFY | Free Cash Flow 10Yrs | ₹ 1,45,232 Cr. |
| INFY | CF Opr 3Yrs | ₹ 71,562 Cr. |
| INFY | CF Opr 5Yrs | ₹ 1,11,789 Cr. |
| INFY | CF Opr 7Yrs | ₹ 1,39,848 Cr. |
| INFY | CF Opr 10Yrs | ₹ 1,69,760 Cr. |
| INFY | CF Inv 10Yrs | ₹ -31,002 Cr. |
| INFY | CF Inv 7Yrs | ₹ -16,452 Cr. |
| INFY | CF Inv 5Yrs | ₹ -20,353 Cr. |
| INFY | CF Inv 3Yrs | ₹ -12,649 Cr. |
| INFY | Cash 3Years back | ₹ 24,714 Cr. |
| INFY | Cash 5Years back | ₹ 19,568 Cr. |
| INFY | Cash 7Years back | ₹ 22,625 Cr. |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | No. Eq. Shares | 415 |
| INFY | Book value | ₹ 200 |
| INFY | Inven TO |  |
| INFY | Quick ratio | 1.89 |
| INFY | Exports percentage | 0.00 % |
| INFY | Piotroski score | 6.00 |
| INFY | G Factor | 3.00 |
| INFY | Asset Turnover | 1.18 |
| INFY | Financial leverage | 1.48 |
| INFY | No. of Share Holders | 28,20,740 |
| INFY | Unpledged Prom Hold | 14.6 % |
| INFY | ROIC | 39.2 % |
| INFY | Debtor days | 71.7 |
| INFY | Industry PBV | 8.28 |
| INFY | Credit rating |  |
| INFY | WC Days | 59.1 |
| INFY | Earning Power | 25.8 % |
| INFY | Graham Number | ₹ 538 |
| INFY | Cash Cycle | 71.7 |
| INFY | Days Payable |  |
| INFY | Days Receivable | 71.7 |
| INFY | Inventory Days |  |
| INFY | Public holding | 14.9 % |
| INFY | FII holding | 32.7 % |
| INFY | Chg in FII Hold | -1.37 % |
| INFY | DII holding | 37.3 % |
| INFY | Chg in DII Hold | 1.66 % |
| INFY | B.V. Prev Ann | ₹ 182 |
| INFY | ROCE Prev Yr | 40.5 % |
| INFY | ROA Prev Yr | 19.9 % |
| INFY | ROE Prev Ann | 31.8 % |
| INFY | No. of Share Holders Prev Qtr | 27,73,406 |
| INFY | No. Eq. Shares 10 Yrs | 459 |
| INFY | BV 3yrs back | ₹ 179 |
| INFY | BV 5yrs back | ₹ 154 |
| INFY | BV 10yrs back | ₹ 110 |
| INFY | Inven TO 3Yr |  |
| INFY | Inven TO 5Yr |  |
| INFY | Inven TO 7Yr |  |
| INFY | Inven TO 10Yr |  |
| INFY | Export 3Yr | 0.00 % |
| INFY | Export 5Yr | 0.00 % |
| INFY | Div 5Yrs | ₹ 13,005 Cr. |
| INFY | ROCE 3Yr | 39.1 % |
| INFY | ROCE 5Yr | 37.0 % |
| INFY | ROCE 7Yr | 35.3 % |
| INFY | ROCE 10Yr | 34.7 % |
| INFY | ROE 10Yr | 26.7 % |
| INFY | ROE 7Yr | 27.7 % |
| INFY | ROE 5Yr Var | 6.23 % |
| INFY | OPM 5Year | 25.0 % |
| INFY | OPM 10Year | 25.5 % |
| INFY | No. of Share Holders 1Yr | 31,44,613 |
| INFY | Avg Div Payout 3Yrs | 63.3 % |
| INFY | Debtor days 3yrs | 67.7 |
| INFY | Debtor days 3yrs back | 70.1 |
| INFY | Debtor days 5yrs back | 65.5 |
| INFY | ROA 5Yr | 19.5 % |
| INFY | ROA 3Yr | 19.8 % |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | Avg Vol 1Mth | 1,00,06,753 |
| INFY | Avg Vol 1Wk | 70,51,158 |
| INFY | Volume | 59,09,175 |
| INFY | High price | ₹ 1,883 |
| INFY | Low price | ₹ 1,333 |
| INFY | High price all time | ₹ 1,954 |
| INFY | Low price all time | ₹ 117 |
| INFY | Return over 1day | 2.67 % |
| INFY | Return over 1week | 1.78 % |
| INFY | Return over 1month | 18.4 % |
| INFY | DMA 50 | ₹ 1,612 |
| INFY | DMA 200 | ₹ 1,533 |
| INFY | DMA 50 previous day | ₹ 1,603 |
| INFY | 200 DMA prev. | ₹ 1,530 |
| INFY | RSI | 83.6 |
| INFY | MACD | 78.2 |
| INFY | MACD Previous Day | 77.6 |
| INFY | MACD Signal | 66.6 |
| INFY | MACD Signal Prev | 63.7 |
| INFY | Avg Vol 1Yr | 71,40,494 |
| INFY | Return over 7years | 20.4 % |
| INFY | Return over 10years | 15.8 % |
| INFY | Market Cap | ₹ 7,77,903 Cr. |
| INFY | Current Price | ₹ 1,874 |
| INFY | High / Low | ₹ 1,883 / 1,333 |
| INFY | Stock P/E | 29.1 |
| INFY | Book Value | ₹ 200 |
| INFY | Dividend Yield | 2.06 % |
| INFY | ROCE | 40.0 % |
| INFY | ROE | 31.8 % |
| INFY | Face Value | ₹ 5.00 |
| INFY | WC to Sales | 30.6 % |
| INFY | QoQ Profits | -20.1 % |
| INFY | QoQ Sales | 3.67 % |
| INFY | Net worth | ₹ 83,069 Cr. |
| INFY | Market Cap to Sales | 5.02 |
| INFY | Interest Coverage | 76.7 |
| INFY | EV / EBIT | 20.4 |
| INFY | Debt Capacity | 0.12 |
| INFY | Debt To Profit | 0.32 |
| INFY | Capital Employed | ₹ 75,161 Cr. |
| INFY | CROIC | 23.8 % |
| INFY | debtplus | 0.14 |
| INFY | Leverage | ₹ 1.48 |
| INFY | Dividend Payout | 72.6 % |
| INFY | Intrinsic Value | ₹ 974 |
| INFY | CDL | 0.37 % |
| INFY | Cash by market cap | 0.02 |
| INFY | 52w Index | 98.3 % |
| INFY | Down from 52w high | 0.50 % |
| INFY | Up from 52w low | 40.5 % |
| INFY | From 52w high | 1.00 |
| INFY | Mkt Cap To Debt Cap | 2.78 |
| INFY | Dividend Payout | 72.6 % |
| INFY | Graham | ₹ 538 |
| INFY | Price to Cash Flow | 30.9 |
| INFY | ROCE3yr avg | 39.1 % |
| INFY | PB X PE | 270 |
| INFY | NCAVPS | ₹ 114 |
| INFY | Mar Cap to CF | 30.9 |
| INFY | Altman Z Score | 11.8 |
| INFY | M.Cap / Qtr Profit | 122 |