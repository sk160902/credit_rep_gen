# Complete Company Data

## Modal Content
About
[
edit
]
Angel One Ltd is a diversified financial services company and is primarily engaged in the business  of stock, commodity and currency broking, institutional broking, providing margin trading facility, depository services and distribution of mutual funds, lending as a NBFC and corporate agents of insurance companies.
[1]
Key Points
[
edit
]
Service Offerings
The company's financial products and service offerings include broking services, research services, investment advisory, margin trading facility, loan against shares, distribution of third party financial products and investor education.
[1]
KPIs Q4FY24
[2]
Total Client Base - 22.2 Mn
Gross Client Acquisition - 2.9 Mn
NSE Active Client Base - 6.1 Mn
Number of Orders - 471 Mn
Average Daily Turnover - Rs. 44.4 Trn
Client base <25 yrs. age - 48%
Client base >25 yrs. age - 52%
Market Share
[2]
Share in India’s Demat Accounts - ~15%
Share in NSE Active Client Base - ~15%
Revenue Breakup Q4FY24
[3]
Gross Broking - 68%
Interest on Deposits - 18%
Ancillary Transaction - 8%
Depository - 4%
Distribution - 1%
Others - 1%
Gross Broking Revenue Split Q4FY24
F&O - 85%
Cash - 11%
Commodity - 4%
3rd Party Products
The company has partnership with various 3rd party such as vested, smallcase, Sensibull, Streak, Quicko & Marketsmojo.
[4]
QIP
[5]
In April,24, the company raised Rs. 1500 crs. through QIP for  Rs. 2,555.01 per equity share, with a FV of Rs. 10/-. The company raised the funds for funding the margin obligations that are fulfilled on behalf of its clients and the margin trading facility provided to its clients; and future growth requirements.
Key Investors - Motilal Oswal MF, Whiteoak, Nippon MF,Goldman Sachs Asset Management etc.
[6]
Restructure
[7]
The company is planning to restructure the group by demerging Broking: Assisted Business into Angel Securities Ltd. and Broking: Direct Clients business into Angel Crest Ltd.
Focus
The company is expanding their assisted business through channels and products and foraying into wealth management.
[8]
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 450 | 451 | 440 | 770 | 778 | 748 | 1,289 | 2,292 | 3,002 | 4,272 | 4,870 |
| Expenses + | 339 | 362 | 437 | 516 | 575 | 570 | 828 | 1,366 | 1,708 | 2,579 | 3,028 |
| Operating Profit | 112 | 90 | 3 | 254 | 203 | 178 | 460 | 926 | 1,294 | 1,693 | 1,842 |
| OPM % | 25% | 20% | 1% | 33% | 26% | 24% | 36% | 40% | 43% | 40% | 38% |
| Other Income + | 11 | 11 | 112 | 14 | 11 | 7 | 10 | 5 | 18 | 7 | 9 |
| Interest | 38 | 36 | 54 | 95 | 70 | 50 | 42 | 76 | 91 | 137 | 173 |
| Depreciation | 10 | 13 | 14 | 15 | 20 | 21 | 18 | 19 | 30 | 50 | 64 |
| Profit before tax | 74 | 52 | 48 | 159 | 124 | 114 | 410 | 836 | 1,192 | 1,514 | 1,614 |
| Tax % | 37% | 39% | 35% | 32% | 36% | 28% | 28% | 25% | 25% | 26% |  |
| Net Profit + | 47 | 32 | 31 | 108 | 80 | 82 | 297 | 625 | 890 | 1,126 | 1,197 |
| EPS in Rs | 32.69 | 22.08 | 21.59 | 14.99 | 11.09 | 11.44 | 36.28 | 75.41 | 106.68 | 133.98 | 140.27 |
| Dividend Payout % | 13% | 25% | 31% | 91% | 24% | 24% | 35% | 36% | 37% | 26% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 49% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 56% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 70% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 34% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 42% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 43% |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2017 | Mar 2018 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Dinesh Thakkar Individual |  |  |  |  |  |  |  |
| Dividend paid | 2.28 | 4.56 |  | 8.47 | 41 | 60 | 81 |
| Remuneration Paid | 1.43 | 1.84 |  | 3.16 | 4.26 | 5.74 | 7.21 |
| Other Receivables |  |  |  | 0.75 | 0.75 | 0.75 | 0.75 |
| Repayment of Loan from Directors |  | 2.40 |  |  |  |  |  |
| Loan from Directors | 2.40 |  |  |  |  |  |  |
| Long-term loans and advances | 0.75 | 0.75 |  |  |  |  |  |
| Lease income from furnished property |  |  |  | 0.15 | 0.13 | 0.15 | 0.16 |
| Short term loans and advances |  | 0.50 |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  |  | 0.45 |
| Rent Received | 0.05 | 0.06 |  |  |  |  |  |
| Income from broking and allied activities |  |  |  |  |  |  | 0.09 |
| Personal training fees | 0.02 | 0.02 |  |  |  |  |  |
| Income from broking |  | 0.02 |  |  |  |  |  |
| Nirwan Monetary Services Private Limited |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 3.06 | 15 | 22 | 29 |
| Trade Payables to |  |  |  |  |  | 14 | 3.14 |
| DIVIDEND PAID |  |  | 1.64 |  |  |  |  |
| Income from broking and allied activities |  |  |  |  |  | 0.01 | 0.14 |
| Income from broking activities |  |  |  |  | 0.01 |  |  |
| Ashok Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.44 | 0.87 |  | 0.98 | 6.40 | 9.23 | 13 |
| Remuneration Paid | 0.36 | 0.36 |  | 0.43 |  |  |  |
| Income from broking | 0.01 | 0.02 |  |  |  |  |  |
| Nirwan Monetary Service Private Limited |  |  |  |  |  |  |  |
| Loans Given | 3.41 | 8.75 |  |  |  |  |  |
| Loan Repaid | 3.41 | 8.75 |  |  |  |  |  |
| Dividend paid | 0.82 | 1.65 |  |  |  |  |  |
| Purchase of property |  |  |  | 2.41 |  |  |  |
| Interest Received | 0.01 | 0.01 |  |  |  |  |  |
| Mr. Dinesh Thakkar Parent Co. |  |  |  |  |  |  |  |
| DIVIDEND PAID |  |  | 4.53 |  |  |  |  |
| REMUNERATION PAID |  |  | 2.52 |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.75 |  |  |  |  |
| LEASE INCOME FROM FURNISHED PROPERTY |  |  | 0.08 |  |  |  |  |
| INCOME FROM BROKING ACTIVITIES |  |  | 0.04 |  |  |  |  |
| Lalit Thakkar Individual |  |  |  |  |  |  |  |
| Dividend paid | 1.23 | 2.45 |  |  |  |  |  |
| Remuneration Paid | 0.80 | 0.94 |  |  |  |  |  |
| Loan from Directors | 0.85 | 0.85 |  |  |  |  |  |
| Vinay Agrawal Key Person |  |  |  |  |  |  |  |
| Remuneration Paid | 1.58 | 1.58 |  | 2.67 | 0.19 |  |  |
| Dividend paid | 0.01 | 0.01 |  | 0.11 | 0.15 |  |  |
| Dinesh Dariyanumal Thakkar HUF Relative |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  | 2.19 | 2.98 |
| Trade Payables to |  |  |  |  |  |  | 0.21 |
| Kanta Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  | 3.10 | 0.06 |
| Income from broking and allied activities |  |  |  |  |  | 0.03 | 0.06 |
| Dividend paid |  |  |  |  | 0.01 | 0.02 | 0.03 |
| Narayan Gangadhar Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  |  | 3.20 |  |  |
| Vineet Agrawal Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  | 1.24 | 1.43 |  |  |
| Dividend paid |  |  |  |  | 0.15 |  |  |
| Dinesh Thakkar HUF Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.08 | 0.17 |  | 0.31 | 1.52 |  |  |
| DIVIDEND PAID |  |  | 0.17 |  |  |  |  |
| Vinay Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  | 0.45 | 1.25 |
| Remuneration Paid |  |  |  |  |  | 0.16 | 0.19 |
| Income from broking and allied activities |  |  |  |  |  |  | 0.02 |
| Mr. Vinay Agrawal Key Person |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 1.91 |  |  |  |  |
| DIVIDEND PAID |  |  | 0.06 |  |  |  |  |
| Ketan Shah Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  |  | 1.50 |  |  |
| Dividend paid |  |  |  |  | 0.07 |  |  |
| Deepak Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.48 | 0.94 |  |  |  |  |  |
| Income from broking | 0.01 | 0.01 |  |  |  |  |  |
| Mr. Ashok Thakkar Relative |  |  |  |  |  |  |  |
| DIVIDEND PAID |  |  | 0.86 |  |  |  |  |
| REMUNERATION PAID |  |  | 0.38 |  |  |  |  |
| Vinay Agarwal Key Person |  |  |  |  |  |  |  |
| Short term loans and advances |  | 0.75 |  |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.03 |  |  |  |  |
| Tarachand Thakkar Relative |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  | 0.30 | 0.41 |
| Vijay Thakkar Key Person |  |  |  |  |  |  |  |
| Remuneration Paid | 0.25 | 0.27 |  | 0.12 |  |  |  |
| Income from cafeteria |  | 0.01 |  |  |  |  |  |
| Naheed Patel Key Person |  |  |  |  |  |  |  |
| Remuneration Paid |  |  |  | 0.22 | 0.27 |  |  |
| VijayThakkar Relative |  |  |  |  |  |  |  |
| Professional Fees |  |  |  |  |  | 0.05 | 0.08 |
| Professional fees paid |  |  |  | 0.12 |  |  |  |
| Remuneration Paid |  |  |  |  |  |  | 0.08 |
| Trade Payables to |  |  |  |  |  | 0.01 | 0.04 |
| Other Payables |  |  |  |  |  | 0.05 |  |
| Income from broking and allied activities |  |  |  |  |  |  | 0.02 |
| Mr. Vijay Thakkar Relative |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 0.32 |  |  |  |  |
| Sunita Magnani Relative |  |  |  |  |  |  |  |
| Dividend paid | 0.10 | 0.20 |  |  |  |  |  |
| Ms. Naheed Patel Key Person |  |  |  |  |  |  |  |
| REMUNERATION PAID |  |  | 0.21 |  |  |  |  |
| Kamalji Jagat Bhushan Sahay Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.12 |  |  |
| Directors' setting fees |  |  |  | 0.08 |  |  |  |
| Uday Sankar Roy Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.11 |  |  |
| Directors' setting fees |  |  |  | 0.08 |  |  |  |
| Anisha Motwani Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.06 |  |  |
| Directors' setting fees |  |  |  | 0.06 |  |  |  |
| Angel Insurance Brokers and Advisors Private Limited |  |  |  |  |  |  |  |
| Repayment of Loan Given |  |  |  |  |  | 0.03 |  |
| Other Payables |  |  |  |  | 0.02 |  |  |
| Other Receivables |  |  |  | 0.02 |  |  |  |
| Loan Given |  |  |  |  |  | 0.01 |  |
| LOAN GIVEN |  |  | 0.01 |  |  |  |  |
| REPAYMENT OF LOAN GIVEN |  |  | 0.01 |  |  |  |  |
| OTHER RECEIVABLES |  |  | 0.01 |  |  |  |  |
| Mr. Kamalji Jagat Bhushan Sahay Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.07 |  |  |  |  |
| Mr. Uday Sankar Roy Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.07 |  |  |  |  |
| Krishna Iyer Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.05 |  |  |
| Ms. Anisha Motwani Key Person |  |  |  |  |  |  |  |
| DIRECTORS SEETING FEES |  |  | 0.05 |  |  |  |  |
| Muralidharan Ramachandran Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.04 |  |  |
| Mala Todarwal Key Person |  |  |  |  |  |  |  |
| Directors' sitting fees |  |  |  |  | 0.03 |  |  |
| Shalini Agrawal Relative |  |  |  |  |  |  |  |
| Income from broking activities |  |  |  |  | 0.02 |  |  |
| Poonam Vijay Thakkar Relative |  |  |  |  |  |  |  |
| Trade Payables to |  |  |  |  |  |  | 0.01 |
| Anuradhal Thakkar Individual |  |  |  |  |  |  |  |
| Income from broking |  | 0.01 |  |  |  |  |  |
| Rahul Thakkar Relative |  |  |  |  |  |  |  |
| Income from broking |  | 0.01 |  |  |  |  |  |
| Hema Thakkar Individual |  |  |  |  |  |  |  |
| Personal training fees |  | 0.01 |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 450 | 451 | 440 | 770 | 778 | 748 | 1,289 | 2,292 | 3,002 | 4,272 | 4,870 |
| Expenses + | 339 | 362 | 437 | 516 | 575 | 570 | 828 | 1,366 | 1,708 | 2,579 | 3,028 |
| Operating Profit | 112 | 90 | 3 | 254 | 203 | 178 | 460 | 926 | 1,294 | 1,693 | 1,842 |
| OPM % | 25% | 20% | 1% | 33% | 26% | 24% | 36% | 40% | 43% | 40% | 38% |
| Other Income + | 11 | 11 | 112 | 14 | 11 | 7 | 10 | 5 | 18 | 7 | 9 |
| Interest | 38 | 36 | 54 | 95 | 70 | 50 | 42 | 76 | 91 | 137 | 173 |
| Depreciation | 10 | 13 | 14 | 15 | 20 | 21 | 18 | 19 | 30 | 50 | 64 |
| Profit before tax | 74 | 52 | 48 | 159 | 124 | 114 | 410 | 836 | 1,192 | 1,514 | 1,614 |
| Tax % | 37% | 39% | 35% | 32% | 36% | 28% | 28% | 25% | 25% | 26% |  |
| Net Profit + | 47 | 32 | 31 | 108 | 80 | 82 | 297 | 625 | 890 | 1,126 | 1,197 |
| EPS in Rs | 32.69 | 22.08 | 21.59 | 14.99 | 11.09 | 11.44 | 36.28 | 75.41 | 106.68 | 133.98 | 140.27 |
| Dividend Payout % | 13% | 25% | 31% | 91% | 24% | 24% | 35% | 36% | 37% | 26% |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 49% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 56% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 70% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 55% |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 34% |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | % |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 42% |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 45% |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 43% |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 11 | -77 | -210 | -309 | 689 | 643 | -1,199 | 558 | 804 | -330 |
| Cash from Investing Activity + | -7 | -13 | -50 | 47 | -6 | -28 | 25 | -52 | -185 | -91 |
| Cash from Financing Activity + | 2 | 40 | 350 | 239 | -361 | -449 | 894 | -165 | -908 | 1,331 |
| Net Cash Flow | 5 | -51 | 91 | -23 | 323 | 166 | -280 | 340 | -289 | 910 |

## Ratios Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 218 | 361 | 712 | 75 | 101 | 19 | 64 | 90 | 45 | 42 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 218 | 361 | 712 | 75 | 101 | 19 | 64 | 90 | 45 | 42 |
| Working Capital Days | 122 | 119 | 289 | 244 | 127 | -380 | -235 | -569 | -474 | -525 |
| ROCE % |  | 12% | 11% | 18% | 13% | 14% | 27% | 35% | 44% | 39% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 43.77% | 43.68% | 44.00% | 43.83% | 43.71% | 43.68% | 38.48% | 38.30% | 38.26% | 38.23% | 38.21% | 35.63% |
| FIIs + | 4.66% | 5.44% | 8.96% | 10.54% | 11.27% | 17.25% | 16.61% | 17.04% | 16.82% | 19.11% | 17.27% | 15.36% |
| DIIs + | 8.17% | 8.57% | 10.33% | 8.92% | 9.71% | 9.27% | 9.73% | 10.25% | 10.41% | 9.32% | 9.49% | 14.03% |
| Public + | 43.40% | 42.31% | 36.72% | 36.70% | 35.32% | 29.80% | 35.17% | 34.42% | 34.52% | 33.33% | 35.02% | 34.99% |
| No. of Shareholders | 84,764 | 1,11,755 | 1,01,028 | 1,28,787 | 1,21,000 | 1,25,067 | 1,42,320 | 1,29,211 | 1,31,876 | 1,55,194 | 2,00,355 | 2,70,528 |

## Yearly Data
| Unknown | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- |
| Promoters + | 44.55% | 44.00% | 38.48% | 38.21% | 35.63% |
| FIIs + | 5.01% | 8.96% | 16.61% | 17.27% | 15.36% |
| DIIs + | 11.97% | 10.33% | 9.73% | 9.49% | 14.03% |
| Public + | 38.47% | 36.72% | 35.17% | 35.02% | 34.99% |
| No. of Shareholders | 46,605 | 1,01,028 | 1,42,320 | 2,00,355 | 2,70,528 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/angel-one-ltd/angelone/543235/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS
20h - Allotment of 23,770 equity shares having face value of Rs. 10 each under Angel Broking Employee Long Term incentive Plan 2021.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b048b744-298b-4299-a000-f6b1eacabd7d.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd284372-86d3-4a07-9791-846445c47ce3.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
19 Jul - Newspaper Adverstisement of notice of 28th Annual General Meeting of the Company](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9942656e-e0fb-4def-acc0-2a2d96a2cdd9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c43e39b6-e9ee-4678-bca3-7cef9d9cb97d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b04f1756-3d4e-4b07-9917-54a6664500be.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b04f1756-3d4e-4b07-9917-54a6664500be.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\36cfd4ef-c9ff-4142-850d-cc014c9f4810.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/543235/72977543235_12_05_22.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/543235/68537543235_11_06_21.pdf)

## Credit Ratings
- [Rating update
29 Mar from care](https://www.careratings.com/upload/CompanyFiles/PR/202403120343_Angel_One_Limited.pdf)
- [Rating update
29 Feb from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_February%2029,%202024_RR_336376.html)
- [Rating update
25 Sep 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_September%2025,%202023_RR_328411.html)
- [Rating update
21 Aug 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_August%2021,%202023_RR_326282.html)
- [Rating update
18 Aug 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202308130809_Angel_One_Limited.pdf)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_July%2024,%202023_RR_324214.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd284372-86d3-4a07-9791-846445c47ce3.pdf)
- [PPT](https://w3assets.angelone.in/wp-content/uploads/pdfs/15072024_Investorpresentation.pdf?_gl=1*1ue6c4p*_gcl_aw*R0NMLjE3MjEzMjI0MTIuQ2owS0NRanctdUswQmhDMEFSSXNBTlF0Z0dOTGg5QmJUa2ZSVTdTSVlNSEJ5YVRJX0RGR2tBakc2UXhzTktRV0R4UmpnUW5hWUZxNUZKOGFBdUk1RUFMd193Y0I.*_gcl_au*OTQ3MzYzNDU5LjE3MjEzMjI0MTI.*_ga*OTIwOTUyNTcxLjE3MjEzMjI0MTI.*_ga_CDX93S7LDP*MTcyMTU1MTYzMy4zLjEuMTcyMTU1MTYzNy41Ni4wLjA.)
- [REC](https://www.youtube.com/embed/SkbbeULGpZE)
- [Transcript](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q1-Angel-One-Earnings-Transcript.pdf?_gl=1*1v7yet3*_gcl_au*MTE5NjA0MDQ2My4xNzE5NzY0NTA3*_ga*MTM5MTczNTM3Ni4xNzE5NzY0NTA4*_ga_CDX93S7LDP*MTcyMTA2MDAyNC4yLjAuMTcyMTA2MDAyNC42MC4wLjA.)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06d01fbc-b45d-4627-9c99-2822aa7cd86b.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2bfcc32-033d-4731-a3ef-84d4b6eeb2d9.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=22fb4db9-1502-4f89-b3f2-fa60561f5abf.pdf)
- [REC](https://www.youtube.com/embed/M_1z9y_X9RU)
- [Transcript](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q4-Angel-One-Earnings-Transcript.pdf?_gl=1*1d76xjr*_ga*MTEzOTc5MDc4LjE3MTM5ODg5NjQ.*_ga_CDX93S7LDP*MTcxMzk4ODk2NC4xLjAuMTcxMzk4ODk3MC41NC4wLjA.)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=40a2c66a-435b-47d3-9cc8-251587753a7b.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=559d4564-7587-4585-8164-3bffaaec23ab.pdf)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q3-Angel-One-Earnings-Transcript.pdf?_gl=1*j935kx*_ga*OTA5NjI4OTc0LjE3MDExNjgxOTk.*_ga_CDX93S7LDP*MTcxMzI2OTYzMS4xMzMuMS4xNzEzMjY5NzgxLjUwLjAuMA..)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q3-Angel-One-Earnings-Transcript.pdf?_gl=1*oz3ter*_ga*MjY1NTc2NTczLjE2OTYxNjYwMTU.*_ga_CDX93S7LDP*MTcxMDg0ODA2OC43LjEuMTcxMDg0ODEyOC42MC4wLjA.)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=85c564da-d5d7-4eb5-830e-f50c765a42be.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f83ab91c-6008-481e-8a65-c093da231d7a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=71b064e2-b841-498f-8848-3e5514084cbf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11d1ed03-7fe1-4ffb-ac98-166a6323a3fb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=08762938-73c5-4494-ba39-859dbcfacf03.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9f107916-849d-4684-bc17-ce4ee3958522.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3cb1b6a-cfed-45a7-a183-1b65ff9f6796.pdf)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/InvestorPresentation_17042023.pdf?_gl=1*1izgdac*_ga*MTE1NDgyMzkwMi4xNjg4NjI1MTIw*_ga_CDX93S7LDP*MTY4ODYyNTEyMC4xLjEuMTY4ODYyNTE3OS4xLjAuMA..)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=681690ec-8c63-4a58-a598-cd0d93ce2ddb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b50b4bd-9c4d-4428-be9e-ff1f5bd2817e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2d5abc0b-ba0c-498a-ba71-1ce3ffef6c5b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e16a454-7f0f-49c0-8888-acd16f0dbe95.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4983972a-851f-444e-9045-07765d10f1a9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=10d51121-97af-4179-8a78-ddbb71afe7ea.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=76d33349-a2c6-4781-a90e-b3b86fb1d3cb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f72083ce-031d-4452-aaee-ad633978c821.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf8486ca-7962-4734-91a6-f1b0eebb509a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da32bdac-bf62-41e0-b9b8-23749e11624f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=26d98ade-39fd-4013-bbfd-1a8108e7dd0a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c1621c2c-f975-4907-82dd-5fd40d5918a5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a9e28445-5372-4636-a575-67d613739cd5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d23e14ca-de16-42e8-b55b-420ae99431e0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5df52c26-e851-46d8-a042-1bf8612d9e52.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1494adb2-39da-43bb-8bac-b2a2bd7661e7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2831bcf9-cf80-424f-828a-1a2fedfb4d1e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bf8583-c2de-402c-8bd7-80262df4cadd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=be4a2d33-74f9-405f-b658-93232761c9ca.pdf)
- [](https://www.angelone.in/get-pdf-report-wp/Earning-calls-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2cc8329-a0fc-4c44-bb86-ed76926c7594.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3bbb3c2-2eee-45a4-b684-e7439ff71618.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=662402b2-5a96-42b3-afaa-53a9a9fae35d.pdf)
- [](https://www.angelone.in/get-pdf-report-wp/November1FilingoftranscriptofEarningscall.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=515759ae-3b26-4f86-80bb-f3946e53f3c4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28bbd273-ab15-40b3-8bb3-62188a712757.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Motil.Oswal.Fin. | 589.95 | 35222.57 | 12.60 | 3.96 | 4.46 | -38.41 | 7.93 | 32.52 | 0.60 | 20.69 | 8.94 | 32.59 | 0.26 | 1.58 | 4.10 | 3.13 | 7895.52 | 58.65 | 2796.01 | 2312.34 | 881.89 | 54.00 | 67.36 | 46.97 | 13787.48 | 69.04 | -0.12 | 12.63 | 15.90 | 0.00 | 60.32 | 95.89 | 36938.74 | 1.64 | 0.24 | -11.09 | 33.32 | 30.56 | 182.30 | 25.28 | 24.42 | 52.72 | 22.48 | 23.61 | 24.93 | 15.62 | 12.94 | 1.64 | 40.96 | 52.03 | 11.66 | 9.58 | 15.40 | 99.04 | 59.18 |
| 2. | ICICI Securities | 765.70 | 24797.25 | 12.71 | 6.31 | 4.31 | -7.97 | 7.72 | 27.66 | 3.84 | 19.74 | 8.24 | 50.09 | 0.25 | 4.30 | 3.19 | 5.25 | 5755.59 | 68.37 | 1952.76 | 1640.69 | 526.91 | 75.60 | 94.55 | 60.39 | 16886.54 | 74.65 | -0.09 | 12.60 | 15.90 | 0.00 | 61.83 | 75.15 | 30432.33 | 3.10 | 0.45 | 4.41 | -1.89 | 1.33 | 19.00 | 51.44 | 53.76 | 28.14 | 16.68 | 23.96 | 24.98 | 42.28 | 18.07 | 3.01 | 52.47 | 28.05 | 17.70 | 14.88 | 17.34 | 69.33 | 32.29 |
| 3. | Nuvama Wealth | 5635.80 | 19951.16 | 31.89 | 6.89 | 6.32 | -11.61 | 8.98 |  | 0.00 | 16.54 | 3.78 | 24.28 | 0.19 | 2.33 | 2.31 | 5.72 | 3156.30 | 49.59 | 625.20 | 927.38 | 180.74 | 51.34 | 111.64 | 177.10 | 6745.71 | 55.68 | -0.13 | 10.40 | 15.90 | 0.00 | 41.96 | 105.12 | 14083.59 | 1.40 |  | 3.73 | 58.26 |  |  | 18.74 |  |  | 82.14 |  | 31.63 | 14.57 | 12.20 | 1.33 | 177.10 |  | 27.73 | 27.73 | 27.73 | 75.96 |  |
| 4. | Angel One | 2131.00 | 19197.82 | 16.02 | 5.90 | 3.94 | 87.95 | 6.43 |  | 1.88 | 38.70 | 10.86 | 43.29 | 0.41 | 0.84 | 10.32 | 3.41 | 4869.68 | 37.82 | 1197.52 | 1405.45 | 292.74 | 74.05 | 32.56 | 140.26 | 2541.12 | 35.63 | -2.58 | 15.04 | 15.90 | 0.00 | 55.72 | 28.85 | 11894.65 | 1.48 | 0.23 | -24.41 | -27.11 | 20.93 | 33.84 | 45.16 | 41.68 | 69.77 | 55.46 | 40.60 | 49.11 | 47.12 | 43.94 | 1.48 | 133.98 | 64.61 | 20.55 | 19.05 | 20.55 | 41.60 | 8.34 |
| 5. | Prudent Corp. | 2340.35 | 9690.68 | 69.85 | 20.12 | 12.04 | 80.52 | 45.02 |  | 0.07 | 43.27 | 21.74 | 33.38 | 1.26 | 0.04 | 89.92 | 1.33 | 805.09 | 23.99 | 138.75 | 239.70 | 44.57 | 35.45 | 8.10 | 33.51 | 20.32 | 58.43 | 0.00 | 2.04 | 15.90 | 0.00 | 30.48 | 18.87 | 9578.95 | 1.56 | 1.56 | 47.02 | 79.81 |  | 92.31 | 37.02 | 35.87 | 44.89 | 45.27 | 29.04 | 39.78 | 39.73 | 51.45 | 1.56 | 33.51 | -30.74 | 37.93 | 37.93 | 37.93 | 64.20 | 4.14 |
| 6. | Share India Sec. | 308.00 | 6231.13 | 14.02 | 3.37 | 3.85 | -87.96 | 6.69 | 84.72 | 0.54 | 38.34 | 18.12 | 30.96 | 0.63 | 0.23 | 7.21 | 1.35 | 1619.69 | 41.93 | 446.66 | 414.18 | 102.80 | 49.36 | 25.20 | 25.03 | 402.75 | 51.32 | -1.87 | 14.42 | 15.90 | 37.76 | 42.74 | 27.28 | 4615.41 | 3.44 | 0.18 | -7.79 | -17.63 | 40.85 | 30.63 | 38.81 | 37.47 | 76.92 | 74.13 | 48.43 | 48.49 | 45.13 | 52.36 | 3.44 | 22.22 | 62.32 | 13.62 | 15.32 | 13.19 | 3.50 | 16.27 |
| 7. | IIFL Securities | 194.00 | 5977.68 | 11.84 | 3.33 | 2.70 | -156.99 | 2.84 |  | 1.60 | 34.56 | 7.75 | 32.32 | 0.34 | 0.65 | 5.49 | 3.67 | 2217.52 | 42.08 | 506.90 | 686.43 | 179.87 | 70.80 | 108.33 | 16.64 | 1153.85 | 30.88 | -0.02 | 33.69 | 15.90 | 0.00 | 62.97 | 104.63 | 2664.00 | 1.29 | 0.49 | 33.01 | 7.76 | 20.19 | 187.37 | 26.91 | 25.25 | 24.28 | 33.05 | 20.58 | 38.18 | 19.56 | 22.88 | 1.29 | 16.64 | -29.01 | 8.40 | 8.65 | 8.40 | 7.84 | 30.55 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| ANGELONE | Market Cap | ₹ 19,198 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | Sales | ₹ 4,870 Cr. |
| ANGELONE | OPM | 37.8 % |
| ANGELONE | Profit after tax | ₹ 1,198 Cr. |
| ANGELONE | Mar Cap | ₹ 19,198 Cr. |
| ANGELONE | Sales Qtr | ₹ 1,405 Cr. |
| ANGELONE | PAT Qtr | ₹ 293 Cr. |
| ANGELONE | Qtr Sales Var | 74.0 % |
| ANGELONE | Qtr Profit Var | 32.6 % |
| ANGELONE | Price to Earning | 16.0 |
| ANGELONE | Dividend yield | 1.88 % |
| ANGELONE | Price to book value | 5.90 |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | Return on assets | 10.9 % |
| ANGELONE | Debt to equity | 0.84 |
| ANGELONE | Return on equity | 43.3 % |
| ANGELONE | EPS | ₹ 140 |
| ANGELONE | Debt | ₹ 2,541 Cr. |
| ANGELONE | Promoter holding | 35.6 % |
| ANGELONE | Change in Prom Hold | -2.58 % |
| ANGELONE | Earnings yield | 15.0 % |
| ANGELONE | Pledged percentage | 0.00 % |
| ANGELONE | Industry PE | 15.9 |
| ANGELONE | Sales growth | 55.7 % |
| ANGELONE | Profit growth | 28.8 % |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | Price to Sales | 3.94 |
| ANGELONE | CMP / FCF | 88.0 |
| ANGELONE | EVEBITDA | 6.43 |
| ANGELONE | Enterprise Value | ₹ 11,895 Cr. |
| ANGELONE | Current ratio | 1.48 |
| ANGELONE | Int Coverage | 10.3 |
| ANGELONE | PEG Ratio | 0.23 |
| ANGELONE | Return over 3months | -24.4 % |
| ANGELONE | Return over 6months | -27.1 % |
| ANGELONE | No. Eq. Shares | 9.01 |
| ANGELONE | Sales growth 3Years | 49.1 % |
| ANGELONE | Sales growth 5Years | 40.6 % |
| ANGELONE | Profit Var 3Yrs | 55.5 % |
| ANGELONE | Profit Var 5Yrs | 69.8 % |
| ANGELONE | ROE 5Yr | 41.7 % |
| ANGELONE | ROE 3Yr | 45.2 % |
| ANGELONE | Return over 1year | 33.8 % |
| ANGELONE | Return over 3years | 20.9 % |
| ANGELONE | Return over 5years | % |
| ANGELONE | Market Cap | ₹ 19,199 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | Sales last year | ₹ 4,272 Cr. |
| ANGELONE | OP Ann | ₹ 1,693 Cr. |
| ANGELONE | Other Inc Ann | ₹ 7.31 Cr. |
| ANGELONE | EBIDT last year | ₹ 1,700 Cr. |
| ANGELONE | Dep Ann | ₹ 49.9 Cr. |
| ANGELONE | EBIT last year | ₹ 1,650 Cr. |
| ANGELONE | Interest last year | ₹ 137 Cr. |
| ANGELONE | PBT Ann | ₹ 1,514 Cr. |
| ANGELONE | Tax last year | ₹ 388 Cr. |
| ANGELONE | PAT Ann | ₹ 1,126 Cr. |
| ANGELONE | Extra Ord Item Ann | ₹ -0.11 Cr. |
| ANGELONE | NP Ann | ₹ 1,126 Cr. |
| ANGELONE | Dividend last year | ₹ 291 Cr. |
| ANGELONE | Raw Material | 0.00 % |
| ANGELONE | Employee cost | ₹ 558 Cr. |
| ANGELONE | OPM last year | 39.6 % |
| ANGELONE | NPM last year | 26.4 % |
| ANGELONE | Operating profit | ₹ 1,842 Cr. |
| ANGELONE | Interest | ₹ 173 Cr. |
| ANGELONE | Depreciation | ₹ 63.6 Cr. |
| ANGELONE | EPS last year | ₹ 134 |
| ANGELONE | EBIT | ₹ 1,787 Cr. |
| ANGELONE | Net profit | ₹ 1,197 Cr. |
| ANGELONE | Current Tax | ₹ 402 Cr. |
| ANGELONE | Tax | ₹ 416 Cr. |
| ANGELONE | Other income | ₹ 9.03 Cr. |
| ANGELONE | Ann Date | 2,02,403 |
| ANGELONE | Sales Prev Ann | ₹ 3,002 Cr. |
| ANGELONE | OP Prev Ann | ₹ 1,294 Cr. |
| ANGELONE | Other Inc Prev Ann | ₹ 18.3 Cr. |
| ANGELONE | EBIDT Prev Ann | ₹ 1,303 Cr. |
| ANGELONE | Dep Prev Ann | ₹ 30.3 Cr. |
| ANGELONE | EBIT preceding year | ₹ 1,272 Cr. |
| ANGELONE | Interest Prev Ann | ₹ 90.9 Cr. |
| ANGELONE | PBT Prev Ann | ₹ 1,192 Cr. |
| ANGELONE | Tax preceding year | ₹ 302 Cr. |
| ANGELONE | PAT Prev Ann | ₹ 882 Cr. |
| ANGELONE | Extra Ord Prev Ann | ₹ 10.0 Cr. |
| ANGELONE | NP Prev Ann | ₹ 890 Cr. |
| ANGELONE | Dividend Prev Ann | ₹ 332 Cr. |
| ANGELONE | OPM preceding year | 43.1 % |
| ANGELONE | NPM preceding year | 29.4 % |
| ANGELONE | EPS preceding year | ₹ 107 |
| ANGELONE | Sales Prev 12M | ₹ 4,272 Cr. |
| ANGELONE | Profit Prev 12M | ₹ 1,126 Cr. |
| ANGELONE | Med Sales Gwth 10Yrs | 31.0 % |
| ANGELONE | Med Sales Gwth 5Yrs | 42.3 % |
| ANGELONE | Sales growth 7Years | 38.4 % |
| ANGELONE | Sales Var 10Yrs | % |
| ANGELONE | EBIDT growth 3Years | 53.1 % |
| ANGELONE | EBIDT growth 5Years | 51.3 % |
| ANGELONE | EBIDT growth 7Years | 46.9 % |
| ANGELONE | EBIDT Var 10Yrs | % |
| ANGELONE | EPS growth 3Years | 54.1 % |
| ANGELONE | EPS growth 5Years | 64.6 % |
| ANGELONE | EPS growth 7Years | 29.8 % |
| ANGELONE | EPS growth 10Years | % |
| ANGELONE | Profit Var 7Yrs | 67.1 % |
| ANGELONE | Profit Var 10Yrs | % |
| ANGELONE | Chg in Prom Hold 3Yr | -8.63 % |
| ANGELONE | Market Cap | ₹ 19,199 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | OP Qtr | ₹ 470 Cr. |
| ANGELONE | Other Inc Qtr | ₹ 4.60 Cr. |
| ANGELONE | EBIDT Qtr | ₹ 475 Cr. |
| ANGELONE | Dep Qtr | ₹ 22.6 Cr. |
| ANGELONE | EBIT latest quarter | ₹ 452 Cr. |
| ANGELONE | Interest Qtr | ₹ 55.6 Cr. |
| ANGELONE | PBT Qtr | ₹ 397 Cr. |
| ANGELONE | Tax latest quarter | ₹ 104 Cr. |
| ANGELONE | Extra Ord Item Qtr | ₹ -0.01 Cr. |
| ANGELONE | NP Qtr | ₹ 293 Cr. |
| ANGELONE | GPM latest quarter | 100 % |
| ANGELONE | OPM latest quarter | 33.5 % |
| ANGELONE | NPM latest quarter | 20.8 % |
| ANGELONE | Eq Cap Qtr | ₹ 90.1 Cr. |
| ANGELONE | EPS latest quarter | ₹ 32.5 |
| ANGELONE | OP 2Qtr Bk | ₹ 398 Cr. |
| ANGELONE | OP 3Qtr Bk | ₹ 443 Cr. |
| ANGELONE | Sales 2Qtr Bk | ₹ 1,059 Cr. |
| ANGELONE | Sales 3Qtr Bk | ₹ 1,048 Cr. |
| ANGELONE | NP 2Qtr Bk | ₹ 260 Cr. |
| ANGELONE | NP 3Qtr Bk | ₹ 304 Cr. |
| ANGELONE | Opert Prft Gwth | 36.7 % |
| ANGELONE | Last result date | 2,02,406 |
| ANGELONE | Exp Qtr Sales Var | 57.1 % |
| ANGELONE | Exp Qtr Sales | ₹ 1,646 Cr. |
| ANGELONE | Exp Qtr OP | ₹ 650 Cr. |
| ANGELONE | Exp Qtr NP | ₹ 572 Cr. |
| ANGELONE | Exp Qtr EPS | ₹ 63.5 |
| ANGELONE | Sales Prev Qtr | ₹ 1,357 Cr. |
| ANGELONE | OP Prev Qtr | ₹ 530 Cr. |
| ANGELONE | Other Inc Prev Qtr | ₹ 1.25 Cr. |
| ANGELONE | EBIDT Prev Qtr | ₹ 531 Cr. |
| ANGELONE | Dep Prev Qtr | ₹ 16.7 Cr. |
| ANGELONE | EBIT Prev Qtr | ₹ 514 Cr. |
| ANGELONE | Interest Prev Qtr | ₹ 55.6 Cr. |
| ANGELONE | PBT Prev Qtr | ₹ 459 Cr. |
| ANGELONE | Tax Prev Qtr | ₹ 119 Cr. |
| ANGELONE | PAT Prev Qtr | ₹ 340 Cr. |
| ANGELONE | Extra Ord Prev Qtr | ₹ -0.01 Cr. |
| ANGELONE | NP Prev Qtr | ₹ 340 Cr. |
| ANGELONE | OPM Prev Qtr | 39.0 % |
| ANGELONE | NPM Prev Qtr | 25.0 % |
| ANGELONE | Eq Cap Prev Qtr | ₹ 83.9 Cr. |
| ANGELONE | EPS Prev Qtr | ₹ 40.5 |
| ANGELONE | Sales PY Qtr | ₹ 808 Cr. |
| ANGELONE | OP PY Qtr | ₹ 320 Cr. |
| ANGELONE | Other Inc PY Qtr | ₹ 3.55 Cr. |
| ANGELONE | EBIDT PY Qtr | ₹ 324 Cr. |
| ANGELONE | Dep PY Qtr | ₹ 8.93 Cr. |
| ANGELONE | EBIT PY Qtr | ₹ 315 Cr. |
| ANGELONE | Interest PY Qtr | ₹ 18.3 Cr. |
| ANGELONE | PBT PY Qtr | ₹ 297 Cr. |
| ANGELONE | Tax PY Qtr | ₹ 75.9 Cr. |
| ANGELONE | Market Cap | ₹ 19,199 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | Equity capital | ₹ 84.0 Cr. |
| ANGELONE | Preference capital | ₹ 0.00 Cr. |
| ANGELONE | Reserves | ₹ 2,955 Cr. |
| ANGELONE | Secured loan | ₹ 2,402 Cr. |
| ANGELONE | Unsecured loan | ₹ 139 Cr. |
| ANGELONE | Balance sheet total | ₹ 13,254 Cr. |
| ANGELONE | Gross block | ₹ 527 Cr. |
| ANGELONE | Revaluation reserve | ₹ 0.00 Cr. |
| ANGELONE | Accum Dep | ₹ 118 Cr. |
| ANGELONE | Net block | ₹ 409 Cr. |
| ANGELONE | CWIP | ₹ 0.60 Cr. |
| ANGELONE | Investments | ₹ 0.00 Cr. |
| ANGELONE | Current assets | ₹ 11,360 Cr. |
| ANGELONE | Current liabilities | ₹ 7,658 Cr. |
| ANGELONE | BV Unq Invest | ₹ 0.00 Cr. |
| ANGELONE | MV Quoted Inv | ₹ 0.00 Cr. |
| ANGELONE | Cont Liab | ₹ 3,083 Cr. |
| ANGELONE | Total Assets | ₹ 13,254 Cr. |
| ANGELONE | Working capital | ₹ 3,702 Cr. |
| ANGELONE | Lease liabilities | ₹ 0.00 Cr. |
| ANGELONE | Inventory | ₹ 0.00 Cr. |
| ANGELONE | Trade receivables | ₹ 487 Cr. |
| ANGELONE | Face value | ₹ 10.0 |
| ANGELONE | Cash Equivalents | ₹ 9,844 Cr. |
| ANGELONE | Adv Cust | ₹ 0.00 Cr. |
| ANGELONE | Trade Payables | ₹ 7,197 Cr. |
| ANGELONE | No. Eq. Shares PY | 8.34 |
| ANGELONE | Debt preceding year | ₹ 788 Cr. |
| ANGELONE | Work Cap PY | ₹ 1,590 Cr. |
| ANGELONE | Net Block PY | ₹ 187 Cr. |
| ANGELONE | Gross Block PY | ₹ 262 Cr. |
| ANGELONE | CWIP PY | ₹ 61.6 Cr. |
| ANGELONE | Work Cap 3Yr | ₹ 1,049 Cr. |
| ANGELONE | Work Cap 5Yr | ₹ 1,257 Cr. |
| ANGELONE | Work Cap 7Yr | ₹ 966 Cr. |
| ANGELONE | Work Cap 10Yr | ₹ Cr. |
| ANGELONE | Debt 3Years back | ₹ 1,171 Cr. |
| ANGELONE | Debt 5Years back | ₹ 872 Cr. |
| ANGELONE | Debt 7Years back | ₹ 772 Cr. |
| ANGELONE | Debt 10Years back | ₹ Cr. |
| ANGELONE | Net Block 3Yrs Back | ₹ 115 Cr. |
| ANGELONE | Net Block 5Yrs Back | ₹ 134 Cr. |
| ANGELONE | Net Block 7Yrs Back | ₹ 123 Cr. |
| ANGELONE | Market Cap | ₹ 19,199 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | CF Operations | ₹ -330 Cr. |
| ANGELONE | Free Cash Flow | ₹ -537 Cr. |
| ANGELONE | CF Investing | ₹ -91.0 Cr. |
| ANGELONE | CF Financing | ₹ 1,331 Cr. |
| ANGELONE | Net CF | ₹ 910 Cr. |
| ANGELONE | Cash Beginning | ₹ 133 Cr. |
| ANGELONE | Cash End | ₹ 9,844 Cr. |
| ANGELONE | FCF Prev Ann | ₹ 704 Cr. |
| ANGELONE | CF Operations PY | ₹ 804 Cr. |
| ANGELONE | CF Investing PY | ₹ -185 Cr. |
| ANGELONE | CF Financing PY | ₹ -908 Cr. |
| ANGELONE | Net CF PY | ₹ -289 Cr. |
| ANGELONE | Cash Beginning PY | ₹ 422 Cr. |
| ANGELONE | Cash End PY | ₹ 5,491 Cr. |
| ANGELONE | Free Cash Flow 3Yrs | ₹ 655 Cr. |
| ANGELONE | Free Cash Flow 5Yrs | ₹ 73.1 Cr. |
| ANGELONE | Free Cash Flow 7Yrs | ₹ 435 Cr. |
| ANGELONE | Free Cash Flow 10Yrs | ₹ 118 Cr. |
| ANGELONE | CF Opr 3Yrs | ₹ 1,032 Cr. |
| ANGELONE | CF Opr 5Yrs | ₹ 476 Cr. |
| ANGELONE | CF Opr 7Yrs | ₹ 856 Cr. |
| ANGELONE | CF Opr 10Yrs | ₹ 580 Cr. |
| ANGELONE | CF Inv 10Yrs | ₹ -360 Cr. |
| ANGELONE | CF Inv 7Yrs | ₹ -290 Cr. |
| ANGELONE | CF Inv 5Yrs | ₹ -332 Cr. |
| ANGELONE | CF Inv 3Yrs | ₹ -329 Cr. |
| ANGELONE | Cash 3Years back | ₹ 1,877 Cr. |
| ANGELONE | Cash 5Years back | ₹ 986 Cr. |
| ANGELONE | Cash 7Years back | ₹ 618 Cr. |
| ANGELONE | Market Cap | ₹ 19,199 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | No. Eq. Shares | 9.01 |
| ANGELONE | Book value | ₹ 362 |
| ANGELONE | Inven TO |  |
| ANGELONE | Quick ratio | 1.48 |
| ANGELONE | Exports percentage | 0.00 % |
| ANGELONE | Piotroski score | 2.00 |
| ANGELONE | G Factor | 7.00 |
| ANGELONE | Asset Turnover | 0.41 |
| ANGELONE | Financial leverage | 3.41 |
| ANGELONE | No. of Share Holders | 2,70,528 |
| ANGELONE | Unpledged Prom Hold | 35.6 % |
| ANGELONE | ROIC | 29.8 % |
| ANGELONE | Debtor days | 41.6 |
| ANGELONE | Industry PBV | 2.90 |
| ANGELONE | Credit rating |  |
| ANGELONE | WC Days | -525 |
| ANGELONE | Earning Power | 13.5 % |
| ANGELONE | Graham Number | ₹ 1,068 |
| ANGELONE | Cash Cycle | 41.6 |
| ANGELONE | Days Payable |  |
| ANGELONE | Days Receivable | 41.6 |
| ANGELONE | Inventory Days |  |
| ANGELONE | Public holding | 35.0 % |
| ANGELONE | FII holding | 15.4 % |
| ANGELONE | Chg in FII Hold | -2.59 % |
| ANGELONE | DII holding | 14.0 % |
| ANGELONE | Chg in DII Hold | 0.44 % |
| ANGELONE | B.V. Prev Ann | ₹ 259 |
| ANGELONE | ROCE Prev Yr | 43.9 % |
| ANGELONE | ROA Prev Yr | 12.0 % |
| ANGELONE | ROE Prev Ann | 47.1 % |
| ANGELONE | No. of Share Holders Prev Qtr | 2,00,363 |
| ANGELONE | No. Eq. Shares 10 Yrs | 1.44 |
| ANGELONE | BV 3yrs back | ₹ 138 |
| ANGELONE | BV 5yrs back | ₹ |
| ANGELONE | BV 10yrs back | ₹ |
| ANGELONE | Inven TO 3Yr | 71.6 |
| ANGELONE | Inven TO 5Yr | 94.6 |
| ANGELONE | Inven TO 7Yr | 47.1 |
| ANGELONE | Inven TO 10Yr |  |
| ANGELONE | Export 3Yr | 0.00 % |
| ANGELONE | Export 5Yr | 0.00 % |
| ANGELONE | Div 5Yrs | ₹ 195 Cr. |
| ANGELONE | ROCE 3Yr | 39.4 % |
| ANGELONE | ROCE 5Yr | 31.8 % |
| ANGELONE | ROCE 7Yr | 27.2 % |
| ANGELONE | ROCE 10Yr | 23.7 % |
| ANGELONE | ROE 10Yr | % |
| ANGELONE | ROE 7Yr | 39.2 % |
| ANGELONE | ROE 5Yr Var | 22.2 % |
| ANGELONE | OPM 5Year | 39.2 % |
| ANGELONE | OPM 10Year | 36.0 % |
| ANGELONE | No. of Share Holders 1Yr | 1,29,211 |
| ANGELONE | Avg Div Payout 3Yrs | 33.0 % |
| ANGELONE | Debtor days 3yrs | 59.0 |
| ANGELONE | Debtor days 3yrs back | 64.5 |
| ANGELONE | Debtor days 5yrs back | 101 |
| ANGELONE | ROA 5Yr | 9.18 % |
| ANGELONE | ROA 3Yr | 11.1 % |
| ANGELONE | Market Cap | ₹ 19,198 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | Avg Vol 1Mth | 12,06,225 |
| ANGELONE | Avg Vol 1Wk | 14,04,132 |
| ANGELONE | Volume | 5,14,882 |
| ANGELONE | High price | ₹ 3,900 |
| ANGELONE | Low price | ₹ 1,460 |
| ANGELONE | High price all time | ₹ 3,900 |
| ANGELONE | Low price all time | ₹ 222 |
| ANGELONE | Return over 1day | 0.08 % |
| ANGELONE | Return over 1week | 2.03 % |
| ANGELONE | Return over 1month | -18.1 % |
| ANGELONE | DMA 50 | ₹ 2,435 |
| ANGELONE | DMA 200 | ₹ 2,545 |
| ANGELONE | DMA 50 previous day | ₹ 2,447 |
| ANGELONE | 200 DMA prev. | ₹ 2,549 |
| ANGELONE | RSI | 35.2 |
| ANGELONE | MACD | -103 |
| ANGELONE | MACD Previous Day | -103 |
| ANGELONE | MACD Signal | -98.3 |
| ANGELONE | MACD Signal Prev | -97.1 |
| ANGELONE | Avg Vol 1Yr | 7,22,754 |
| ANGELONE | Return over 7years | % |
| ANGELONE | Return over 10years | % |
| ANGELONE | Market Cap | ₹ 19,198 Cr. |
| ANGELONE | Current Price | ₹ 2,131 |
| ANGELONE | High / Low | ₹ 3,900 / 1,460 |
| ANGELONE | Stock P/E | 16.0 |
| ANGELONE | Book Value | ₹ 362 |
| ANGELONE | Dividend Yield | 1.88 % |
| ANGELONE | ROCE | 38.7 % |
| ANGELONE | ROE | 43.3 % |
| ANGELONE | Face Value | ₹ 10.0 |
| ANGELONE | WC to Sales | 76.0 % |
| ANGELONE | QoQ Profits | -13.9 % |
| ANGELONE | QoQ Sales | 3.55 % |
| ANGELONE | Net worth | ₹ 3,039 Cr. |
| ANGELONE | Market Cap to Sales | 3.94 |
| ANGELONE | Interest Coverage | 10.3 |
| ANGELONE | EV / EBIT | 6.66 |
| ANGELONE | Debt Capacity | 0.40 |
| ANGELONE | Debt To Profit | 2.26 |
| ANGELONE | Capital Employed | ₹ 4,112 Cr. |
| ANGELONE | CROIC | 5.12 % |
| ANGELONE | debtplus | 1.73 |
| ANGELONE | Leverage | ₹ 3.41 |
| ANGELONE | Dividend Payout | 25.9 % |
| ANGELONE | Intrinsic Value | ₹ 3,578 |
| ANGELONE | CDL | 22.0 % |
| ANGELONE | Cash by market cap | 0.40 |
| ANGELONE | 52w Index | 27.5 % |
| ANGELONE | Down from 52w high | 45.4 % |
| ANGELONE | Up from 52w low | 46.0 % |
| ANGELONE | From 52w high | 0.55 |
| ANGELONE | Mkt Cap To Debt Cap | 16.1 |
| ANGELONE | Dividend Payout | 25.9 % |
| ANGELONE | Graham | ₹ 1,068 |
| ANGELONE | Price to Cash Flow | -58.2 |
| ANGELONE | ROCE3yr avg | 39.4 % |
| ANGELONE | PB X PE | 94.5 |
| ANGELONE | NCAVPS | ₹ 411 |
| ANGELONE | Mar Cap to CF | -58.2 |
| ANGELONE | Altman Z Score | 3.79 |
| ANGELONE | M.Cap / Qtr Profit | 65.6 |