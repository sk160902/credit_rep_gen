from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions, ContentSettings
from datetime import datetime, timedelta


def upload_image_to_azure(file_path: str, file_name: str) -> str:
    # Azure Blob Storage connection string and container name
    connection_string = "DefaultEndpointsProtocol=https;AccountName=prodpublic24;AccountKey=9uBBrUvKWddmweMD7uNvZb2KjaqYL1xM7I8+2M3tsVBDZZtPlbmm3cVzqIH6ZsjWaZabjVF1NJtS+AStzgxShg==;EndpointSuffix=core.windows.net"
    container_name = "generated-tables"
    account_name = "prodpublic24"
    account_key = "9uBBrUvKWddmweMD7uNvZb2KjaqYL1xM7I8+2M3tsVBDZZtPlbmm3cVzqIH6ZsjWaZabjVF1NJtS+AStzgxShg=="

    # Create the BlobServiceClient and container client
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service_client.get_container_client(container_name)

    # Ensure the container exists
    if not container_client.exists():
        container_client.create_container()

    # Upload the image
    blob_client = container_client.get_blob_client(file_name)
    with open(file_path, "rb") as image_file:
        blob_client.upload_blob(image_file, blob_type="BlockBlob", overwrite=True,
                                content_settings=ContentSettings(content_type="image/jpeg"))

    # Generate SAS token for the uploaded image
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=file_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(hours=1)
    )

    # Construct the full URL with SAS token
    sas_url = f"https://{account_name}.blob.core.windows.net/{container_name}/{file_name}?{sas_token}"

    return sas_url

# Example usage
image_url = upload_image_to_azure("/Users/Shreyas2/Desktop/Onfinance/credit/credit-report/peer_graphs/5Yrs_Return.png", "shreyas_test_cred_rep.png")
print(f"Image URL: {image_url}")