About
[
edit
]
Union Bank of India is engaged in the Business of Banking Services, Government Business ,Merchant Banking, Agency Business  Insurance, Mutual Funds, Wealth Management etc.
[1]
Key Points
[
edit
]
Segments Revenue FY24
1) Corporate and Wholesale Banking (36%):
The Bank offers a variety of products, including working capital loans, term loans, and project financing to corporate clients, businesses, and large enterprises.
[1]
2) Retail Banking (~34%):
The Bank provides a variety of retail loans, including home loans, vehicle loans, and personal loans, to meet the diverse needs of its customers.
[2]
3) Treasury (27%):
The Bank’s treasury operations involve managing the Bank’s liquidity, investments, and foreign exchange activities. The Bank employs advanced risk management techniques to ensure optimal liquidity and maximize ROI.
[3]
4) Other Banking Operations (~3%):
Offers digital banking services, including app banking, internet banking, self-service banking, ATM banking, SMS banking, etc.
[4]
[5]
Market Share
As of FY24, the bank’s market share in deposits and net advances is ~6% and 5.5%, respectively, thereby making it the fifth-largest public sector bank.
[6]
[7]
Key Ratios
Capital Adequacy Ratio - 16.9% in FY24 vs 14.5% in FY22
[8]
[9]
NIM - 3.10% in FY24 vs 2.9% in FY22
[10]
[11]
Improvement in Asset Quality
Gross NPA - 4.76% in FY24 vs 11.11% in FY22
Net NPA - 1.03% in FY24 vs 3.68% in FY22
PCR - 92.3% in FY24 vs 83.6% in FY22
[12]
The bank has employed a multi-faceted approach to recover and resolve NPAs. Key strategies include- Legal Resources like SARFAESI and DRT Acts for quick recovery, Restructuring of NPA Accounts, and One-Time Settlement.
[13]
Branch Network
As of FY24, the bank has a network of 8,466 Branches & 8,982 ATMs. It has overseas branches in Sydney and Dubai, along with operations in London through WOS, Union Bank of India (UK) Ltd., and a JV in Malaysia, India International Bank (Malaysia) Berhad.
[14]
Rural: 30%
Semi-Urban: 29%
Metro: 21%
Urban: 20%
[7]
Loan Book
As of FY24, Gross advances stood at Rs. ~9,04,800 Cr vs Rs. ~7,16,400 Cr in FY22.
Corporate & Other: 45%
Retail: ~20%
Agriculture: 20%
MSME: 15%
The share of these segments to the gross advances largely remains the same between FY22 to FY24.
[15]
[16]
Loan Book Exposure
Infrastructure- ~10%, NBFC& HFC- 13.5%, Food Processing- 3.3%, Basic Metals- 2.7%, Textiles- 1.9%, Chemical - 1.6%, Petroleum- 1%.
Total exposure to these industries stood at ~34% of domestic advances in FY24 down from 43% as of FY22.
[17]
[18]
Deposits
As of FY24, total deposits of the company stood at Rs. ~12,21,500 Cr vs Rs. ~10,32,300 Cr in FY22.
CASA: ~34% in FY24 vs 36% in FY22
Retail Term Deposit: 37%
Bulk Term Deposit: 29%
[19]
[20]
IT Capex
In FY24, the company incurred Rs. 1,150 Cr on IT infrastructure, further plans to invest Rs. 1,400 Cr in FY25 on its core IT, security, analytics, and digital transformation project.
[21]
Fund Raising
In FY24, the Bank raised equity capital of Rs. 5,000 Cr by the allotment of 57.77 Cr equity shares on Aug 23 and equity capital of Rs. 3,000 Cr by the allotment of 22.11 Cr equity shares on Feb 24 through QIP issues.
[22]
Merger
In 2020, Andhra Bank and Corporation Bank were amalgamated into the Union Bank of India. This merger has enhanced UBI’s operational capabilities, customer reach, and financial strength, positioning.
[23]
Outlook
For the FY25, the bank projects growth in advances between 11%-13%, 9%-11% deposit growth, NIM of 2.8%-3%, and GNPA below 4%.
[24]
Last edited 2 weeks, 5 days ago
Request an update
© Protected by Copyright
