# Complete Company Data

## Modal Content
About
[
edit
]
Ashok Leyland is the flagship Company of the Hinduja group, having a long-standing presence in the domestic medium and heavy commercial vehicle (M&HCV) segment. The company has a strong brand and well-diversified distribution and service network across the country and has a presence in 50 countries, it is one of the most fully-integrated manufacturing companies. Its headquarter is in Chennai
[1]
They manage driver training institutes across India and have trained over 8,00,000 drivers since inception.
[1]
Key Points
[
edit
]
Market Leadership
The Company is the second largest manufacturer of commercial vehicles in India in the medium and heavy commercial vehicle segment, fourth largest manufacturer of buses in the world and the fifteenth largest manufacturer of trucks globally.
[1]
Segment Performance
M&HCV Truck Segment
The Co.’s sales in the M&HCV Trucks segment (excluding Defence vehicles) in India grew by ~44% in FY22. It enhanced its product portfolio with CNG models in the ICV trucks segment to cater to the boost in demand for alternate fuels in ecommerce and last-mile delivery applications. Further, product enhancements like High Horsepower Mining Tipper and Surface Tipper, helped the Co. to strengthen its presence in the Construction and Mining industry. It pioneered in launching 8x2 Multi-Axle Truck with Dual Tyre Lift Axle and 6x2 Multi-Axle Truck with Single Tyre Lift Axle.
[2]
M&HCV Bus Segment
The Co.’s sales in the M&HCV Bus segment (excluding Defence vehicles) in India grew by ~11% in FY22. It was able to achieve a market share of ~27% in the M&HCV Bus and Truck segment.
[2]
LCV Segment
The Co. continues to deliver best-in-industry SSI/CSI, lowest defect product, low warranty cost and high service retention through its network of 547 outlets, achieving a service market share of 70.0%. Its new product ‘Bada Dost’ was awarded ‘CV of Year’ and ‘Pick up of the Year 2021-22’. It is on track to launch 3 new products in FY23 for the domestic market.
[3]
Defense
In FY22, the Co. supplied all time high 1,125 units of completely built-up units (CBUs) including bullet proof vehicles and 600 kits. It completed the execution of 711 Ambulances in record time under emergency procurement of the Indian Army. Further, it is expanding its portfolio in Light Vehicles, new applications on the Super Stallion platform and products specific to export markets.
[3]
Foundry Division
The Foundry Division of the Co. mainly caters to the automotive industry in product segments of Cylinder Block, Head and Tractor Housings. In FY22, the Foundry division increased production by 20% and achieved a sales growth of 12% as compared to FY21.
[3]
Revenue Mix FY22
Commercial Vehicle - 88%
Financial Service - 12%
[4]
Geographical Split FY22
India - 89%
Outside India - 11%
[4]
International market
The Co. focused on expanding its global footprint across retail markets in Africa, and continued strengthening its network in SAARC and GCC countries. It observed overall I/O sales growth of 37% over FY21. Penetration in LCV portfolio across geographies was achieved while retaining market leadership position in MDV bus segment in SAARC and GCC countries.
[2]
Manufacturing Facilities
The Co. has 5 manufacturing plants in India, and 1 each in UAE, Bangladesh and Srilanka.
[5]
[6]
Distribution Network
The Co. added 71 new outlets during FY22, increasing the total count to 907 primary touch-points. To keep up with the rising commercial vehicle operations in Northern and Eastern regions of India, it opened more than half of the new outlets in these regions.
[3]
Fundraise
During FY22, the Co. issued and allotted on private placement basis, secured redeemable non-convertible debentures (NCDs) aggregating to Rs. 200 Crores. Additionally, fresh secured rupee term loans of Rs. 450 Crores were availed during the year. It repaid rupee term loan installments amounting to Rs. 12.50 Crores on the due date during the year.
[7]
Subsidiary
Hinduja Tech Limited (HTL) has ceased to be a wholly owned subsidiary of the Co., consequent to the exercise of stock options by HTL employees pursuant to ‘Hinduja Tech Limited Employees Stock Option Plan 2017’. It currently holds 98.91% in the paid up equity share capital of HTL.
[8]
Transfer of Business
During FY22, the Co. transferred its Electric Vehicle business to Switch Mobility Automotive Limited, step-down subsidiary of the Co. on slump sale basis. Further, it is in the process of transferring its E-MaaS business to Ohm Global Mobility Private Limited, a fellow subsidiary, on a slump sale basis.
[8]
Capex
During FY22, the Co. incurred Rs. 400 Crores towards capital expenditure predominantly towards:
a) Improving manufacturing capacity and capability covering LCV Engines, Frame Side member, SG Cast Iron, Cab Paint &Trim and Chassis Assembly;
b) New products covering Project Vayu (CNG vehicles development), Low Cost EATS development & Emission migration Projects (BS Construction Equipment Vehicle {CEV IV} and BS VI Phase 2); and
c) Unit replacement & maintenance capex for sustenance
[9]
Changes in KMP
Mr. Vipin Sondhi, Managing Director and CEO of the Company stepped down from the Board with effect from December 31, 2021. The BOD at their meeting held on November 26, 2021 appointed Mr. Dheeraj G Hinduja as the Executive Chairman (Whole-time) of the Company, for a period of three years commencing from November 26, 2021 to November 25, 2024.
[8]
Investments
In FY22, the Co. invested Rs. 10 Crores in Gro Digital, Rs. 4 Crores in Ashley Aviation and Rs. 3 Crores in Ashley Alteams. Therefore, it has invested Rs. 17 Crores in aggregate by cash in joint venture/associates/subsidiaries. In addition, Rs. 4 Crore loan has been converted into equity in Albonair GmBH. It has done an impairment reversal of equity investment in Optare Plc for Rs. 781 Crores. There had also been impairments of Rs. 350 Crores during FY22 (Hinduja Energy Rs. 107 Crores, Albonair GmbH Rs. 239 Crores and Ashley Aviation Rs. 4 Crores).
[9]
Last edited 5 months, 4 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 11,859 | 15,708 | 21,260 | 22,871 | 29,636 | 33,197 | 21,951 | 19,454 | 26,237 | 41,673 | 45,791 | 46,824 |
| Expenses + | 11,437 | 14,191 | 18,281 | 19,826 | 25,387 | 28,287 | 18,718 | 16,992 | 23,472 | 36,580 | 37,848 | 38,521 |
| Operating Profit | 422 | 1,517 | 2,979 | 3,045 | 4,248 | 4,910 | 3,233 | 2,462 | 2,765 | 5,093 | 7,943 | 8,303 |
| OPM % | 4% | 10% | 14% | 13% | 14% | 15% | 15% | 13% | 11% | 12% | 17% | 18% |
| Other Income + | 613 | -106 | -321 | 406 | 190 | 139 | 57 | 207 | -230 | 166 | 73 | 56 |
| Interest | 805 | 872 | 925 | 1,049 | 1,227 | 1,502 | 1,802 | 1,901 | 1,869 | 2,094 | 2,982 | 3,231 |
| Depreciation | 530 | 580 | 524 | 573 | 646 | 676 | 750 | 836 | 866 | 900 | 927 | 936 |
| Profit before tax | -300 | -42 | 1,209 | 1,829 | 2,565 | 2,872 | 739 | -67 | -200 | 2,265 | 4,106 | 4,192 |
| Tax % | -23% | 415% | 41% | 11% | 29% | 24% | 38% | 4% | 43% | 40% | 34% |  |
| Net Profit + | -222 | -205 | 712 | 1,633 | 1,814 | 2,195 | 460 | -70 | -285 | 1,359 | 2,696 | 2,662 |
| EPS in Rs | -0.62 | 0.47 | 2.40 | 5.58 | 6.01 | 7.08 | 1.15 | -0.56 | -1.22 | 4.22 | 8.46 | 8.34 |
| Dividend Payout % | 0% | 96% | 40% | 28% | 40% | 44% | 44% | -107% | -82% | 62% | 59% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 206% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ashok Leyland Vehicles Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  | 1,026 | 764 |  |  |  |  |  |  |  |
| Other operatingincome |  | 75 | 59 |  |  |  |  |  |  |  |
| Sales and services |  | 34 | 34 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 35 | 23 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | -0.46 | 15 |  |  |  |  |  |  |  |
| Lanka Ashok Leyland, PLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and services |  | 331 | 336 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | -11 | 1.23 |  |  |  |  |  |  |  |
| Ashok Leyland (UAE) LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and Services (net of taxes) | 363 |  |  |  |  |  |  |  |  |  |
| Disposal of Investments to | 1.87 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.52 |  |  |  |  |  |  |  |  |  |
| Lanka Ashok Leyland PLC Associate |  |  |  |  |  |  |  |  |  |  |
| Sales and Services (net of taxes) | 285 |  |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 1.40 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | -10 |  |  |  |  |  |  |  |  |  |
| Gulf Oil Lubricants India Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  | 87 | 109 |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 62 |  |  |  |  |  |  |  |  |  |
| Hinduja Automotive Limited, United Kingdom Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Dividend payment |  | 65 | 136 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 0.69 | 3.37 |  |  |  |  |  |  |  |
| Nisssan Ashok Leyland Powertrain Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 110 |  |  |  |  |  |  |  |  |  |
| Hinduja Foundries Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods |  |  | 109 |  |  |  |  |  |  |  |
| Sale of assets |  |  | 0.09 |  |  |  |  |  |  |  |
| Ashok Leyland John Deere Construction Equipment Company Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of |  | 46 | 25 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 1.27 | -0.73 |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.24 |  |  |  |  |  |  |  |  |  |
| Avia Ashok Leyland Motors s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Loans / Advance repaid | 66 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 1.88 |  |  |  |  |  |  |  |  |  |
| Purchase of assets | 0.39 |  |  |  |  |  |  |  |  |  |
| Ashley Powertrain Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other operatingincome |  | 26 | 22 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | 0.37 | 2.40 |  |  |  |  |  |  |  |
| Nissan Ashok Leyland Technologies Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 39 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 9.22 |  |  |  |  |  |  |  |  |  |
| Albonair GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of | 26 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.05 |  |  |  |  |  |  |  |  |  |
| Hinduja Tech Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 8.44 | 15 |  |  |  |  |  |  |  |
| Purchase of assets |  | 0.20 | 0.13 |  |  |  |  |  |  |  |
| Ashley Alteams India Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of raw materials, components and traded goods ( net of CENVAT/ VAT) | 20 |  |  |  |  |  |  |  |  |  |
| Interest and other income | 0.11 |  |  |  |  |  |  |  |  |  |
| Ashok Leyland Defence Systems Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investment in shares of |  |  | 6.47 |  |  |  |  |  |  |  |
| Other expenditure incurred / (recovered) |  | 1.47 | 3.93 |  |  |  |  |  |  |  |
| Advance/current account - net increase / (decrease) |  | 2.29 |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 0.60 |  |  |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.55 |  |  |  |  |  |  |  |  |  |
| Nissan Ashok Leyland Powertrain Limited JV |  |  |  |  |  |  |  |  |  |  |
| Other Operating Income | 12 |  |  |  |  |  |  |  |  |  |
| Advance / Current account - Net increase / (decrease) | 0.04 |  |  |  |  |  |  |  |  |  |
| Ashley Aviation Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Interest and other income | 2.25 | 2.25 | 2.25 |  |  |  |  |  |  |  |
| Other Expenditure incurred / (recovered) (net) | 0.58 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 11,859 | 15,708 | 21,260 | 22,871 | 29,636 | 33,197 | 21,951 | 19,454 | 26,237 | 41,673 | 45,791 | 46,824 |
| Expenses + | 11,437 | 14,191 | 18,281 | 19,826 | 25,387 | 28,287 | 18,718 | 16,992 | 23,472 | 36,580 | 37,848 | 38,521 |
| Operating Profit | 422 | 1,517 | 2,979 | 3,045 | 4,248 | 4,910 | 3,233 | 2,462 | 2,765 | 5,093 | 7,943 | 8,303 |
| OPM % | 4% | 10% | 14% | 13% | 14% | 15% | 15% | 13% | 11% | 12% | 17% | 18% |
| Other Income + | 613 | -106 | -321 | 406 | 190 | 139 | 57 | 207 | -230 | 166 | 73 | 56 |
| Interest | 805 | 872 | 925 | 1,049 | 1,227 | 1,502 | 1,802 | 1,901 | 1,869 | 2,094 | 2,982 | 3,231 |
| Depreciation | 530 | 580 | 524 | 573 | 646 | 676 | 750 | 836 | 866 | 900 | 927 | 936 |
| Profit before tax | -300 | -42 | 1,209 | 1,829 | 2,565 | 2,872 | 739 | -67 | -200 | 2,265 | 4,106 | 4,192 |
| Tax % | -23% | 415% | 41% | 11% | 29% | 24% | 38% | 4% | 43% | 40% | 34% |  |
| Net Profit + | -222 | -205 | 712 | 1,633 | 1,814 | 2,195 | 460 | -70 | -285 | 1,359 | 2,696 | 2,662 |
| EPS in Rs | -0.62 | 0.47 | 2.40 | 5.58 | 6.01 | 7.08 | 1.15 | -0.56 | -1.22 | 4.22 | 8.46 | 8.34 |
| Dividend Payout % | 0% | 96% | 40% | 28% | 40% | 44% | 44% | -107% | -82% | 62% | 59% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 33% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 206% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -104 | 95 | -1,275 | 270 | 1,462 | -3,745 | 383 | -1,065 | 2,845 | -4,499 | -6,258 |
| Cash from Investing Activity + | -378 | -124 | 456 | -1,676 | -3,163 | 1,897 | -1,201 | -973 | -1,917 | -2,904 | 1,135 |
| Cash from Financing Activity + | 461 | 781 | 1,660 | 738 | 1,905 | 2,398 | 1,239 | 1,331 | -378 | 7,281 | 8,432 |
| Net Cash Flow | -20 | 752 | 841 | -668 | 205 | 549 | 421 | -707 | 550 | -122 | 3,309 |

## Ratios Data
| Unknown | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 43 | 31 | 25 | 20 | 14 | 30 | 25 | 57 | 45 | 37 | 31 |
| Inventory Days | 69 | 58 | 50 | 73 | 42 | 52 | 42 | 76 | 53 | 44 | 50 |
| Days Payable | 116 | 108 | 71 | 85 | 96 | 88 | 90 | 162 | 150 | 96 | 85 |
| Cash Conversion Cycle | -5 | -19 | 5 | 8 | -39 | -6 | -22 | -30 | -52 | -16 | -4 |
| Working Capital Days | -6 | -22 | -5 | -5 | -31 | 10 | 16 | 113 | 68 | 66 | 66 |
| ROCE % |  | 8% | 17% | 15% | 17% | 16% | 9% | 5% | 6% | 11% | 15% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 51.54% | 51.54% | 51.54% | 51.54% | 51.54% | 51.53% | 51.53% | 51.53% | 51.53% | 51.53% | 51.52% | 51.52% |
| FIIs + | 16.33% | 15.05% | 13.45% | 15.03% | 17.59% | 15.29% | 14.85% | 16.59% | 20.21% | 20.48% | 21.45% | 22.03% |
| DIIs + | 19.55% | 20.65% | 21.94% | 21.73% | 19.50% | 21.16% | 22.15% | 20.79% | 16.51% | 14.66% | 12.23% | 14.12% |
| Government + | 0.08% | 0.08% | 0.08% | 0.08% | 0.07% | 0.07% | 0.07% | 0.07% | 0.07% | 0.07% | 0.07% | 0.07% |
| Public + | 12.50% | 12.68% | 12.99% | 11.62% | 11.29% | 11.94% | 11.40% | 11.02% | 11.66% | 13.25% | 14.72% | 12.24% |
| No. of Shareholders | 10,36,773 | 11,60,873 | 12,42,008 | 11,20,964 | 10,96,220 | 11,30,372 | 11,18,107 | 10,99,982 | 12,06,482 | 13,39,744 | 14,91,397 | 14,75,874 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 50.38% | 51.27% | 51.12% | 51.54% | 51.54% | 51.54% | 51.53% | 51.52% | 51.52% |
| FIIs + | 17.89% | 23.26% | 19.06% | 16.94% | 18.08% | 13.45% | 14.85% | 21.45% | 22.03% |
| DIIs + | 9.79% | 11.07% | 10.00% | 14.98% | 16.72% | 21.94% | 22.15% | 12.23% | 14.12% |
| Government + | 0.08% | 0.08% | 0.08% | 0.08% | 0.08% | 0.08% | 0.07% | 0.07% | 0.07% |
| Public + | 21.86% | 14.32% | 19.74% | 16.46% | 13.58% | 12.99% | 11.40% | 14.72% | 12.24% |
| No. of Shareholders | 5,18,972 | 4,81,404 | 8,62,936 | 9,51,725 | 10,05,180 | 12,42,008 | 11,18,107 | 14,91,397 | 14,75,874 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/ashok-leyland-ltd/ashokley/500477/corp-announcements/)
- [Shareholder Meeting / Postal Ballot-Outcome of AGM 16h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c84c0b30-38b2-426a-bacf-35e9fd3d95c7.pdf)
- [Announcement under Regulation 30 (LODR)-Change in Directorate 22h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=229b7896-5a48-4cae-affc-fb0d3471574a.pdf)
- [Contact Details Of Key Managerial Personnel, To Determine Materiality Of An Event Or Information Under Regulation 30 Of SEBI Listing Regulations 22h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b2d84eb-8dde-4f73-958c-69ab16b2eca3.pdf)
- [Announcement Under Regn 30 (LODR)](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6e8e76fe-6b5c-49b4-ac44-23c6e74dc420.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0206ce4c-a83b-4946-8d59-b5f0196cd0f8.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2ff1a8a1-f253-4fdb-afc0-2b9544fd5094.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\81c97bce-6af2-475d-a4c3-5c76934179e1.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/73509500477.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/69484500477.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500477/5004770311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ASHOKLEY_2009_2010_18082010121500.zip)

## Credit Ratings
- [Rating update
12 Oct 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=122895)
- [Rating update
4 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310131050_Ashok_Leyland_Limited.pdf)
- [Rating update
7 Nov 2022 from care](https://www.careratings.com/upload/CompanyFiles/PR/07112022061800_Ashok_Leyland_Limited.pdf)
- [Rating update
31 Oct 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=115495)
- [Rating update
28 Jan 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=109614)
- [](https://www.careratings.com/upload/CompanyFiles/PR/07012022074329_Ashok_Leyland_Limited.pdf)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3996a258-24c9-4356-8908-044b1b41c146.pdf)
- [REC](https://al-website-uat-contents.s3.ap-south-1.amazonaws.com/uploads/2024/05/ENA0820240524153357.mp3?X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAZC5D6DIGERJ3UP44%2F20240528%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20240528T072712Z&X-Amz-SignedHeaders=host&X-Amz-Expires=28800&X-Amz-Signature=4f155a79340d9e47dda07fda06c0f0d0eed17eb4a8cb859351affbadc026067d)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da8d4f9c-cfc2-44cb-b7b3-c6518c2f3606.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5a8dd3ba-1c6b-4a4d-9310-30fb3e600e91.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81d9af88-f09b-46cf-9d71-911fe2dbbb91.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba8fba79-a510-4e87-aa8d-c3b3d3f33079.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a0568a85-cfd2-4097-823f-d2014223dea7.pdf)
- [Transcript](https://www.ashokleyland.com/backend/in/conference-call-transcripts/conference-call-transcript-q3-fy-23-2nd-feb-23-clean-v3/#toolbar=0)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2022/02/Emkay-AshokLeyland-15Nov-20211.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/08/AL-Q1-FY-22-Con-call-trasncript-13-08-2021-clean-version.docx)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c9130dd-6378-404a-aea0-57d36a920527.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/07/AL-con-call-transcript-25th-June-21-Clean.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/05/Q-3-FY-21-analyst-call-transcript-Final.doc)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0f6527a1-a0b1-43d0-8d15-a86953d0196d.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q2-FY-21-Analyst-conference-call-transcript.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q1-FY-21-Analyst-call-transcript.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q4-conference-call-transcriptJun26-2020.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q3-2020-Analyst-call-transcript-clean-version.docx)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q-2-Transcript-clean-version-1.doc)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9a005e7d-6379-4853-874a-64c4408bb613.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/MOSL-AL-Transcript-clean-version.doc)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/BK-Sec-Concall-Transcript-Q4-FY-2019-May24-2019-Clean.docx)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/AxisCap-AshokeLeyland-15Feb-2019-Rajan-v2.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/Q2-FY19-Concall-Transcript.pdf)
- [](https://www.ashokleyland.com/backend/in/wp-content/uploads/sites/2/2021/01/BKSec-AsholLeyland-Nov09-2017-V2.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Tata Motors | 1105.80 | 406080.65 | 12.59 | 4.29 | 0.93 | 21.00 | 7.06 | 49.28 | 0.27 | 20.11 | 9.26 | 49.44 | 1.24 | 1.26 | 3.90 | 4.15 | 437927.77 | 13.60 | 32193.28 | 119986.31 | 17482.35 | 13.27 | 213.80 | 94.47 | 107262.50 | 46.36 | 0.00 | 8.42 | 27.33 | 0.00 | 26.58 | 1265.71 | 467536.46 | 0.88 | 0.14 | 9.15 | 34.38 | 55.28 | 69.48 | 14.63 | 5.84 | 93.11 | 128.07 | 7.72 | 20.58 | 5.25 | 6.30 | 0.61 | 94.47 | 88.17 | 18.77 | 18.55 | 18.03 | -47.68 | 332.13 |
| 2. | Ashok Leyland | 246.70 | 72441.72 | 28.99 | 7.97 | 1.55 | -21.19 | 12.57 | 25.65 | 1.97 | 15.01 | 4.42 | 28.35 | 0.75 | 4.53 | 2.32 | 6.79 | 46823.81 | 17.73 | 2497.57 | 10724.49 | 506.40 | 10.66 | -6.17 | 8.34 | 40802.18 | 51.42 | -0.02 | 7.36 | 27.33 | 22.10 | 9.16 | 44.00 | 106163.85 | 1.05 | 7.18 | 25.64 | 36.92 | 23.83 | 27.78 | 15.68 | 10.07 | 4.04 | 205.53 | 6.64 | 33.02 | 15.05 | 11.44 | 0.90 | 8.46 | 4.04 | 27.21 | 35.66 | 22.64 | -3.77 | 293.61 |
| 3. | Tata Motors-DVR | 756.55 | 38470.85 |  |  |  |  |  | 60.16 | 0.40 |  |  |  |  |  |  |  |  |  |  | 7769.67 | 1251.40 | -26.91 | 372.94 |  |  | 7.67 | 0.00 |  | 27.33 | 0.00 |  |  |  |  |  | 11.08 | 38.91 | 76.72 | 78.21 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 4. | Olectra Greentec | 1714.40 | 14071.92 | 183.18 | 15.45 | 12.19 | 988.43 | 75.57 | 55.43 | 0.02 | 14.79 | 5.00 | 8.76 | 0.73 | 0.13 | 3.46 | 1.72 | 1154.14 | 14.37 | 76.83 | 288.81 | 13.71 | -23.17 | -49.24 | 9.36 | 120.75 | 50.02 | 0.00 | 1.07 | 27.33 | 0.00 | 5.81 | 17.15 | 14018.13 | 1.88 | 3.94 | -2.50 | 0.23 | 85.44 | 40.22 | 7.34 | 4.82 | 46.55 | 111.68 | 46.66 | 60.07 | 8.11 | 13.29 | 1.53 | 9.36 | 45.87 | 148.84 | 146.69 | 124.71 | 85.59 | 8.21 |
| 5. | Force Motors | 8467.25 | 11159.82 | 28.75 | 4.99 | 1.60 | 43.62 | 12.03 | 48.29 | 0.11 | 23.77 | 9.21 | 18.79 | 1.66 | 0.23 | 10.74 | 1.87 | 6992.13 | 12.80 | 388.09 | 2011.21 | 140.26 | 34.96 | 259.90 | 294.54 | 524.50 | 61.63 | 0.00 | 6.12 | 27.33 | 0.00 | 39.04 | 1119.40 | 11235.56 | 1.25 | 1.30 | -14.54 | 133.09 | 75.30 | 223.37 | 5.79 | 3.23 | 22.06 | 79.99 | 13.87 | 52.07 | 1.76 | 4.73 | 0.54 | 294.54 | 22.06 | 25.66 | 31.57 | 20.13 | 27.43 | 1.32 |
| 6. | SML ISUZU | 2040.00 | 2951.86 | 27.40 | 10.34 | 1.34 | -117.21 | 18.04 | 26.51 | 0.00 | 23.81 | 10.04 | 46.55 | 2.04 | 1.48 | 4.51 | 3.76 | 2195.93 | 8.15 | 107.88 | 679.60 | 52.32 | 16.53 | 95.30 | 74.55 | 421.27 | 43.96 | 0.00 | 4.17 | 27.33 | 0.00 | 20.55 | 443.75 | 3324.44 | 1.01 | 0.67 | -10.80 | 54.91 | 52.16 | 92.12 | 4.58 | -9.55 | 40.87 | 41.06 | 9.28 | 54.88 | 11.69 | 9.39 | 0.30 | 74.55 | 40.87 | 49.47 | 35.16 | 57.54 | 81.38 | 1.45 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| ASHOKLEY | Market Cap | ₹ 72,500 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | Sales | ₹ 46,824 Cr. |
| ASHOKLEY | OPM | 17.7 % |
| ASHOKLEY | Profit after tax | ₹ 2,498 Cr. |
| ASHOKLEY | Mar Cap | ₹ 72,500 Cr. |
| ASHOKLEY | Sales Qtr | ₹ 10,724 Cr. |
| ASHOKLEY | PAT Qtr | ₹ 506 Cr. |
| ASHOKLEY | Qtr Sales Var | 10.7 % |
| ASHOKLEY | Qtr Profit Var | -6.17 % |
| ASHOKLEY | Price to Earning | 29.0 |
| ASHOKLEY | Dividend yield | 1.97 % |
| ASHOKLEY | Price to book value | 7.97 |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | Return on assets | 4.42 % |
| ASHOKLEY | Debt to equity | 4.53 |
| ASHOKLEY | Return on equity | 28.4 % |
| ASHOKLEY | EPS | ₹ 8.34 |
| ASHOKLEY | Debt | ₹ 40,802 Cr. |
| ASHOKLEY | Promoter holding | 51.4 % |
| ASHOKLEY | Change in Prom Hold | -0.02 % |
| ASHOKLEY | Earnings yield | 7.36 % |
| ASHOKLEY | Pledged percentage | 22.1 % |
| ASHOKLEY | Industry PE | 27.3 |
| ASHOKLEY | Sales growth | 9.16 % |
| ASHOKLEY | Profit growth | 44.0 % |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | Price to Sales | 1.55 |
| ASHOKLEY | CMP / FCF | -21.2 |
| ASHOKLEY | EVEBITDA | 12.6 |
| ASHOKLEY | Enterprise Value | ₹ 1,06,223 Cr. |
| ASHOKLEY | Current ratio | 1.05 |
| ASHOKLEY | Int Coverage | 2.32 |
| ASHOKLEY | PEG Ratio | 7.18 |
| ASHOKLEY | Return over 3months | 25.6 % |
| ASHOKLEY | Return over 6months | 36.9 % |
| ASHOKLEY | No. Eq. Shares | 294 |
| ASHOKLEY | Sales growth 3Years | 33.0 % |
| ASHOKLEY | Sales growth 5Years | 6.64 % |
| ASHOKLEY | Profit Var 3Yrs | 206 % |
| ASHOKLEY | Profit Var 5Yrs | 4.04 % |
| ASHOKLEY | ROE 5Yr | 10.1 % |
| ASHOKLEY | ROE 3Yr | 15.7 % |
| ASHOKLEY | Return over 1year | 27.8 % |
| ASHOKLEY | Return over 3years | 23.8 % |
| ASHOKLEY | Return over 5years | 25.6 % |
| ASHOKLEY | Market Cap | ₹ 72,500 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | Sales last year | ₹ 45,791 Cr. |
| ASHOKLEY | OP Ann | ₹ 7,943 Cr. |
| ASHOKLEY | Other Inc Ann | ₹ 72.7 Cr. |
| ASHOKLEY | EBIDT last year | ₹ 8,025 Cr. |
| ASHOKLEY | Dep Ann | ₹ 927 Cr. |
| ASHOKLEY | EBIT last year | ₹ 7,098 Cr. |
| ASHOKLEY | Interest last year | ₹ 2,982 Cr. |
| ASHOKLEY | PBT Ann | ₹ 4,106 Cr. |
| ASHOKLEY | Tax last year | ₹ 1,410 Cr. |
| ASHOKLEY | PAT Ann | ₹ 2,489 Cr. |
| ASHOKLEY | Extra Ord Item Ann | ₹ -9.34 Cr. |
| ASHOKLEY | NP Ann | ₹ 2,696 Cr. |
| ASHOKLEY | Dividend last year | ₹ 1,453 Cr. |
| ASHOKLEY | Raw Material | 63.8 % |
| ASHOKLEY | Employee cost | ₹ 3,723 Cr. |
| ASHOKLEY | OPM last year | 17.4 % |
| ASHOKLEY | NPM last year | 5.90 % |
| ASHOKLEY | Operating profit | ₹ 8,303 Cr. |
| ASHOKLEY | Interest | ₹ 3,231 Cr. |
| ASHOKLEY | Depreciation | ₹ 936 Cr. |
| ASHOKLEY | EPS last year | ₹ 8.46 |
| ASHOKLEY | EBIT | ₹ 7,510 Cr. |
| ASHOKLEY | Net profit | ₹ 2,662 Cr. |
| ASHOKLEY | Current Tax | ₹ 1,524 Cr. |
| ASHOKLEY | Tax | ₹ 1,530 Cr. |
| ASHOKLEY | Other income | ₹ 55.8 Cr. |
| ASHOKLEY | Ann Date | 2,02,403 |
| ASHOKLEY | Sales Prev Ann | ₹ 41,673 Cr. |
| ASHOKLEY | OP Prev Ann | ₹ 5,093 Cr. |
| ASHOKLEY | Other Inc Prev Ann | ₹ 166 Cr. |
| ASHOKLEY | EBIDT Prev Ann | ₹ 5,171 Cr. |
| ASHOKLEY | Dep Prev Ann | ₹ 900 Cr. |
| ASHOKLEY | EBIT preceding year | ₹ 4,271 Cr. |
| ASHOKLEY | Interest Prev Ann | ₹ 2,094 Cr. |
| ASHOKLEY | PBT Prev Ann | ₹ 2,265 Cr. |
| ASHOKLEY | Tax preceding year | ₹ 906 Cr. |
| ASHOKLEY | PAT Prev Ann | ₹ 1,193 Cr. |
| ASHOKLEY | Extra Ord Prev Ann | ₹ 87.8 Cr. |
| ASHOKLEY | NP Prev Ann | ₹ 1,359 Cr. |
| ASHOKLEY | Dividend Prev Ann | ₹ 763 Cr. |
| ASHOKLEY | OPM preceding year | 12.2 % |
| ASHOKLEY | NPM preceding year | 3.14 % |
| ASHOKLEY | EPS preceding year | ₹ 4.22 |
| ASHOKLEY | Sales Prev 12M | ₹ 45,791 Cr. |
| ASHOKLEY | Profit Prev 12M | ₹ 2,696 Cr. |
| ASHOKLEY | Med Sales Gwth 10Yrs | 12.0 % |
| ASHOKLEY | Med Sales Gwth 5Yrs | 9.88 % |
| ASHOKLEY | Sales growth 7Years | 10.4 % |
| ASHOKLEY | Sales Var 10Yrs | 14.5 % |
| ASHOKLEY | EBIDT growth 3Years | 45.9 % |
| ASHOKLEY | EBIDT growth 5Years | 9.93 % |
| ASHOKLEY | EBIDT growth 7Years | 13.1 % |
| ASHOKLEY | EBIDT Var 10Yrs | 31.9 % |
| ASHOKLEY | EPS growth 3Years | 206 % |
| ASHOKLEY | EPS growth 5Years | 4.04 % |
| ASHOKLEY | EPS growth 7Years | 6.63 % |
| ASHOKLEY | EPS growth 10Years | 20.3 % |
| ASHOKLEY | Profit Var 7Yrs | 7.10 % |
| ASHOKLEY | Profit Var 10Yrs | 21.2 % |
| ASHOKLEY | Chg in Prom Hold 3Yr | -0.06 % |
| ASHOKLEY | Market Cap | ₹ 72,500 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | OP Qtr | ₹ 1,868 Cr. |
| ASHOKLEY | Other Inc Qtr | ₹ 35.9 Cr. |
| ASHOKLEY | EBIDT Qtr | ₹ 1,900 Cr. |
| ASHOKLEY | Dep Qtr | ₹ 235 Cr. |
| ASHOKLEY | EBIT latest quarter | ₹ 1,664 Cr. |
| ASHOKLEY | Interest Qtr | ₹ 904 Cr. |
| ASHOKLEY | PBT Qtr | ₹ 765 Cr. |
| ASHOKLEY | Tax latest quarter | ₹ 215 Cr. |
| ASHOKLEY | Extra Ord Item Qtr | ₹ 4.88 Cr. |
| ASHOKLEY | NP Qtr | ₹ 551 Cr. |
| ASHOKLEY | GPM latest quarter | 38.5 % |
| ASHOKLEY | OPM latest quarter | 17.4 % |
| ASHOKLEY | NPM latest quarter | 5.11 % |
| ASHOKLEY | Eq Cap Qtr | ₹ 294 Cr. |
| ASHOKLEY | EPS latest quarter | ₹ 1.73 |
| ASHOKLEY | OP 2Qtr Bk | ₹ 1,961 Cr. |
| ASHOKLEY | OP 3Qtr Bk | ₹ 1,870 Cr. |
| ASHOKLEY | Sales 2Qtr Bk | ₹ 11,093 Cr. |
| ASHOKLEY | Sales 3Qtr Bk | ₹ 11,429 Cr. |
| ASHOKLEY | NP 2Qtr Bk | ₹ 609 Cr. |
| ASHOKLEY | NP 3Qtr Bk | ₹ 569 Cr. |
| ASHOKLEY | Opert Prft Gwth | 42.4 % |
| ASHOKLEY | Last result date | 2,02,406 |
| ASHOKLEY | Exp Qtr Sales Var | 9.49 % |
| ASHOKLEY | Exp Qtr Sales | ₹ 12,514 Cr. |
| ASHOKLEY | Exp Qtr OP | ₹ 2,156 Cr. |
| ASHOKLEY | Exp Qtr NP | ₹ 996 Cr. |
| ASHOKLEY | Exp Qtr EPS | ₹ 3.14 |
| ASHOKLEY | Sales Prev Qtr | ₹ 13,578 Cr. |
| ASHOKLEY | OP Prev Qtr | ₹ 2,603 Cr. |
| ASHOKLEY | Other Inc Prev Qtr | ₹ -24.7 Cr. |
| ASHOKLEY | EBIDT Prev Qtr | ₹ 2,644 Cr. |
| ASHOKLEY | Dep Prev Qtr | ₹ 233 Cr. |
| ASHOKLEY | EBIT Prev Qtr | ₹ 2,411 Cr. |
| ASHOKLEY | Interest Prev Qtr | ₹ 829 Cr. |
| ASHOKLEY | PBT Prev Qtr | ₹ 1,516 Cr. |
| ASHOKLEY | Tax Prev Qtr | ₹ 582 Cr. |
| ASHOKLEY | PAT Prev Qtr | ₹ 891 Cr. |
| ASHOKLEY | Extra Ord Prev Qtr | ₹ -66.2 Cr. |
| ASHOKLEY | NP Prev Qtr | ₹ 934 Cr. |
| ASHOKLEY | OPM Prev Qtr | 19.2 % |
| ASHOKLEY | NPM Prev Qtr | 7.18 % |
| ASHOKLEY | Eq Cap Prev Qtr | ₹ 294 Cr. |
| ASHOKLEY | EPS Prev Qtr | ₹ 2.91 |
| ASHOKLEY | Sales PY Qtr | ₹ 9,691 Cr. |
| ASHOKLEY | OP PY Qtr | ₹ 1,509 Cr. |
| ASHOKLEY | Other Inc PY Qtr | ₹ 52.8 Cr. |
| ASHOKLEY | EBIDT PY Qtr | ₹ 1,554 Cr. |
| ASHOKLEY | Dep PY Qtr | ₹ 227 Cr. |
| ASHOKLEY | EBIT PY Qtr | ₹ 1,327 Cr. |
| ASHOKLEY | Interest PY Qtr | ₹ 655 Cr. |
| ASHOKLEY | PBT PY Qtr | ₹ 679 Cr. |
| ASHOKLEY | Tax PY Qtr | ₹ 94.9 Cr. |
| ASHOKLEY | Market Cap | ₹ 72,471 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | Equity capital | ₹ 294 Cr. |
| ASHOKLEY | Preference capital | ₹ 0.00 Cr. |
| ASHOKLEY | Reserves | ₹ 8,711 Cr. |
| ASHOKLEY | Secured loan | ₹ 27,566 Cr. |
| ASHOKLEY | Unsecured loan | ₹ 13,237 Cr. |
| ASHOKLEY | Balance sheet total | ₹ 67,595 Cr. |
| ASHOKLEY | Gross block | ₹ 15,088 Cr. |
| ASHOKLEY | Revaluation reserve | ₹ 0.00 Cr. |
| ASHOKLEY | Accum Dep | ₹ 6,931 Cr. |
| ASHOKLEY | Net block | ₹ 8,157 Cr. |
| ASHOKLEY | CWIP | ₹ 415 Cr. |
| ASHOKLEY | Investments | ₹ 2,329 Cr. |
| ASHOKLEY | Current assets | ₹ 28,103 Cr. |
| ASHOKLEY | Current liabilities | ₹ 26,680 Cr. |
| ASHOKLEY | BV Unq Invest | ₹ 22.9 Cr. |
| ASHOKLEY | MV Quoted Inv | ₹ 0.00 Cr. |
| ASHOKLEY | Cont Liab | ₹ 449 Cr. |
| ASHOKLEY | Total Assets | ₹ 67,595 Cr. |
| ASHOKLEY | Working capital | ₹ 15,379 Cr. |
| ASHOKLEY | Lease liabilities | ₹ 238 Cr. |
| ASHOKLEY | Inventory | ₹ 4,008 Cr. |
| ASHOKLEY | Trade receivables | ₹ 3,898 Cr. |
| ASHOKLEY | Face value | ₹ 1.00 |
| ASHOKLEY | Cash Equivalents | ₹ 7,080 Cr. |
| ASHOKLEY | Adv Cust | ₹ 258 Cr. |
| ASHOKLEY | Trade Payables | ₹ 6,798 Cr. |
| ASHOKLEY | No. Eq. Shares PY | 294 |
| ASHOKLEY | Debt preceding year | ₹ 31,161 Cr. |
| ASHOKLEY | Work Cap PY | ₹ 9,746 Cr. |
| ASHOKLEY | Net Block PY | ₹ 8,146 Cr. |
| ASHOKLEY | Gross Block PY | ₹ 14,245 Cr. |
| ASHOKLEY | CWIP PY | ₹ 268 Cr. |
| ASHOKLEY | Work Cap 3Yr | ₹ 7,818 Cr. |
| ASHOKLEY | Work Cap 5Yr | ₹ 2,691 Cr. |
| ASHOKLEY | Work Cap 7Yr | ₹ 764 Cr. |
| ASHOKLEY | Work Cap 10Yr | ₹ -74.7 Cr. |
| ASHOKLEY | Debt 3Years back | ₹ 24,077 Cr. |
| ASHOKLEY | Debt 5Years back | ₹ 19,168 Cr. |
| ASHOKLEY | Debt 7Years back | ₹ 13,168 Cr. |
| ASHOKLEY | Debt 10Years back | ₹ 8,500 Cr. |
| ASHOKLEY | Net Block 3Yrs Back | ₹ 8,484 Cr. |
| ASHOKLEY | Net Block 5Yrs Back | ₹ 6,695 Cr. |
| ASHOKLEY | Net Block 7Yrs Back | ₹ 6,591 Cr. |
| ASHOKLEY | Market Cap | ₹ 72,471 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | CF Operations | ₹ -6,258 Cr. |
| ASHOKLEY | Free Cash Flow | ₹ -7,346 Cr. |
| ASHOKLEY | CF Investing | ₹ 1,135 Cr. |
| ASHOKLEY | CF Financing | ₹ 8,432 Cr. |
| ASHOKLEY | Net CF | ₹ 3,309 Cr. |
| ASHOKLEY | Cash Beginning | ₹ 1,909 Cr. |
| ASHOKLEY | Cash End | ₹ 7,080 Cr. |
| ASHOKLEY | FCF Prev Ann | ₹ -5,353 Cr. |
| ASHOKLEY | CF Operations PY | ₹ -4,499 Cr. |
| ASHOKLEY | CF Investing PY | ₹ -2,904 Cr. |
| ASHOKLEY | CF Financing PY | ₹ 7,281 Cr. |
| ASHOKLEY | Net CF PY | ₹ -122 Cr. |
| ASHOKLEY | Cash Beginning PY | ₹ 2,031 Cr. |
| ASHOKLEY | Cash End PY | ₹ 2,187 Cr. |
| ASHOKLEY | Free Cash Flow 3Yrs | ₹ -10,256 Cr. |
| ASHOKLEY | Free Cash Flow 5Yrs | ₹ -12,987 Cr. |
| ASHOKLEY | Free Cash Flow 7Yrs | ₹ -17,005 Cr. |
| ASHOKLEY | Free Cash Flow 10Yrs | ₹ -18,340 Cr. |
| ASHOKLEY | CF Opr 3Yrs | ₹ -7,913 Cr. |
| ASHOKLEY | CF Opr 5Yrs | ₹ -8,595 Cr. |
| ASHOKLEY | CF Opr 7Yrs | ₹ -10,878 Cr. |
| ASHOKLEY | CF Opr 10Yrs | ₹ -11,787 Cr. |
| ASHOKLEY | CF Inv 10Yrs | ₹ -8,470 Cr. |
| ASHOKLEY | CF Inv 7Yrs | ₹ -7,125 Cr. |
| ASHOKLEY | CF Inv 5Yrs | ₹ -5,860 Cr. |
| ASHOKLEY | CF Inv 3Yrs | ₹ -3,686 Cr. |
| ASHOKLEY | Cash 3Years back | ₹ 1,779 Cr. |
| ASHOKLEY | Cash 5Years back | ₹ 1,777 Cr. |
| ASHOKLEY | Cash 7Years back | ₹ 1,064 Cr. |
| ASHOKLEY | Market Cap | ₹ 72,471 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | No. Eq. Shares | 294 |
| ASHOKLEY | Book value | ₹ 30.7 |
| ASHOKLEY | Inven TO | 7.93 |
| ASHOKLEY | Quick ratio | 0.90 |
| ASHOKLEY | Exports percentage | 8.18 % |
| ASHOKLEY | Piotroski score | 5.00 |
| ASHOKLEY | G Factor | 4.00 |
| ASHOKLEY | Asset Turnover | 0.75 |
| ASHOKLEY | Financial leverage | 6.79 |
| ASHOKLEY | No. of Share Holders | 14,75,874 |
| ASHOKLEY | Unpledged Prom Hold | 40.1 % |
| ASHOKLEY | ROIC | 19.8 % |
| ASHOKLEY | Debtor days | 31.1 |
| ASHOKLEY | Industry PBV | 7.58 |
| ASHOKLEY | Credit rating |  |
| ASHOKLEY | WC Days | 66.2 |
| ASHOKLEY | Earning Power | 11.1 % |
| ASHOKLEY | Graham Number | ₹ 75.9 |
| ASHOKLEY | Cash Cycle | -3.77 |
| ASHOKLEY | Days Payable | 84.9 |
| ASHOKLEY | Days Receivable | 31.1 |
| ASHOKLEY | Inventory Days | 50.0 |
| ASHOKLEY | Public holding | 12.2 % |
| ASHOKLEY | FII holding | 22.0 % |
| ASHOKLEY | Chg in FII Hold | 0.58 % |
| ASHOKLEY | DII holding | 14.1 % |
| ASHOKLEY | Chg in DII Hold | 1.89 % |
| ASHOKLEY | B.V. Prev Ann | ₹ 29.1 |
| ASHOKLEY | ROCE Prev Yr | 11.4 % |
| ASHOKLEY | ROA Prev Yr | 2.66 % |
| ASHOKLEY | ROE Prev Ann | 15.0 % |
| ASHOKLEY | No. of Share Holders Prev Qtr | 14,91,397 |
| ASHOKLEY | No. Eq. Shares 10 Yrs | 285 |
| ASHOKLEY | BV 3yrs back | ₹ 26.8 |
| ASHOKLEY | BV 5yrs back | ₹ 26.5 |
| ASHOKLEY | BV 10yrs back | ₹ 15.8 |
| ASHOKLEY | Inven TO 3Yr | 6.04 |
| ASHOKLEY | Inven TO 5Yr | 5.85 |
| ASHOKLEY | Inven TO 7Yr | 7.53 |
| ASHOKLEY | Inven TO 10Yr | 6.58 |
| ASHOKLEY | Export 3Yr | 0.00 % |
| ASHOKLEY | Export 5Yr | 0.00 % |
| ASHOKLEY | Div 5Yrs | ₹ 567 Cr. |
| ASHOKLEY | ROCE 3Yr | 10.8 % |
| ASHOKLEY | ROCE 5Yr | 9.28 % |
| ASHOKLEY | ROCE 7Yr | 11.4 % |
| ASHOKLEY | ROCE 10Yr | 12.0 % |
| ASHOKLEY | ROE 10Yr | 13.0 % |
| ASHOKLEY | ROE 7Yr | 14.2 % |
| ASHOKLEY | ROE 5Yr Var | 2.34 % |
| ASHOKLEY | OPM 5Year | 13.9 % |
| ASHOKLEY | OPM 10Year | 13.8 % |
| ASHOKLEY | No. of Share Holders 1Yr | 10,99,982 |
| ASHOKLEY | Avg Div Payout 3Yrs | 12.8 % |
| ASHOKLEY | Debtor days 3yrs | 37.7 |
| ASHOKLEY | Debtor days 3yrs back | 56.7 |
| ASHOKLEY | Debtor days 5yrs back | 29.9 |
| ASHOKLEY | ROA 5Yr | 1.68 % |
| ASHOKLEY | ROA 3Yr | 2.46 % |
| ASHOKLEY | Market Cap | ₹ 72,471 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | Avg Vol 1Mth | 1,24,33,079 |
| ASHOKLEY | Avg Vol 1Wk | 1,74,97,531 |
| ASHOKLEY | Volume | 2,23,47,439 |
| ASHOKLEY | High price | ₹ 248 |
| ASHOKLEY | Low price | ₹ 158 |
| ASHOKLEY | High price all time | ₹ 248 |
| ASHOKLEY | Low price all time | ₹ 6.15 |
| ASHOKLEY | Return over 1day | 6.18 % |
| ASHOKLEY | Return over 1week | 3.79 % |
| ASHOKLEY | Return over 1month | -3.23 % |
| ASHOKLEY | DMA 50 | ₹ 223 |
| ASHOKLEY | DMA 200 | ₹ 195 |
| ASHOKLEY | DMA 50 previous day | ₹ 223 |
| ASHOKLEY | 200 DMA prev. | ₹ 195 |
| ASHOKLEY | RSI | 54.5 |
| ASHOKLEY | MACD | 0.56 |
| ASHOKLEY | MACD Previous Day | 0.35 |
| ASHOKLEY | MACD Signal | 0.70 |
| ASHOKLEY | MACD Signal Prev | 0.73 |
| ASHOKLEY | Avg Vol 1Yr | 1,60,64,507 |
| ASHOKLEY | Return over 7years | 11.4 % |
| ASHOKLEY | Return over 10years | 21.6 % |
| ASHOKLEY | Market Cap | ₹ 72,471 Cr. |
| ASHOKLEY | Current Price | ₹ 247 |
| ASHOKLEY | High / Low | ₹ 248 / 158 |
| ASHOKLEY | Stock P/E | 29.0 |
| ASHOKLEY | Book Value | ₹ 30.7 |
| ASHOKLEY | Dividend Yield | 1.97 % |
| ASHOKLEY | ROCE | 15.0 % |
| ASHOKLEY | ROE | 28.4 % |
| ASHOKLEY | Face Value | ₹ 1.00 |
| ASHOKLEY | WC to Sales | 32.8 % |
| ASHOKLEY | QoQ Profits | -41.0 % |
| ASHOKLEY | QoQ Sales | -21.0 % |
| ASHOKLEY | Net worth | ₹ 9,005 Cr. |
| ASHOKLEY | Market Cap to Sales | 1.55 |
| ASHOKLEY | Interest Coverage | 2.32 |
| ASHOKLEY | EV / EBIT | 14.1 |
| ASHOKLEY | Debt Capacity | -0.51 |
| ASHOKLEY | Debt To Profit | 15.1 |
| ASHOKLEY | Capital Employed | ₹ 23,950 Cr. |
| ASHOKLEY | CROIC | -7.23 % |
| ASHOKLEY | debtplus | 4.58 |
| ASHOKLEY | Leverage | ₹ 6.79 |
| ASHOKLEY | Dividend Payout | 58.5 % |
| ASHOKLEY | Intrinsic Value | ₹ 66.3 |
| ASHOKLEY | CDL | -47.2 % |
| ASHOKLEY | Cash by market cap | 0.06 |
| ASHOKLEY | 52w Index | 98.2 % |
| ASHOKLEY | Down from 52w high | 0.64 % |
| ASHOKLEY | Up from 52w low | 56.6 % |
| ASHOKLEY | From 52w high | 0.99 |
| ASHOKLEY | Mkt Cap To Debt Cap | -3.37 |
| ASHOKLEY | Dividend Payout | 58.5 % |
| ASHOKLEY | Graham | ₹ 75.9 |
| ASHOKLEY | Price to Cash Flow | -11.6 |
| ASHOKLEY | ROCE3yr avg | 10.8 % |
| ASHOKLEY | PB X PE | 231 |
| ASHOKLEY | NCAVPS | ₹ 52.4 |
| ASHOKLEY | Mar Cap to CF | -11.6 |
| ASHOKLEY | Altman Z Score | 3.23 |
| ASHOKLEY | M.Cap / Qtr Profit | 143 |