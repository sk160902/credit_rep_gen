# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/bharat-heavy-electricals-ltd/bhel/500103/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
1d - Published Notice of 60th AGM, Record Date & other related information](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=720e2a12-0ddf-4f27-a0fa-91f7b1b09bcf.pdf)
- [Board Meeting Intimation for Unaudited Financial Results For The Quarter Ended 30Th June, 2024 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=303e2fc4-72e6-4f1c-8bf3-7a2f8c85fb2f.pdf)
- [Intimation Of Record Date For Final Dividend For FY 2023-24 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa630432-03bd-49a6-995f-8c4c1c9e78e0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bff2633f-f8ba-43ff-a13b-1517ebf988a4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=59a19481-8cb2-429e-9c09-8a49be34527d.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b6e66b29-cb68-48f7-9a6a-d309a42dd11c.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/76557500103.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/70082500103.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/66171500103.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_1154_BHEL_2012_2013_23082013190414.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030313.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_BHEL_2011_2012_18092012091256.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500103/5001030311.pdf)

## Credit Ratings
- [Rating update
27 Jun from fitch](https://www.indiaratings.co.in/pressrelease/70641)
- [Rating update
18 Jun from care](https://www.careratings.com/upload/CompanyFiles/PR/202406130631_Bharat_Heavy_Electricals_Limited.pdf)
- [Rating update
17 Oct 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatHeavyElectricalsLimited_October%2017,%202023_RR_318353.html)
- [Rating update
28 Jun 2023 from fitch](https://www.indiaratings.co.in/pressrelease/62468)
- [Rating update
19 Jun 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202306130652_Bharat_Heavy_Electricals_Limited.pdf)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatHeavyElectricalsLimited_March%2030,%202023_RR_316263.html)

## Concalls
- [REC](https://www.bhel.com/sites/default/files/2024-05/ICI0420240521153066.mp3)
- [PPT](https://www.bhel.com/sites/default/files/Supplementary%20Information%20BHEL%20Q2FY24.pdf)
- [Transcript](https://www.bhel.com/sites/default/files/BHEL-Q4FY23%20concall%20transcript-26May2023.pdf)
- [REC](https://www.bhel.com/sites/ANT0420230526147376.mp3)
- [PPT](https://www.bhel.com/sites/default/files/Supplementary%20Information%20BHEL%20Q3FY23%20Results%2010.02.2023_updated.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=def3e115-c2f3-4c39-80af-f866bf99b0b6.pdf)
- [Transcript](https://www.bhel.com/sites/default/files/BHEL%20Q1FY22%20ConCall%20transcript%20300721%20%281%29_0.pdf)
- [](https://www.bhel.com/sites/default/files/Q1FY21_BHEL_ConCall_transcript_110920_130920.pdf)
- [](https://www.bhel.com/sites/default/files/BHEL-Q4FY20-ConCall-transcript-130620.pdf)
- [](https://www.bhel.com/sites/default/files/Q3FY20BHELConCallTranscript.pdf)
- [](https://www.bhel.com/sites/default/files/Q2FY20BHELConcallTranscript221119.pdf)
- [](https://www.bhel.com/sites/default/files/BHEL_Q1FY20_ConCall_transcript_090819.pdf)

