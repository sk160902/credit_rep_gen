import os
import re
import time
import pandas as pd
from PIL import Image
import pytesseract
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException
from bs4 import BeautifulSoup
class ScreenerScraper:
    def __init__(self, company):
        self.company = company
        self.chrome_options = Options()
        self.chrome_options.add_argument("user-data-dir=/Users/Shreyas2/Library/Application Support/Google/Chrome/Default")
        self.chrome_options.add_argument("profile-directory=Default")
        self.chrome_options.add_argument("--start-maximized")
        self.browser = webdriver.Chrome(service=Service(), options=self.chrome_options)
        self.wait = WebDriverWait(self.browser, 30)
        self.data = []
        self.seen_checkboxes_text = set()
        self.output_folder = "golden_screener_outputs"
        os.makedirs(self.output_folder, exist_ok=True)

    def safe_click(self, element, retries=3):
        for _ in range(retries):
            try:
                self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
                time.sleep(1)
                self.browser.execute_script("arguments[0].click();", element)
                return True
            except ElementClickInterceptedException:
                time.sleep(1)
        return False

    def extract_modal_content(self):
        try:
            self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated/')
            read_more_button = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Read More')]")))
            if not self.safe_click(read_more_button):
                raise Exception("Failed to click 'Read More' button")

            modal_content = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.modal-content')))

            last_height = self.browser.execute_script("return arguments[0].scrollHeight", modal_content)
            while True:
                self.browser.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", modal_content)
                time.sleep(1)
                new_height = self.browser.execute_script("return arguments[0].scrollHeight", modal_content)
                if new_height == last_height:
                    break
                last_height = new_height

            page_source = self.browser.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            modal_body = soup.select_one('div.modal-content')
            all_text = modal_body.get_text(separator="\n", strip=True) if modal_body else "N/A"

            citations = modal_body.find_all('a', href=True)
            citation_dict = {re.search(r'\[\d+\]', citation.text).group(0): citation['href']
                             for citation in citations if re.search(r'\[\d+\]', citation.text)}

            return all_text, citation_dict
        except Exception as e:
            print(f"Error during modal extraction: {e}")
            return "", {}

    def extract_text_from_screenshot(self, url):
        try:
            self.browser.get(url)
            time.sleep(5)
            screenshot_path = 'screenshot.png'
            self.browser.save_screenshot(screenshot_path)
            image = Image.open(screenshot_path)
            text = pytesseract.image_to_string(image)
            os.remove(screenshot_path)
            return text.strip()
        except Exception as e:
            print(f"Error extracting text from screenshot: {e}")
            return "Error extracting PDF content"

    def extract_citation_content(self, citation_dict):
        return {citation: {'source': url, 'content': self.extract_text_from_screenshot(url)}
                for citation, url in citation_dict.items()}

    def replace_citations(self, text, citation_contents):
        for citation, data in citation_contents.items():
            replacement_text = f'\n{{reference id: {citation[1:-1]}\nsource: {data["source"]}\ncontext: {data["content"]}}}\n'
            text = text.replace(citation, replacement_text)
        return text

    def extract_quarterly_data(self):
        self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated')
        time.sleep(5)
        section = self.wait.until(EC.presence_of_element_located((By.ID, 'quarters')))

        headers_before, data_before = self.extract_table_data(section)

        button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-segment-button="1"]')))
        if not self.safe_click(button):
            raise Exception("Failed to click 'Product Segments' button")
        time.sleep(5)

        headers_after, data_after = self.extract_table_data(section)

        return headers_before, data_before, headers_after, data_after

    def extract_quick_ratios(self):
        ratio_groups = ["most_used", "annual_pl", "quarter_pl", "balance_sheet", "cash_flow", "ratios", "price",
                        "user_ratio"]

        self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated/')
        edit_ratios_button = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/user/quick_ratios')]")))
        edit_ratios_button.click()

        for group in ratio_groups:
            group_button = self.wait.until(EC.element_to_be_clickable((By.XPATH, f"//button[@value='{group}']")))
            self.browser.execute_script("arguments[0].click();", group_button)

            selected_labels = self.get_selected_checkboxes()
            self.deselect_checkboxes(selected_labels)
            self.select_checkboxes()

            save_button = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Save quick_ratios')]")))
            self.browser.execute_script("arguments[0].click();", save_button)

            self.wait.until(EC.url_contains(f'/company/{self.company}/consolidated/'))
            time.sleep(5)

            self.extract_ratio_data()

            edit_ratios_button = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/user/quick_ratios')]")))
            edit_ratios_button.click()

    def get_selected_checkboxes(self):
        selected_elements = self.browser.find_elements(By.CSS_SELECTOR, '#manage-menu .draggable-row')
        return [elem.get_attribute('data-name') for elem in selected_elements]

    def deselect_checkboxes(self, selected_labels):
        for label in selected_labels:
            deselect_button = self.browser.find_element(By.XPATH, f"//li[@data-name='{label}']//button")
            self.browser.execute_script("arguments[0].click();", deselect_button)

    def select_checkboxes(self):
        checkboxes = self.wait.until(EC.presence_of_all_elements_located((By.XPATH, "//input[@type='checkbox']")))
        count = 0
        for checkbox in checkboxes:
            label = checkbox.find_element(By.XPATH, "following-sibling::*").text.strip()
            if label not in self.seen_checkboxes_text:
                if not checkbox.is_selected():
                    self.browser.execute_script("arguments[0].click();", checkbox)
                    self.seen_checkboxes_text.add(label)
                    count += 1
                if count >= 100:
                    break

    def extract_ratio_data(self):
        soup = BeautifulSoup(self.browser.page_source, 'html.parser')
        section = soup.find('ul', {'id': 'top-ratios'})
        if section:
            for item in section.find_all('li'):
                label = item.find('span', {'class': 'name'}).text.strip()
                value = item.find('span', {'class': 'nowrap value'}).text
                clean_value = re.sub(r'\s+', ' ', value).strip()
                clean_value = re.sub(r'₹\s+', '₹ ', clean_value)
                clean_value = re.sub(r'\s+Cr\.', ' Cr.', clean_value)
                self.data.append([self.company, label, clean_value])

    def extract_profit_loss_data(self):
        self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated')
        time.sleep(5)

        print("searching for section",'extract_profit_loss_data')

        section = self.browser.find_element(By.ID, 'profit-loss')
        print("done for section",'extract_profit_loss_data')

        headers_before, data_before = self.extract_table_data(section)
        print("searching for grid",'extract_profit_loss_data')
        grid_data_before = self.extract_grid_data()
        print("done searching for grid",'extract_profit_loss_data')

        

        # Extract Related Party Transactions
        related_party_button = self.browser.find_element(By.CSS_SELECTOR,
                                                         'button[data-title="Related Party Transactions"]')
        related_party_button.click()

        print("related_party_button")
        time.sleep(5)

        modal = self.browser.find_element(By.CSS_SELECTOR, 'div.modal-body')
        modal_headers, modal_data = self.extract_table_data(modal)

        print("modal_headers")

        close_button = self.browser.find_element(By.CSS_SELECTOR, 'div.modal-header button[type="button"]')
        close_button.click()

        print("close_button")

        # Extract Product Segments data
        try:
            segments_button = self.browser.find_element(By.CSS_SELECTOR, 'button[data-segment-button="1"]')
            segments_button.click()
        except:
            segments_button = None
        print("segments_button")
        time.sleep(5)

        headers_after, data_after = self.extract_table_data(section)
        grid_data_after = self.extract_grid_data()

        return (headers_before, data_before, grid_data_before,
                modal_headers, modal_data,
                headers_after, data_after, grid_data_after)

    def extract_table_data(self, section):
        headers = section.find_elements(By.CSS_SELECTOR, 'table thead th')
        header_names = [header.text if header.text else header.get_attribute('data-tooltip') for header in headers]
        header_names = [header if header else 'Unknown' for header in
                        header_names]  # Replace any remaining None with 'Unknown'
        data = []
        tbodies = section.find_elements(By.CSS_SELECTOR, 'table tbody')
        for tbody in tbodies:
            rows = tbody.find_elements(By.CSS_SELECTOR, 'tr')
            for row in rows:
                cells = row.find_elements(By.CSS_SELECTOR, 'td')
                row_data = [cell.text for cell in cells]
                if any(row_data):  # Only include rows with non-empty data
                    if len(row_data) < len(header_names):
                        row_data.extend([''] * (len(header_names) - len(row_data)))
                    data.append(row_data)
        return header_names, data

    def extract_grid_data(self):
        grid_data = []
        grids = self.browser.find_elements(By.CSS_SELECTOR, 'div[data-segment-table] .ranges-table')
        for grid in grids:
            rows = grid.find_elements(By.CSS_SELECTOR, 'tbody tr')
            grid_title = grid.find_element(By.CSS_SELECTOR, 'th').text
            grid_content = [(row.find_elements(By.TAG_NAME, 'td')[0].text, row.find_elements(By.TAG_NAME, 'td')[1].text)
                            for row in rows]
            grid_data.append((grid_title, grid_content))
        return grid_data

    def format_grid_as_markdown(self, grid_data):
        grid_md = ""
        for title, content in grid_data:
            grid_md += f"### {title}\n\n"
            for item in content:
                grid_md += f"- **{item[0]}**: {item[1]}\n"
            grid_md += "\n"
        return grid_md

    def scrape_cash_flows(self):
        print("Scraping cash flows...")
        cash_flows_section = self.browser.find_element(By.ID, 'cash-flow')
        headers, data = self.extract_table_data(cash_flows_section)
        print(f"Cash flows headers: {headers}")
        print(f"Cash flows data rows: {len(data)}")
        return headers, data

    def scrape_ratios(self):
        print("Scraping ratios...")
        ratios_section = self.browser.find_element(By.ID, 'ratios')
        headers, data = self.extract_table_data(ratios_section)
        print(f"Ratios headers: {headers}")
        print(f"Ratios data rows: {len(data)}")
        return headers, data

    def scrape_shareholding_pattern(self):
        shareholding_pattern = {}
        quarterly_shp_section = self.browser.find_element(By.ID, 'quarterly-shp')
        quarterly_headers, quarterly_data = self.extract_table_data(quarterly_shp_section)
        shareholding_pattern['Quarterly'] = (quarterly_headers, quarterly_data)

        yearly_shp_button = self.browser.find_element(By.CSS_SELECTOR, 'button[data-tab-id="yearly-shp"]')
        self.safe_click(yearly_shp_button)
        time.sleep(3)  # Wait for the tab content to load

        yearly_shp_section = self.browser.find_element(By.ID, 'yearly-shp')
        yearly_headers, yearly_data = self.extract_table_data(yearly_shp_section)
        shareholding_pattern['Yearly'] = (yearly_headers, yearly_data)

        return shareholding_pattern

    def extract_links(self, section):
        links = section.find_elements(By.CSS_SELECTOR, 'a')
        link_data = []
        for link in links:
            href = link.get_attribute('href')
            text = link.text.strip()
            link_data.append((text, href))
        return link_data

    def scrape_documents_section(self):
        documents_data = {}
        sections = {
            'Announcements': 'div#company-announcements-tab',
            'Annual Reports': 'div.annual-reports',
            'Credit Ratings': 'div.credit-ratings',
            'Concalls': 'div.concalls'
        }
        for section_name, selector in sections.items():
            try:
                section = self.browser.find_element(By.CSS_SELECTOR, selector)
                documents_data[section_name] = self.extract_links(section)
            except:
                print(f"Could not find {section_name} section")
        return documents_data

    def scrape_peer_comparison(self):
        self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated')
        time.sleep(5)

        peer_comparison_section = self.browser.find_element(By.ID, 'peers')
        print("Peer Section",peer_comparison_section.text)
        headers, data = self.extract_table_data(peer_comparison_section)

        # If headers are empty, manually extract headers from the text
        if not headers:
            text = peer_comparison_section.text
            headers = self.extract_headers_from_text(text)

        print("Peer Comparison Headers",headers)
        return headers, data

    def extract_headers_from_text(self, text):
        # Manually extract headers from the text
        lines = text.split('\n')
        headers_line = lines[3]  # Assuming the headers are in the 4th line
        headers = headers_line.split()
        return headers

    def run(self):
        try:
            self.browser.get(f'https://www.screener.in/company/{self.company}/consolidated')
            time.sleep(5)

            # Extract modal content
            all_text, citation_dict = self.extract_modal_content()
            # citation_contents = self.extract_citation_content(citation_dict)
            # final_text = self.replace_citations(all_text, citation_contents)
            final_text = all_text
            print("---------Modal content extraction is done.-------")

            # Extract quarterly data
            headers_before, data_before, headers_after, data_after = self.extract_quarterly_data()
            print("---------Quarterly data extraction is done.-------")

            # Extract quick ratios
            self.extract_quick_ratios()
            print("---------Quick Ratios extraction is done.-------")

            # Extract profit and loss data
            profit_loss_data = self.extract_profit_loss_data()
            print("---------Profit Loss extraction is done.-------")

            # Extract cash flows and ratios
            cash_flows_headers, cash_flows_data = self.scrape_cash_flows()
            ratios_headers, ratios_data = self.scrape_ratios()
            print("---------Cashflow and Ratios Data extraction is done.-------",cash_flows_headers)

            # Extract shareholding pattern
            shareholding_pattern_data = self.scrape_shareholding_pattern()
            print("---------Shareholding content extraction is done.-------")

            # Extract documents section
            documents_section_data = self.scrape_documents_section()
            print("---------Document content extraction is done.-------")

            # Extract peer comparison table
            peer_comparison_headers, peer_comparison_data = self.scrape_peer_comparison()
            print("---------Peer Comparison extraction is done.-------",peer_comparison_headers)

            # Save all data
            self.save_data(final_text, headers_before, data_before, headers_after, data_after, profit_loss_data,
                           cash_flows_headers, cash_flows_data, ratios_headers, ratios_data,
                           shareholding_pattern_data, documents_section_data, peer_comparison_headers, peer_comparison_data)
        except Exception as e:
            print(f"Error during scraping: {e}")
        finally:
            self.browser.quit()

    def save_data(self, final_text, headers_before, data_before, headers_after, data_after, profit_loss_data,
                  cash_flows_headers, cash_flows_data, ratios_headers, ratios_data,
                  shareholding_pattern_data, documents_section_data, peer_comparison_headers, peer_comparison_data):

        # Save modal content
        with open(f'{self.output_folder}/company_{self.company}_data.md', 'w') as file:
            print("Writing to file... company data")
            file.write(final_text + "\n")

        # Save quarterly data
        with open(f'{self.output_folder}/company_{self.company}_cash_flows_and_ratios.md', 'w') as file:
            print("writing to file... cash flows and ratios data")
            file.write('# Cash Flows and Ratios Results\n\n')
            file.write('## Cash Flows Data\n')
            file.write(self.format_as_markdown(cash_flows_headers, cash_flows_data))
            file.write('\n\n')
            print("Ratios Data")
            file.write('## Ratios Data\n')
            file.write(self.format_as_markdown(ratios_headers, ratios_data))



        # Save profit and loss data
        (headers_before, data_before, grid_data_before,
         modal_headers, modal_data,
         headers_after, data_after, grid_data_after) = profit_loss_data

        with open(f'{self.output_folder}/company_{self.company}_profit_loss.md', 'w') as file:
            print("Writing to file... profit loss data")
            file.write('# Profit & Loss Results\n\n')
            file.write('## Data Before Clicking "Product Segments" Button\n')
            file.write(self.format_as_markdown(headers_before, data_before))
            file.write('\n\n')
            file.write(self.format_grid_as_markdown(grid_data_before))
            file.write('\n\n')
            file.write('## Data from "Related Party Transactions" Modal\n')
            file.write(self.format_as_markdown(modal_headers, modal_data))
            file.write('\n\n')
            file.write('## Data After Clicking "Product Segments" Button\n')
            file.write(self.format_as_markdown(headers_after, data_after))
            file.write('\n\n')
            file.write(self.format_grid_as_markdown(grid_data_after))

        # Save cash flows and ratios data
        with open(f'{self.output_folder}/company_{self.company}_cash_flows_and_ratios.md', 'w') as file:
            print("Writing to file... cash flows and ratios data")
            file.write('# Cash Flows and Ratios Results\n\n')
            file.write('## Cash Flows Data\n')
            file.write(self.format_as_markdown(cash_flows_headers, cash_flows_data))
            file.write('\n\n')
            file.write('## Ratios Data\n')
            file.write(self.format_as_markdown(ratios_headers, ratios_data))

        # Save shareholding pattern data
        with open(f'{self.output_folder}/company_{self.company}_shareholding_pattern.md', 'w') as file:
            print("Writing to file... shareholding pattern data")
            file.write('# Shareholding Pattern Results\n\n')
            for period, (headers, data) in shareholding_pattern_data.items():
                file.write(f'## {period} Data\n')
                file.write(self.format_as_markdown(headers, data))
                file.write('\n\n')

        # Save documents section data
        with open(f'{self.output_folder}/company_{self.company}_documents.md', 'w') as file:
            print("Writing to file... documents data")
            file.write('# Documents Section Results\n\n')
            for section, links in documents_section_data.items():
                file.write(f'## {section}\n')
                file.write(self.format_as_markdown_list(links))
                file.write('\n\n')

        # Save peer comparison data
        with open(f'{self.output_folder}/company_{self.company}_peer_comparison.md', 'w') as file:
            print("Writing to file... peer comparison data")
            file.write('# Peer Comparison Results\n\n')
            file.write(self.format_as_markdown(peer_comparison_headers, peer_comparison_data))


        print("Cleaning Data")

        # Ensure no None values are present in self.data
        cleaned_data = [[str(item) if item is not None else '' for item in row] for row in self.data]

        # Save quick ratios
        df = pd.DataFrame(cleaned_data, columns=['Ticker', 'Label', 'Value'])
        df.to_excel(f'{self.output_folder}/company_{self.company}_quick_ratios.xlsx', index=False)
        df.to_csv(f'{self.output_folder}/company_{self.company}_quick_ratios.csv', index=False)

        # Save complete company data in one file
        with open(f'{self.output_folder}/company_{self.company}_complete_data.md', 'w') as file:
            print("Writing to file... complete company data")
            file.write('# Complete Company Data\n\n')

            # Modal content
            file.write('## Modal Content\n')
            file.write(final_text + "\n\n")

            # Profit and Loss Data
            file.write('# Profit & Loss Results\n\n')
            file.write('## Data Before Clicking "Product Segments" Button\n')
            file.write(self.format_as_markdown(headers_before, data_before))
            file.write('\n\n')
            file.write(self.format_grid_as_markdown(grid_data_before))
            file.write('\n\n')
            file.write('## Data from "Related Party Transactions" Modal\n')
            file.write(self.format_as_markdown(modal_headers, modal_data))
            file.write('\n\n')
            file.write('## Data After Clicking "Product Segments" Button\n')
            file.write(self.format_as_markdown(headers_after, data_after))
            file.write('\n\n')
            file.write(self.format_grid_as_markdown(grid_data_after))
            file.write('\n\n')

            # Cash Flows and Ratios Data
            file.write('# Cash Flows and Ratios Results\n\n')
            file.write('## Cash Flows Data\n')
            file.write(self.format_as_markdown(cash_flows_headers, cash_flows_data))
            file.write('\n\n')
            file.write('## Ratios Data\n')
            file.write(self.format_as_markdown(ratios_headers, ratios_data))
            file.write('\n\n')

            # Shareholding Pattern Data
            file.write('# Shareholding Pattern Results\n\n')
            for period, (headers, data) in shareholding_pattern_data.items():
                file.write(f'## {period} Data\n')
                file.write(self.format_as_markdown(headers, data))
                file.write('\n\n')

            # Documents Section Data
            file.write('# Documents Section Results\n\n')
            for section, links in documents_section_data.items():
                file.write(f'## {section}\n')
                file.write(self.format_as_markdown_list(links))
                file.write('\n\n')

            # Peer Comparison Data
            file.write('# Peer Comparison Results\n\n')
            file.write(self.format_as_markdown(peer_comparison_headers, peer_comparison_data))
            file.write('\n\n')

            # Quick Ratios
            file.write('# Quick Ratios\n\n')
            cleaned_data = [[str(item) if item is not None else '' for item in row] for row in self.data]
            quick_ratios_df = pd.DataFrame(cleaned_data, columns=['Ticker', 'Label', 'Value'])
            quick_ratios_md = self.format_as_markdown(quick_ratios_df.columns.tolist(), quick_ratios_df.values.tolist())
            file.write(quick_ratios_md)

        print("Cleaning Data done")

    @staticmethod
    def format_as_markdown(headers, data):
        print("Formatting data to markdown")
        headers = [header if header is not None else "Unknown" for header in headers]
        print('headers',headers)
        print('data',data)
        header_line = '| ' + ' | '.join(headers) + ' |'
        separator_line = '| ' + ' | '.join(['---'] * len(headers)) + ' |'
        data_lines = ['| ' + ' | '.join(row) + ' |' for row in data]
        return '\n'.join([header_line, separator_line] + data_lines)

    @staticmethod
    def format_as_markdown_list(link_data):
        lines = [f'- [{text}]({href})' for text, href in link_data]
        return '\n'.join(lines)


if __name__ == "__main__":
    company = "TCS"
    scraper = ScreenerScraper(company)
    scraper.run()
