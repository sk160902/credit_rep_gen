# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 395,957 | 433,521 | 374,372 | 272,583 | 303,954 | 390,823 | 568,337 | 596,679 | 466,307 | 694,673 | 876,396 | 901,064 | 925,289 |
| Expenses + | 362,802 | 398,586 | 336,923 | 230,802 | 257,647 | 326,508 | 484,087 | 507,413 | 385,517 | 586,092 | 734,078 | 738,831 | 762,384 |
| Operating Profit | 33,155 | 34,935 | 37,449 | 41,781 | 46,307 | 64,315 | 84,250 | 89,266 | 80,790 | 108,581 | 142,318 | 162,233 | 162,905 |
| OPM % | 8% | 8% | 10% | 15% | 15% | 16% | 15% | 15% | 17% | 16% | 16% | 18% | 18% |
| Other Income + | 7,757 | 8,865 | 8,528 | 12,212 | 9,222 | 9,869 | 8,406 | 8,570 | 22,432 | 19,600 | 12,020 | 16,057 | 16,438 |
| Interest | 3,463 | 3,836 | 3,316 | 3,691 | 3,849 | 8,052 | 16,495 | 22,027 | 21,189 | 14,584 | 19,571 | 23,118 | 23,199 |
| Depreciation | 11,232 | 11,201 | 11,547 | 11,565 | 11,646 | 16,706 | 20,934 | 22,203 | 26,572 | 29,782 | 40,303 | 50,832 | 52,653 |
| Profit before tax | 26,217 | 28,763 | 31,114 | 38,737 | 40,034 | 49,426 | 55,227 | 53,606 | 55,461 | 83,815 | 94,464 | 104,340 | 103,491 |
| Tax % | 20% | 22% | 24% | 23% | 25% | 27% | 28% | 26% | 3% | 19% | 22% | 25% |  |
| Net Profit + | 20,886 | 22,548 | 23,640 | 29,861 | 29,833 | 36,080 | 39,837 | 39,880 | 53,739 | 67,845 | 74,088 | 79,020 | 78,207 |
| EPS in Rs | 30.31 | 32.62 | 34.14 | 43.03 | 43.11 | 53.39 | 58.55 | 58.20 | 77.50 | 89.74 | 98.59 | 102.90 | 101.61 |
| Dividend Payout % | 13% | 12% | 12% | 10% | 11% | 10% | 10% | 10% | 9% | 9% | 9% | 10% |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Jamnagar Utilities & Power Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electric Power, Fuel and Water |  |  |  | 4,656 | 5,140 | 4,898 |  | 4,503 | 4,657 |
| Revenue from Operations |  |  |  | 200 | 279 | 126 |  | 258 | 350 |
| Deposits |  |  |  |  | 118 | 118 |  | 118 | 118 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 116 | 18 | 38 |  | 80 | 1 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 25 | 62 |
| Other Income |  |  |  | 3 |  | 2 |  | 1 | 1 |
| Purchases / Material Consumed |  |  |  |  | 6 |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 2 |
| Purchases/ Material Consumed |  |  |  | 1 |  |  |  |  |  |
| Reliance Ports and Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales and Distribution Expenses |  | 2,576 | 2,567 |  |  |  |  |  |  |
| Sales & Distribution Expenses | 2,751 |  |  |  |  |  |  |  |  |
| Deposits | 1,050 | 353 | 353 |  |  |  |  |  |  |
| Purchases/ Material Consumed |  | 611 | 623 |  |  |  |  |  |  |
| Hire Charges | 301 | 220 | 387 |  |  |  |  |  |  |
| Purchases / Material Consumed | 241 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  | 166 | 41 |  |  |  |  |  |  |
| Purchase of Fixed Assets | 198 |  |  |  |  |  |  |  |  |
| Revenue from Operations | 2 | 5 | 15 |  |  |  |  |  |  |
| General Expenses | 3 | 12 | 7 |  |  |  |  |  |  |
| Other Income | 1 | 1 | 1 |  |  |  |  |  |  |
| Sikka Ports and Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales and Distribution Expenses |  |  |  | 2,499 | 2,003 | 2,118 |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 1,259 | 1,395 |  |  |  |
| Deposits |  |  |  |  | 353 | 353 |  |  |  |
| Purchases/ Material Consumed |  |  |  | 589 |  |  |  |  |  |
| Hire Charges |  |  |  | 334 | 87 | 97 |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 22 | 216 | 163 |  |  |  |
| Revenue from Operations |  |  |  | 3 | 22 | 19 |  |  |  |
| General Expenses |  |  |  | 12 | 13 | 12 |  |  |  |
| Other Income |  |  |  | 1 |  |  |  |  |  |
| Sikka Ports & Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 2,039 | 2,266 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1,417 | 1,571 |
| Deposits |  |  |  |  |  |  |  | 353 | 353 |
| Revenue from Operations |  |  |  |  |  |  |  | 227 | 16 |
| Other Income |  |  |  |  |  |  |  | 1 | 226 |
| Labour Processing and Hire Charges |  |  |  |  |  |  |  | 101 | 54 |
| General Expenses |  |  |  |  |  |  |  | 8 | 9 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 2 | 1 |
| Reliance Utilities and Power Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electric Power, Fuel and Water | 1,579 | 1,719 | 2,484 |  |  |  |  |  |  |
| Revenue from Operations | 363 | 236 | 286 |  |  |  |  |  |  |
| Deposits | 350 | 118 | 118 |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  | 68 | 192 |  |  |  |  |  |  |
| Purchase of Fixed Assets | 10 |  |  |  |  |  |  |  |  |
| Other Income | 3 | 3 | 3 |  |  |  |  |  |  |
| Capital Advance Returned | 5 |  |  |  |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 4 |  |  |  |  |  |  |
| Reliance Europe Limited Associate |  |  |  |  |  |  |  |  |  |
| Financial Guarantees |  | 1,837 | 1,532 |  | 1,419 | 1,447 |  |  |  |
| Professional Fees | 25 | 34 | 30 | 39 | 29 | 23 |  | 11 | 11 |
| Unsecured Loans |  |  |  |  |  |  |  | 80 | 80 |
| Other Income | 13 | 13 | 17 | 15 | 15 | 16 |  |  |  |
| Finance Costs |  | 1 | 1 | 2 | 2 | 2 |  | 1 | 3 |
| General Expenses | 7 |  |  |  |  | 3 |  |  |  |
| Rent |  |  |  |  |  |  |  |  | 5 |
| Loans and Advances |  | 3 |  |  |  |  |  |  |  |
| Loans & Advances | 3 |  |  |  |  |  |  |  |  |
| Finance Cost | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  |  | 3 |  |  |  |  |  |  |
| Alok Industries Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 3,083 | 3,086 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 92 | 426 |
| Other Income |  |  |  |  |  |  |  |  | 13 |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 6 | 1 |
| General Expenses |  |  |  |  |  |  |  | 1 | 1 |
| East West Pipeline Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales / Transfer / Redemption of Investments |  |  |  |  | 3,768 |  |  |  |  |
| Hire Charges |  |  |  | 475 | 759 |  |  |  |  |
| Other Income |  |  |  | 218 | 229 |  |  |  |  |
| Revenue from Operations |  |  |  | 37 | 34 |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 5 |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 1 |  |  |  |  |
| Reliance Foundation |  |  |  |  |  |  |  |  |  |
| Donations | 737 | 592 | 575 | 698 | 341 | 225 |  | 870 | 912 |
| Revenue from Operations |  | 4 | 1 | 5 | 17 | 11 |  | 37 | 5 |
| General Expenses |  |  |  |  |  |  |  | 5 |  |
| India Gas Solutions Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1,094 | 1,083 |
| Revenue from Operations |  | 5 | 2 | 2 | 3 | 1 |  | 847 | 1,169 |
| Other Income |  |  |  |  |  |  |  |  | 249 |
| Professional Fees |  | 8 | 3 |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 6 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  |  | 5 |
| Sintex Industries Limited JV |  |  |  |  |  |  |  |  |  |
| Financial Guarantees |  |  |  |  |  |  |  |  | 1,900 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1,500 |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| Sanmina-SCI India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1,763 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  |  | 299 |
| Reliance Employees Provident Fund Bombay |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 207 | 222 | 287 | 314 | 320 |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 279 | 299 |
| Reliance Commercial Dealers Limited Associate |  |  |  |  |  |  |  |  |  |
| General Expenses | 282 | 418 | 139 |  |  |  |  |  |  |
| Deposits | 155 | 175 |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 170 |  |  |  |  |  |  |  |
| Loans and Advances |  | 150 |  |  |  |  |  |  |  |
| Revenue from Operations | 16 | 13 | 9 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/ (Returned | 23 |  |  |  |  |  |  |  |  |
| EFS Midstream LLC Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 1,334 |  |  |  |  |  |  |  |
| Gujarat Chemical Port Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 160 | 162 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 142 | 157 |
| Deposits |  |  |  |  | 112 | 71 |  | 49 | 33 |
| Sales and Distribution Expenses |  |  |  |  | 63 | 65 |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 66 | 57 |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 25 | 41 |  |  |  |
| Other Income |  |  |  |  | 1 | 10 |  | 15 | 15 |
| Revenue from Operations |  |  |  |  | 2 | 4 |  | 11 | 4 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  | 1 |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 | 16 |
| GTPL Hathway Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 3 | 92 |  | 126 | 172 |
| Purchase / Subscription of Investments |  |  |  |  | 391 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 105 | 147 |
| Sales and Distribution Expenses |  |  |  |  |  | 49 |  |  |  |
| Other Income |  |  |  |  |  | 1 |  |  | 18 |
| Loans and Advances |  |  |  |  |  |  |  | 1 | 1 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 |  |
| Programming and Telecast Related Expense |  |  |  |  | 1 |  |  |  |  |
| Gujarat Chemical Port Terminal Company Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 111 | 138 | 147 |  |  |  |  |  |  |
| Hire Charges | 90 | 117 | 2 |  |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 90 | 109 |  |  |  |  |  |
| Sales and Distribution Expenses |  | 33 | 52 | 86 |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 22 | 9 |  |  |  |  |  |  |
| Other Income | 10 |  | 6 | 10 |  |  |  |  |  |
| Sales & Distribution Expenses | 16 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given | 12 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  | 10 |  |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 8 |  |  |  |  |  |
| Loans & Advances | 6 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  |  | 4 |  |  |  |  |  |  |
| Revenue from Operations |  |  | 1 | 2 |  |  |  |  |  |
| Purchases / Material Consumed | 3 |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 2 |  |  |  |  |  |  |  |  |
| Reliance Foundation Institution of Education and Research |  |  |  |  |  |  |  |  |  |
| Donations |  |  |  | 1 | 476 | 229 |  | 142 | 207 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 2 |
| R P Chemicals (Malaysia) Sdn. Bhd. Associate |  |  |  |  |  |  |  |  |  |
| Purchases / Material Consumed | 1,052 |  |  |  |  |  |  |  |  |
| Reliance Gas Transportation Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Hire Charges | 194 | 214 | 203 |  |  |  |  |  |  |
| Other Income | 14 |  | 204 |  |  |  |  |  |  |
| Revenue from Operations | 50 | 60 | 32 |  |  |  |  |  |  |
| Purchases / Material Consumed | 3 |  |  |  |  |  |  |  |  |
| RP Chemicals (Malaysia ) Sdn. Bhd. Associate |  |  |  |  |  |  |  |  |  |
| Purchases/ Material Consumed |  | 745 |  |  |  |  |  |  |  |
| Reliance Industrial Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Hire Charges | 37 | 34 | 45 | 40 | 23 | 22 |  |  |  |
| Professional Fees | 17 | 24 | 25 | 26 | 27 | 17 |  |  |  |
| Rent | 8 | 9 | 15 | 11 | 10 | 11 |  | 16 | 17 |
| Purchases / Material Consumed | 19 |  |  |  | 21 | 21 |  |  |  |
| Purchases/ Material Consumed |  | 20 | 13 | 21 |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 22 | 21 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 5 | 20 | 8 |  |  |  |
| Labour Processing and Hire Charges |  |  |  |  |  |  |  | 12 | 15 |
| Electric Power, Fuel and Water |  |  |  |  |  |  |  | 14 | 12 |
| Other Income |  |  |  | 2 | 2 | 2 |  | 2 | 2 |
| Revenue from Operations |  | 1 | 3 | 2 | 1 |  |  | 1 | 1 |
| Purchase of Fixed Assets | 8 |  |  |  |  |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 4 | 3 |
| Purchase of Tangible and Intangible Assets |  | 3 | 2 |  |  |  |  |  |  |
| Capital Advance Returned | 3 |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 2 |  |
| Reliance Services and Holdings Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 703 |
| Loans and Advances |  |  |  |  |  | 7 |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 2 |  |  |  |
| Neolync Solutions Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 555 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 20 | 20 |
| Football Sports Development Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 |  | 4 | 9 | 3 |  | 29 | 69 |
| Purchase / Subscription of Investments |  |  | 42 |  |  | 51 |  |  |  |
| Net Loans and Advances, Deposits Given |  |  |  | 42 | 51 |  |  |  |  |
| Loans and Advances |  |  |  |  | 93 |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 55 | 22 |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 42 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 42 |  |  |  |  |  |
| Other Income |  |  |  | 2 | 4 |  |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  | 5 |  |  |  |  |
| I P C L Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 98 | 103 | 110 | 109 | 124 |  |  |  |
| Big Tree Entertainment Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 191 |  | 278 |  |  |  |  |
| Revenue from Operations |  |  | 1 |  |  |  |  | 1 | 12 |
| Programming and Telecast Related Expense |  |  |  |  | 7 | 1 |  |  |  |
| Professional Fees |  | 2 | 1 | 1 | 1 | 1 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 3 |
| General Expenses |  |  | 1 |  |  |  |  |  | 1 |
| Sales and Distribution Expenses |  |  |  |  | 1 |  |  |  |  |
| Ashwani Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 65 |  |  |  | 63 | 63 |  | 57 | 54 |
| Purchase / Subscription of Investments |  |  |  |  | 136 |  |  |  |  |
| Rent |  |  |  | 2 | 2 | 2 |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 3 |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Net Loans and Advances, Deposits Given/ (Returned | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 4 | 3 |
| Jamnaben Hirachand Ambani Foundation |  |  |  |  |  |  |  |  |  |
| Donations | 4 | 15 | 19 | 6 | 40 | 66 |  | 101 | 155 |
| Other Income |  |  |  |  | 3 | 3 |  | 4 | 5 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Reliance Retail Limited Employees Provident Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 151 | 269 |
| Honeywell Properties Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 50 | 50 | 50 |  | 50 | 50 |  | 45 | 51 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 5 | 6 |
| The Indian Film Combine Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 340 |  |  |  |  |  |
| Jio Payments Bank Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 92 |  | 70 |  |  | 22 | 80 |
| Revenue from Operations |  |  |  | 1 | 3 | 5 |  | 7 | 7 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 4 | 6 |
| General Expenses |  |  |  |  | 1 | 1 |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 1 |
| Marks and Spencer Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 20 |  | 47 | 81 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 26 | 84 |
| Purchase / Subscription of Investments |  | 15 |  |  |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 2 | 5 |  |  |  |
| Purchases/ Material Consumed |  |  | 2 | 2 |  |  |  |  |  |
| Einsten Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 43 | 43 | 43 |  | 36 | 36 |  | 36 | 36 |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 1 |  |  |  |
| Genesis Luxury Fashion Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 269 |  |  |  |  |  |
| Carin Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 77 |  |  |  | 77 | 77 |  | 77 | 9 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 68 |
| IPCL Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 126 | 121 |
| Chander Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 33 | 34 | 34 |  | 35 | 35 |  | 32 | 36 |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 1 | 1 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 3 | 4 |
| Extramarks Education Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 100 | 125 |  |  |  |  |  |  |
| Other Income | 9 | 5 |  |  |  |  |  |  |  |
| GTPL Kolkata Cable & Broad Band Pariseva Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 60 | 71 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 46 | 57 |
| Shree Salasar Bricks Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 33 | 33 | 33 |  | 33 | 33 |  | 33 | 33 |
| Kaniska Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 23 | 23 | 23 |  | 27 | 30 |  | 40 | 41 |
| Net Loans and Advances, Deposits Given | 1 |  |  | 3 |  | 3 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 3 | 1 |
| Reliance Industries Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 31 |  | 16 | 63 | 100 |  |  |  |
| Reliance Foundation Youth Sports |  |  |  |  |  |  |  |  |  |
| Donations |  |  | 22 | 38 | 41 | 47 |  | 22 | 34 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Rocky Farms Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 29 | 29 | 29 |  | 29 | 29 |  | 29 | 29 |
| Dunzo Digital Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 200 |
| Shri Nikhil R. Meswani Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 21 | 24 |  | 24 | 25 |
| PaymentToKeyManagementPersonnel/Relative |  | 14 | 17 |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 21 |  |
| Payment To |  |  |  | 20 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 12 |  |  |  |  |  |  |  |  |
| Shri Hital R. Meswani Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 21 | 24 |  | 24 | 25 |
| PaymentToKeyManagementPersonnel/Relative |  | 14 | 17 |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 20 |  |
| Payment To |  |  |  | 20 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 12 |  |  |  |  |  |  |  |  |
| Iconix Lifestyle India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 89 |  |
| General Expenses |  |  |  |  |  |  |  | 16 | 20 |
| Revenue from Operations |  | 2 | 2 | 3 | 3 | 3 |  | 3 | 5 |
| Other Income |  |  |  |  |  | 11 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 3 |
| Den Satellite Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 | 19 |  | 21 | 24 |
| Purchase / Subscription of Investments |  |  |  |  | 64 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 8 | 3 |
| General Expenses |  |  |  |  |  | 5 |  |  | 5 |
| Sales and Distribution Expenses |  |  |  |  |  | 5 |  |  |  |
| Cairn Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 77 | 77 |  |  |  |  |  |  |
| IMG Reliance Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 65 | 7 |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 3 | 10 | 18 |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  | 9 | 18 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 9 |  |  |  |  |  |
| Sales and Distribution Expenses |  |  | 1 | 2 |  | 1 |  |  |  |
| Professional Fees |  |  |  |  |  | 2 |  |  |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Prakhar Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 48 |  |  |  | 29 | 30 |  | 29 | 10 |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 19 |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 | 19 |
| Shri Mukesh D. Ambani Key Person |  |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 52 |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 15 | 15 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 15 | 15 |  |  |  |  |  |  |
| Payment To |  |  |  | 15 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 15 |  |  |  |  |  |  |  |  |
| Eenadu Television Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 |  | 1 | 2 | 10 |  | 10 | 19 |
| Programming and Telecast Related Expense |  |  |  |  | 14 | 26 |  |  |  |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 16 | 20 |
| General Expenses | 7 | 2 | 2 | 2 |  | 1 |  |  | 1 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 4 |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 |  |
| Atri Exports Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 19 | 19 | 19 |  | 19 | 19 |  | 19 | 19 |
| Ashwani Commericals Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 65 | 65 |  |  |  |  |  |  |
| Gaurav Overseas Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 17 | 17 | 17 |  | 17 | 17 |  | 17 | 17 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1 |
| Viacom18 Media Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 33 | 28 | 30 |  |  |  |  |  |
| General Expenses |  | 13 | 7 |  |  |  |  |  |  |
| Parinita Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 28 | 28 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 22 |  |
| Creative Agrotech Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 15 | 15 | 15 |  | 15 | 15 |  | 15 | 16 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| IndiaCast Media Distribution Private Limited JV |  |  |  |  |  |  |  |  |  |
| General Expenses |  | 48 | 50 |  |  |  |  |  |  |
| Revenue from Operations |  | 5 | 4 |  |  |  |  |  |  |
| Sir HN Hospital Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 42 | 53 |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 4 |
| Other Income |  |  |  |  |  |  |  | 1 | 1 |
| General Expenses |  |  |  |  |  |  |  | 1 |  |
| Diesel Fashion India Reliance Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 3 | 6 | 6 | 6 | 6 |  | 10 | 12 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 11 | 14 |
| Purchase / Subscription of Investments |  | 3 | 1 |  | 6 | 5 |  |  | 4 |
| Purchase/Subscription of Investments |  |  |  | 5 |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 1 | 1 |  |  |  |  |  |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Purchases / Material Consumed |  |  |  |  | 1 |  |  |  |  |
| Clarks Reliance Footwear Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 51 | 2 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 4 | 25 |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 15 |
| Other Income |  |  |  |  |  |  |  | 1 | 1 |
| Algenol LLC Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 25 | 73 |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  |  |  | 1 |  |  |  |  |  |
| Shri Srikanth Venkatachari Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 14 | 14 |  | 15 | 17 |
| PaymentToKeyManagementPersonnel/Relative |  | 11 | 11 |  |  |  |  |  |  |
| Payment To |  |  |  | 13 |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 2 |  |
| Prakher Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 48 | 48 |  |  |  |  |  |  |
| Brooks Brothers India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 14 | 24 |
| Revenue from Operations |  |  |  | 3 | 4 | 4 |  | 9 | 17 |
| Purchases / Material Consumed |  |  |  |  | 3 | 1 |  |  |  |
| Purchase / Subscription of Investments |  | 2 | 2 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Loans and Advances |  |  |  |  |  |  |  |  | 1 |
| Purchase/Subscription of Investments |  |  |  | 1 |  |  |  |  |  |
| Purchases/ Material Consumed |  |  |  | 1 |  |  |  |  |  |
| Sales and Distribution Expenses |  | 1 |  |  |  |  |  |  |  |
| Reliance Jio Infocomm Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  | 20 | 26 | 20 |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 10 |
| Reliance Industries Limited Staff Superannuation Scheme |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 19 | 20 |
| Employee Benefits Expense |  | 10 | 10 | 11 |  |  |  |  |  |
| Ryohin-Keikaku Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 7 |  | 3 | 8 |  | 3 | 3 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 11 | 8 |
| Revenue from Operations |  |  |  | 3 | 2 | 2 |  | 5 | 6 |
| Purchase/Subscription of Investments |  |  |  | 6 |  |  |  |  |  |
| Centura Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 10 | 10 | 10 |  | 10 | 10 |  | 10 | 8 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 2 |
| Television Home Shopping Network Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 61 |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 |  |  |  |  |
| Vishnumaya Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 10 | 10 | 10 |  | 8 | 7 |  | 7 | 7 |
| Net Loans and Advances, Deposits Returned |  |  |  | 2 |  |  |  |  |  |
| Shri Alok Agarwal Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 12 | 12 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 12 | 12 |  |  |  |  |  |  |
| Payment To |  |  |  | 12 |  |  |  |  |  |
| Matrix Genetics LLC Associate |  |  |  |  |  |  |  |  |  |
| General Expenses |  | 27 | 27 | 6 |  |  |  |  |  |
| Reliance-Vision Express Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 3 |  | 3 | 5 |  | 6 | 10 |
| Revenue from Operations |  | 2 | 3 | 2 | 3 | 3 |  | 4 | 4 |
| Net Loans and Advances, Deposits Given |  |  |  |  | 3 |  |  |  |  |
| Loans and Advances |  |  |  |  | 3 |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 3 |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Hathway MCN Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 10 |  | 15 | 13 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 7 | 7 |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  |  | 3 |  |  |  |
| Reliance Retail Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 26 | 33 |
| Smt. Nita M. Ambani Relative |  |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 52 |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 2 | 2 |
| Reliance Commercial Trading Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 42 |  |  |  |  |  |  |  |
| Loans & Advances | 12 |  |  |  |  |  |  |  |  |
| Loans and Advances |  | 6 |  |  |  |  |  |  |  |
| Sale / Transfer / Redemption of Investments | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 6 |  |  |  |  |  |  |  |
| Reliance Gas Transportation and Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 46 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  |  | 8 |  |  |  |  |  |  |
| Netravati Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 6 | 7 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Rakshita Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 6 | 7 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Shri P.M.S. Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 10 | 11 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 7 | 7 |  |  |  |  |  |  |
| Payment To |  |  |  | 9 |  |  |  |  |  |
| Hathway Sai Star Cable & Datacom Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  | 7 | 6 |
| Purchase / Subscription of Investments |  |  |  |  | 10 |  |  |  |  |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Sales and Distribution Expenses |  |  |  |  |  | 2 |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  |  | 2 |  |  |  |
| Loans and Advances |  |  |  |  |  | 1 |  |  |  |
| DL GTPL Cabnet Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 5 |  | 8 | 9 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 5 | 6 |
| Sales and Distribution Expenses |  |  |  |  |  | 3 |  |  |  |
| Marugandha Land Developers Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 5 | 5 | 5 |  | 5 | 5 |  | 5 | 5 |
| Shri Alok AgarwalAA Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 12 | 13 |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 9 |  |
| GTPL Broadband Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 15 | 18 |
| Indiacast Media Distribution Private Limited JV |  |  |  |  |  |  |  |  |  |
| General Expenses |  |  |  | 25 |  |  |  |  |  |
| Revenue from Operations |  |  |  | 5 |  |  |  |  |  |
| TCO Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 3 | 11 |
| Purchase / Subscription of Investments |  |  |  |  |  | 14 |  |  |  |
| Jaipur Enclave Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 4 | 4 | 4 |  | 4 | 4 |  | 4 | 4 |
| TV18 Home Shopping Network Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 28 |  |  |  |  |  |
| IBN Lokmat News Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 1 |  | 1 | 3 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 | 4 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 2 |
| Programming and Telecast Related Expense |  |  |  |  | 2 | 2 |  |  |  |
| Other Income |  |  |  |  |  | 1 |  | 1 | 1 |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 1 |
| General Expenses |  |  |  | 1 |  |  |  |  |  |
| GTPL Kolkata Cable & Broadband Pariseva Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 | 19 |  |  |  |
| Sales and Distribution Expenses |  |  |  |  |  | 6 |  |  |  |
| Jio Platforms Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 26 |
| Shri PMS Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 12 | 14 |
| Reliance Paul & Shark Fashions Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 1 |  | 2 | 4 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 2 | 6 |
| Purchase / Subscription of Investments |  |  |  |  | 1 | 1 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 2 |  |  |  |  |  |
| Net Loans and Advances, Deposits Given |  |  |  |  | 1 |  |  |  |  |
| Loans and Advances |  |  |  |  | 1 |  |  |  |  |
| Vayana Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 24 |  |  |  |  |  |  |  |
| Canali India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 4 | 9 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 2 | 6 |
| Purchases / Material Consumed |  |  |  |  | 1 | 1 |  |  |  |
| Pipeline Management Services Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  |  | 2 |
| General Expenses |  |  |  |  |  |  |  |  | 6 |
| Other Income |  |  |  |  |  | 6 |  |  |  |
| Professional Fees |  |  |  |  |  | 4 |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 1 |  |  |  |  |
| DEN ADN Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 6 |  |  |  |
| Revenue from Operations |  |  |  |  |  | 3 |  | 1 | 1 |
| Other Income |  |  |  |  |  | 1 |  | 1 | 2 |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 2 | 1 |
| General Expenses |  |  |  |  |  | 1 |  | 1 | 1 |
| Sales and Distribution Expenses |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 4 |  |
| Reliance Bally India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 1 | 1 | 2 |  | 3 | 4 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 3 | 4 |
| Purchase/Subscription of Investments |  |  |  | 4 |  |  |  |  |  |
| Zegna South Asia Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 2 | 2 | 2 |  | 2 | 2 |
| General Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Purchase / Subscription of Investments |  | 1 | 2 |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Purchases/ Material Consumed |  | 2 |  |  |  |  |  |  |  |
| Reliance Industries Limited Sta Superannuation Scheme |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  |  | 11 | 11 |  |  |  |
| Hathway Cable MCN Nanded Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 5 |  | 7 | 5 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Hirachand Govardhandas Ambani Public Charitable Trust |  |  |  |  |  |  |  |  |  |
| Donations | 2 |  |  | 2 | 5 | 6 |  | 3 | 3 |
| Fame Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 3 | 3 | 3 |  | 3 | 3 |  | 3 | 3 |
| Noveltech Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 3 | 3 | 3 |  | 3 | 3 |  | 3 | 3 |
| Shri Pawan Kumar Kapil Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 4 | 4 |  | 4 | 4 |
| Payment To |  |  |  | 3 |  |  |  |  |  |
| HNH Trust and HNH Research Society |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  |  | 8 | 10 |  |  |  |
| Hathway Latur MCN Cable & Datacom Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  | 5 | 4 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Shri K. Sethuraman Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 2 | 3 |  | 2 |  |
| PaymentToKeyManagementPersonnel/Relative |  | 2 | 2 |  |  |  |  |  |  |
| Payment To |  |  |  | 3 |  |  |  |  |  |
| Clayfin Technologies Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 11 |
| CCN DEN Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 18 |  |  |  |
| Revenue from Operations |  |  |  |  |  | 3 |  | 1 |  |
| Other Income |  |  |  |  |  | 3 |  |  |  |
| Sales and Distribution Expenses |  |  |  |  |  | 2 |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 18 |  |
| IndiaCast UK Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 5 | 6 |  |  |  |  |  |  |
| Shri P. M. S. Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 6 |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 4 |  |
| Future101 Design Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 4 |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 2 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  |  | 1 |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Indospace MET Logistics Park Farukhnagar Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 5 |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 2 |
| Other Income |  |  |  |  |  |  |  |  | 1 |
| Hathway CCN Multinet Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 6 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 1 |  |
| Smt Nita M. Ambani Relative |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 2 | 1 |  |  |  |
| Payment To |  |  |  | 2 |  |  |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 1 | 1 |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 1 |  |  |  |  |  |  |  |  |
| GenNext Ventures Investment Advisers LLP Associate |  |  |  |  |  |  |  |  |  |
| Professional Fees | 5 | 1 | 2 |  |  |  |  |  |  |
| Smt. Savithri Parekh Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  | 2 |  | 2 | 3 |
| Vadodara Enviro Channel Limited Associate |  |  |  |  |  |  |  |  |  |
| General Expenses |  |  |  |  |  | 3 |  | 2 | 2 |
| Pepino Farms Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 1 | 1 | 1 |  | 1 | 1 |  | 1 | 1 |
| Hathway Dattatray Cable Network Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 2 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Hathway CCN Entertainment (India) Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 1 |  |
| Einsten Commericals Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  | 6 |  |  |  |  |  |
| Indiacast UK Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 6 |  |  |  |  |  |
| Shri P.K.Kapil Key Person |  |  |  |  |  |  |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 3 | 3 |  |  |  |  |  |  |
| HirachandGovardhandasAmbaniPublicCharitableTrust |  |  |  |  |  |  |  |  |  |
| Donations |  | 4 | 2 |  |  |  |  |  |  |
| Burberry India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 2 | 2 |
| DEN New Broad Communication Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 1 |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Ubona Technologies Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 2 |
| Ethane Crystal LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Emerald LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Opal LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Pearl LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Sapphire LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Topaz LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Enercent Technologies Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 4 |  |
| ZegnaSouthAsiaPrivateLimited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  | 3 |  |  |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Net 9 Online Hathway Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 3 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  |  |  |
| Reliance Industries Limited Vadodara Unit Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  | 2 | 1 | 1 |  |  |  |
| Reliance Industries Limited Vadodara Unit |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 2 | 2 |  |  |  |  |  |  |
| RIL Vadodara Unit Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 3 |  |  |  |  |  |  |  |
| CAA-Global Brands Reliance Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 2 |
| Konark IP Dossiers Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Reliance Luxury Fashion Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  |  | 1 |  |  |  |  |  |  |
| Loans and Advances |  |  | 1 |  |  |  |  |  |  |
| Brook Brothers India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  | 2 |  |  |  |  |  |  |
| Ryohin - Keikaku Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  | 2 |  |  |  |  |  |  |
| Shri P. K. Kapil Key Person |  |  |  |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 2 |  |  |  |  |  |  |  |  |
| Hathway Bhawani NDS Network Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| Reliance Industries Limited Vadodara Units Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 1 |  |
| IndiaGasSolutionsPrivateLimited JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  | 1 |  |  |  |
| Hathway CBN Multinet Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 1 |  |  |  |  |
| Aurora Algae LLC Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments | 1 |  |  |  |  |  |  |  |  |
| Wespro Digital Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations | 1 |  |  |  |  |  |  |  |  |
| Hathway ICE Television Private Limited JV |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 395,957 | 433,521 | 374,372 | 272,583 | 303,954 | 390,823 | 568,337 | 596,679 | 466,307 | 694,673 | 876,396 | 901,064 | 925,289 |
| Expenses + | 362,802 | 398,586 | 336,923 | 230,802 | 257,647 | 326,508 | 484,087 | 507,413 | 385,517 | 586,092 | 734,078 | 738,831 | 762,384 |
| Operating Profit | 33,155 | 34,935 | 37,449 | 41,781 | 46,307 | 64,315 | 84,250 | 89,266 | 80,790 | 108,581 | 142,318 | 162,233 | 162,905 |
| OPM % | 8% | 8% | 10% | 15% | 15% | 16% | 15% | 15% | 17% | 16% | 16% | 18% | 18% |
| Other Income + | 7,757 | 8,865 | 8,528 | 12,212 | 9,222 | 9,869 | 8,406 | 8,570 | 22,432 | 19,600 | 12,020 | 16,057 | 16,438 |
| Interest | 3,463 | 3,836 | 3,316 | 3,691 | 3,849 | 8,052 | 16,495 | 22,027 | 21,189 | 14,584 | 19,571 | 23,118 | 23,199 |
| Depreciation | 11,232 | 11,201 | 11,547 | 11,565 | 11,646 | 16,706 | 20,934 | 22,203 | 26,572 | 29,782 | 40,303 | 50,832 | 52,653 |
| Profit before tax | 26,217 | 28,763 | 31,114 | 38,737 | 40,034 | 49,426 | 55,227 | 53,606 | 55,461 | 83,815 | 94,464 | 104,340 | 103,491 |
| Tax % | 20% | 22% | 24% | 23% | 25% | 27% | 28% | 26% | 3% | 19% | 22% | 25% |  |
| Net Profit + | 20,886 | 22,548 | 23,640 | 29,861 | 29,833 | 36,080 | 39,837 | 39,880 | 53,739 | 67,845 | 74,088 | 79,020 | 78,207 |
| EPS in Rs | 30.31 | 32.62 | 34.14 | 43.03 | 43.11 | 53.39 | 58.55 | 58.20 | 77.50 | 89.74 | 98.59 | 102.90 | 101.61 |
| Dividend Payout % | 13% | 12% | 12% | 10% | 11% | 10% | 10% | 10% | 9% | 9% | 9% | 10% |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |

