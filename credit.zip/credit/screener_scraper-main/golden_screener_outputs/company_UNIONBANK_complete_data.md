# Complete Company Data

## Modal Content
About
[
edit
]
Union Bank of India is engaged in the Business of Banking Services, Government Business ,Merchant Banking, Agency Business  Insurance, Mutual Funds, Wealth Management etc.
[1]
Key Points
[
edit
]
Segments Revenue FY24
1) Corporate and Wholesale Banking (36%):
The Bank offers a variety of products, including working capital loans, term loans, and project financing to corporate clients, businesses, and large enterprises.
[1]
2) Retail Banking (~34%):
The Bank provides a variety of retail loans, including home loans, vehicle loans, and personal loans, to meet the diverse needs of its customers.
[2]
3) Treasury (27%):
The Bank’s treasury operations involve managing the Bank’s liquidity, investments, and foreign exchange activities. The Bank employs advanced risk management techniques to ensure optimal liquidity and maximize ROI.
[3]
4) Other Banking Operations (~3%):
Offers digital banking services, including app banking, internet banking, self-service banking, ATM banking, SMS banking, etc.
[4]
[5]
Market Share
As of FY24, the bank’s market share in deposits and net advances is ~6% and 5.5%, respectively, thereby making it the fifth-largest public sector bank.
[6]
[7]
Key Ratios
Capital Adequacy Ratio - 16.9% in FY24 vs 14.5% in FY22
[8]
[9]
NIM - 3.10% in FY24 vs 2.9% in FY22
[10]
[11]
Improvement in Asset Quality
Gross NPA - 4.76% in FY24 vs 11.11% in FY22
Net NPA - 1.03% in FY24 vs 3.68% in FY22
PCR - 92.3% in FY24 vs 83.6% in FY22
[12]
The bank has employed a multi-faceted approach to recover and resolve NPAs. Key strategies include- Legal Resources like SARFAESI and DRT Acts for quick recovery, Restructuring of NPA Accounts, and One-Time Settlement.
[13]
Branch Network
As of FY24, the bank has a network of 8,466 Branches & 8,982 ATMs. It has overseas branches in Sydney and Dubai, along with operations in London through WOS, Union Bank of India (UK) Ltd., and a JV in Malaysia, India International Bank (Malaysia) Berhad.
[14]
Rural: 30%
Semi-Urban: 29%
Metro: 21%
Urban: 20%
[7]
Loan Book
As of FY24, Gross advances stood at Rs. ~9,04,800 Cr vs Rs. ~7,16,400 Cr in FY22.
Corporate & Other: 45%
Retail: ~20%
Agriculture: 20%
MSME: 15%
The share of these segments to the gross advances largely remains the same between FY22 to FY24.
[15]
[16]
Loan Book Exposure
Infrastructure- ~10%, NBFC& HFC- 13.5%, Food Processing- 3.3%, Basic Metals- 2.7%, Textiles- 1.9%, Chemical - 1.6%, Petroleum- 1%.
Total exposure to these industries stood at ~34% of domestic advances in FY24 down from 43% as of FY22.
[17]
[18]
Deposits
As of FY24, total deposits of the company stood at Rs. ~12,21,500 Cr vs Rs. ~10,32,300 Cr in FY22.
CASA: ~34% in FY24 vs 36% in FY22
Retail Term Deposit: 37%
Bulk Term Deposit: 29%
[19]
[20]
IT Capex
In FY24, the company incurred Rs. 1,150 Cr on IT infrastructure, further plans to invest Rs. 1,400 Cr in FY25 on its core IT, security, analytics, and digital transformation project.
[21]
Fund Raising
In FY24, the Bank raised equity capital of Rs. 5,000 Cr by the allotment of 57.77 Cr equity shares on Aug 23 and equity capital of Rs. 3,000 Cr by the allotment of 22.11 Cr equity shares on Feb 24 through QIP issues.
[22]
Merger
In 2020, Andhra Bank and Corporation Bank were amalgamated into the Union Bank of India. This merger has enhanced UBI’s operational capabilities, customer reach, and financial strength, positioning.
[23]
Outlook
For the FY25, the bank projects growth in advances between 11%-13%, 9%-11% deposit growth, NIM of 2.8%-3%, and GNPA below 4%.
[24]
Last edited 2 weeks, 5 days ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 25,169 | 29,394 | 32,164 | 32,316 | 32,817 | 32,952 | 34,314 | 37,479 | 69,311 | 68,230 | 81,163 | 100,376 | 103,289 |
| Interest | 17,575 | 21,467 | 23,640 | 23,894 | 23,776 | 23,471 | 23,896 | 25,837 | 44,112 | 40,178 | 48,033 | 63,364 | 65,703 |
| Expenses + | 7,268 | 8,829 | 9,498 | 10,349 | 13,871 | 21,181 | 19,019 | 21,166 | 36,270 | 32,264 | 36,155 | 32,420 | 34,706 |
| Financing Profit | 325 | -902 | -973 | -1,928 | -4,830 | -11,700 | -8,601 | -9,523 | -11,071 | -4,213 | -3,024 | 4,591 | 2,880 |
| Financing Margin % | 1% | -3% | -3% | -6% | -15% | -36% | -25% | -25% | -16% | -6% | -4% | 5% | 3% |
| Other Income + | 2,868 | 3,141 | 3,957 | 3,934 | 5,430 | 5,462 | 5,042 | 5,789 | 14,307 | 13,524 | 15,915 | 17,813 | 18,402 |
| Depreciation | 156 | 198 | 225 | 249 | 241 | 368 | 374 | 417 | 908 | 745 | 745 | 896 | 0 |
| Profit before tax | 3,037 | 2,040 | 2,759 | 1,758 | 359 | -6,607 | -3,933 | -4,151 | 2,327 | 8,566 | 12,147 | 21,508 | 21,282 |
| Tax % | 30% | 18% | 36% | 24% | -58% | -21% | -25% | -27% | -22% | 39% | 31% | 36% |  |
| Net Profit + | 2,146 | 1,687 | 1,771 | 1,347 | 573 | -5,212 | -2,922 | -3,121 | 2,863 | 5,265 | 8,512 | 13,797 | 14,167 |
| EPS in Rs | 36.14 | 26.59 | 27.69 | 19.73 | 8.33 | -44.61 | -16.58 | -9.12 | 4.47 | 7.70 | 12.45 | 18.07 | 18.84 |
| Dividend Payout % | 22% | 15% | 22% | 10% | 0% | 0% | 0% | 0% | 0% | 25% | 24% | 20% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 46% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 69% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Executive Directors Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  | 0.76 | 0.81 | 0.75 | 1.11 | 1.21 |  |  |
| Remuneration paid. |  |  | 0.50 |  |  |  |  |  |  |  |
| CEO and Managing Director Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  | 0.33 | 0.30 | 0.34 | 0.37 |  |  |
| Shri Nitesh Ranjan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.39 | 0.41 |
| Shri Nidhu Saxena Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.32 | 0.34 |
| Chairman and Managing Director Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  | 0.28 |  |  |  |  |  |  |
| Remuneration paid. |  |  | 0.23 |  |  |  |  |  |  |  |
| Shri Ramasubramanian S Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.12 | 0.37 |
| Ms. A. Manimekhalai Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  |  | 0.40 |
| Shri Rajneesh Karnatak Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.34 | 0.03 |
| Ms. A Manimekhalai Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.30 |  |
| Shri Rajkiran Rai G. Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.19 |  |
| Shri Sanjay Rudra Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  |  | 0.16 |
| Shri Manas Ranjan Biswal Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  |  |  |  |  |  |  |  | 0.11 |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 25,169 | 29,394 | 32,164 | 32,316 | 32,817 | 32,952 | 34,314 | 37,479 | 69,311 | 68,230 | 81,163 | 100,376 | 103,289 |
| Interest | 17,575 | 21,467 | 23,640 | 23,894 | 23,776 | 23,471 | 23,896 | 25,837 | 44,112 | 40,178 | 48,033 | 63,364 | 65,703 |
| Expenses + | 7,268 | 8,829 | 9,498 | 10,349 | 13,871 | 21,181 | 19,019 | 21,166 | 36,270 | 32,264 | 36,155 | 32,420 | 34,706 |
| Financing Profit | 325 | -902 | -973 | -1,928 | -4,830 | -11,700 | -8,601 | -9,523 | -11,071 | -4,213 | -3,024 | 4,591 | 2,880 |
| Financing Margin % | 1% | -3% | -3% | -6% | -15% | -36% | -25% | -25% | -16% | -6% | -4% | 5% | 3% |
| Other Income + | 2,868 | 3,141 | 3,957 | 3,934 | 5,430 | 5,462 | 5,042 | 5,789 | 14,307 | 13,524 | 15,915 | 17,813 | 18,402 |
| Depreciation | 156 | 198 | 225 | 249 | 241 | 368 | 374 | 417 | 908 | 745 | 745 | 896 | 0 |
| Profit before tax | 3,037 | 2,040 | 2,759 | 1,758 | 359 | -6,607 | -3,933 | -4,151 | 2,327 | 8,566 | 12,147 | 21,508 | 21,282 |
| Tax % | 30% | 18% | 36% | 24% | -58% | -21% | -25% | -27% | -22% | 39% | 31% | 36% |  |
| Net Profit + | 2,146 | 1,687 | 1,771 | 1,347 | 573 | -5,212 | -2,922 | -3,121 | 2,863 | 5,265 | 8,512 | 13,797 | 14,167 |
| EPS in Rs | 36.14 | 26.59 | 27.69 | 19.73 | 8.33 | -44.61 | -16.58 | -9.12 | 4.47 | 7.70 | 12.45 | 18.07 | 18.84 |
| Dividend Payout % | 22% | 15% | 22% | 10% | 0% | 0% | 0% | 0% | 0% | 25% | 24% | 20% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 46% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 69% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 43% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | -4,245 | 2,570 | -3,567 | 81 | -6,624 | 6,097 | -7,778 | -77 | 20,527 | 36,339 | 6,056 | 19,930 |
| Cash from Investing Activity + | -343 | -363 | -318 | -9 | -280 | -315 | -297 | -4 | -601 | -558 | -2,561 | -1,394 |
| Cash from Financing Activity + | 5,096 | 4,902 | 3,168 | -2 | 10,194 | 10,792 | 1,758 | 201 | -18,861 | -786 | -10,654 | -11,489 |
| Net Cash Flow | 507 | 7,109 | -718 | 70 | 3,289 | 16,574 | -6,317 | 121 | 1,066 | 34,995 | -7,159 | 7,047 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % | 13% | 9% | 9% | 6% | 2% | -21% | -11% | -10% | 6% | 8% | 11% | 16% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 83.49% | 83.49% | 83.49% | 83.49% | 83.49% | 83.49% | 83.49% | 83.49% | 76.99% | 76.99% | 74.76% | 74.76% |
| FIIs + | 1.49% | 1.19% | 1.18% | 1.13% | 1.43% | 1.62% | 1.66% | 1.46% | 2.89% | 3.97% | 6.75% | 7.37% |
| DIIs + | 6.72% | 7.02% | 7.05% | 6.90% | 7.05% | 8.39% | 8.27% | 7.88% | 12.69% | 12.28% | 12.24% | 11.38% |
| Public + | 8.29% | 8.30% | 8.27% | 8.47% | 8.02% | 6.49% | 6.57% | 7.17% | 7.42% | 6.76% | 6.25% | 6.50% |
| No. of Shareholders | 6,90,809 | 7,39,143 | 7,61,809 | 7,98,214 | 7,81,554 | 7,80,208 | 7,83,550 | 7,75,773 | 8,65,251 | 8,74,309 | 9,14,940 | 9,84,229 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 63.44% | 67.43% | 74.27% | 86.75% | 89.07% | 83.49% | 83.49% | 74.76% | 74.76% |
| FIIs + | 5.02% | 5.01% | 3.15% | 1.29% | 0.66% | 1.18% | 1.66% | 6.75% | 7.37% |
| DIIs + | 20.80% | 19.89% | 13.15% | 6.37% | 4.37% | 7.05% | 8.27% | 12.24% | 11.38% |
| Public + | 10.74% | 7.68% | 9.42% | 5.59% | 5.90% | 8.27% | 6.57% | 6.25% | 6.50% |
| No. of Shareholders | 2,37,105 | 2,42,378 | 2,70,916 | 2,99,546 | 6,31,887 | 7,61,809 | 7,83,550 | 9,14,940 | 9,84,229 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/union-bank-of-india/unionbank/532477/corp-announcements/)
- [Transcript Of Post Earnings Call 15h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=045f69e4-b7a9-4027-a6eb-ba28a9b8c9ad.pdf)
- [Annual Interest Payment On Bonds - INE692A08193 18h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a9f3bdd-f8c9-4f76-bc49-5e102f5513c5.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=69f4fa12-f010-4db7-831f-e5b997dc307b.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cce3282e-1c35-471c-8f59-5052f8c435a1.pdf)
- [Union Bank Of India Has informed About Audio Recording Of Post Earnings Call](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06dc9f99-48a6-4e98-a33b-b076a1f3fc02.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a59b26ca-8c5f-424f-ae8d-27c1b78e35f3.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\083844e2-7459-4598-a74d-1254dc28b4bc.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/532477/73178532477.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/532477/68848532477.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_UNIONBANK_2011_2012_29062012101542.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/532477/5324770311.pdf)
- [DRHP](https://www.sebi.gov.in/filings/public-issues/feb-2006/union-bank-of-india_10881.html)

## Credit Ratings
- [Rating update
2 Jul from fitch](https://www.indiaratings.co.in/pressrelease/70691)
- [Rating update
22 Dec 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/UnionBankofIndia_December%2022,%202023_RR_333748.html)
- [Rating update
23 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123645)
- [Rating update
26 Oct 2023 from fitch](https://www.indiaratings.co.in/pressrelease/67015)
- [Rating update
22 Sep 2023 from brickwork](https://www.brickworkratings.com/Admin/PressRelease/Union-Bank-of-India-22Sep2023.pdf)
- [](https://www.careratings.com/upload/CompanyFiles/PR/202309130901_Union_Bank_of_India.pdf)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=045f69e4-b7a9-4027-a6eb-ba28a9b8c9ad.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d005b8cc-a914-4f29-8cc1-74efaa183490.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bd074b10-0bad-4166-9fa1-aa05d632ae5e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cbf0f5cd-4877-43e5-b0a8-08dda9f446a6.pdf)
- [REC](https://www.unionbankofindia.co.in/pdf/UBI0320240511152831.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94798d5c-c2e4-41bb-b4c6-f6f3117926ef.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2b7d13f-d95c-4a7d-9d9f-dee412ba8cbd.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51dd1033-1178-4bed-b7a4-84c59cdb8084.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=377de62c-82a3-478d-ab3f-6890b9f749cd.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3aa0dae8-68e2-4984-90d3-ea71f8e4dc7e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=96f6d1d3-e63b-4e32-a5e7-aad79ff8a58a.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94c83fb3-6c76-482c-a5a3-5e2d2bf34f9f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=62a4b9c9-3c6a-455e-915b-07c29d5b2b71.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b03ee25c-263b-47a5-9560-7a2d68e890ca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=acd5310c-3109-418c-abb8-2f9e37dcdc96.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f645fd64-188b-45c9-8118-8bc87204db67.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3d755666-bebb-42d5-a8e8-1a07af767556.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d56f4b8d-d453-4ce2-9658-f649aa9d2a14.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1c6e8a55-2833-4abc-9fc2-573b11e80bb5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f8edae24-cac7-4284-aba6-35269775b6df.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cd50aa0d-8770-4a55-8e4d-2a6e239470f8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a82e0a78-9931-4953-a999-a89fb2d5deae.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e48de141-53ee-482d-90e4-badf60a3b0f5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=50c03543-9328-4edd-b182-fb15393fbca2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f358f1ff-a18d-4cd2-bb2f-b7c40547162a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=037ed777-34e5-4f8f-a9b6-bb8fdc14e198.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Transcript-of-Earnings-Conference-Call-Q1-FY2022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d2f285f8-1909-4731-8c6e-ed76a0bf5325.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=693d2082-8da7-4899-982b-705a0f534374.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBankofIndiaTranscriptQ4FY21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0578eccb-8f68-4107-954f-efb943ce1c04.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c0096a9f-5393-410f-8a1b-00e758dbfaf4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f053d0c-fc89-44c7-b5ea-f2fa303478ca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6071eb97-f4ef-4335-a231-f29b6b84bf5d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=07cffb26-38ef-4312-ad86-58e859ee0998.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBank-Analyst%20Call-Transcript-Dec-2020.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBank-Earnings-06Nov-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c826894-0908-4dd3-8e8e-14a2df736aa0.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBank-Analyst-21Aug-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c349986f-25cc-4858-9151-7273de48a90e.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBank-Earnings-June24-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28b97ec2-20fa-4dc3-ba5f-76807332f78a.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Transcript-UnionBank-of-India-Feb10-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bdf5690-5df6-4ef5-a827-56b78b674131.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ecbd78a5-d2e1-4740-9a3c-902b8d912013.pdf)
- [](https://www.unionbankofindia.co.in/pdf/ElaraSec-UnionBank-Aug02-2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=27201ac4-f155-49fb-a7ee-1930341defe6.pdf)
- [](https://www.unionbankofindia.co.in/pdf/CONCALL-TRANSCRIPT-MAR%2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=40c811cc-a455-4ff0-bc4e-e1eef2523593.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Union-Bank-Of-India-Q3FY19-Concall-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=518819f7-c70b-4deb-a1f2-258c94a9876b.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UnionBank-Q2FY19-conference-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3ab9d857-5c5d-41a5-8710-401d1f2cbb22.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UBI-Q1FY19-Results-Conference-Call-Transcript-Aug%2010-2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a9f93c8-486c-491b-b5cf-4645f3f875f3.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Union-Bank-Q4FY18-Results-Conference-Call-Transcript-May-10-2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7e9ad4d0-8e4d-47ed-81b6-553c4b52f6f7.pdf)
- [](https://www.unionbankofindia.co.in/pdf/UBI-Q3FY18-Transcript-03-Feb-18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d834db5e-3d36-4250-8640-1fece377dd76.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Q2FY18-Results-03Nov-2017.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f176efc-d51b-4102-ac4e-2bccf7ccd696.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cb955196-f982-4214-bae2-d174f42937c3.pdf)
- [](https://www.unionbankofindia.co.in/pdf/conference-call-transcript-10-Aug-2017.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=76c94c8d-041e-49b2-b9bd-7bee876dc200.pdf)
- [](https://www.unionbankofindia.co.in/pdf/Conference-Call-Transcript-08-May-17-EDEL.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | St Bk of India | 858.35 | 766044.01 | 11.51 | 1.83 | 1.74 | -236.01 | 17.04 | 19.89 | 1.60 | 6.16 | 1.10 | 17.34 | 0.07 | 13.51 | 1.35 | 15.29 | 439188.51 | 45.41 | 67102.23 | 117469.38 | 21384.15 | 19.77 | 18.18 | 75.17 | 5606146.99 | 57.54 | 0.00 | 5.81 | 9.46 | 0.00 | 25.18 | 20.54 | 6045618.70 | 2.56 | 0.12 | 5.89 | 38.47 | 25.43 | 37.62 | 15.66 | 13.00 | 98.73 | 44.11 | 11.63 | 16.45 | 16.75 | 5.20 | 2.56 | 75.17 | 98.73 | 11.87 | 11.24 | 12.24 | 0.00 | 892.46 |
| 2. | Punjab Natl.Bank | 118.70 | 130700.76 | 14.35 | 1.18 | 1.20 | 31.49 | 17.36 | 11.60 | 1.26 | 5.46 | 0.59 | 8.54 | 0.07 | 13.15 | 1.21 | 14.01 | 109064.58 | 63.67 | 9102.91 | 28682.32 | 3342.20 | 18.01 | 79.27 | 8.27 | 1451810.86 | 73.15 | 0.00 | 5.70 | 9.46 | 0.00 | 25.58 | 171.99 | 1451111.43 | 4.88 | 0.59 | -13.73 | 12.65 | 44.34 | 88.65 | 5.40 | 4.44 | 24.17 | 52.35 | 15.90 | 10.00 | 3.34 | 4.10 | 4.88 | 8.27 | 19.11 | 16.71 | 15.21 | 17.41 | 0.00 | 1101.10 |
| 3. | Bank of Baroda | 248.45 | 128482.48 | 6.88 | 1.05 | 1.09 | -14.55 | 15.22 | 16.87 | 3.07 | 6.33 | 1.19 | 16.69 | 0.07 | 12.14 | 1.37 | 13.28 | 118379.22 | 62.51 | 18761.10 | 31072.17 | 5132.45 | 14.25 | -2.34 | 36.29 | 1453760.94 | 63.97 | 0.00 | 6.46 | 9.46 | 0.00 | 25.27 | 25.99 | 1481953.57 | 1.80 | 0.09 | -8.47 | 8.06 | 45.29 | 23.14 | 13.93 | 9.87 | 76.82 | 144.18 | 17.48 | 16.79 | 15.12 | 5.17 | 1.80 | 36.29 | 54.63 | 9.77 | 7.51 | 11.53 | 0.00 | 517.14 |
| 4. | I O B | 67.17 | 126967.59 | 45.55 | 4.50 | 5.05 | -31.32 | 22.52 | 41.94 | 0.00 | 5.41 | 0.80 | 9.98 | 0.07 | 11.32 | 1.24 | 11.91 | 25160.45 | 51.55 | 2788.05 | 6535.03 | 632.81 | 20.48 | 26.47 | 1.47 | 316292.55 | 96.38 | 0.00 | 4.47 | 9.46 | 0.00 | 23.40 | 26.33 | 424705.72 | 4.53 | 2.08 | -1.62 | 43.54 | 38.91 | 148.75 | 9.14 | -1.20 | 21.90 | 47.32 | 6.41 | 12.33 | 8.69 | 4.53 | 4.53 | 1.40 | 18.48 | 30.14 | 28.32 | 30.14 | 0.00 | 1890.24 |
| 5. | Canara Bank | 113.60 | 103042.62 | 6.61 | 1.11 | 0.90 | -11.58 | 13.80 | 18.41 | 2.86 | 6.63 | 1.06 | 17.94 | 0.08 | 14.87 | 1.27 | 15.83 | 114240.94 | 57.92 | 15607.15 | 29172.97 | 4067.51 | 14.63 | 8.79 | 17.21 | 1369780.03 | 62.93 | 0.00 | 7.26 | 9.46 | 0.00 | 23.11 | 21.80 | 1321657.96 | 2.58 | 0.07 | -9.42 | 20.23 | 55.50 | 62.25 | 14.35 | 10.51 | 90.75 | 74.70 | 18.18 | 16.30 | 14.79 | 5.33 | 2.58 | 16.84 | 60.00 | 6.81 | 6.03 | 7.34 | 0.00 | 907.07 |
| 6. | Union Bank (I) | 132.30 | 100992.58 | 7.16 | 1.02 | 0.98 | 5.21 | 14.17 | 13.48 | 2.70 | 6.55 | 1.03 | 15.64 | 0.07 | 12.82 | 1.32 | 13.78 | 103289.30 | 66.40 | 14167.24 | 26526.92 | 3641.78 | 12.34 | 11.31 | 18.84 | 1251567.63 | 74.76 | 0.00 | 7.06 | 9.46 | 0.00 | 19.38 | 38.89 | 1232914.36 | 3.24 | 0.15 | -12.50 | -5.93 | 54.29 | 43.36 | 11.95 | 8.79 | 46.36 | 69.30 | 23.95 | 13.14 | 11.38 | 5.02 | 3.24 | 18.07 | 25.31 | 6.84 | 6.43 | 7.50 | 0.00 | 683.47 |
| 7. | Indian Bank | 579.85 | 78103.78 | 9.24 | 1.32 | 1.40 | -26.04 | 17.02 | 21.67 | 2.05 | 5.92 | 1.12 | 15.35 | 0.07 | 11.80 | 1.34 | 12.52 | 55649.73 | 63.45 | 8421.32 | 14633.41 | 2295.61 | 19.41 | 51.06 | 62.51 | 711095.95 | 73.84 | 0.00 | 5.82 | 9.46 | 0.00 | 23.71 | 51.13 | 747022.82 | 2.18 | 0.11 | 7.81 | 23.24 | 60.52 | 72.80 | 12.56 | 11.26 | 85.67 | 38.80 | 23.74 | 12.48 | 11.80 | 4.55 | 2.18 | 62.51 | 51.07 | 6.77 | 6.93 | 7.97 | 0.00 | 124.54 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | Sales | ₹ 1,03,289 Cr. |
| UNIONBANK | OPM | 66.4 % |
| UNIONBANK | Profit after tax | ₹ 14,167 Cr. |
| UNIONBANK | Mar Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Sales Qtr | ₹ 26,527 Cr. |
| UNIONBANK | PAT Qtr | ₹ 3,642 Cr. |
| UNIONBANK | Qtr Sales Var | 12.3 % |
| UNIONBANK | Qtr Profit Var | 11.3 % |
| UNIONBANK | Price to Earning | 7.17 |
| UNIONBANK | Dividend yield | 2.70 % |
| UNIONBANK | Price to book value | 1.02 |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | Return on assets | 1.03 % |
| UNIONBANK | Debt to equity | 12.8 |
| UNIONBANK | Return on equity | 15.6 % |
| UNIONBANK | EPS | ₹ 18.8 |
| UNIONBANK | Debt | ₹ 12,51,568 Cr. |
| UNIONBANK | Promoter holding | 74.8 % |
| UNIONBANK | Change in Prom Hold | 0.00 % |
| UNIONBANK | Earnings yield | 7.06 % |
| UNIONBANK | Pledged percentage | 0.00 % |
| UNIONBANK | Industry PE | 9.46 |
| UNIONBANK | Sales growth | 19.4 % |
| UNIONBANK | Profit growth | 38.9 % |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | Price to Sales | 0.98 |
| UNIONBANK | CMP / FCF | 5.21 |
| UNIONBANK | EVEBITDA | 14.2 |
| UNIONBANK | Enterprise Value | ₹ 12,33,029 Cr. |
| UNIONBANK | Current ratio | 3.24 |
| UNIONBANK | Int Coverage | 1.32 |
| UNIONBANK | PEG Ratio | 0.15 |
| UNIONBANK | Return over 3months | -12.5 % |
| UNIONBANK | Return over 6months | -5.93 % |
| UNIONBANK | No. Eq. Shares | 763 |
| UNIONBANK | Sales growth 3Years | 13.1 % |
| UNIONBANK | Sales growth 5Years | 24.0 % |
| UNIONBANK | Profit Var 3Yrs | 69.3 % |
| UNIONBANK | Profit Var 5Yrs | 46.4 % |
| UNIONBANK | ROE 5Yr | 8.79 % |
| UNIONBANK | ROE 3Yr | 12.0 % |
| UNIONBANK | Return over 1year | 43.4 % |
| UNIONBANK | Return over 3years | 54.3 % |
| UNIONBANK | Return over 5years | 13.5 % |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | Sales last year | ₹ 1,00,376 Cr. |
| UNIONBANK | OP Ann | ₹ 67,955 Cr. |
| UNIONBANK | Other Inc Ann | ₹ 17,813 Cr. |
| UNIONBANK | EBIDT last year | ₹ 85,766 Cr. |
| UNIONBANK | Dep Ann | ₹ 896 Cr. |
| UNIONBANK | EBIT last year | ₹ 84,870 Cr. |
| UNIONBANK | Interest last year | ₹ 63,364 Cr. |
| UNIONBANK | PBT Ann | ₹ 21,508 Cr. |
| UNIONBANK | Tax last year | ₹ 7,799 Cr. |
| UNIONBANK | PAT Ann | ₹ 13,796 Cr. |
| UNIONBANK | Extra Ord Item Ann | ₹ 2.17 Cr. |
| UNIONBANK | NP Ann | ₹ 13,797 Cr. |
| UNIONBANK | Dividend last year | ₹ 2,748 Cr. |
| UNIONBANK | Raw Material | 0.00 % |
| UNIONBANK | Employee cost | ₹ 14,600 Cr. |
| UNIONBANK | OPM last year | 67.7 % |
| UNIONBANK | NPM last year | 13.7 % |
| UNIONBANK | Operating profit | ₹ 68,584 Cr. |
| UNIONBANK | Interest | ₹ 65,703 Cr. |
| UNIONBANK | Depreciation | ₹ 0.00 Cr. |
| UNIONBANK | EPS last year | ₹ 18.1 |
| UNIONBANK | EBIT | ₹ 86,986 Cr. |
| UNIONBANK | Net profit | ₹ 14,167 Cr. |
| UNIONBANK | Current Tax | ₹ 7,213 Cr. |
| UNIONBANK | Tax | ₹ 7,213 Cr. |
| UNIONBANK | Other income | ₹ 18,402 Cr. |
| UNIONBANK | Ann Date | 2,02,403 |
| UNIONBANK | Sales Prev Ann | ₹ 81,163 Cr. |
| UNIONBANK | OP Prev Ann | ₹ 45,009 Cr. |
| UNIONBANK | Other Inc Prev Ann | ₹ 15,915 Cr. |
| UNIONBANK | EBIDT Prev Ann | ₹ 60,925 Cr. |
| UNIONBANK | Dep Prev Ann | ₹ 745 Cr. |
| UNIONBANK | EBIT preceding year | ₹ 60,181 Cr. |
| UNIONBANK | Interest Prev Ann | ₹ 48,033 Cr. |
| UNIONBANK | PBT Prev Ann | ₹ 12,147 Cr. |
| UNIONBANK | Tax preceding year | ₹ 3,716 Cr. |
| UNIONBANK | PAT Prev Ann | ₹ 8,513 Cr. |
| UNIONBANK | Extra Ord Prev Ann | ₹ -1.49 Cr. |
| UNIONBANK | NP Prev Ann | ₹ 8,512 Cr. |
| UNIONBANK | Dividend Prev Ann | ₹ 2,050 Cr. |
| UNIONBANK | OPM preceding year | 55.4 % |
| UNIONBANK | NPM preceding year | 10.5 % |
| UNIONBANK | EPS preceding year | ₹ 12.4 |
| UNIONBANK | Sales Prev 12M | ₹ 1,00,376 Cr. |
| UNIONBANK | Profit Prev 12M | ₹ 13,797 Cr. |
| UNIONBANK | Med Sales Gwth 10Yrs | 4.13 % |
| UNIONBANK | Med Sales Gwth 5Yrs | 19.0 % |
| UNIONBANK | Sales growth 7Years | 17.3 % |
| UNIONBANK | Sales Var 10Yrs | 13.1 % |
| UNIONBANK | EBIDT growth 3Years | 21.9 % |
| UNIONBANK | EBIDT growth 5Years | 33.4 % |
| UNIONBANK | EBIDT growth 7Years | 19.7 % |
| UNIONBANK | EBIDT Var 10Yrs | 13.7 % |
| UNIONBANK | EPS growth 3Years | 59.7 % |
| UNIONBANK | EPS growth 5Years | 25.3 % |
| UNIONBANK | EPS growth 7Years | 12.4 % |
| UNIONBANK | EPS growth 10Years | -3.78 % |
| UNIONBANK | Profit Var 7Yrs | 58.6 % |
| UNIONBANK | Profit Var 10Yrs | 23.5 % |
| UNIONBANK | Chg in Prom Hold 3Yr | -8.73 % |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | OP Qtr | ₹ 17,160 Cr. |
| UNIONBANK | Other Inc Qtr | ₹ 4,799 Cr. |
| UNIONBANK | EBIDT Qtr | ₹ 21,958 Cr. |
| UNIONBANK | Dep Qtr | ₹ 0.00 Cr. |
| UNIONBANK | EBIT latest quarter | ₹ 21,958 Cr. |
| UNIONBANK | Interest Qtr | ₹ 17,004 Cr. |
| UNIONBANK | PBT Qtr | ₹ 4,954 Cr. |
| UNIONBANK | Tax latest quarter | ₹ 1,354 Cr. |
| UNIONBANK | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| UNIONBANK | NP Qtr | ₹ 3,642 Cr. |
| UNIONBANK | GPM latest quarter | 100 % |
| UNIONBANK | OPM latest quarter | 64.7 % |
| UNIONBANK | NPM latest quarter | 13.7 % |
| UNIONBANK | Eq Cap Qtr | ₹ 7,634 Cr. |
| UNIONBANK | EPS latest quarter | ₹ 4.77 |
| UNIONBANK | OP 2Qtr Bk | ₹ 17,509 Cr. |
| UNIONBANK | OP 3Qtr Bk | ₹ 16,770 Cr. |
| UNIONBANK | Sales 2Qtr Bk | ₹ 25,521 Cr. |
| UNIONBANK | Sales 3Qtr Bk | ₹ 24,732 Cr. |
| UNIONBANK | NP 2Qtr Bk | ₹ 3,625 Cr. |
| UNIONBANK | NP 3Qtr Bk | ₹ 3,572 Cr. |
| UNIONBANK | Opert Prft Gwth | 36.9 % |
| UNIONBANK | Last result date | 2,02,406 |
| UNIONBANK | Exp Qtr Sales Var | 19.6 % |
| UNIONBANK | Exp Qtr Sales | ₹ 29,571 Cr. |
| UNIONBANK | Exp Qtr OP | ₹ 19,782 Cr. |
| UNIONBANK | Exp Qtr NP | ₹ 2,769 Cr. |
| UNIONBANK | Exp Qtr EPS | ₹ 3.63 |
| UNIONBANK | Sales Prev Qtr | ₹ 26,510 Cr. |
| UNIONBANK | OP Prev Qtr | ₹ 17,145 Cr. |
| UNIONBANK | Other Inc Prev Qtr | ₹ 5,102 Cr. |
| UNIONBANK | EBIDT Prev Qtr | ₹ 22,247 Cr. |
| UNIONBANK | Dep Prev Qtr | ₹ 0.00 Cr. |
| UNIONBANK | EBIT Prev Qtr | ₹ 22,247 Cr. |
| UNIONBANK | Interest Prev Qtr | ₹ 16,966 Cr. |
| UNIONBANK | PBT Prev Qtr | ₹ 5,281 Cr. |
| UNIONBANK | Tax Prev Qtr | ₹ 1,971 Cr. |
| UNIONBANK | PAT Prev Qtr | ₹ 3,328 Cr. |
| UNIONBANK | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| UNIONBANK | NP Prev Qtr | ₹ 3,328 Cr. |
| UNIONBANK | OPM Prev Qtr | 64.7 % |
| UNIONBANK | NPM Prev Qtr | 12.6 % |
| UNIONBANK | Eq Cap Prev Qtr | ₹ Cr. |
| UNIONBANK | EPS Prev Qtr | ₹ 4.36 |
| UNIONBANK | Sales PY Qtr | ₹ 23,613 Cr. |
| UNIONBANK | OP PY Qtr | ₹ 15,636 Cr. |
| UNIONBANK | Other Inc PY Qtr | ₹ 4,209 Cr. |
| UNIONBANK | EBIDT PY Qtr | ₹ 19,845 Cr. |
| UNIONBANK | Dep PY Qtr | ₹ 0.00 Cr. |
| UNIONBANK | EBIT PY Qtr | ₹ 19,845 Cr. |
| UNIONBANK | Interest PY Qtr | ₹ 14,664 Cr. |
| UNIONBANK | PBT PY Qtr | ₹ 5,180 Cr. |
| UNIONBANK | Tax PY Qtr | ₹ 1,940 Cr. |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | Equity capital | ₹ 7,634 Cr. |
| UNIONBANK | Preference capital | ₹ 0.00 Cr. |
| UNIONBANK | Reserves | ₹ 89,964 Cr. |
| UNIONBANK | Secured loan | ₹ 26,974 Cr. |
| UNIONBANK | Unsecured loan | ₹ 12,24,593 Cr. |
| UNIONBANK | Balance sheet total | ₹ 14,01,996 Cr. |
| UNIONBANK | Gross block | ₹ 19,621 Cr. |
| UNIONBANK | Revaluation reserve | ₹ 5,644 Cr. |
| UNIONBANK | Accum Dep | ₹ 10,397 Cr. |
| UNIONBANK | Net block | ₹ 9,224 Cr. |
| UNIONBANK | CWIP | ₹ 35.9 Cr. |
| UNIONBANK | Investments | ₹ 3,43,953 Cr. |
| UNIONBANK | Current assets | ₹ 1,70,990 Cr. |
| UNIONBANK | Current liabilities | ₹ 52,831 Cr. |
| UNIONBANK | BV Unq Invest | ₹ 3,166 Cr. |
| UNIONBANK | MV Quoted Inv | ₹ 0.00 Cr. |
| UNIONBANK | Cont Liab | ₹ 6,33,499 Cr. |
| UNIONBANK | Total Assets | ₹ 14,01,996 Cr. |
| UNIONBANK | Working capital | ₹ 1,18,159 Cr. |
| UNIONBANK | Lease liabilities | ₹ 0.00 Cr. |
| UNIONBANK | Inventory | ₹ 0.00 Cr. |
| UNIONBANK | Trade receivables | ₹ 0.00 Cr. |
| UNIONBANK | Face value | ₹ 10.0 |
| UNIONBANK | Cash Equivalents | ₹ 1,19,646 Cr. |
| UNIONBANK | Adv Cust | ₹ 0.00 Cr. |
| UNIONBANK | Trade Payables | ₹ 2,641 Cr. |
| UNIONBANK | No. Eq. Shares PY | 683 |
| UNIONBANK | Debt preceding year | ₹ 11,63,059 Cr. |
| UNIONBANK | Work Cap PY | ₹ 1,16,348 Cr. |
| UNIONBANK | Net Block PY | ₹ 8,826 Cr. |
| UNIONBANK | Gross Block PY | ₹ 18,681 Cr. |
| UNIONBANK | CWIP PY | ₹ 22.2 Cr. |
| UNIONBANK | Work Cap 3Yr | ₹ 86,894 Cr. |
| UNIONBANK | Work Cap 5Yr | ₹ 51,469 Cr. |
| UNIONBANK | Work Cap 7Yr | ₹ 34,908 Cr. |
| UNIONBANK | Work Cap 10Yr | ₹ 20,045 Cr. |
| UNIONBANK | Debt 3Years back | ₹ 9,77,576 Cr. |
| UNIONBANK | Debt 5Years back | ₹ 4,60,780 Cr. |
| UNIONBANK | Debt 7Years back | ₹ 4,18,420 Cr. |
| UNIONBANK | Debt 10Years back | ₹ 3,27,078 Cr. |
| UNIONBANK | Net Block 3Yrs Back | ₹ 7,303 Cr. |
| UNIONBANK | Net Block 5Yrs Back | ₹ 3,743 Cr. |
| UNIONBANK | Net Block 7Yrs Back | ₹ 3,896 Cr. |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | CF Operations | ₹ 19,930 Cr. |
| UNIONBANK | Free Cash Flow | ₹ 18,624 Cr. |
| UNIONBANK | CF Investing | ₹ -1,394 Cr. |
| UNIONBANK | CF Financing | ₹ -11,489 Cr. |
| UNIONBANK | Net CF | ₹ 7,047 Cr. |
| UNIONBANK | Cash Beginning | ₹ 1,12,599 Cr. |
| UNIONBANK | Cash End | ₹ 1,19,646 Cr. |
| UNIONBANK | FCF Prev Ann | ₹ 3,673 Cr. |
| UNIONBANK | CF Operations PY | ₹ 6,056 Cr. |
| UNIONBANK | CF Investing PY | ₹ -2,561 Cr. |
| UNIONBANK | CF Financing PY | ₹ -10,654 Cr. |
| UNIONBANK | Net CF PY | ₹ -7,159 Cr. |
| UNIONBANK | Cash Beginning PY | ₹ 1,19,758 Cr. |
| UNIONBANK | Cash End PY | ₹ 1,12,599 Cr. |
| UNIONBANK | Free Cash Flow 3Yrs | ₹ 58,194 Cr. |
| UNIONBANK | Free Cash Flow 5Yrs | ₹ 78,040 Cr. |
| UNIONBANK | Free Cash Flow 7Yrs | ₹ 75,747 Cr. |
| UNIONBANK | Free Cash Flow 10Yrs | ₹ 64,999 Cr. |
| UNIONBANK | CF Opr 3Yrs | ₹ 62,324 Cr. |
| UNIONBANK | CF Opr 5Yrs | ₹ 82,775 Cr. |
| UNIONBANK | CF Opr 7Yrs | ₹ 81,094 Cr. |
| UNIONBANK | CF Opr 10Yrs | ₹ 70,983 Cr. |
| UNIONBANK | CF Inv 10Yrs | ₹ -6,336 Cr. |
| UNIONBANK | CF Inv 7Yrs | ₹ -5,729 Cr. |
| UNIONBANK | CF Inv 5Yrs | ₹ -5,117 Cr. |
| UNIONBANK | CF Inv 3Yrs | ₹ -4,513 Cr. |
| UNIONBANK | Cash 3Years back | ₹ 84,763 Cr. |
| UNIONBANK | Cash 5Years back | ₹ 43,163 Cr. |
| UNIONBANK | Cash 7Years back | ₹ 32,906 Cr. |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | No. Eq. Shares | 763 |
| UNIONBANK | Book value | ₹ 128 |
| UNIONBANK | Inven TO |  |
| UNIONBANK | Quick ratio | 3.24 |
| UNIONBANK | Exports percentage | 0.00 % |
| UNIONBANK | Piotroski score | 7.00 |
| UNIONBANK | G Factor | 7.00 |
| UNIONBANK | Asset Turnover | 0.07 |
| UNIONBANK | Financial leverage | 13.8 |
| UNIONBANK | No. of Share Holders | 9,84,229 |
| UNIONBANK | Unpledged Prom Hold | 74.8 % |
| UNIONBANK | ROIC | 6.55 % |
| UNIONBANK | Debtor days | 0.00 |
| UNIONBANK | Industry PBV | 1.03 |
| UNIONBANK | Credit rating |  |
| UNIONBANK | WC Days | -5.41 |
| UNIONBANK | Earning Power | 6.20 % |
| UNIONBANK | Graham Number | ₹ 233 |
| UNIONBANK | Cash Cycle | 0.00 |
| UNIONBANK | Days Payable |  |
| UNIONBANK | Days Receivable | 0.00 |
| UNIONBANK | Inventory Days |  |
| UNIONBANK | Public holding | 6.50 % |
| UNIONBANK | FII holding | 7.37 % |
| UNIONBANK | Chg in FII Hold | 0.62 % |
| UNIONBANK | DII holding | 11.4 % |
| UNIONBANK | Chg in DII Hold | -0.86 % |
| UNIONBANK | B.V. Prev Ann | ₹ 115 |
| UNIONBANK | ROCE Prev Yr | 5.02 % |
| UNIONBANK | ROA Prev Yr | 0.69 % |
| UNIONBANK | ROE Prev Ann | 11.4 % |
| UNIONBANK | No. of Share Holders Prev Qtr | 9,14,940 |
| UNIONBANK | No. Eq. Shares 10 Yrs | 63.6 |
| UNIONBANK | BV 3yrs back | ₹ 101 |
| UNIONBANK | BV 5yrs back | ₹ 99.3 |
| UNIONBANK | BV 10yrs back | ₹ 313 |
| UNIONBANK | Inven TO 3Yr |  |
| UNIONBANK | Inven TO 5Yr |  |
| UNIONBANK | Inven TO 7Yr |  |
| UNIONBANK | Inven TO 10Yr |  |
| UNIONBANK | Export 3Yr | 0.00 % |
| UNIONBANK | Export 5Yr | 0.00 % |
| UNIONBANK | Div 5Yrs | ₹ 1,219 Cr. |
| UNIONBANK | ROCE 3Yr | 5.33 % |
| UNIONBANK | ROCE 5Yr | 5.22 % |
| UNIONBANK | ROCE 7Yr | 4.84 % |
| UNIONBANK | ROCE 10Yr | 5.36 % |
| UNIONBANK | ROE 10Yr | 5.36 % |
| UNIONBANK | ROE 7Yr | 5.31 % |
| UNIONBANK | ROE 5Yr Var | 27.7 % |
| UNIONBANK | OPM 5Year | 55.6 % |
| UNIONBANK | OPM 10Year | 55.4 % |
| UNIONBANK | No. of Share Holders 1Yr | 7,75,773 |
| UNIONBANK | Avg Div Payout 3Yrs | 22.9 % |
| UNIONBANK | Debtor days 3yrs | 0.00 |
| UNIONBANK | Debtor days 3yrs back | 0.00 |
| UNIONBANK | Debtor days 5yrs back | 0.00 |
| UNIONBANK | ROA 5Yr | 0.39 % |
| UNIONBANK | ROA 3Yr | 0.72 % |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | Avg Vol 1Mth | 1,39,22,868 |
| UNIONBANK | Avg Vol 1Wk | 1,15,93,501 |
| UNIONBANK | Volume | 98,04,697 |
| UNIONBANK | High price | ₹ 172 |
| UNIONBANK | Low price | ₹ 84.8 |
| UNIONBANK | High price all time | ₹ 427 |
| UNIONBANK | Low price all time | ₹ 22.6 |
| UNIONBANK | Return over 1day | 0.32 % |
| UNIONBANK | Return over 1week | -2.67 % |
| UNIONBANK | Return over 1month | -6.01 % |
| UNIONBANK | DMA 50 | ₹ 141 |
| UNIONBANK | DMA 200 | ₹ 131 |
| UNIONBANK | DMA 50 previous day | ₹ 141 |
| UNIONBANK | 200 DMA prev. | ₹ 131 |
| UNIONBANK | RSI | 37.1 |
| UNIONBANK | MACD | -2.31 |
| UNIONBANK | MACD Previous Day | -2.08 |
| UNIONBANK | MACD Signal | -2.22 |
| UNIONBANK | MACD Signal Prev | -2.20 |
| UNIONBANK | Avg Vol 1Yr | 2,48,71,882 |
| UNIONBANK | Return over 7years | -2.44 % |
| UNIONBANK | Return over 10years | -3.68 % |
| UNIONBANK | Market Cap | ₹ 1,01,107 Cr. |
| UNIONBANK | Current Price | ₹ 132 |
| UNIONBANK | High / Low | ₹ 172 / 84.8 |
| UNIONBANK | Stock P/E | 7.17 |
| UNIONBANK | Book Value | ₹ 128 |
| UNIONBANK | Dividend Yield | 2.70 % |
| UNIONBANK | ROCE | 6.55 % |
| UNIONBANK | ROE | 15.6 % |
| UNIONBANK | Face Value | ₹ 10.0 |
| UNIONBANK | WC to Sales | 114 % |
| UNIONBANK | QoQ Profits | 9.42 % |
| UNIONBANK | QoQ Sales | 0.06 % |
| UNIONBANK | Net worth | ₹ 97,598 Cr. |
| UNIONBANK | Market Cap to Sales | 0.98 |
| UNIONBANK | Interest Coverage | 1.32 |
| UNIONBANK | EV / EBIT | 14.2 |
| UNIONBANK | Debt Capacity | -7.29 |
| UNIONBANK | Debt To Profit | 90.7 |
| UNIONBANK | Capital Employed | ₹ 1,27,419 Cr. |
| UNIONBANK | CROIC | 1.50 % |
| UNIONBANK | debtplus | 19.3 |
| UNIONBANK | Leverage | ₹ 13.8 |
| UNIONBANK | Dividend Payout | 19.9 % |
| UNIONBANK | Intrinsic Value | ₹ 262 |
| UNIONBANK | CDL | -1,746 % |
| UNIONBANK | Cash by market cap | 1.15 |
| UNIONBANK | 52w Index | 54.3 % |
| UNIONBANK | Down from 52w high | 23.2 % |
| UNIONBANK | Up from 52w low | 56.1 % |
| UNIONBANK | From 52w high | 0.77 |
| UNIONBANK | Mkt Cap To Debt Cap | 0.49 |
| UNIONBANK | Dividend Payout | 19.9 % |
| UNIONBANK | Graham | ₹ 233 |
| UNIONBANK | Price to Cash Flow | 5.07 |
| UNIONBANK | ROCE3yr avg | 5.33 % |
| UNIONBANK | PB X PE | 7.31 |
| UNIONBANK | NCAVPS | ₹ 155 |
| UNIONBANK | Mar Cap to CF | 5.07 |
| UNIONBANK | Altman Z Score | 0.59 |
| UNIONBANK | M.Cap / Qtr Profit | 27.8 |