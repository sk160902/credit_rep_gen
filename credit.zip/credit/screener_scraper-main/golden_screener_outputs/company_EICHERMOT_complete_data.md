# Complete Company Data

## Modal Content
About
[
edit
]
Eicher Motors Limited, incorporated in 1982, is the listed company of the Eicher Group in India and a leading player in the Indian automobile industry and the global leader in middleweight motorcycles.
Eicher has a joint venture with Sweden’s AB Volvo to create Volvo Eicher Commercial Vehicles Limited (VECV). VECV is engaged in truck and bus operations, auto components business, and technical consulting services business
[1]
Key Points
[
edit
]
Iconic Brand
It is the owner of the iconic Royal Enfield brand which is focused on mid-sized motorcycles (250-750 cc). Classic, Bullet, Himalayan are some of the brands that come under its Royal Enfield brand. It is sold in 60+ countries globally. It also provides protective riding apparel, urban casual wear, and Motorcycle accessories and parts.
It has launched two BS-VI Compliant Motorcycles, i.e. Classic 350 BS-VI and Himalayan BS-VI in FY20
[1]
Commercial Vehicle segment
Its VECV segment makes- light & medium-duty trucks, heavy-duty trucks and buses, engineering components, and aggregates. It is also the manufacturer of medium-duty base engines for Euro VI requirements of the Volvo Group
[2]
It has launched India’s first BS-VI compliant CV range in FY20
[3]
Manufacturing Facility
It has 3 Manufacturing Facility around Chennai.
[4]
Its VECV’s manufacturing plant in Pithampur, Madhya Pradesh produces medium-duty five- and eight-liter engines.
[5]
Its VE PowerTrain plant is the first engine plant in India to produce a Euro-6 compliant base engine
[6]
A new body shop for Pro 2000 and Pro 8000 trucks has been commissioned and installed.
[5]
Capacity expansion
Its Pithampur Plant has the capacity to produce ~90,000 trucks per annum
[5]
Its Phase 1 capacity expansion for the Bhopal plant is 40k vehicles per annum
[7]
Its VE PowerTrain plant current capacity is 50,000 engines, scalable up to 100,000 engines
[6]
Distribution
It has 1889 dealers (989 stores and 900 studio stores) across 1,550 cities. Its network has grown 3 times in the last 5 years. They are planning to add 600 stores during FY21.
[8]
It has 308 dealers, 27 distributors for its Bus Segment
[9]
It has added 35 new stores across international markets in FY19-20, increasing its overall touchpoints to over 660 stores including 77 exclusive stores and 585 multi-brand outlets.
[10]
Market Share
Mid-size Motorcycles segment: >95% in FY20
VE Commercial Vehicles market share in domestic LMD  segment: 29.5% in FY20
[11]
Above 125cc segment: 26.6% in FY20
[12]
Commercial Vehicle: 14.6% in FY20
[13]
Overall Motorcycle segment: 6%
[10]
Eicher HD Trucks Market Share: 5.1% in FY20
[13]
Revenue Mix
Domestic: 91% In FY20
International: 9.1% in FY20 which was 2.8% in FY16
[14]
Product-wise Revenue
Two-wheelers: 88% of Revenue
Spare parts and other components: 7% of Revenue
Accessories and other allied products: 5% of Revenue
[15]
R&D
It has 2 technology centers, one each at Leicestershire, UK and Chennai, India
[4]
Last edited 5 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Dec 2012 | Dec 2013 | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 6,390 | 6,810 | 8,738 | 6,173 | 7,033 | 8,965 | 9,797 | 9,154 | 8,720 | 10,298 | 14,442 | 16,536 |
| Expenses + | 5,840 | 6,094 | 7,621 | 4,484 | 4,859 | 6,156 | 6,893 | 6,971 | 6,937 | 8,120 | 10,996 | 12,209 |
| Operating Profit | 550 | 715 | 1,118 | 1,690 | 2,174 | 2,809 | 2,904 | 2,183 | 1,783 | 2,178 | 3,446 | 4,327 |
| OPM % | 9% | 11% | 13% | 27% | 31% | 31% | 30% | 24% | 20% | 21% | 24% | 26% |
| Other Income + | 136 | 93 | 105 | 326 | 416 | 536 | 701 | 572 | 482 | 496 | 908 | 1,524 |
| Interest | 4 | 8 | 10 | 2 | 4 | 5 | 7 | 19 | 16 | 19 | 28 | 51 |
| Depreciation | 82 | 130 | 220 | 137 | 154 | 223 | 300 | 382 | 451 | 452 | 526 | 598 |
| Profit before tax | 600 | 671 | 993 | 1,877 | 2,433 | 3,116 | 3,297 | 2,355 | 1,798 | 2,203 | 3,800 | 5,202 |
| Tax % | 21% | 22% | 29% | 29% | 30% | 30% | 33% | 22% | 25% | 24% | 23% | 23% |
| Net Profit + | 475 | 525 | 702 | 1,338 | 1,667 | 1,960 | 2,203 | 1,827 | 1,347 | 1,677 | 2,914 | 4,001 |
| EPS in Rs | 12.01 | 14.57 | 22.71 | 49.27 | 61.27 | 71.89 | 80.75 | 66.91 | 49.28 | 61.32 | 106.55 | 146.13 |
| Dividend Payout % | 17% | 21% | 22% | 20% | 16% | 15% | 15% | 19% | 34% | 34% | 35% | 35% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 37% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 47% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 24% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| VE Commercial Vehicles Limited JV |  |  |  |  |  |  |  |  |  |
| Investment in equity share capital |  |  | 1,571 |  |  |  |  |  |  |
| Purchase of raw materials and components / services |  |  |  | 160 | 172 | 147 | 127 | 1.51 | 2.41 |
| Bills discounted |  |  |  |  |  |  | 459 | 6.77 | 5.89 |
| Purchase of finished goods/services |  |  | 146 |  |  |  |  |  |  |
| Trade payables |  |  |  |  | 51 | 35 | 30 | 0.42 | 0.56 |
| Payables |  |  | 33 |  |  |  |  |  |  |
| Corporate service charges paid |  |  | 2.60 | 2.43 | 2.53 | 1.58 | 1.69 | 0.02 | 0.02 |
| Discount on bills |  |  |  |  |  |  | 9.52 | 0.34 | 0.40 |
| Expenses reimbursed |  |  | 0.43 | 0.35 | 0.49 | 0.50 | 0.22 |  |  |
| Tooling advance given |  |  |  |  |  | 0.60 |  |  |  |
| Advances |  |  |  |  |  | 0.60 |  |  |  |
| Expenses recovered |  |  |  |  |  |  |  | 0.01 | 0.02 |
| Eicher Polaris Private Limited JV |  |  |  |  |  |  |  |  |  |
| Investment in equity share capital |  |  | 175 |  | 30 | 0.99 |  |  |  |
| Investment in equity share capital (including |  |  | 46 |  |  |  |  |  |  |
| Investment in equity share capital (including advance given in previous year) |  |  |  | 28 |  |  |  |  |  |
| Advance given for subscription of equity shares |  |  | 11 |  |  |  |  |  |  |
| Advances |  |  | 11 |  |  |  |  |  |  |
| Rent income |  |  | 2.78 | 2.92 | 0.26 |  |  |  |  |
| Expenses recovered |  |  | 1.07 | 0.05 |  |  |  |  |  |
| Investment in equity share capital - Allotted |  |  |  |  |  |  | 0.99 |  |  |
| Purchase of fixed assets |  |  |  |  |  | 0.55 |  |  |  |
| Eicher Group Foundation JV |  |  |  |  |  |  |  |  |  |
| Corporate social responsibility expenditure |  |  |  | 25 | 43 | 53 | 56 | 0.53 | 0.45 |
| Contribution for CSR expenditure |  |  | 18 |  |  |  |  |  |  |
| Receivable of surplus on CSR unspent fund |  |  |  |  |  |  |  | 0.02 |  |
| EGPL |  |  |  |  |  |  |  |  |  |
| Brand fees | 27 | 51 |  |  |  |  |  |  |  |
| Payables | 26 | 47 |  |  |  |  |  |  |  |
| Rent Paid | 11 | 14 |  |  |  |  |  |  |  |
| Security deposit receivable | 4.60 | 4.60 |  |  |  |  |  |  |  |
| Expenses reimbursed |  | 2.38 |  |  |  |  |  |  |  |
| Corporate service charges paid |  | 0.91 |  |  |  |  |  |  |  |
| Purchase of finished goods/services |  | 0.03 |  |  |  |  |  |  |  |
| Eicher Goodearth India Private Limited |  |  |  |  |  |  |  |  |  |
| Brand fees |  |  |  | 6.31 | 24 | 23 | 22 | 0.25 | 0.05 |
| Trade payables |  |  |  | 6.31 | 24 | 23 | 22 | 0.25 | 0.05 |
| AB Volvo |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 26 | 67 |  |  |  |  |  |  |  |
| Eicher Goodearth Private Limited |  |  |  |  |  |  |  |  |  |
| Rent |  |  |  | 3.42 | 4.69 | 4.81 | 4.72 | 0.05 | 0.04 |
| Brand fees paid |  |  | 18 |  |  |  |  |  |  |
| Trade payables |  |  |  | 16 |  |  |  |  |  |
| Brand fees |  |  |  | 16 |  |  |  |  |  |
| Expenses reimbursed |  |  | 6.28 |  |  |  |  |  |  |
| Corporate service charges paid |  |  | 0.83 | 0.88 | 1.16 | 0.97 | 0.73 | 0.01 | 0.01 |
| Security deposits receivable |  |  |  | 1.09 | 1.09 | 1.09 | 1.09 | 0.01 | 0.01 |
| Rent paid |  |  | 3.33 |  |  |  |  |  |  |
| Security deposit receivable |  |  | 1.09 |  |  |  |  |  |  |
| Payables |  |  | 0.23 |  |  |  |  |  |  |
| Rent payable |  |  |  |  |  |  | 0.19 |  |  |
| Sunshine Automobiles Relative |  |  |  |  |  |  |  |  |  |
| Sale of motorcycles, spares, Apparel and accessories |  |  |  |  |  | 34 | 31 |  |  |
| Advances received towards Vehicles, spares, apparel and accessories sales |  |  |  |  |  | 1.31 |  |  |  |
| Advances received towards vehicles, spares, apparel and accessories sales |  |  |  |  |  |  | 0.93 | 0.01 |  |
| Payment for Free service coupon and warranty claims |  |  |  |  |  | 0.46 | 0.41 |  | 0.01 |
| Security deposit payable |  |  |  |  |  |  | 0.02 |  |  |
| Security deposit received |  |  |  |  |  |  | 0.01 |  |  |
| Security deposits receivable |  |  |  |  |  | 0.01 |  |  |  |
| Mr. Vinod K. Dasari Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  | 28 | 15 | 0.12 |  |
| Share based payments |  |  |  |  |  |  | 10 | 0.13 |  |
| Variable pay |  |  |  |  |  |  | 4.03 |  |  |
| Commission payable |  |  |  |  |  | 3.73 |  |  |  |
| Post-employment benefits |  |  |  |  |  | 0.39 | 0.40 |  |  |
| Other long-term benefits |  |  |  |  |  | 0.12 | 0.16 |  |  |
| Mr. Siddhartha Lal Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  | 4.20 |  | 5.28 | 5.07 | 7.62 | 0.09 | 0.12 |
| Salary (including perquisites) |  |  |  |  |  |  | 14 | 0.13 | 0.14 |
| Short-term benefits |  |  | 9.20 |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  | 6.70 | 0.08 | 0.10 |
| Statutory contributions |  |  |  |  |  |  | 1.81 | 0.03 | 0.03 |
| Post-employment benefits |  |  | 0.33 |  |  |  |  |  |  |
| Other long-term benefits |  |  | 0.17 |  |  |  |  |  |  |
| Mr. Siddhartha Lai Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  | 10 | 13 | 19 |  |  |  |
| Commission payable |  |  |  | 4.80 |  |  |  |  |  |
| Post-employment benefits |  |  |  | 0.14 | 0.06 |  |  |  |  |
| Other long-term benefits |  |  |  | 0.05 | 0.06 |  |  |  |  |
| VE CommercialVehicles Limited JV |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  | 46 |  |  |  |  |  |
| EPPL JV |  |  |  |  |  |  |  |  |  |
| Sale of finished goods/services | 6.39 | 7.51 |  |  |  |  |  |  |  |
| Rental income | 2.49 | 3.28 |  |  |  |  |  |  |  |
| Receivables | 0.45 | 0.36 |  |  |  |  |  |  |  |
| Expenses recovered | 0.38 | 0.08 |  |  |  |  |  |  |  |
| Corporate service charges recovered | 0.15 | 0.02 |  |  |  |  |  |  |  |
| Others |  | 0.08 |  |  |  |  |  |  |  |
| Advance from customer |  | 0.03 |  |  |  |  |  |  |  |
| Eicher Executive Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund |  |  |  | 3.55 | 4.71 | 6.57 | 0.59 | 0.01 | 0.01 |
| Contribution |  |  | 2.59 |  |  |  |  |  |  |
| Mr Siddhartha Lal Key Person |  |  |  |  |  |  |  |  |  |
| Managerial remuneration | 5.37 | 8.49 |  |  |  |  |  |  |  |
| Mr. Lalit Malik Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  | 2.51 | 2.06 | 4.68 | 3.69 | 0.28 |  |  |
| Post-employment benefits |  |  | 0.05 | 0.04 | 0.04 | 0.07 |  |  |  |
| Other long-term benefits |  |  | 0.05 |  | 0.03 | 0.06 |  |  |  |
| Eicher Motors Limited Employees Gratuity Trust |  |  |  |  |  |  |  |  |  |
| Contribution to gratuity fund |  |  |  |  | 4.35 | 4.70 | 4.31 |  |  |
| Sale of motorcycles, spares, Apparel and accessories |  |  |  |  |  |  |  | 0.36 | 0.42 |
| Benefits paid |  |  |  |  | -1.42 | -2.64 | -2.61 | -0.04 | -0.04 |
| Mr. Manhar Kapoor Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  | 0.82 | 0.88 | 1.98 | 1.28 | 1.38 | 0.01 |  |
| Post-employment benefits |  |  | 0.02 | 0.01 | 0.02 | 0.02 | 0.02 |  |  |
| Other long-term benefits |  |  | 0.01 | 0.01 | 0.02 | 0.02 | 0.02 |  |  |
| Non-executive and independent directors Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  |  | 0.96 | 0.92 | 0.79 | 0.87 | 0.01 | 0.01 |
| Eicher Motors Limited Employee Gratuity Trusts |  |  |  |  |  |  |  |  |  |
| Contribution |  |  |  | 4.50 |  |  |  |  |  |
| Benefits paid |  |  |  | -1.39 |  |  |  |  |  |
| Mr. S. Sandilya Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.48 | 0.53 | 0.57 | 0.57 | 0.63 |  |  |
| Sitting fees |  |  | 0.03 | 0.03 | 0.04 | 0.05 | 0.06 |  |  |
| Mr. Kaleeswaran Arunachalam Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  | 1.85 | 0.02 | 0.01 |
| Other long-term benefits |  |  |  |  |  |  | 0.02 |  |  |
| Post-employment benefits |  |  |  |  |  |  | 0.02 |  |  |
| Eicher Tractors Executive Staff Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Contribution to superannuation fund |  |  |  |  | 0.33 | 0.44 | 0.02 |  |  |
| Contribution |  |  | 0.25 |  |  |  |  |  |  |
| Contribution to gratuity fund |  |  |  |  |  |  |  | 0.08 | 0.14 |
| Non-Executive and Independent Directors Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  | 1.02 |  |  |  |  |  |  |
| Nicobar Design Private Limited |  |  |  |  |  |  |  |  |  |
| Rent income |  |  |  |  | 0.99 |  |  |  |  |
| EML Employees Company Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution |  |  | 1 |  |  |  |  |  |  |
| Benefits paid |  |  | -0.25 |  |  |  |  |  |  |
| Mr R.L. Ravichandran Key Person |  |  |  |  |  |  |  |  |  |
| Managerial remuneration | 0.68 |  |  |  |  |  |  |  |  |
| Ms. Manvi Sinha Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 |  | 0.11 | 0.11 | 0.12 |  |  |
| Sitting fees |  |  | 0.01 |  | 0.03 | 0.05 | 0.05 |  |  |
| Mr. Prateek Jalan Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.21 |  | 0.18 |  |  |  |  |
| Sitting fees |  |  | 0.03 |  | 0.02 |  |  |  |  |
| Mr. Inder Mohan Singh Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  | 0.04 | 0.11 | 0.12 |  |  |
| Sitting fees |  |  |  |  | 0.01 | 0.05 | 0.06 |  |  |
| EicherTractors Executive Staff Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Contribution to superannuation fund |  |  |  | 0.31 |  |  |  |  |  |
| Ms. Natasha Jamal Relative |  |  |  |  |  |  |  |  |  |
| Sale of vehicle |  |  |  |  |  | 0.30 |  |  |  |
| Mr. Prateekjalan Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  | 0.23 |  |  |  |  |  |
| Sitting fees |  |  |  | 0.03 |  |  |  |  |  |
| Mr. M.J. Subbaiah Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 | 0.10 |  |  |  |  |  |
| Sitting fees |  |  | 0.02 | 0.02 |  |  |  |  |  |
| Mr. Priya Brat Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 |  | 0.02 |  |  |  |  |
| Sitting fees |  |  | 0.03 | 0.01 |  |  |  |  |  |
| Ms. ManviSinha Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  | 0.10 |  |  |  |  |  |
| Sitting fees |  |  |  | 0.02 |  |  |  |  |  |
| Mr. B Govindarajan Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  |  | 0.03 | 0.05 |
| Other long-term benefits |  |  |  |  |  |  |  |  | 0.01 |
| Post-employment benefits |  |  |  |  |  |  |  |  | 0.01 |
| Shardul Amarchand Mangaldas & Co. |  |  |  |  |  |  |  |  |  |
| Professional charges |  |  |  |  |  |  |  |  | 0.01 |
| Ms. Vidhya Srinivasan Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  |  |  | 0.01 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2007 | Mar 2008 | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales | Amount
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 1,662 | 1,885 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 198 | 240 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 119 | 108 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | 35 | 73 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: Intersegment | -23 | -29 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Profit before Tax & Int | Amount
Margin %
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 5% | 5% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 1% | 2% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 5% | -3% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | -35% | -9% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital Employed | Amount
ROCE % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 36% | 33% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 5% | 22% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 11% | -5% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | % | -45% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated | 3% | 2% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 37% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 47% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Dec 2012 | Dec 2013 | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 496 | 716 | 1,047 | 1,463 | 1,708 | 2,482 | 1,575 | 1,694 | 1,691 | 1,527 | 2,847 | 3,724 |
| Cash from Investing Activity + | -773 | -790 | -1,214 | -1,001 | -1,744 | -2,145 | -660 | -1,508 | -1,625 | -983 | -2,422 | -2,852 |
| Cash from Financing Activity + | -111 | -47 | -162 | -466 | 25 | -262 | -292 | -858 | -15 | -593 | -417 | -844 |
| Net Cash Flow | -388 | -121 | -329 | -4 | -10 | 75 | 623 | -673 | 51 | -50 | 8 | 27 |

## Ratios Data
| Unknown | Dec 2012 | Dec 2013 | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 25 | 27 | 23 | 2 | 3 | 3 | 3 | 3 | 7 | 11 | 9 | 8 |
| Inventory Days | 39 | 41 | 41 | 33 | 33 | 31 | 46 | 42 | 62 | 69 | 57 | 57 |
| Days Payable | 76 | 94 | 96 | 77 | 75 | 92 | 89 | 74 | 108 | 110 | 80 | 85 |
| Cash Conversion Cycle | -12 | -25 | -31 | -42 | -40 | -58 | -40 | -28 | -39 | -29 | -14 | -19 |
| Working Capital Days | -20 | -27 | -33 | -45 | -49 | -58 | -35 | -37 | -23 | -12 | -12 | 12 |
| ROCE % | 22% | 22% | 28% | 51% | 53% | 49% | 41% | 25% | 17% | 18% | 27% | 31% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 49.22% | 49.22% | 49.21% | 49.21% | 49.21% | 49.20% | 49.20% | 49.18% | 49.15% | 49.15% | 49.14% | 49.11% |
| FIIs + | 30.28% | 29.45% | 29.22% | 29.50% | 30.25% | 29.85% | 28.63% | 30.28% | 28.89% | 30.27% | 28.95% | 28.81% |
| DIIs + | 8.65% | 9.73% | 9.95% | 10.13% | 9.95% | 9.96% | 11.19% | 10.03% | 10.48% | 9.73% | 11.04% | 11.84% |
| Government + | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% | 0.10% |
| Public + | 11.76% | 11.50% | 11.52% | 11.06% | 10.48% | 10.88% | 10.88% | 10.43% | 11.37% | 10.76% | 10.77% | 10.14% |
| No. of Shareholders | 2,49,288 | 2,71,075 | 2,63,479 | 2,34,512 | 2,38,294 | 2,60,161 | 2,66,168 | 2,45,461 | 2,80,530 | 2,48,486 | 2,63,132 | 2,56,978 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 50.58% | 50.49% | 49.32% | 49.28% | 49.23% | 49.21% | 49.20% | 49.14% | 49.11% |
| FIIs + | 32.45% | 30.97% | 32.49% | 27.71% | 29.06% | 29.22% | 28.63% | 28.95% | 28.81% |
| DIIs + | 4.03% | 5.90% | 4.55% | 11.12% | 9.08% | 9.95% | 11.19% | 11.04% | 11.84% |
| Government + | 0.00% | 0.03% | 0.11% | 0.15% | 0.15% | 0.10% | 0.10% | 0.10% | 0.10% |
| Public + | 12.94% | 12.61% | 13.53% | 11.75% | 12.49% | 11.52% | 10.88% | 10.77% | 10.14% |
| No. of Shareholders | 81,872 | 93,341 | 1,17,136 | 1,09,899 | 2,52,014 | 2,63,479 | 2,66,168 | 2,63,132 | 2,56,978 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/eicher-motors-ltd/eichermot/505200/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 20 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01c7053a-3ada-4730-b3a3-48a573854b60.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=617ec1d6-b0f4-4c90-a018-19de177b6213.pdf)
- [GST Demand Order 18 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5ac9bf2f-586d-4e57-82d3-daefb5cf9222.pdf)
- [Announcement under Regulation 30 (LODR)-Press Release / Media Release 17 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d3e76458-1215-401e-b768-62ed3b72938d.pdf)
- [GST Demand Order 12 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fbb2e84e-4b4e-40c1-b02d-c07f6b22a9b0.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\857d13f1-9d43-4eac-b527-ed0df0099697.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/505200/74102505200_07_09_22.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/505200/69102505200.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/505200/5052000320.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/505200/5052000319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052000318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052000317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052000316.pdf)
- [](https://www.bseindia.com/HIS_ANN_RPT/HISTANNR/2015/EICHER_MOTORS_LTD-505200-MARCH-2015.PDF)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052001214.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052001213.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_3185_EICHERMOT_2013_2013_27022014120002.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052001212.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/505200/5052001211.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_EICHERMOT_2011_2011_27022012082526.zip)

## Credit Ratings
- [Rating update
18 Aug 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=121637)
- [Rating update
23 Mar 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=118761)
- [Rating update
2 Nov 2022 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=115590)
- [Rating update
1 Sep 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=106116)
- [Rating update
22 Feb 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=101441)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=89880)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5deca674-4e06-4818-bd73-e3ca5b5c097d.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c85bf35d-307d-43c4-8476-1df3ecdf8278.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bf624baa-f6d3-43e7-a978-ab3044b87e74.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44e42a03-b8a3-4d3f-b64d-967a6258338e.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b18b8106-7a2c-42b7-ac56-72bfc33385ca.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d6362e40-9303-4d59-adfd-9ec8103a8c9d.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa9c57d0-4244-46d9-9668-9edfe2bee4f8.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2692c44-36a7-474d-b768-6ae057d90544.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=362d9310-ca36-4e46-ac4a-db5e8a6a1700.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6e2fd1d9-dc50-4ea9-b1c7-fbde8d7f5176.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=29ea8294-2af5-42ac-852b-10b39f117168.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3e05de95-4a5f-488d-9382-a029f8447927.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a0e449ca-ed3d-423b-ac5d-1a27d3e1310d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6d956087-8fe3-4e5c-bc8c-09e78ac33892.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8eec0cad-3e4c-4a28-ae93-da94b41de509.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a7b06f6f-0832-436b-8219-982aaa1f425d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6f96193b-fce0-41d4-b23a-0b95ae3dc15e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a7533da-0e1e-4ae0-85b6-a1b5272128df.pdf)
- [](https://www.eicher.in/uploads/1645519795_conference-call-transcripts-Q3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8d2af09a-f8e2-4308-959e-8af53164baf2.pdf)
- [](https://www.eicher.in/uploads/1636698383_conference-call-transcripts-Q2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3f93f903-ffdb-47ca-96db-0657290e4153.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=792aa195-24b5-4951-a9ea-f6e2afee36e9.pdf)
- [](https://www.eicher.in/uploads/1632983315_conference-call-transcripts-Q1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b989e1c1-18b1-4d4b-9bf6-1f051ebb80e7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=45602724-4216-46de-b147-e5e7850fd6f4.pdf)
- [](https://www.eicher.in/uploads/1622702179_conference-call-transcripts-Q4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=58b04e86-ffa9-4a39-b86e-036dc1cdd789.pdf)
- [](http://www.eicher.in/uploads/1613731299_eicher-motors-earnings-call-transcript-for-3Q-FY-2020-21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a1a3d665-c689-41de-8715-ddd8313d318e.pdf)
- [](http://www.eicher.in/uploads/1606471076_eicher-motors-earnings-call-transcript-for-2Q-FY-2020-21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=20299c3f-1612-4367-a518-d3873d60b9fc.pdf)
- [](http://www.eicher.in/uploads/1604902542_Eicher-Motors-Earnings-Call-Transcript-for-1Q-FY-2020-21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=401f151a-1452-49d1-a7d1-853a9842c3e2.pdf)
- [](http://www.eicher.in/uploads/1592907982_Eicher%20Motors%20Earnings%20Call%20Transcript%20for%204Q%20FY%202019-20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ed9a6f2e-fd1e-4edb-abba-e9656d8b2eb8.pdf)
- [](http://www.eicher.in/uploads/1581395251_Eicher_Motors_Earnings_Call_Transcript_for_3Q_FY_2019-20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba278eb6-b95a-4c04-af54-6ac83295edb6.pdf)
- [](http://www.eicher.in/uploads/1574076867_Eicher_Motors_Earnings_Call_Transcript_for_2Q_FY_2019-20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=557dc2e6-01ae-4732-b554-e01d912db813.pdf)
- [](http://www.eicher.in/uploads/1566622667_Eicher_Motors_Earnings_Call_Transcript_for_1Q_FY_2019-20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=405c535c-834a-4464-a27f-705cb9e6dc9e.pdf)
- [](http://www.eicher.in/uploads/1568091380_Eicher_Motors_Earnings_Call_Transcript_for_4Q_FY_2018-19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5daee41a-885c-4510-aa8f-77d4ab1531c8.pdf)
- [](http://www.eicher.in/uploads/1551154263_Eicher-motors-earnings-call-transcript-for-3Q-FY-2018-19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49b591e5-e35c-469d-8dec-6f22dd0eb14a.pdf)
- [](http://www.eicher.in/uploads/1542974116_Eicher_Motors_Earnings_Call_Transcript_for_2Q_FY_2018-19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=29d7e4f1-e730-4e0b-8f41-ea55462461c5.pdf)
- [](http://www.eicher.in/uploads/1534392780_Eicher_Motors_Earnings_Call_Transcript_for_1Q_FY_2018-19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88cf7cf7-7af1-4bc0-bf72-d5be4b33be16.pdf)
- [](http://www.eicher.in/uploads/1532327065_Eicher_Motors_Earnings_Call_Transcript_for_4Q_FY_2017-18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6b73ddf8-eff7-46b1-bf09-35d9632f5db9.pdf)
- [](http://www.eicher.in/uploads/1532326923_Eicher_Motors_Earnings_Call_Transcript_for_3Q_FY_2017-18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f2d1ffab-bb1b-4749-9e9a-4bec74925b7b.pdf)
- [](http://www.eicher.in/uploads/1532326857_Eicher_Motors_Earnings_Call_Transcript_for_2Q_FY_2017-18.pdf)
- [](http://www.eicher.in/uploads/1532521344_Eicher_Motors_Earnings_Call_Transcript_for_1Q_FY_2017-18.pdf)
- [](http://www.eicher.in/uploads/1532170858_Eicher_Motors_Earnings_Call_Transcript_for_4Q_FY_2016-17.pdf)
- [](http://www.eicher.in/uploads/1532170858_Eicher_Motors_Earnings_Call_Transcript_for_1Q_FY_2016-17.pdf)
- [](http://www.eicher.in/uploads/1532166297_Eicher_Motors_Earnings_Call_Transcript_for_5Q_FY_2015-16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=38FCF20D_AD4F_4DC4_BE72_8CA41053B150_181444.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Eicher Motors | 5014.45 | 137401.21 | 34.36 | 7.60 | 8.31 | 69.03 | 23.53 | 23.31 | 1.03 | 31.13 | 18.91 | 24.22 | 0.78 | 0.02 | 103.24 | 1.17 | 16535.78 | 26.17 | 4001.01 | 4256.04 | 1070.45 | 11.87 | 18.21 | 146.13 | 419.44 | 49.11 | -0.04 | 3.90 | 52.45 | 0.00 | 14.50 | 37.29 | 137674.34 | 1.15 | 2.71 | 6.51 | 35.51 | 23.98 | 47.26 | 20.30 | 18.84 | 12.67 | 43.71 | 11.04 | 23.77 | 21.12 | 27.35 | 0.76 | 146.13 | 12.59 | 36.98 | 37.53 | 37.67 | -19.41 | 27.35 |
| 2. | TVS Motor Co. | 2510.15 | 119257.21 | 73.06 | 17.60 | 3.05 | -33.69 | 25.91 | 45.48 | 0.33 | 14.68 | 4.47 | 26.55 | 1.02 | 3.83 | 2.35 | 5.68 | 39144.74 | 14.05 | 1631.32 | 10042.47 | 386.98 | 25.04 | 15.29 | 35.50 | 26005.70 | 50.27 | 0.00 | 3.24 | 52.45 | 0.00 | 22.43 | 27.45 | 142837.18 | 1.01 | 4.00 | 21.46 | 26.18 | 61.54 | 80.65 | 24.11 | 22.36 | 18.25 | 39.42 | 14.19 | 26.32 | 25.85 | 13.25 | 0.91 | 35.50 | 18.25 | 44.92 | 44.88 | 44.71 | -48.50 | 47.51 |
| 3. | Hero Motocorp | 5481.75 | 109597.15 | 29.07 | 6.10 | 2.90 | 42.46 | 18.37 | 16.97 | 2.13 | 29.09 | 15.06 | 21.95 | 1.51 | 0.03 | 68.16 | 1.41 | 37788.62 | 13.85 | 3770.44 | 9616.68 | 935.01 | 14.02 | 16.13 | 187.31 | 606.41 | 34.76 | 0.00 | 4.82 | 52.45 | 0.00 | 10.63 | 38.70 | 109507.09 | 0.85 | 12.16 | 20.30 | 21.63 | 24.59 | 72.24 | 17.80 | 18.72 | 2.39 | 10.52 | 2.15 | 6.87 | 16.73 | 22.72 | 0.60 | 187.31 | 2.37 | 20.16 | 20.69 | 20.00 | -29.93 | 19.98 |
| 4. | Wardwizard Inno. | 58.40 | 1522.39 | 107.53 | 14.87 | 4.80 | -37.41 | 49.27 | 52.09 | 0.17 | 17.81 | 5.56 | 14.79 | 1.25 | 0.82 | 4.96 | 2.48 | 317.31 | 10.17 | 14.15 | 128.05 | 4.28 | 153.31 | 195.17 | 0.54 | 84.57 | 58.62 | -8.84 | 1.64 | 52.45 | 0.54 | 32.82 | 52.15 | 1602.13 | 1.23 | 0.74 | -10.08 | -25.13 | -6.61 | 50.33 | 14.76 | 13.44 | 146.19 | 96.32 |  | 100.60 | 12.31 | 17.73 | 0.78 | 0.54 | 89.43 | 160.86 | 157.77 | 160.90 | 106.21 | 25.89 |
| 5. | Urja Global | 21.86 | 1148.69 | 563.05 | 6.59 | 25.83 | -147.02 | 303.28 | 55.06 | 0.00 | 1.84 | 0.72 | 1.18 | 0.16 | 0.03 | 5.32 | 1.63 | 44.47 | 5.19 | 2.04 | 13.02 | 0.46 | 22.37 | 411.11 | 0.04 | 5.02 | 19.43 | 0.00 | 0.29 | 52.45 | 0.00 | 12.35 | 33.33 | 1152.47 | 1.42 | 2.97 | 3.03 | -4.13 | 49.24 | 131.17 | 0.85 | 0.87 | 189.69 | 5.65 | -20.08 | -33.09 | 0.89 | 1.55 | 0.56 | 0.04 | 193.10 | 257.50 | 361.67 | 239.50 | 468.22 | 52.55 |
| 6. | Tunwal E-Motors | 52.20 | 288.66 | 24.46 |  | 2.76 | -62.57 | 16.33 |  | 0.00 | 52.37 | 17.79 | 82.16 | 1.58 | 1.00 | 8.58 | 3.23 | 104.60 | 17.05 | 11.81 |  |  |  |  | 2.85 | 20.52 | 62.34 |  | 5.55 | 52.45 | 0.00 | 36.82 | 217.47 | 306.53 | 1.40 |  |  |  |  |  | 77.53 | 76.85 |  | 428.51 |  | 333.95 | 59.66 | 26.21 | 0.27 | 2.85 |  | 20.28 | 20.28 | 20.28 | 173.44 | 2.06 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | Sales | ₹ 16,536 Cr. |
| EICHERMOT | OPM | 26.2 % |
| EICHERMOT | Profit after tax | ₹ 4,001 Cr. |
| EICHERMOT | Mar Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Sales Qtr | ₹ 4,256 Cr. |
| EICHERMOT | PAT Qtr | ₹ 1,070 Cr. |
| EICHERMOT | Qtr Sales Var | 11.9 % |
| EICHERMOT | Qtr Profit Var | 18.2 % |
| EICHERMOT | Price to Earning | 34.4 |
| EICHERMOT | Dividend yield | 1.03 % |
| EICHERMOT | Price to book value | 7.60 |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | Return on assets | 18.9 % |
| EICHERMOT | Debt to equity | 0.02 |
| EICHERMOT | Return on equity | 24.2 % |
| EICHERMOT | EPS | ₹ 146 |
| EICHERMOT | Debt | ₹ 419 Cr. |
| EICHERMOT | Promoter holding | 49.1 % |
| EICHERMOT | Change in Prom Hold | -0.04 % |
| EICHERMOT | Earnings yield | 3.90 % |
| EICHERMOT | Pledged percentage | 0.00 % |
| EICHERMOT | Industry PE | 52.4 |
| EICHERMOT | Sales growth | 14.5 % |
| EICHERMOT | Profit growth | 37.3 % |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | Price to Sales | 8.31 |
| EICHERMOT | CMP / FCF | 69.0 |
| EICHERMOT | EVEBITDA | 23.5 |
| EICHERMOT | Enterprise Value | ₹ 1,37,674 Cr. |
| EICHERMOT | Current ratio | 1.15 |
| EICHERMOT | Int Coverage | 103 |
| EICHERMOT | PEG Ratio | 2.71 |
| EICHERMOT | Return over 3months | 6.51 % |
| EICHERMOT | Return over 6months | 35.5 % |
| EICHERMOT | No. Eq. Shares | 27.4 |
| EICHERMOT | Sales growth 3Years | 23.8 % |
| EICHERMOT | Sales growth 5Years | 11.0 % |
| EICHERMOT | Profit Var 3Yrs | 43.7 % |
| EICHERMOT | Profit Var 5Yrs | 12.7 % |
| EICHERMOT | ROE 5Yr | 18.8 % |
| EICHERMOT | ROE 3Yr | 20.3 % |
| EICHERMOT | Return over 1year | 47.3 % |
| EICHERMOT | Return over 3years | 24.0 % |
| EICHERMOT | Return over 5years | 23.3 % |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | Sales last year | ₹ 16,536 Cr. |
| EICHERMOT | OP Ann | ₹ 4,327 Cr. |
| EICHERMOT | Other Inc Ann | ₹ 1,524 Cr. |
| EICHERMOT | EBIDT last year | ₹ 5,850 Cr. |
| EICHERMOT | Dep Ann | ₹ 598 Cr. |
| EICHERMOT | EBIT last year | ₹ 5,253 Cr. |
| EICHERMOT | Interest last year | ₹ 50.9 Cr. |
| EICHERMOT | PBT Ann | ₹ 5,202 Cr. |
| EICHERMOT | Tax last year | ₹ 1,201 Cr. |
| EICHERMOT | PAT Ann | ₹ 4,001 Cr. |
| EICHERMOT | Extra Ord Item Ann | ₹ 0.00 Cr. |
| EICHERMOT | NP Ann | ₹ 4,001 Cr. |
| EICHERMOT | Dividend last year | ₹ 1,396 Cr. |
| EICHERMOT | Raw Material | 54.3 % |
| EICHERMOT | Employee cost | ₹ 1,236 Cr. |
| EICHERMOT | OPM last year | 26.2 % |
| EICHERMOT | NPM last year | 24.2 % |
| EICHERMOT | Operating profit | ₹ 4,327 Cr. |
| EICHERMOT | Interest | ₹ 50.9 Cr. |
| EICHERMOT | Depreciation | ₹ 598 Cr. |
| EICHERMOT | EPS last year | ₹ 146 |
| EICHERMOT | EBIT | ₹ 5,253 Cr. |
| EICHERMOT | Net profit | ₹ 4,001 Cr. |
| EICHERMOT | Current Tax | ₹ 1,040 Cr. |
| EICHERMOT | Tax | ₹ 1,201 Cr. |
| EICHERMOT | Other income | ₹ 1,524 Cr. |
| EICHERMOT | Ann Date | 2,02,403 |
| EICHERMOT | Sales Prev Ann | ₹ 14,442 Cr. |
| EICHERMOT | OP Prev Ann | ₹ 3,446 Cr. |
| EICHERMOT | Other Inc Prev Ann | ₹ 908 Cr. |
| EICHERMOT | EBIDT Prev Ann | ₹ 4,354 Cr. |
| EICHERMOT | Dep Prev Ann | ₹ 526 Cr. |
| EICHERMOT | EBIT preceding year | ₹ 3,828 Cr. |
| EICHERMOT | Interest Prev Ann | ₹ 28.0 Cr. |
| EICHERMOT | PBT Prev Ann | ₹ 3,800 Cr. |
| EICHERMOT | Tax preceding year | ₹ 886 Cr. |
| EICHERMOT | PAT Prev Ann | ₹ 2,914 Cr. |
| EICHERMOT | Extra Ord Prev Ann | ₹ -0.31 Cr. |
| EICHERMOT | NP Prev Ann | ₹ 2,914 Cr. |
| EICHERMOT | Dividend Prev Ann | ₹ 1,012 Cr. |
| EICHERMOT | OPM preceding year | 23.9 % |
| EICHERMOT | NPM preceding year | 20.2 % |
| EICHERMOT | EPS preceding year | ₹ 107 |
| EICHERMOT | Sales Prev 12M | ₹ 16,084 Cr. |
| EICHERMOT | Profit Prev 12M | ₹ 3,836 Cr. |
| EICHERMOT | Med Sales Gwth 10Yrs | 13.9 % |
| EICHERMOT | Med Sales Gwth 5Yrs | 14.5 % |
| EICHERMOT | Sales growth 7Years | 13.0 % |
| EICHERMOT | Sales Var 10Yrs | 9.28 % |
| EICHERMOT | EBIDT growth 3Years | 37.2 % |
| EICHERMOT | EBIDT growth 5Years | 10.2 % |
| EICHERMOT | EBIDT growth 7Years | 12.3 % |
| EICHERMOT | EBIDT Var 10Yrs | 22.3 % |
| EICHERMOT | EPS growth 3Years | 43.6 % |
| EICHERMOT | EPS growth 5Years | 12.6 % |
| EICHERMOT | EPS growth 7Years | 13.2 % |
| EICHERMOT | EPS growth 10Years | 26.4 % |
| EICHERMOT | Profit Var 7Yrs | 13.3 % |
| EICHERMOT | Profit Var 10Yrs | 26.6 % |
| EICHERMOT | Chg in Prom Hold 3Yr | -0.11 % |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | OP Qtr | ₹ 1,129 Cr. |
| EICHERMOT | Other Inc Qtr | ₹ 437 Cr. |
| EICHERMOT | EBIDT Qtr | ₹ 1,566 Cr. |
| EICHERMOT | Dep Qtr | ₹ 165 Cr. |
| EICHERMOT | EBIT latest quarter | ₹ 1,400 Cr. |
| EICHERMOT | Interest Qtr | ₹ 15.3 Cr. |
| EICHERMOT | PBT Qtr | ₹ 1,385 Cr. |
| EICHERMOT | Tax latest quarter | ₹ 315 Cr. |
| EICHERMOT | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| EICHERMOT | NP Qtr | ₹ 1,070 Cr. |
| EICHERMOT | GPM latest quarter | 46.5 % |
| EICHERMOT | OPM latest quarter | 26.5 % |
| EICHERMOT | NPM latest quarter | 25.2 % |
| EICHERMOT | Eq Cap Qtr | ₹ 27.4 Cr. |
| EICHERMOT | EPS latest quarter | ₹ 39.1 |
| EICHERMOT | OP 2Qtr Bk | ₹ 1,087 Cr. |
| EICHERMOT | OP 3Qtr Bk | ₹ 1,021 Cr. |
| EICHERMOT | Sales 2Qtr Bk | ₹ 4,115 Cr. |
| EICHERMOT | Sales 3Qtr Bk | ₹ 3,986 Cr. |
| EICHERMOT | NP 2Qtr Bk | ₹ 1,016 Cr. |
| EICHERMOT | NP 3Qtr Bk | ₹ 918 Cr. |
| EICHERMOT | Opert Prft Gwth | 25.6 % |
| EICHERMOT | Last result date | 2,02,403 |
| EICHERMOT | Exp Qtr Sales Var | 14.6 % |
| EICHERMOT | Exp Qtr Sales | ₹ 4,566 Cr. |
| EICHERMOT | Exp Qtr OP | ₹ 1,186 Cr. |
| EICHERMOT | Exp Qtr NP | ₹ 1,004 Cr. |
| EICHERMOT | Exp Qtr EPS | ₹ 36.6 |
| EICHERMOT | Sales Prev Qtr | ₹ 4,179 Cr. |
| EICHERMOT | OP Prev Qtr | ₹ 1,090 Cr. |
| EICHERMOT | Other Inc Prev Qtr | ₹ 368 Cr. |
| EICHERMOT | EBIDT Prev Qtr | ₹ 1,458 Cr. |
| EICHERMOT | Dep Prev Qtr | ₹ 148 Cr. |
| EICHERMOT | EBIT Prev Qtr | ₹ 1,310 Cr. |
| EICHERMOT | Interest Prev Qtr | ₹ 12.4 Cr. |
| EICHERMOT | PBT Prev Qtr | ₹ 1,298 Cr. |
| EICHERMOT | Tax Prev Qtr | ₹ 302 Cr. |
| EICHERMOT | PAT Prev Qtr | ₹ 996 Cr. |
| EICHERMOT | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| EICHERMOT | NP Prev Qtr | ₹ 996 Cr. |
| EICHERMOT | OPM Prev Qtr | 26.1 % |
| EICHERMOT | NPM Prev Qtr | 23.8 % |
| EICHERMOT | Eq Cap Prev Qtr | ₹ 27.4 Cr. |
| EICHERMOT | EPS Prev Qtr | ₹ 36.4 |
| EICHERMOT | Sales PY Qtr | ₹ 3,804 Cr. |
| EICHERMOT | OP PY Qtr | ₹ 934 Cr. |
| EICHERMOT | Other Inc PY Qtr | ₹ 379 Cr. |
| EICHERMOT | EBIDT PY Qtr | ₹ 1,313 Cr. |
| EICHERMOT | Dep PY Qtr | ₹ 148 Cr. |
| EICHERMOT | EBIT PY Qtr | ₹ 1,165 Cr. |
| EICHERMOT | Interest PY Qtr | ₹ 8.16 Cr. |
| EICHERMOT | PBT PY Qtr | ₹ 1,156 Cr. |
| EICHERMOT | Tax PY Qtr | ₹ 251 Cr. |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | Equity capital | ₹ 27.4 Cr. |
| EICHERMOT | Preference capital | ₹ 0.00 Cr. |
| EICHERMOT | Reserves | ₹ 18,018 Cr. |
| EICHERMOT | Secured loan | ₹ 196 Cr. |
| EICHERMOT | Unsecured loan | ₹ 92.7 Cr. |
| EICHERMOT | Balance sheet total | ₹ 23,128 Cr. |
| EICHERMOT | Gross block | ₹ 5,121 Cr. |
| EICHERMOT | Revaluation reserve | ₹ 0.00 Cr. |
| EICHERMOT | Accum Dep | ₹ 2,431 Cr. |
| EICHERMOT | Net block | ₹ 3,258 Cr. |
| EICHERMOT | CWIP | ₹ 212 Cr. |
| EICHERMOT | Investments | ₹ 13,527 Cr. |
| EICHERMOT | Current assets | ₹ 4,151 Cr. |
| EICHERMOT | Current liabilities | ₹ 3,598 Cr. |
| EICHERMOT | BV Unq Invest | ₹ 0.00 Cr. |
| EICHERMOT | MV Quoted Inv | ₹ 9,639 Cr. |
| EICHERMOT | Cont Liab | ₹ 163 Cr. |
| EICHERMOT | Total Assets | ₹ 23,128 Cr. |
| EICHERMOT | Working capital | ₹ 701 Cr. |
| EICHERMOT | Lease liabilities | ₹ 144 Cr. |
| EICHERMOT | Inventory | ₹ 1,410 Cr. |
| EICHERMOT | Trade receivables | ₹ 374 Cr. |
| EICHERMOT | Face value | ₹ 1.00 |
| EICHERMOT | Cash Equivalents | ₹ 146 Cr. |
| EICHERMOT | Adv Cust | ₹ 126 Cr. |
| EICHERMOT | Trade Payables | ₹ 2,090 Cr. |
| EICHERMOT | No. Eq. Shares PY | 27.4 |
| EICHERMOT | Debt preceding year | ₹ 288 Cr. |
| EICHERMOT | Work Cap PY | ₹ 386 Cr. |
| EICHERMOT | Net Block PY | ₹ 2,690 Cr. |
| EICHERMOT | Gross Block PY | ₹ 5,121 Cr. |
| EICHERMOT | CWIP PY | ₹ 472 Cr. |
| EICHERMOT | Work Cap 3Yr | ₹ 5,277 Cr. |
| EICHERMOT | Work Cap 5Yr | ₹ 2,035 Cr. |
| EICHERMOT | Work Cap 7Yr | ₹ -921 Cr. |
| EICHERMOT | Work Cap 10Yr | ₹ 182 Cr. |
| EICHERMOT | Debt 3Years back | ₹ 219 Cr. |
| EICHERMOT | Debt 5Years back | ₹ 187 Cr. |
| EICHERMOT | Debt 7Years back | ₹ 112 Cr. |
| EICHERMOT | Debt 10Years back | ₹ 83.9 Cr. |
| EICHERMOT | Net Block 3Yrs Back | ₹ 2,433 Cr. |
| EICHERMOT | Net Block 5Yrs Back | ₹ 1,875 Cr. |
| EICHERMOT | Net Block 7Yrs Back | ₹ 873 Cr. |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | CF Operations | ₹ 3,724 Cr. |
| EICHERMOT | Free Cash Flow | ₹ 2,909 Cr. |
| EICHERMOT | CF Investing | ₹ -2,852 Cr. |
| EICHERMOT | CF Financing | ₹ -844 Cr. |
| EICHERMOT | Net CF | ₹ 27.4 Cr. |
| EICHERMOT | Cash Beginning | ₹ 53.0 Cr. |
| EICHERMOT | Cash End | ₹ 146 Cr. |
| EICHERMOT | FCF Prev Ann | ₹ 2,174 Cr. |
| EICHERMOT | CF Operations PY | ₹ 2,847 Cr. |
| EICHERMOT | CF Investing PY | ₹ -2,422 Cr. |
| EICHERMOT | CF Financing PY | ₹ -417 Cr. |
| EICHERMOT | Net CF PY | ₹ 8.42 Cr. |
| EICHERMOT | Cash Beginning PY | ₹ 44.6 Cr. |
| EICHERMOT | Cash End PY | ₹ 857 Cr. |
| EICHERMOT | Free Cash Flow 3Yrs | ₹ 5,971 Cr. |
| EICHERMOT | Free Cash Flow 5Yrs | ₹ 8,297 Cr. |
| EICHERMOT | Free Cash Flow 7Yrs | ₹ 10,819 Cr. |
| EICHERMOT | Free Cash Flow 10Yrs | ₹ 13,013 Cr. |
| EICHERMOT | CF Opr 3Yrs | ₹ 8,098 Cr. |
| EICHERMOT | CF Opr 5Yrs | ₹ 11,483 Cr. |
| EICHERMOT | CF Opr 7Yrs | ₹ 15,541 Cr. |
| EICHERMOT | CF Opr 10Yrs | ₹ 19,760 Cr. |
| EICHERMOT | CF Inv 10Yrs | ₹ -16,155 Cr. |
| EICHERMOT | CF Inv 7Yrs | ₹ -12,195 Cr. |
| EICHERMOT | CF Inv 5Yrs | ₹ -9,391 Cr. |
| EICHERMOT | CF Inv 3Yrs | ₹ -6,257 Cr. |
| EICHERMOT | Cash 3Years back | ₹ 5,830 Cr. |
| EICHERMOT | Cash 5Years back | ₹ 2,965 Cr. |
| EICHERMOT | Cash 7Years back | ₹ 25.1 Cr. |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | No. Eq. Shares | 27.4 |
| EICHERMOT | Book value | ₹ 659 |
| EICHERMOT | Inven TO | 6.68 |
| EICHERMOT | Quick ratio | 0.76 |
| EICHERMOT | Exports percentage | 0.00 % |
| EICHERMOT | Piotroski score | 6.00 |
| EICHERMOT | G Factor | 5.00 |
| EICHERMOT | Asset Turnover | 0.78 |
| EICHERMOT | Financial leverage | 1.17 |
| EICHERMOT | No. of Share Holders | 2,56,978 |
| EICHERMOT | Unpledged Prom Hold | 49.1 % |
| EICHERMOT | ROIC | 102 % |
| EICHERMOT | Debtor days | 8.25 |
| EICHERMOT | Industry PBV | 7.44 |
| EICHERMOT | Credit rating |  |
| EICHERMOT | WC Days | 12.2 |
| EICHERMOT | Earning Power | 22.7 % |
| EICHERMOT | Graham Number | ₹ 1,472 |
| EICHERMOT | Cash Cycle | -19.4 |
| EICHERMOT | Days Payable | 85.0 |
| EICHERMOT | Days Receivable | 8.25 |
| EICHERMOT | Inventory Days | 57.3 |
| EICHERMOT | Public holding | 10.1 % |
| EICHERMOT | FII holding | 28.8 % |
| EICHERMOT | Chg in FII Hold | -0.14 % |
| EICHERMOT | DII holding | 11.8 % |
| EICHERMOT | Chg in DII Hold | 0.80 % |
| EICHERMOT | B.V. Prev Ann | ₹ 548 |
| EICHERMOT | ROCE Prev Yr | 27.4 % |
| EICHERMOT | ROA Prev Yr | 16.5 % |
| EICHERMOT | ROE Prev Ann | 21.1 % |
| EICHERMOT | No. of Share Holders Prev Qtr | 2,63,132 |
| EICHERMOT | No. Eq. Shares 10 Yrs | 27.1 |
| EICHERMOT | BV 3yrs back | ₹ 418 |
| EICHERMOT | BV 5yrs back | ₹ 365 |
| EICHERMOT | BV 10yrs back | ₹ 92.8 |
| EICHERMOT | Inven TO 3Yr | 7.14 |
| EICHERMOT | Inven TO 5Yr | 8.40 |
| EICHERMOT | Inven TO 7Yr | 12.9 |
| EICHERMOT | Inven TO 10Yr | 9.97 |
| EICHERMOT | Export 3Yr | 0.00 % |
| EICHERMOT | Export 5Yr | 0.00 % |
| EICHERMOT | Div 5Yrs | ₹ 758 Cr. |
| EICHERMOT | ROCE 3Yr | 25.6 % |
| EICHERMOT | ROCE 5Yr | 23.6 % |
| EICHERMOT | ROCE 7Yr | 29.7 % |
| EICHERMOT | ROCE 10Yr | 34.0 % |
| EICHERMOT | ROE 10Yr | 22.6 % |
| EICHERMOT | ROE 7Yr | 20.8 % |
| EICHERMOT | ROE 5Yr Var | -2.60 % |
| EICHERMOT | OPM 5Year | 23.5 % |
| EICHERMOT | OPM 10Year | 24.6 % |
| EICHERMOT | No. of Share Holders 1Yr | 2,45,461 |
| EICHERMOT | Avg Div Payout 3Yrs | 34.6 % |
| EICHERMOT | Debtor days 3yrs | 9.43 |
| EICHERMOT | Debtor days 3yrs back | 6.62 |
| EICHERMOT | Debtor days 5yrs back | 3.14 |
| EICHERMOT | ROA 5Yr | 14.3 % |
| EICHERMOT | ROA 3Yr | 15.4 % |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | Avg Vol 1Mth | 6,29,370 |
| EICHERMOT | Avg Vol 1Wk | 5,95,544 |
| EICHERMOT | Volume | 4,16,043 |
| EICHERMOT | High price | ₹ 5,053 |
| EICHERMOT | Low price | ₹ 3,272 |
| EICHERMOT | High price all time | ₹ 5,053 |
| EICHERMOT | Low price all time | ₹ 13.5 |
| EICHERMOT | Return over 1day | 2.32 % |
| EICHERMOT | Return over 1week | 1.03 % |
| EICHERMOT | Return over 1month | 3.40 % |
| EICHERMOT | DMA 50 | ₹ 4,736 |
| EICHERMOT | DMA 200 | ₹ 4,225 |
| EICHERMOT | DMA 50 previous day | ₹ 4,729 |
| EICHERMOT | 200 DMA prev. | ₹ 4,219 |
| EICHERMOT | RSI | 58.5 |
| EICHERMOT | MACD | 45.6 |
| EICHERMOT | MACD Previous Day | 46.0 |
| EICHERMOT | MACD Signal | 39.0 |
| EICHERMOT | MACD Signal Prev | 37.4 |
| EICHERMOT | Avg Vol 1Yr | 6,67,127 |
| EICHERMOT | Return over 7years | 7.58 % |
| EICHERMOT | Return over 10years | 19.0 % |
| EICHERMOT | Market Cap | ₹ 1,37,401 Cr. |
| EICHERMOT | Current Price | ₹ 5,014 |
| EICHERMOT | High / Low | ₹ 5,053 / 3,272 |
| EICHERMOT | Stock P/E | 34.4 |
| EICHERMOT | Book Value | ₹ 659 |
| EICHERMOT | Dividend Yield | 1.03 % |
| EICHERMOT | ROCE | 31.1 % |
| EICHERMOT | ROE | 24.2 % |
| EICHERMOT | Face Value | ₹ 1.00 |
| EICHERMOT | WC to Sales | 4.24 % |
| EICHERMOT | QoQ Profits | 7.48 % |
| EICHERMOT | QoQ Sales | 1.85 % |
| EICHERMOT | Net worth | ₹ 18,046 Cr. |
| EICHERMOT | Market Cap to Sales | 8.31 |
| EICHERMOT | Interest Coverage | 103 |
| EICHERMOT | EV / EBIT | 26.2 |
| EICHERMOT | Debt Capacity | 0.15 |
| EICHERMOT | Debt To Profit | 0.10 |
| EICHERMOT | Capital Employed | ₹ 4,170 Cr. |
| EICHERMOT | CROIC | 11.8 % |
| EICHERMOT | debtplus | 0.03 |
| EICHERMOT | Leverage | ₹ 1.17 |
| EICHERMOT | Dividend Payout | 34.9 % |
| EICHERMOT | Intrinsic Value | ₹ 2,485 |
| EICHERMOT | CDL | -0.32 % |
| EICHERMOT | Cash by market cap | 0.00 |
| EICHERMOT | 52w Index | 97.8 % |
| EICHERMOT | Down from 52w high | 0.77 % |
| EICHERMOT | Up from 52w low | 53.2 % |
| EICHERMOT | From 52w high | 0.99 |
| EICHERMOT | Mkt Cap To Debt Cap | 4.79 |
| EICHERMOT | Dividend Payout | 34.9 % |
| EICHERMOT | Graham | ₹ 1,472 |
| EICHERMOT | Price to Cash Flow | 36.9 |
| EICHERMOT | ROCE3yr avg | 25.6 % |
| EICHERMOT | PB X PE | 261 |
| EICHERMOT | NCAVPS | ₹ 25.6 |
| EICHERMOT | Mar Cap to CF | 36.9 |
| EICHERMOT | Altman Z Score | 12.1 |
| EICHERMOT | M.Cap / Qtr Profit | 128 |