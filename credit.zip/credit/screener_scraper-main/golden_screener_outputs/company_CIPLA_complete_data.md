# Complete Company Data

## Modal Content
About
[
edit
]
Cipla is engaged in the Business of Pharmaceuticals.(Source : 202003 Annual Report Page No:157)
Key Points
[
edit
]
Market Leadership
[1]
#
3rd largest in the India domestic Rx market
#
Leadership in Gx
#
1st rank in Respiratory
#
Top 5 in Urology and Anti-infectives.
#
Over 5 Lac+ no of downloads - Digital Breathe free
#
7,500+ field force detailing to HCPs across the country – 85% of physicians prescribe at least one Cipla product.
#
3rd largest player in private Rx market in SAGA
#
Fastest growing generic player in North America.
Diversified Product portfolio
Co. has a diversified product portfolio of 1,500+ products in 50+ dosage forms and 65 therapeutic categories.
[2]
In FY22, it launched 93 products across the globe.
[3]
Consumer Brands
[4]
India - Nicotex, Cofsils, Cipladine, ORS, Omnigel
South Africa - Cipla Actin, Broncol, Flomist, Asthavent, coryx.
Therapy – Market share – Market Rank
Overall - 5.2% - 3
Chronic - 7.9% - 2
Acute - 3.7% - 7
Respiratory - 22.2% - 1
Urology - 14.2% - 1
Anti-infective - 6.9% - 4
Cardiac - 5.3% - 5
Gastro-Intestinal - 2.9% - 9
Anti-diabetics - 0.8% - 27
[5]
Therapy – FY22 Revenue Contribution
Respiratory – 37%
Anti Infectives – 16%
Cardiac – 12%
Antiviral – 5%
Gastrointestinal – 6%
Urology – 5%
Derma – 3%
CNS – 3%
Pain – 3%
Opthimal - 3%
Others – 7%
[5]
API Business
The Co. has produced 200+ generics and complex APIs that are supplied to 62 countries worldwide. It continues to be a preferred partner to many large generic pharmaceutical co.s. The API business has also made efforts to de-risking the supply chain for Cipla’s focus APIs, by shifting to indigenous suppliers for key starting materials (KSM) and intermediates. It has a robust pipeline of over 75+ APIs across regulated markets in various stages of development.
[6]
Geographical Split FY23
[1]
India - 43%
North America - 26%
South Africa, Sub-Saharan Africa, and Cipla Global Access (SAGA) - 14%
EMEU - 13%
Others - 4%
Manufacturing Facilities
The product pipeline of the Co. is driven by 47 state-of-the-art manufacturing facilities across six countries.
[7]
Strategic Partnerships
[8]
On March 24th, the company established a partnership with Sanofi India Ltd. to distribute and promote Sanofi India’s Central Nervous System (CNS) product range in India. Under this agreement, Cipla will manage the distribution of six CNS brands from Sanofi India, which includes Frisium®, a prominent brand in the anti-epileptic medication segment.
Acquisitions
In FY22, Cipla entered into definitive agreements for the acquisition of a 33% partnership interest in Clean Max Auriga Power LLP and a 32.49% stake in AMP Energy Green Eleven Private Limited for setting up renewable power generation plants in Karnataka and Maharashtra, respectively.
[9]
Joint Venture
The Co. entered into a joint venture agreement with ‘Kemwell Biopharma Private Limited for undertaking the business of developing, manufacturing, and other allied activities relating to biologic products.
[9]
Subsidiaries
Two wholly-owned step-down subsidiaries were voluntarily deregistered/dissolved as these were operationally inactive and not required, namely - Cipla Biotec South Africa (Pty) Limited with effect from 3rd February 2022 and Inyanga Trading 386 (Pty) Limited with effect from 10th December 2021.
[10]
POC Model
[11]
The company plans to enter the POC model by Leveraging Cipla’s reach with doctors, clinics, and nursing homes. For this, they launched Cippoint on Jan,23, Achira (In-development) and Neodocs.
** R&D Capabilities**
[12]
The Co. has 5 R&D facilities that are located in New York, Maharashtra, and Karnataka and a total team of 1650 scientists. In FY23, the company spent Rs. 1343 crs. (6% of revenue) on R&D. last 5 yrs avg. spend is Rs. 1140 crs.
[13]
New Products
- the company has launched 78 new products in FY23. (vs 93 in FY22 and 81 in FY21). Out of these 78, 27 were launched in Emerging Markets, 20 in Europe, and 12 in India.
303 patents are granted to Cipla till FY23
. The company launched 30 new products in 9MFY24.
[14]
**Consumer Business **
In FY22, the consumer business continued to drive the illness-to-wellness theme led by brand-building initiatives, deepening distribution and category innovations.
Consumers Reached -
Retailers - 500k
Grocers and others - 40K+
Modern Trade - 700+
E-commerce - 9
The Co’s anchor brands Nicotex and Cofsils continued to maintain a strong market position in their respective categories in FY22.
[15]
New Streams
[16]
The company is working on Cell & Gene therapy (Genomics), Oligonucleotides, mRNAs, and Stem cells.
Focus
The company is expecting a growth of ~20% till 2030.
[17]
and aims to be the 2nd Largest Pharma company in Rx Market in India. It aims to be the largest in SAGA and the 2nd largest in North America.
[18]
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,279 | 10,173 | 11,345 | 13,790 | 14,394 | 15,156 | 16,362 | 17,132 | 19,160 | 21,763 | 22,753 | 25,774 |
| Expenses + | 6,065 | 8,026 | 9,183 | 11,310 | 11,898 | 12,329 | 13,265 | 13,926 | 14,907 | 17,211 | 17,726 | 19,483 |
| Operating Profit | 2,214 | 2,147 | 2,163 | 2,480 | 2,496 | 2,826 | 3,097 | 3,206 | 4,252 | 4,553 | 5,027 | 6,291 |
| OPM % | 27% | 21% | 19% | 18% | 17% | 19% | 19% | 19% | 22% | 21% | 22% | 24% |
| Other Income + | 245 | 251 | 164 | 208 | 208 | 280 | 477 | 344 | 266 | 99 | 293 | 552 |
| Interest | 34 | 146 | 168 | 207 | 159 | 114 | 168 | 197 | 161 | 106 | 110 | 90 |
| Depreciation | 330 | 373 | 505 | 754 | 1,323 | 1,323 | 1,326 | 1,175 | 1,068 | 1,052 | 1,172 | 1,051 |
| Profit before tax | 2,095 | 1,880 | 1,654 | 1,727 | 1,222 | 1,669 | 2,079 | 2,178 | 3,290 | 3,493 | 4,038 | 5,702 |
| Tax % | 26% | 25% | 24% | 19% | 15% | 15% | 27% | 29% | 27% | 27% | 30% | 27% |
| Net Profit + | 1,545 | 1,404 | 1,229 | 1,383 | 1,035 | 1,417 | 1,492 | 1,500 | 2,389 | 2,547 | 2,833 | 4,154 |
| EPS in Rs | 19.24 | 17.29 | 14.71 | 16.93 | 12.51 | 17.52 | 18.96 | 19.18 | 29.82 | 31.19 | 34.71 | 51.05 |
| Dividend Payout % | 10% | 12% | 14% | 12% | 16% | 17% | 16% | 21% | 17% | 16% | 24% | 25% |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 50% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cipla Limited Employees Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  | 42 | 42 | 41 | 40 | 39 | 43 |
| Contribution payable to provident/gratuity fund |  |  |  |  | 9.64 | 10 |  |  |  |
| Avenue Therapeutics, Inc. Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  | 242 |  |  |  |  |
| Cipla foundation |  |  |  |  |  |  |  |  |  |
| Donations given |  |  |  |  | 29 | 38 | 33 | 56 | 63 |
| Dr. Y. K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 50 | 115 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.02 | 2.03 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Remuneration |  |  | 2.02 |  |  |  |  |  |  |
| Cipla Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  | 28 | 15 | 15 | 28 | 20 | 24 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  | 28 |  |  |  |
| Advances receivable from gratuity trust |  |  |  |  | 9.51 |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  | 3.92 |  |  |  |  |  |
| GoApptiv Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Service Charges and reimbursement paid |  |  |  |  |  |  | 15 | 38 | 34 |
| Payable to |  |  |  |  |  |  |  | 24 | 3.34 |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  | 7.20 |  | 18 |
| Investment in equity shares of Associates |  |  |  |  |  |  | 1.80 |  | 8.25 |
| Reimbursement of operating/other expenses |  |  |  |  |  |  | 0.65 |  |  |
| Payable to associates and others |  |  |  |  |  |  | 0.29 |  |  |
| Mr. Umang Vohra Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 15 | 17 | 15 |  |  |  |
| Remuneration |  | 4.74 | 14 |  |  |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 5.50 | 4 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 4 |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 0.04 | 0.16 |  |  |  |
| Cipla Foundation |  |  |  |  |  |  |  |  |  |
| Donations given | 9.28 | 12 |  | 31 |  |  |  |  |  |
| Donations Given |  |  | 16 |  |  |  |  |  |  |
| Payable to |  |  |  |  |  |  |  | 0.33 |  |
| Outstanding receivables |  |  |  |  |  |  |  |  | 0.07 |
| Mr. Subhanu Saxena Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 13 | 12 | 25 |  |  |  |  |  |  |
| Mr. M. K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 10 | 24 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.07 | 2.08 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Remuneration |  | 0.11 | 2.09 |  |  |  |  |  |  |
| AMPSolar Power Systems Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electricity charges paid |  |  |  |  |  |  | 2.42 | 16 | 14 |
| Investment in Compulsory Convertible Debentures |  |  |  |  |  | 8.91 |  |  |  |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  |  | 1.16 |  |
| Investment in equity shares |  |  |  |  |  | 0.09 |  | 0.01 |  |
| Stempeutics Research Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investment in Equity | 20 | 13 |  |  |  |  |  |  |  |
| Loan repaid | 2.94 |  |  |  |  |  |  |  |  |
| Purchase of Goods |  | 2.01 |  |  |  |  |  |  |  |
| Outstanding payables | 0.02 | 1 |  |  |  |  |  |  |  |
| Dr. Y.K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 33 |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 2.03 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Ms. Samina Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 5.37 | 13 |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 7.27 | 6.74 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2.30 | 2.30 |  |  |  |
| Cipla Limited Employees Provident fund |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 11 | 12 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 11 |  |  |
| Brandmed (Pty) Ltd. Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  |  | 32 |  |  |  |
| Brandmed (Pty) Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding receivables |  |  |  |  |  |  |  | 2.61 | 7.27 |
| Loan given |  |  |  |  |  |  |  | 2.61 | 4.72 |
| Purchase of goods |  |  |  |  |  |  | 4.99 | 0.77 |  |
| Payable towards acquisition of stake in associate |  |  |  |  |  |  | 2.47 |  |  |
| Interest Income |  |  |  |  |  |  |  | 0.02 | 0.33 |
| Achira Labs Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Investment in Compulsory Convertible Preference Share of Associates |  |  |  |  |  |  |  |  | 23 |
| Investment in equity shares of Associates |  |  |  |  |  |  |  |  | 2 |
| Stempeutics Research Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  | 3 |  | 2 |  |  |
| Purchase of goods |  |  |  | 1.10 | 0.16 |  |  | 0.46 | 2.33 |
| Testing and analysis charges paid |  |  |  |  | 1.79 | 2.06 |  |  |  |
| Service Charges and reimbursement paid |  |  |  |  |  |  | 1.16 | 1.05 | 1.26 |
| Purchase of Fixed Assets |  |  |  |  |  |  |  |  | 2 |
| Payable to |  |  |  |  |  |  |  | 0.52 | 1.25 |
| Reimbursement of operating/other expenses |  |  |  |  | 0.18 | 0.31 |  |  |  |
| Freight charges paid |  |  |  |  |  | 0.02 |  | 0.02 |  |
| Mr. S. Radhakrishnan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 3.69 | 3.37 | 4.06 |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 2.09 | 2.10 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 2 | 2 |  |  |  |
| Dividend Paid |  |  |  |  | 0.01 | 0.11 |  |  |  |
| Mr. Kedar Upadhye Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 3.31 | 3.85 | 3.84 |  |  |  |
| Remuneration |  |  | 3.13 |  |  |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.91 | 0.90 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.70 |  |  |  |  |  |
| Dividend Paid |  |  |  |  |  | 0.03 |  |  |  |
| Mr. Rajesh Garg Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration | 4.98 | 11 |  |  |  |  |  |  |  |
| Ms. Samina Vaziralli Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 2.47 | 3.90 |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 4.83 |  |  |  |  |  |
| Dividend paid |  |  |  | 3.58 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 1.14 |  |  |  |  |  |
| Cipla Limited Employees Gratuity fund |  |  |  |  |  |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  |  | 9.30 |  |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 4.26 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  |  | 0.32 |
| Clean Max Auriga Power LLP Associate |  |  |  |  |  |  |  |  |  |
| Investment in equity shares |  |  |  |  |  |  |  | 6.75 |  |
| Electricity charges paid |  |  |  |  |  |  |  |  | 5.19 |
| Payable to |  |  |  |  |  |  |  |  | 0.84 |
| AMP Energy Green Eleven Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Investment in Compulsory Convertible Debentures of Associates |  |  |  |  |  |  |  | 6.75 |  |
| Electricity charges paid |  |  |  |  |  |  |  |  | 3.67 |
| Investment in equity shares |  |  |  |  |  |  |  | 0.75 |  |
| Payable to |  |  |  |  |  |  |  |  | 0.40 |
| The Cipla Foundation (SA) |  |  |  |  |  |  |  |  |  |
| Donations given |  |  |  |  |  |  |  |  | 9.19 |
| Outstanding receivables |  |  |  |  |  |  |  | 1.68 | 0.49 |
| Hamied Foundation |  |  |  |  |  |  |  |  |  |
| Service charges paid |  | 1.76 |  | 4.87 |  |  |  |  |  |
| Service Charges Paid |  |  | 2.49 |  |  |  |  |  |  |
| Donations Given |  |  | 1.64 |  |  |  |  |  |  |
| Donations given |  | 0.36 |  |  |  |  |  |  |  |
| Mr. M.K. Hamied Key Person |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 6.33 |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 2.10 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Dr. Raghunathan Ananthanarayanan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  |  | 8.85 | -0.47 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 1.78 |  |  |  |  |
| Mr. S.Radhakrishnan Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 4.03 |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 2 |  |  |  |  |  |
| Chest Research Foundation |  |  |  |  |  |  |  |  |  |
| Service charges paid |  |  |  |  | 2.22 |  |  |  |  |
| Donations given |  |  |  |  |  | 2 |  |  |  |
| Sitec Labs Private Limited Employees Group Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.98 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 1.11 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.13 | 0.85 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.08 |  |  |
| Cipla Limited Employee Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident fund |  |  |  | 3.53 |  |  |  |  |  |
| Dr. Peter Mugyenyi Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.43 | 0.43 | 0.66 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.41 |  |  |  |
| Remuneration |  |  | 0.42 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Stempeutics Research Pvt. Ltd Associate |  |  |  |  |  |  |  |  |  |
| Investment - Equity |  |  | 2.57 |  |  |  |  |  |  |
| Purchase of Goods |  |  | 0.57 |  |  |  |  |  |  |
| Mr. Ashok Sinha Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.47 | 0.46 | 0.48 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.40 |  |  |  |
| Remuneration |  |  | 0.51 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Cipla Health Limited Employees Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.96 | 1.50 |
| Contribution to provident fund and other fund |  |  |  |  |  |  |  | 0.38 | 0.08 |
| Ms. Naina Lal Kidwai Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.40 | 0.43 | 0.45 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.35 | 0.35 |  |  |  |
| Remuneration |  |  | 0.43 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.35 |  |  |  |  |  |
| Mr. Adil Zainulbhai Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.36 | 0.38 | 0.47 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.32 | 0.36 |  |  |  |
| Remuneration |  |  | 0.42 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.32 |  |  |  |  |  |
| Ms. Punita Lal Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.39 | 0.41 | 0.40 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.35 | 0.35 |  |  |  |
| Remuneration |  |  | 0.38 |  |  |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.33 |  |  |  |  |  |
| Medispray Laboratories Private Limited Employees Comprehensive Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.53 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.10 | 0.38 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.22 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.12 |  |  |
| Mr. Peter Lankau Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.44 | 0.73 | 0.17 |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.40 | 0.10 |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.40 |  |  |  |  |  |
| Remuneration |  |  | 0.11 |  |  |  |  |  |  |
| Meditab Specialities Limited Employees Comprehensive Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 1.20 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.22 | 0.52 |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.01 |  |  |
| Ms. Ireena Vittal Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration (including sitting fees) |  |  |  | 0.41 | 0.41 |  |  |  |  |
| Payable to (Commission and remuneration) |  |  |  |  | 0.36 |  |  |  |  |
| Payable to KMP (Commission and remuneration) |  |  |  | 0.36 |  |  |  |  |  |
| Remuneration |  |  | 0.14 |  |  |  |  |  |  |
| Goldencross Pharma Private Limited Employees Group Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund and other fund |  |  |  |  |  |  | 0.80 |  |  |
| Contribution payable to provident/ gratuity fund |  |  |  |  |  |  |  | 0.21 | 0.46 |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.12 |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.04 |  |  |
| Cipla Health Limited Employees Gratuity scheme |  |  |  |  |  |  |  |  |  |
| Contribution payable to provident/gratuity fund |  |  |  |  |  |  | 0.95 |  |  |
| Mr. Kamil Hamied Relative |  |  |  |  |  |  |  |  |  |
| Remuneration |  | 0.38 |  |  |  |  |  |  |  |
| Cipla Biotec Private Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Advances receivable from gratuity fund |  |  |  |  |  |  | 0.01 | 0.01 | 0.01 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,279 | 10,173 | 11,345 | 13,790 | 14,394 | 15,156 | 16,362 | 17,132 | 19,160 | 21,763 | 22,753 | 25,774 |
| Expenses + | 6,065 | 8,026 | 9,183 | 11,310 | 11,898 | 12,329 | 13,265 | 13,926 | 14,907 | 17,211 | 17,726 | 19,483 |
| Operating Profit | 2,214 | 2,147 | 2,163 | 2,480 | 2,496 | 2,826 | 3,097 | 3,206 | 4,252 | 4,553 | 5,027 | 6,291 |
| OPM % | 27% | 21% | 19% | 18% | 17% | 19% | 19% | 19% | 22% | 21% | 22% | 24% |
| Other Income + | 245 | 251 | 164 | 208 | 208 | 280 | 477 | 344 | 266 | 99 | 293 | 552 |
| Interest | 34 | 146 | 168 | 207 | 159 | 114 | 168 | 197 | 161 | 106 | 110 | 90 |
| Depreciation | 330 | 373 | 505 | 754 | 1,323 | 1,323 | 1,326 | 1,175 | 1,068 | 1,052 | 1,172 | 1,051 |
| Profit before tax | 2,095 | 1,880 | 1,654 | 1,727 | 1,222 | 1,669 | 2,079 | 2,178 | 3,290 | 3,493 | 4,038 | 5,702 |
| Tax % | 26% | 25% | 24% | 19% | 15% | 15% | 27% | 29% | 27% | 27% | 30% | 27% |
| Net Profit + | 1,545 | 1,404 | 1,229 | 1,383 | 1,035 | 1,417 | 1,492 | 1,500 | 2,389 | 2,547 | 2,833 | 4,154 |
| EPS in Rs | 19.24 | 17.29 | 14.71 | 16.93 | 12.51 | 17.52 | 18.96 | 19.18 | 29.82 | 31.19 | 34.71 | 51.05 |
| Dividend Payout % | 10% | 12% | 14% | 12% | 16% | 17% | 16% | 21% | 17% | 16% | 24% | 25% |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 50% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 1,398 | 1,563 | 1,173 | 1,741 | 2,382 | 1,463 | 1,691 | 3,068 | 3,755 | 3,326 | 3,238 | 4,134 |
| Cash from Investing Activity + | -2,063 | -1,265 | -950 | -4,533 | -1,304 | -834 | -1,688 | 114 | -2,374 | -1,858 | -2,376 | -2,988 |
| Cash from Financing Activity + | 718 | -266 | 165 | 3,104 | -1,326 | -385 | -349 | -2,949 | -1,240 | -1,600 | -958 | -1,200 |
| Net Cash Flow | 53 | 33 | 388 | 312 | -248 | 243 | -345 | 234 | 141 | -132 | -97 | -55 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 74 | 59 | 64 | 62 | 65 | 75 | 93 | 83 | 66 | 57 | 65 | 68 |
| Inventory Days | 295 | 273 | 329 | 273 | 239 | 271 | 250 | 267 | 232 | 230 | 228 | 217 |
| Days Payable | 102 | 92 | 126 | 106 | 108 | 142 | 123 | 139 | 103 | 108 | 109 | 102 |
| Cash Conversion Cycle | 266 | 239 | 267 | 230 | 196 | 204 | 220 | 211 | 195 | 180 | 184 | 182 |
| Working Capital Days | 142 | 126 | 133 | 121 | 111 | 129 | 143 | 122 | 106 | 103 | 122 | 193 |
| ROCE % | 24% | 19% | 15% | 13% | 7% | 9% | 11% | 12% | 17% | 17% | 18% | 23% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 36.12% | 36.11% | 33.63% | 33.61% | 33.61% | 33.61% | 33.55% | 33.46% | 33.46% | 33.46% | 33.46% | 30.91% |
| FIIs + | 24.80% | 24.36% | 26.65% | 27.65% | 27.69% | 28.39% | 27.42% | 25.49% | 25.74% | 25.73% | 25.82% | 27.82% |
| DIIs + | 21.03% | 21.52% | 21.99% | 21.33% | 21.47% | 20.87% | 21.83% | 24.05% | 23.90% | 24.05% | 24.15% | 24.66% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% | 0.21% |
| Public + | 18.05% | 18.01% | 17.73% | 17.40% | 17.00% | 16.91% | 16.99% | 16.76% | 16.68% | 16.53% | 16.36% | 16.40% |
| No. of Shareholders | 4,10,831 | 4,51,365 | 4,18,584 | 4,18,910 | 3,88,864 | 4,04,182 | 4,75,293 | 4,66,515 | 4,26,863 | 4,25,731 | 4,36,154 | 4,63,569 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 37.48% | 37.21% | 36.70% | 36.68% | 36.73% | 33.63% | 33.55% | 33.46% | 30.91% |
| FIIs + | 20.20% | 24.18% | 26.63% | 17.98% | 23.26% | 26.65% | 27.42% | 25.82% | 27.82% |
| DIIs + | 15.85% | 13.92% | 14.18% | 22.63% | 17.17% | 21.99% | 21.83% | 24.15% | 24.66% |
| Government + | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.21% | 0.21% | 0.21% |
| Public + | 26.47% | 24.69% | 22.49% | 22.71% | 22.84% | 17.73% | 16.99% | 16.36% | 16.40% |
| No. of Shareholders | 2,20,759 | 2,01,096 | 2,13,139 | 2,42,910 | 3,64,796 | 4,18,584 | 4,75,293 | 4,36,154 | 4,63,569 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/cipla-ltd/cipla/500087/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
2m - Newspaper publication of consolidated unaudited financial results for the quarter ended 30th June 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4b82abe2-0208-4d30-9015-6317c6d3b460.pdf)
- [Announcement under Regulation 30 (LODR)-Investor Presentation 6m](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8074c100-061a-4a7d-9a48-d92bc1053531.pdf)
- [Announcement under Regulation 30 (LODR)-Press Release / Media Release
10m - Press Release for quarter ended 30th June 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=19ed6552-2c56-47af-9236-45b05261be33.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9d732f08-1b3f-450a-871c-00728dc828cc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=429adf35-76be-42f9-9672-edb640efb339.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\8b1af9c1-e37f-4ff0-8583-a71bff16fb42.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500087/74053500087.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500087/69187500087.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870320.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_CIPLA_2010_2011_09092011125555.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500087/5000870310.pdf)

## Credit Ratings
- [Rating update
11 Jan from fitch](https://www.indiaratings.co.in/pressrelease/67979)
- [Rating update
9 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310121027_Cipla_Limited.pdf)
- [Rating update
17 Jan 2023 from fitch](https://www.indiaratings.co.in/pressrelease/60632)
- [Rating update
27 Sep 2022 from care](https://www.careratings.com/upload/CompanyFiles/PR/27092022060517_Cipla_Limited.pdf)
- [Rating update
19 Jan 2022 from fitch](https://www.indiaratings.co.in/pressrelease/57282)
- [](https://www.careratings.com/upload/CompanyFiles/PR/05102021064834_Cipla_Limited.pdf)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8074c100-061a-4a7d-9a48-d92bc1053531.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=20e05c47-5d65-4cae-8e80-3fd901068efa.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4480b26c-29ff-4750-8a60-ebd602b00741.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cd157749-300d-423a-ba64-4975562f0689.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e3497378-376b-482e-893d-8e1cddceaf4e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9199ccf7-4ff5-4f8f-82e9-c21f148618b8.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b6dc9897-3c64-4c9e-bdd2-2c4734877009.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=03194a2d-06a2-4427-87da-306af505daf8.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6983bc6f-fcdf-48bd-9c0d-25dd844f1337.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=37335843-93ef-4383-a671-7add0ceb599d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d890f925-72f4-4d3b-b4eb-9e7392d96f7b.pdf)
- [](https://www.cipla.com/sites/default/files/Q1-FY24-Investor-presentation.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=82aaa297-a625-43f0-be1c-c8cd98de3be3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81ecd68c-01d7-4df5-ae73-b1267955695a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94ef8610-d71d-44ae-8220-07330ea704ac.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a48b4dae-af77-47c6-9639-e89ef7009a9c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28b4fd36-0ffb-4f8e-8f27-5a52843fb9d0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5cca2c85-1ffa-4984-8778-c6afd03ba6e7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2c6b0341-ed61-4735-aedd-d0f29a935bd2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=54f7b95e-4b1b-4fd4-ab73-5206f07a0e51.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7ba2a480-518a-4482-b6a9-923fe422944f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9c58919b-3e59-48a4-ad7c-dd5885259717.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2cd2dfeb-8144-4ad6-b5d8-f13561354f55.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=347fe67b-3a75-48b1-92d3-c24b6e6790a5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4c697e31-0e9d-41e4-8590-437afb408590.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa25daa3-1349-4955-bda7-4d247f5c0976.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a6705c9b-1f44-4e42-b5a9-6b33d2068dc7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b053ace1-599a-4738-a4c7-0168aaf72a82.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bb38f7ad-4d07-4df9-b086-4af3b42d01ff.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f43e1db9-7457-4040-9f41-a1651ad030fa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5bd349ac-0724-44da-acb7-a0201e9ff040.pdf)
- [](https://www.cipla.com/sites/default/files/Earning-call-transcript-Q1FY22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a3e069dd-9619-4467-9bb2-4b56e4e41006.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=441879b8-ac08-42b9-9e21-44f3833d1faa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=56d6a5e8-9d69-4165-9601-237611455400.pdf)
- [](https://www.cipla.com/sites/default/files/Transcript_Q3FY21_Unudited_Financial_Results_31st_December_2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=78263cd8-dc43-4606-90ab-f795e2aea50d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=96685b2d-94ab-4c69-829f-b124753d19ba.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=24a23c98-1f5c-4b9a-9054-166403fa6d2b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=208a90b6-2e26-4965-b4f5-aee15b001eaa.pdf)
- [](https://www.cipla.com/sites/default/files/Earnings%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e02f8b42-ef23-4508-8224-9b6858e76569.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a278a23-2926-4a3e-81a1-1069d8fb0147.pdf)
- [](https://www.cipla.com/sites/default/files/Transcript%20-%20Q1FY21%20Unudited%20Financial%20Results%2030th%20June%202020_0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=34383223-1d85-4796-93ad-357a839af754.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4e2d7d47-f9aa-4795-bd75-0e67b54d71d5.pdf)
- [](https://www.cipla.com/sites/default/files/Earnings%20call%20transcript%20Q4FY20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dcd4b23f-031b-4b68-9153-e59c19b704af.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0048ee9b-899b-43f3-926a-13e58a768280.pdf)
- [](https://www.cipla.com/sites/default/files/Transcript-%20Q3FY20%20Unaudited%20Financial%20Results%2031st%20Dec%202019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ca5481ce-a5ae-4d0b-96a4-aef437c9a208.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=53f505b2-87d7-47a0-8bb4-0a58fca7cffe.pdf)
- [](https://www.cipla.com/sites/default/files/Letter%20-%20W_2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aaa3665e-90d2-48c8-a456-4363ae4b059e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5eaa6abe-c013-49c8-8ed2-502b44db6f7b.pdf)
- [](https://www.cipla.com/sites/default/files/Earnings_Call_Transcript_Q1_FY20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=879b6184-ebc5-402c-bb27-871f43f1c17d.pdf)
- [](https://www.cipla.com/sites/default/files/1559056375_Letter%2055_0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=abb67258-8386-4fd2-964f-0cee9f1b773a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=97ea879a-bab7-45e0-b6fe-5b3a50d29b60.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d7d3c983-5de4-4bda-b7f0-5eab5025968d.pdf)
- [](https://www.cipla.com/sites/default/files/2019-03/Q3%20FY%2019%20Earnings%20Call%20Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=067beff1-22cd-4c87-9d8d-a80577bda42a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=69218207-591e-4910-8568-f493d3e27053.pdf)
- [](https://www.cipla.com/sites/default/files/2019-01/Transcript-%20Q2FY19%20Unaudited%20Financial%20Results%2030th%20Sept%202018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dbc47dcc-0024-4f2b-8889-f65703c014e6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=97c7ed70-9f87-4f3f-bcae-d7b09060427a.pdf)
- [](https://www.cipla.com/sites/default/files/2019-01/Transcript-%20Q1FY19%20Unaudited%20Financial%20Results%2030th%20Jun%202018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ca27a267-26c5-4b9e-b034-0f1693eb296c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1852806c-3157-4214-96dc-b3507b2c995f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fd38558c-355f-4c1b-a489-711691ce7da9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=98907e96-95ca-4c88-b24c-06f3b4e3fac3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=685e9206-2442-4878-b784-e6e96e486c0e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b633e1aa-280f-43ca-9c08-c99ef594057d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5801a445-1da1-469c-a5e6-e973b5746b03.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=30ed3c9d-d667-4601-b2c5-c3853faa2f27.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44b66a4d-9144-4481-b262-e19918556a1f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B528F8FF_FF7F_4FBC_971B_71BE67CDA6BA_165720.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3BAD1874_BC7B_465E_98C8_4F30B20F354F_165114.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=AD02EEE8_F9AC_478E_8BF1_67569C71B698_161441.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=59F03AF7_C790_4602_929D_F5A73EBAFD18_182329.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6B54A815_3522_46EA_A3B8_A351282BC310_170805.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=DC30E39F_C546_4CCA_962D_A13E5BE36032_184731.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Sun Pharma.Inds. | 1715.30 | 411558.00 | 41.26 | 6.47 | 8.49 | 60.50 | 28.10 | 30.51 | 0.80 | 17.32 | 12.08 | 16.69 | 0.58 | 0.05 | 49.61 | 1.30 | 48496.85 | 26.84 | 9988.74 | 11982.90 | 2750.69 | 9.63 | 28.70 | 39.91 | 3273.67 | 54.48 | 0.00 | 3.01 | 38.27 | 1.07 | 10.51 | 16.09 | 404310.99 | 2.05 | 1.76 | 10.57 | 21.74 | 34.26 | 46.77 | 15.84 | 13.79 | 23.38 | 25.14 | 10.78 | 13.13 | 16.55 | 16.44 | 1.47 | 39.91 | 23.38 | 29.53 | 29.65 | 29.65 | 228.95 | 239.93 |
| 2. | Cipla | 1587.30 | 128177.38 | 30.10 | 4.82 | 4.97 | 50.82 | 18.17 | 23.03 | 0.86 | 23.08 | 13.84 | 16.99 | 0.83 | 0.02 | 66.61 | 1.16 | 25774.09 | 24.41 | 4257.33 | 6163.24 | 931.87 | 7.39 | 48.80 | 51.05 | 559.41 | 30.91 | -2.56 | 4.96 | 38.27 | 0.00 | 13.28 | 49.82 | 127861.82 | 3.70 | 1.18 | 6.45 | 9.52 | 17.99 | 28.05 | 14.50 | 13.55 | 25.42 | 21.85 | 9.51 | 10.39 | 12.84 | 18.02 | 2.70 | 51.05 | 25.37 | 29.45 | 29.14 | 30.43 | 181.95 | 80.72 |
| 3. | Zydus Lifesci. | 1206.80 | 121432.34 | 31.48 | 6.06 | 6.21 | 71.54 | 21.42 | 38.79 | 0.25 | 22.34 | 14.61 | 20.67 | 0.72 | 0.04 | 60.23 | 1.37 | 19547.40 | 27.54 | 3860.03 | 5533.80 | 1179.26 | 10.44 | 94.59 | 38.36 | 804.20 | 74.98 | 0.00 | 4.04 | 38.27 | 0.00 | 13.40 | 63.49 | 121131.44 | 2.09 | 1.90 | 27.27 | 63.72 | 26.28 | 85.65 | 20.84 | 19.79 | 16.56 | 17.75 | 8.23 | 10.72 | 13.68 | 14.96 | 1.45 | 38.36 | 16.96 | 22.94 | 22.23 | 22.69 | 174.55 | 101.22 |
| 4. | Dr Reddy's Labs | 6871.05 | 114629.58 | 20.82 | 4.09 | 4.09 | 48.05 | 13.13 | 20.43 | 0.57 | 26.53 | 15.53 | 21.39 | 0.79 | 0.07 | 42.56 | 1.26 | 28011.10 | 28.32 | 5512.22 | 7113.80 | 1309.80 | 12.65 | 36.42 | 334.37 | 2002.00 | 26.65 | 0.00 | 6.35 | 38.27 | 0.00 | 13.54 | 19.89 | 114903.88 | 2.13 | 0.85 | 9.61 | 17.04 | 12.27 | 24.45 | 18.67 | 16.73 | 24.41 | 41.29 | 12.64 | 13.72 | 21.64 | 26.73 | 1.46 | 334.37 | 24.30 | 24.56 | 22.69 | 27.59 | 270.97 | 16.65 |
| 5. | Lupin | 1840.00 | 83896.43 | 44.34 | 5.90 | 4.19 | 95.45 | 21.95 | 18.29 | 0.44 | 15.72 | 8.22 | 14.14 | 0.86 | 0.20 | 8.67 | 1.63 | 20010.82 | 18.99 | 1891.97 | 4960.79 | 359.43 | 11.98 | 52.33 | 42.01 | 2921.77 | 46.98 | -0.03 | 3.23 | 38.27 | 0.00 | 20.25 | 360.95 | 85615.66 | 1.48 | 2.11 | 11.41 | 23.82 | 17.44 | 83.77 | 1.92 | 2.23 | 21.04 | 17.13 | 6.41 | 9.69 | 3.33 | 5.73 | 0.90 | 42.01 | 20.87 | 47.67 | 47.33 | 42.93 | 195.23 | 45.50 |
| 6. | Mankind Pharma | 2051.10 | 82174.24 | 47.98 | 8.61 | 8.87 | 154.84 | 33.12 |  | 0.00 | 24.57 | 16.50 | 19.71 | 0.89 | 0.00 | 141.94 | 1.08 | 9264.81 | 25.10 | 1715.30 | 2152.69 | 454.17 | 14.99 | 61.63 | 45.52 | 8.56 | 74.87 | -0.01 | 2.51 | 38.27 | 0.00 | 14.00 | 40.69 | 81421.79 | 2.04 | 1.76 | -9.48 | 5.61 |  | 15.83 | 19.82 | 21.53 | 27.24 | 17.61 | 19.33 | 18.82 | 17.02 | 20.70 | 1.37 | 45.52 | 27.24 | 53.69 | 53.69 | 53.69 | 57.90 | 40.06 |
| 7. | Aurobindo Pharma | 1387.15 | 81278.48 | 24.80 | 2.70 | 2.80 | 187.05 | 12.79 | 19.32 | 0.33 | 14.17 | 7.76 | 11.58 | 0.69 | 0.22 | 16.78 | 1.42 | 29001.87 | 20.09 | 3282.97 | 7580.15 | 972.80 | 17.10 | 92.29 | 54.15 | 6647.63 | 51.80 | -0.03 | 6.06 | 38.27 | 20.88 | 16.68 | 71.01 | 81647.81 | 1.98 | 4.00 | 20.46 | 18.42 | 14.60 | 63.10 | 10.30 | 12.70 | 6.20 | -1.25 | 8.19 | 5.39 | 7.47 | 9.20 | 1.18 | 54.15 | 6.20 | 14.96 | 13.63 | 15.74 | 215.68 | 58.59 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| CIPLA | Market Cap | ₹ 1,28,416 Cr. |
| CIPLA | Current Price | ₹ 1,590 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.2 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | Sales | ₹ 25,774 Cr. |
| CIPLA | OPM | 24.4 % |
| CIPLA | Profit after tax | ₹ 4,257 Cr. |
| CIPLA | Mar Cap | ₹ 1,28,416 Cr. |
| CIPLA | Sales Qtr | ₹ 6,163 Cr. |
| CIPLA | PAT Qtr | ₹ 932 Cr. |
| CIPLA | Qtr Sales Var | 7.39 % |
| CIPLA | Qtr Profit Var | 48.8 % |
| CIPLA | Price to Earning | 30.2 |
| CIPLA | Dividend yield | 0.86 % |
| CIPLA | Price to book value | 4.83 |
| CIPLA | ROCE | 23.1 % |
| CIPLA | Return on assets | 13.8 % |
| CIPLA | Debt to equity | 0.02 |
| CIPLA | Return on equity | 17.0 % |
| CIPLA | EPS | ₹ 51.0 |
| CIPLA | Debt | ₹ 559 Cr. |
| CIPLA | Promoter holding | 30.9 % |
| CIPLA | Change in Prom Hold | -2.56 % |
| CIPLA | Earnings yield | 4.96 % |
| CIPLA | Pledged percentage | 0.00 % |
| CIPLA | Industry PE | 38.3 |
| CIPLA | Sales growth | 13.3 % |
| CIPLA | Profit growth | 49.8 % |
| CIPLA | Current Price | ₹ 1,590 |
| CIPLA | Price to Sales | 4.98 |
| CIPLA | CMP / FCF | 50.9 |
| CIPLA | EVEBITDA | 18.2 |
| CIPLA | Enterprise Value | ₹ 1,28,100 Cr. |
| CIPLA | Current ratio | 3.70 |
| CIPLA | Int Coverage | 66.6 |
| CIPLA | PEG Ratio | 1.19 |
| CIPLA | Return over 3months | 6.45 % |
| CIPLA | Return over 6months | 9.52 % |
| CIPLA | No. Eq. Shares | 80.8 |
| CIPLA | Sales growth 3Years | 10.4 % |
| CIPLA | Sales growth 5Years | 9.51 % |
| CIPLA | Profit Var 3Yrs | 21.8 % |
| CIPLA | Profit Var 5Yrs | 25.4 % |
| CIPLA | ROE 5Yr | 13.6 % |
| CIPLA | ROE 3Yr | 14.5 % |
| CIPLA | Return over 1year | 28.0 % |
| CIPLA | Return over 3years | 18.0 % |
| CIPLA | Return over 5years | 23.0 % |
| CIPLA | Market Cap | ₹ 1,28,416 Cr. |
| CIPLA | Current Price | ₹ 1,590 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.2 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | Sales last year | ₹ 25,774 Cr. |
| CIPLA | OP Ann | ₹ 6,291 Cr. |
| CIPLA | Other Inc Ann | ₹ 552 Cr. |
| CIPLA | EBIDT last year | ₹ 7,038 Cr. |
| CIPLA | Dep Ann | ₹ 1,051 Cr. |
| CIPLA | EBIT last year | ₹ 5,987 Cr. |
| CIPLA | Interest last year | ₹ 89.9 Cr. |
| CIPLA | PBT Ann | ₹ 5,702 Cr. |
| CIPLA | Tax last year | ₹ 1,547 Cr. |
| CIPLA | PAT Ann | ₹ 4,257 Cr. |
| CIPLA | Extra Ord Item Ann | ₹ -195 Cr. |
| CIPLA | NP Ann | ₹ 4,154 Cr. |
| CIPLA | Dividend last year | ₹ 1,050 Cr. |
| CIPLA | Raw Material | 34.2 % |
| CIPLA | Employee cost | ₹ 4,310 Cr. |
| CIPLA | OPM last year | 24.4 % |
| CIPLA | NPM last year | 16.6 % |
| CIPLA | Operating profit | ₹ 6,291 Cr. |
| CIPLA | Interest | ₹ 89.9 Cr. |
| CIPLA | Depreciation | ₹ 1,051 Cr. |
| CIPLA | EPS last year | ₹ 51.0 |
| CIPLA | EBIT | ₹ 5,987 Cr. |
| CIPLA | Net profit | ₹ 4,154 Cr. |
| CIPLA | Current Tax | ₹ 1,697 Cr. |
| CIPLA | Tax | ₹ 1,547 Cr. |
| CIPLA | Other income | ₹ 552 Cr. |
| CIPLA | Ann Date | 2,02,403 |
| CIPLA | Sales Prev Ann | ₹ 22,753 Cr. |
| CIPLA | OP Prev Ann | ₹ 5,027 Cr. |
| CIPLA | Other Inc Prev Ann | ₹ 293 Cr. |
| CIPLA | EBIDT Prev Ann | ₹ 5,378 Cr. |
| CIPLA | Dep Prev Ann | ₹ 1,172 Cr. |
| CIPLA | EBIT preceding year | ₹ 4,206 Cr. |
| CIPLA | Interest Prev Ann | ₹ 110 Cr. |
| CIPLA | PBT Prev Ann | ₹ 4,038 Cr. |
| CIPLA | Tax preceding year | ₹ 1,203 Cr. |
| CIPLA | PAT Prev Ann | ₹ 2,842 Cr. |
| CIPLA | Extra Ord Prev Ann | ₹ -58.4 Cr. |
| CIPLA | NP Prev Ann | ₹ 2,833 Cr. |
| CIPLA | Dividend Prev Ann | ₹ 686 Cr. |
| CIPLA | OPM preceding year | 22.1 % |
| CIPLA | NPM preceding year | 12.6 % |
| CIPLA | EPS preceding year | ₹ 34.7 |
| CIPLA | Sales Prev 12M | ₹ 25,350 Cr. |
| CIPLA | Profit Prev 12M | ₹ 3,743 Cr. |
| CIPLA | Med Sales Gwth 10Yrs | 7.96 % |
| CIPLA | Med Sales Gwth 5Yrs | 11.8 % |
| CIPLA | Sales growth 7Years | 8.68 % |
| CIPLA | Sales Var 10Yrs | 9.74 % |
| CIPLA | EBIDT growth 3Years | 16.4 % |
| CIPLA | EBIDT growth 5Years | 15.8 % |
| CIPLA | EBIDT growth 7Years | 15.6 % |
| CIPLA | EBIDT Var 10Yrs | 11.3 % |
| CIPLA | EPS growth 3Years | 21.8 % |
| CIPLA | EPS growth 5Years | 25.4 % |
| CIPLA | EPS growth 7Years | 24.5 % |
| CIPLA | EPS growth 10Years | 11.8 % |
| CIPLA | Profit Var 7Yrs | 24.6 % |
| CIPLA | Profit Var 10Yrs | 11.8 % |
| CIPLA | Chg in Prom Hold 3Yr | -5.81 % |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | OP Qtr | ₹ 1,316 Cr. |
| CIPLA | Other Inc Qtr | ₹ 249 Cr. |
| CIPLA | EBIDT Qtr | ₹ 1,565 Cr. |
| CIPLA | Dep Qtr | ₹ 288 Cr. |
| CIPLA | EBIT latest quarter | ₹ 1,277 Cr. |
| CIPLA | Interest Qtr | ₹ 17.6 Cr. |
| CIPLA | PBT Qtr | ₹ 1,259 Cr. |
| CIPLA | Tax latest quarter | ₹ 325 Cr. |
| CIPLA | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| CIPLA | NP Qtr | ₹ 932 Cr. |
| CIPLA | GPM latest quarter | 66.7 % |
| CIPLA | OPM latest quarter | 21.4 % |
| CIPLA | NPM latest quarter | 15.1 % |
| CIPLA | Eq Cap Qtr | ₹ 161 Cr. |
| CIPLA | EPS latest quarter | ₹ 11.6 |
| CIPLA | OP 2Qtr Bk | ₹ 1,734 Cr. |
| CIPLA | OP 3Qtr Bk | ₹ 1,494 Cr. |
| CIPLA | Sales 2Qtr Bk | ₹ 6,678 Cr. |
| CIPLA | Sales 3Qtr Bk | ₹ 6,329 Cr. |
| CIPLA | NP 2Qtr Bk | ₹ 1,155 Cr. |
| CIPLA | NP 3Qtr Bk | ₹ 998 Cr. |
| CIPLA | Opert Prft Gwth | 25.2 % |
| CIPLA | Last result date | 2,02,403 |
| CIPLA | Exp Qtr Sales Var | 13.4 % |
| CIPLA | Exp Qtr Sales | ₹ 7,177 Cr. |
| CIPLA | Exp Qtr OP | ₹ 1,730 Cr. |
| CIPLA | Exp Qtr NP | ₹ 1,409 Cr. |
| CIPLA | Exp Qtr EPS | ₹ 17.4 |
| CIPLA | Sales Prev Qtr | ₹ 6,604 Cr. |
| CIPLA | OP Prev Qtr | ₹ 1,748 Cr. |
| CIPLA | Other Inc Prev Qtr | ₹ -10.2 Cr. |
| CIPLA | EBIDT Prev Qtr | ₹ 1,932 Cr. |
| CIPLA | Dep Prev Qtr | ₹ 233 Cr. |
| CIPLA | EBIT Prev Qtr | ₹ 1,699 Cr. |
| CIPLA | Interest Prev Qtr | ₹ 30.1 Cr. |
| CIPLA | PBT Prev Qtr | ₹ 1,474 Cr. |
| CIPLA | Tax Prev Qtr | ₹ 405 Cr. |
| CIPLA | PAT Prev Qtr | ₹ 1,195 Cr. |
| CIPLA | Extra Ord Prev Qtr | ₹ -195 Cr. |
| CIPLA | NP Prev Qtr | ₹ 1,068 Cr. |
| CIPLA | OPM Prev Qtr | 26.5 % |
| CIPLA | NPM Prev Qtr | 18.3 % |
| CIPLA | Eq Cap Prev Qtr | ₹ 161 Cr. |
| CIPLA | EPS Prev Qtr | ₹ 13.1 |
| CIPLA | Sales PY Qtr | ₹ 5,739 Cr. |
| CIPLA | OP PY Qtr | ₹ 1,174 Cr. |
| CIPLA | Other Inc PY Qtr | ₹ -47.8 Cr. |
| CIPLA | EBIDT PY Qtr | ₹ 1,308 Cr. |
| CIPLA | Dep PY Qtr | ₹ 346 Cr. |
| CIPLA | EBIT PY Qtr | ₹ 962 Cr. |
| CIPLA | Interest PY Qtr | ₹ 34.4 Cr. |
| CIPLA | PBT PY Qtr | ₹ 745 Cr. |
| CIPLA | Tax PY Qtr | ₹ 222 Cr. |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | Equity capital | ₹ 161 Cr. |
| CIPLA | Preference capital | ₹ 0.00 Cr. |
| CIPLA | Reserves | ₹ 26,545 Cr. |
| CIPLA | Secured loan | ₹ 429 Cr. |
| CIPLA | Unsecured loan | ₹ 374 Cr. |
| CIPLA | Balance sheet total | ₹ 32,718 Cr. |
| CIPLA | Gross block | ₹ 17,122 Cr. |
| CIPLA | Revaluation reserve | ₹ 0.00 Cr. |
| CIPLA | Accum Dep | ₹ 7,962 Cr. |
| CIPLA | Net block | ₹ 9,896 Cr. |
| CIPLA | CWIP | ₹ 864 Cr. |
| CIPLA | Investments | ₹ 5,449 Cr. |
| CIPLA | Current assets | ₹ 19,392 Cr. |
| CIPLA | Current liabilities | ₹ 5,246 Cr. |
| CIPLA | BV Unq Invest | ₹ 0.00 Cr. |
| CIPLA | MV Quoted Inv | ₹ 3,090 Cr. |
| CIPLA | Cont Liab | ₹ 567 Cr. |
| CIPLA | Total Assets | ₹ 32,718 Cr. |
| CIPLA | Working capital | ₹ 14,481 Cr. |
| CIPLA | Lease liabilities | ₹ 312 Cr. |
| CIPLA | Inventory | ₹ 5,238 Cr. |
| CIPLA | Trade receivables | ₹ 4,771 Cr. |
| CIPLA | Face value | ₹ 2.00 |
| CIPLA | Cash Equivalents | ₹ 875 Cr. |
| CIPLA | Adv Cust | ₹ 62.6 Cr. |
| CIPLA | Trade Payables | ₹ 2,474 Cr. |
| CIPLA | No. Eq. Shares PY | 80.7 |
| CIPLA | Debt preceding year | ₹ 803 Cr. |
| CIPLA | Work Cap PY | ₹ 9,200 Cr. |
| CIPLA | Net Block PY | ₹ 9,160 Cr. |
| CIPLA | Gross Block PY | ₹ 17,122 Cr. |
| CIPLA | CWIP PY | ₹ 1,093 Cr. |
| CIPLA | Work Cap 3Yr | ₹ 6,946 Cr. |
| CIPLA | Work Cap 5Yr | ₹ 7,015 Cr. |
| CIPLA | Work Cap 7Yr | ₹ 4,992 Cr. |
| CIPLA | Work Cap 10Yr | ₹ 3,687 Cr. |
| CIPLA | Debt 3Years back | ₹ 2,014 Cr. |
| CIPLA | Debt 5Years back | ₹ 4,316 Cr. |
| CIPLA | Debt 7Years back | ₹ 4,113 Cr. |
| CIPLA | Debt 10Years back | ₹ 1,248 Cr. |
| CIPLA | Net Block 3Yrs Back | ₹ 9,516 Cr. |
| CIPLA | Net Block 5Yrs Back | ₹ 9,608 Cr. |
| CIPLA | Net Block 7Yrs Back | ₹ 9,492 Cr. |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | CF Operations | ₹ 4,134 Cr. |
| CIPLA | Free Cash Flow | ₹ 2,819 Cr. |
| CIPLA | CF Investing | ₹ -2,988 Cr. |
| CIPLA | CF Financing | ₹ -1,200 Cr. |
| CIPLA | Net CF | ₹ -54.6 Cr. |
| CIPLA | Cash Beginning | ₹ 561 Cr. |
| CIPLA | Cash End | ₹ 875 Cr. |
| CIPLA | FCF Prev Ann | ₹ 2,102 Cr. |
| CIPLA | CF Operations PY | ₹ 3,238 Cr. |
| CIPLA | CF Investing PY | ₹ -2,376 Cr. |
| CIPLA | CF Financing PY | ₹ -958 Cr. |
| CIPLA | Net CF PY | ₹ -96.8 Cr. |
| CIPLA | Cash Beginning PY | ₹ 658 Cr. |
| CIPLA | Cash End PY | ₹ 1,565 Cr. |
| CIPLA | Free Cash Flow 3Yrs | ₹ 7,566 Cr. |
| CIPLA | Free Cash Flow 5Yrs | ₹ 12,612 Cr. |
| CIPLA | Free Cash Flow 7Yrs | ₹ 14,523 Cr. |
| CIPLA | Free Cash Flow 10Yrs | ₹ 17,043 Cr. |
| CIPLA | CF Opr 3Yrs | ₹ 10,697 Cr. |
| CIPLA | CF Opr 5Yrs | ₹ 17,521 Cr. |
| CIPLA | CF Opr 7Yrs | ₹ 20,675 Cr. |
| CIPLA | CF Opr 10Yrs | ₹ 25,971 Cr. |
| CIPLA | CF Inv 10Yrs | ₹ -18,790 Cr. |
| CIPLA | CF Inv 7Yrs | ₹ -12,004 Cr. |
| CIPLA | CF Inv 5Yrs | ₹ -9,483 Cr. |
| CIPLA | CF Inv 3Yrs | ₹ -7,223 Cr. |
| CIPLA | Cash 3Years back | ₹ 1,401 Cr. |
| CIPLA | Cash 5Years back | ₹ 619 Cr. |
| CIPLA | Cash 7Years back | ₹ 624 Cr. |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | No. Eq. Shares | 80.8 |
| CIPLA | Book value | ₹ 331 |
| CIPLA | Inven TO | 1.70 |
| CIPLA | Quick ratio | 2.70 |
| CIPLA | Exports percentage | 0.00 % |
| CIPLA | Piotroski score | 7.00 |
| CIPLA | G Factor | 4.00 |
| CIPLA | Asset Turnover | 0.83 |
| CIPLA | Financial leverage | 1.16 |
| CIPLA | No. of Share Holders | 4,63,569 |
| CIPLA | Unpledged Prom Hold | 30.9 % |
| CIPLA | ROIC | 17.9 % |
| CIPLA | Debtor days | 67.6 |
| CIPLA | Industry PBV | 3.93 |
| CIPLA | Credit rating |  |
| CIPLA | WC Days | 193 |
| CIPLA | Earning Power | 18.3 % |
| CIPLA | Graham Number | ₹ 616 |
| CIPLA | Cash Cycle | 182 |
| CIPLA | Days Payable | 102 |
| CIPLA | Days Receivable | 67.6 |
| CIPLA | Inventory Days | 217 |
| CIPLA | Public holding | 16.4 % |
| CIPLA | FII holding | 27.8 % |
| CIPLA | Chg in FII Hold | 2.00 % |
| CIPLA | DII holding | 24.7 % |
| CIPLA | Chg in DII Hold | 0.51 % |
| CIPLA | B.V. Prev Ann | ₹ 290 |
| CIPLA | ROCE Prev Yr | 18.0 % |
| CIPLA | ROA Prev Yr | 10.2 % |
| CIPLA | ROE Prev Ann | 12.8 % |
| CIPLA | No. of Share Holders Prev Qtr | 4,36,154 |
| CIPLA | No. Eq. Shares 10 Yrs | 80.3 |
| CIPLA | BV 3yrs back | ₹ 227 |
| CIPLA | BV 5yrs back | ₹ 196 |
| CIPLA | BV 10yrs back | ₹ 135 |
| CIPLA | Inven TO 3Yr | 1.69 |
| CIPLA | Inven TO 5Yr | 1.51 |
| CIPLA | Inven TO 7Yr | 1.52 |
| CIPLA | Inven TO 10Yr | 1.32 |
| CIPLA | Export 3Yr | 0.00 % |
| CIPLA | Export 5Yr | 58.1 % |
| CIPLA | Div 5Yrs | ₹ 573 Cr. |
| CIPLA | ROCE 3Yr | 19.5 % |
| CIPLA | ROCE 5Yr | 17.4 % |
| CIPLA | ROCE 7Yr | 15.4 % |
| CIPLA | ROCE 10Yr | 14.2 % |
| CIPLA | ROE 10Yr | 12.2 % |
| CIPLA | ROE 7Yr | 12.7 % |
| CIPLA | ROE 5Yr Var | 12.6 % |
| CIPLA | OPM 5Year | 21.9 % |
| CIPLA | OPM 10Year | 20.5 % |
| CIPLA | No. of Share Holders 1Yr | 4,66,515 |
| CIPLA | Avg Div Payout 3Yrs | 22.0 % |
| CIPLA | Debtor days 3yrs | 63.4 |
| CIPLA | Debtor days 3yrs back | 65.6 |
| CIPLA | Debtor days 5yrs back | 92.6 |
| CIPLA | ROA 5Yr | 9.98 % |
| CIPLA | ROA 3Yr | 11.4 % |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | Avg Vol 1Mth | 16,09,139 |
| CIPLA | Avg Vol 1Wk | 18,09,926 |
| CIPLA | Volume | 22,77,436 |
| CIPLA | High price | ₹ 1,592 |
| CIPLA | Low price | ₹ 1,132 |
| CIPLA | High price all time | ₹ 1,592 |
| CIPLA | Low price all time | ₹ 84.7 |
| CIPLA | Return over 1day | 5.81 % |
| CIPLA | Return over 1week | 0.98 % |
| CIPLA | Return over 1month | 1.42 % |
| CIPLA | DMA 50 | ₹ 1,487 |
| CIPLA | DMA 200 | ₹ 1,378 |
| CIPLA | DMA 50 previous day | ₹ 1,487 |
| CIPLA | 200 DMA prev. | ₹ 1,377 |
| CIPLA | RSI | 50.4 |
| CIPLA | MACD | 1.55 |
| CIPLA | MACD Previous Day | 1.75 |
| CIPLA | MACD Signal | 3.16 |
| CIPLA | MACD Signal Prev | 3.56 |
| CIPLA | Avg Vol 1Yr | 18,61,459 |
| CIPLA | Return over 7years | 14.9 % |
| CIPLA | Return over 10years | 13.0 % |
| CIPLA | Market Cap | ₹ 1,28,169 Cr. |
| CIPLA | Current Price | ₹ 1,587 |
| CIPLA | High / Low | ₹ 1,592 / 1,132 |
| CIPLA | Stock P/E | 30.1 |
| CIPLA | Book Value | ₹ 331 |
| CIPLA | Dividend Yield | 0.86 % |
| CIPLA | ROCE | 23.1 % |
| CIPLA | ROE | 17.0 % |
| CIPLA | Face Value | ₹ 2.00 |
| CIPLA | WC to Sales | 56.2 % |
| CIPLA | QoQ Profits | -12.8 % |
| CIPLA | QoQ Sales | -6.67 % |
| CIPLA | Net worth | ₹ 26,706 Cr. |
| CIPLA | Market Cap to Sales | 4.97 |
| CIPLA | Interest Coverage | 66.6 |
| CIPLA | EV / EBIT | 21.4 |
| CIPLA | Debt Capacity | 0.13 |
| CIPLA | Debt To Profit | 0.13 |
| CIPLA | Capital Employed | ₹ 25,241 Cr. |
| CIPLA | CROIC | 9.72 % |
| CIPLA | debtplus | 0.04 |
| CIPLA | Leverage | ₹ 1.16 |
| CIPLA | Dividend Payout | 25.5 % |
| CIPLA | Intrinsic Value | ₹ 809 |
| CIPLA | CDL | -0.20 % |
| CIPLA | Cash by market cap | 0.01 |
| CIPLA | 52w Index | 99.0 % |
| CIPLA | Down from 52w high | 0.28 % |
| CIPLA | Up from 52w low | 40.2 % |
| CIPLA | From 52w high | 1.00 |
| CIPLA | Mkt Cap To Debt Cap | 2.93 |
| CIPLA | Dividend Payout | 25.5 % |
| CIPLA | Graham | ₹ 616 |
| CIPLA | Price to Cash Flow | 31.0 |
| CIPLA | ROCE3yr avg | 19.5 % |
| CIPLA | PB X PE | 145 |
| CIPLA | NCAVPS | ₹ 179 |
| CIPLA | Mar Cap to CF | 31.0 |
| CIPLA | Altman Z Score | 9.33 |
| CIPLA | M.Cap / Qtr Profit | 138 |