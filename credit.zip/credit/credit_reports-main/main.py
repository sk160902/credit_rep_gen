import instructor
# from litellm import RouterConfig
from utils import KeyStrengths, llm_call_nomodel, run_search, parse_jina, PromotersList, llm_call, KeyIssues, BriefFinancials, IndustryRisks, search_web, CRISILModel, Peers
from utils import search_web_plain, bing_engine
import json

ticker = "VOLTAS"
report_data = {}
company_profiles_raw = {
    "introduction": [
        "Give me some introduction information on Meghmani Organics Ltd.",
        """
 It was founded in 1996 and rebranded as Polycab India Ltd in 2018. It was publicly listed in 2019.
 Polycab's registered office is in Gujarat, and it operates a significant network of manufacturing facilities across strategic locations in India.
 It has a vertically integrated business model that spans a large manufacturing and distribution network.
 Product variety include wide array of electrical products including wires, cables, electrical
appliances, switches, and other electrical accessories.
"""],
    "core_products_services": [
        "Give me some information on the core products and services of Meghmani Organics Ltd.", 
        """
1) Wires and Cables: This is Polycab's core products and constitutes 89% of the product mix.
It includes products like electrical cables, power cables, telecommunications cables and
specialty cables. Products are critical for power transmission and distribution across various
sectors such as infrastructure, power, telecom, and more.
2) Fast Moving Electrical Goods (FMEG): FMEG includes Electric Fans, lighting products, switches and switchgear and solar products and constitutes 9% of the product mix.
3) EPC Services: EPC involves designing, constructing, and commissioning projects related to power distribution and electrification and constitutes 2% of the product mix.
"""],
    "primary_revenue": [
        "Give me the primary revenue sources of Meghmani Organics Ltd.",
        """
1) Electric Wire and Cables: Majority of Polycab's revenue and makes about 91% as of FY-23 comes from the sale of wires and cables.
2) FMEG Segment: FMEG sector has been a growing revenue stream for Polycab and makes about 9% of revenue as of FY-23.
3) Institutional Sales and EPC Contracts: Revenue is also generated from institutional sales to large industrial, governmental, and corporate clients. The EPC division further adds to the revenue by securing contracts for comprehensive electrical solutions. Almost 3% of the revenue comes from this source as of FY-23.
4) Export Markets: Polycab has been progressively expanding its presence in international markets like the Middle East, Africa, and Southeast Asia.
"""
],
    "manufactering_facilities": [
        "What are the manufacturing facilities of Meghmani Organics Ltd.", """
 Halol Facility: One of the largest and most important facilities, specializing in the production of a wide range of cables and wires.
 Daman Facility: Situated in the Union Territory of Daman and produces wires & cables. It is strategically built near the major markets of Maharashtra and Gujarat.
 Nashik Facility: Focuses on the production of switchgears and other electrical components (FMEG).
 Roorkee Facility: Specializes in the manufacturing of fans and lighting products (FMEG).
 Chennai Facility: This facility focuses on the southern market, producing a range of electrical products tailored to meet regional demands.
"""
],
    "corporate_offices": [
        "where are the corporate and regional offices of Meghmani Organics Ltd.",
        """
 The corporate headquarters of Polycab is located in Mumbai.
 It has established regional offices across major cities in India including New Delhi, Kolkata, Bangalore and Hyderabad.
"""
],
    "research_dev" : [
    "Give me information about the research and development centres of Meghmani Organics Ltd.", 
    """
 Polycab places a strong emphasis on innovation and technological advancement. It operates R&D centers that are integrated within some of its manufacturing sites.
 They have a central quality and test laboratory in Halol, Gujarat and their focus on quality control. This lab is accredited by NABL and UL, signifying their commitment to meeting high quality standards.
 Four international research teams are employed for R&D of polymers required in cables used in niche sectors.
"""
]
}


# instructor.patch(
#     RouterConfig
# )                


report_data["company_profile"] = {}
for key in company_profiles_raw:
    company_profile_messages = [
        {"role": "system", "content": """
Input Details:
1. Company Profile
2. User Question

Answer Instructions:
1. ANSWER IN BULLET POINTS ONLY
2. TALK ABOUT COMPANY DETAILS AND THE INCORPORATION DETAILS
3. MAKE EACH POINT SLIGHLY DESCRIPTIVE

EXAMPLE OUTPUT : 
{company_profiles_raw[key][1]}
    """},
        {"role": "user", "content": f"Company Profile:\n{run_search(company_profiles_raw[key][0])}\nQuestion:\n{company_profiles_raw[key][0]}"}
    ]
    report_data["company_profile"][key] = llm_call_nomodel(company_profile_messages)


promoters_question = "What has been the trend in the overall promoters' shareholding percentage from September 2021 to March 2024?"
promoters = llm_call_nomodel(
    [
        {"role": "system", "content": "Return the output as an unordered list."},
        {"role": "user", "content": f"Context:\n{run_search(promoters_question)}\n\n\nQuestion:\n{promoters_question}"}
    ]
)

promoters_data = parse_jina(bing_engine(f"'{ticker}' board of directors"))

promoters_parsed_profiles = llm_call(
    messages=[
        {"role": "system", "content": "Task: What is the name, experience and qualifications of each of the promoters whose holdings have been mentioned"},
        {"role": "user", "content": f"Promoters Holdings:\n{promoters}\n-------\nPromoterProfiles:{promoters_data}"}
    ],
    model=PromotersList
)

report_data["promoters"] = json.loads(promoters_parsed_profiles.model_dump_json())



key_strengths_question = "What are the key strengths of Meghmani Organics Ltd.?"
report_data["key_strengths"] = json.loads(llm_call(
    messages=[
        {"role": "system", "content": "Task: Identify the KEY STRENGTHS of Meghmani Organics Ltd. as defined by the credit rating agency."},
        {"role": "user", "content": f"Context:\n{run_search(key_strengths_question)}\n\n\nQuestion:\n{key_strengths_question}"}
    ],
    model=KeyStrengths
).model_dump_json())

key_issues_question = "What are the key weaknesses of Meghmani Organics Ltd.? "
report_data["key_issues"] = json.loads(llm_call(
    messages=[
        {"role": "system", "content": "Task: Identify the KEY ISSUES OR WEAKNESSES of Meghmani Organics Ltd. as defined by the credit rating agency."},
        {"role": "user", "content": f"Context:\n{run_search(key_issues_question)}\n\n\nQuestion:\n{key_issues_question}"}
    ],
    model=KeyIssues
).model_dump_json())


query = "Give me the industry risks, trends for Agro Chemicals  and Pigments industry in India."
risks = llm_call(
    messages=[
        {"role": "system", "content": """
**Task**: Analyze the provided context and generate a detailed report on the industry risks associated with the specified market/domain mentioned in the query. The response should include quantitative data and projections to enhance the depth of the analysis.

**Instructions**:
1. **Context Understanding**: Thoroughly review the given web response content to understand the market/domain dynamics and current trends.
2. **Identify Risks**: Based on the query and the context provided, identify specific industry risks related to the market. Focus on aspects such as market competition, regulatory challenges, environmental impacts, and economic factors.
3. **Quantitative Analysis**:
    - Provide numerical values such as market size, growth rates (CAGR), or other relevant financial metrics to support the discussion of each risk.
    - Highlight any financial implications of these risks, such as potential costs, revenue impacts, or investment risks.
4. **Detailed Explanation**:
    - Elaborate on each identified risk, explaining how it affects the industry and the potential long-term consequences for businesses operating within it.
    - Discuss mitigation strategies or industry responses to these risks where applicable.

**Example Request**:
"Based on this query, 'Analyze the industry risks for the Indian footwear market', give me detailed insights into the risks associated with this market. Include numerical values and analysis based on the current market context provided."

**Example Response**:
"User: Provide a detailed risk analysis for the Indian footwear market.
Assistant: The Indian footwear market, valued at INR 900 billion in FY-24, is expected to grow at a CAGR of approximately 8% to reach INR 1,050 billion by FY-26. The sector has witnessed significant growth driven by urbanization and increasing disposable income. However, it faces several challenges:
- Intense competition from unorganized sectors and e-commerce disruptors.
- Environmental concerns due to the use of non-sustainable leather and chemicals in production, with potential regulatory impacts on material usage and disposal.
- Market entry and operational costs influenced by stringent regulatory standards, which may affect profitability.
These factors collectively contribute to the risk landscape of the Indian footwear industry, necessitating strategic planning and regulatory compliance to mitigate impacts."
"""},
        {"role": "user", "content": f"Context:\n{search_web(query)}\n\n\nQuestion:\n{query}"}
    ],
    model=IndustryRisks
)
report_data["industry_risks"] = json.loads(risks.model_dump_json())


# TODO: The brief financials section is not extracting data properly
brief_financials_question = "What are the values for Equity Capital and Profit Before Tax for Meghmani Organics Ltd.?"
brief_financials = llm_call(
    messages=[
        {"role": "system", "content": """
Task: You have been given financials of Meghmani Organics Ltd. and you need to answer the analyst's question **diligently and accurately**.

Answer Instructions:
0. DONOT INVENT ANY NEW DETAILS
1. FOLLOW FORMATTING INSTRUCTIONS
"""},
        {"role": "user", "content": f"Context:\n{run_search(brief_financials_question, n=5)}\n\n\nQuestion:\nExtract the relevant values without making shit up."}
    ],
    model=BriefFinancials
)
report_data["brief_financials"] = json.loads(brief_financials.model_dump_json())


peers_question = "Provide insights into the overall performance and market sentiment of the chemical sector based on the data provided in the table."
peers_list = llm_call(
    messages=[
        {"role": "system", "content": """
Task: You have been given a list of peer companies of Meghmani Organics Ltd. and you need to answer the analyst's question **diligently and accurately**.

Answer Instructions:
0. DONOT INVENT ANY NEW DETAILS
1. FOLLOW FORMATTING INSTRUCTIONS
"""},
        {"role": "user", "content": f"Context:\n{run_search(peers_question)}\n-------\nQuestion:\n{peers_question}"}
    ],
    model=Peers
).peer_names_list

ctx = ""
for i in peers_list:
    query_str = f"what is the crisil rating of {i} after:2024-02-21"
    ctx += f"{search_web_plain(query_str)}\n----------------\n"
    
    
    
peer_ratings = llm_call(
    model=CRISILModel,
    messages=[
        {
            "role": "system",
            "content": f"""
**Task**: Analyze the provided web search result and extract detailed information about CRISIL ratings for a specific company. The output should include the company's name, its long-term and short-term CRISIL ratings, and any relevant commentary or rationale provided in the text.

**Instructions**:
1. **Company Name Extraction**:
- Extract the company name mentioned in the context. Look for the company name preceding the phrase "ratings on" or similar context clues within the text.

2. **Ratings Extraction**:
- Identify the CRISIL ratings from the text. These ratings are typically formatted like 'CRISIL AA+/Stable/CRISIL A1+'. 
- Split this rating to distinguish between long-term and short-term ratings. The format is usually 'Long-term rating/Stability/Short-term rating'.

3. **Commentary Extraction**:
- Extract any commentary related to the ratings. This might begin with phrases like "Detailed Rationale" or "CRISIL Ratings has reaffirmed".
- Summarize this commentary to capture key insights about the rating decision, focusing on growth percentages, financial performance, or market challenges mentioned.

4. **Output Format**:
- Format your findings into a structured JSON object with fields for the company name, long-term rating, short-term rating, and a summary of the commentary.
- Ensure all extracted information is accurate and relevant to the query provided.
        """},
        {
            "role": "user",
            "content": f"User Request:\nGenerate the credit ratings table for all the peers of Meghmani Organics \n\n\nWeb Context:\n{ctx}"
        }
]
)

report_data["peer_ratings"] = json.loads(peer_ratings.model_dump_json())

if __name__ == "__main__":
    print(json.dumps(report_data))