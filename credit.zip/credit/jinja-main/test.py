import subprocess
def convert_tex_to_pdf(tex_file):
    try:
        # Run the pdflatex command
        subprocess.run(['pdflatex', tex_file], check=True)
        print("PDF generated successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred: {e}")
    except FileNotFoundError:
        print("pdflatex command not found. Please ensure it is installed and in your PATH.")
# Path to your .tex file
tex_file = 'credit_appraisal_output4.tex'
# Convert the .tex file to PDF
convert_tex_to_pdf(tex_file)