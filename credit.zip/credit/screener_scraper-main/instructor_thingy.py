import re
import json
from typing import Dict, Union, List
import pandas as pd

import numpy as np
from pydantic import BaseModel, Field, RootModel
import instructor
from litellm import completion


class DynamicDataModel(BaseModel):
    tables: List[Dict[str, List[Union[float, int, str, None]]]] = Field(...,description="table data constructed from json")


def format_data_with_instructor( data):
    oai_client = instructor.from_litellm(completion)
    res = oai_client.chat.completions.create(
        model="azure/gpt4o-dev",
        messages=[
            {
                "role": "system",
                "content": f"""
Prettify this json into below table model

class DynamicDataModel(BaseModel):
    tables: List[Dict[str, List[Union[float, int, str, None]]]] = Field(...,description="table data constructed from json")


**DATA**:

{data}
"""
            }
        ],
        response_model=DynamicDataModel,
        api_key="c0c736e92d0047ad94d66aea592c1e29",
        api_version="2024-02-01",
        api_base="https://harshith-gpt4o.openai.azure.com",
        temperature=0)
    print(res)
    return res

def post_llm_call( input, generated_content):

    res_data = format_data_with_instructor(generated_content)
    print("Data Here", res_data)

    cleaned_data = re.sub(r'```json|```|`+', ',', generated_content)
    cleaned_data = cleaned_data.strip(', \t\n\r')
    cleaned_data = cleaned_data.replace(',\n,', ',')
    print("TableGenLogs-1", cleaned_data)
    final_json = f'[{cleaned_data}]'
    print("TableGenLogs-2", final_json)

    try:
        data_list = json.loads(final_json)
        df_list = []

        # Check maximum length of arrays in each dictionary
        max_length = 0
        print("DataLIST", data_list)
        for data in data_list:
            print("DATA IN DATALIST", data)
            for key, value in data.items():
                if isinstance(value, list):  # Ensure it's a list before checking length
                    max_length = max(max_length, len(value))

        # Pad lists in each dictionary to have the same length
        for data in data_list:
            for key, value in data.items():
                if isinstance(value, list):
                    data[key] = value + [np.nan] * (max_length - len(value))  # Pad with NaNs

        # Now create DataFrames
        for data in data_list:
            df_list.append(pd.DataFrame(data))

        return df_list

    except json.JSONDecodeError as e:
        print("Error decoding JSON:", e)
        return []


data =  """
 ```json
{
  "Period": ["Q3 FY22", "Q1 FY25", "Q1", "FY2025", "Q2", "Full-year", "Various Quarters", "Trailing Twelve Months as of July 2024"],
  "INR Revenue Growth YoY": ["16.3%", null, null, "3.9%", null, "8.6%", null, null],
  "USD Revenue Growth YoY": ["14.4%", null, null, "3.0%", "4.8%", null, null, null],
  "Operating Margin": ["25.0%", null, null, null, null, null, "24.1% to 26.2%", "25.79%"],
  "Net Margin": ["20.0%", "19.2%", null, null, null, null, "18.7% to 21.0%", null],
  "Cash Flow from Operations as % of Net Profit": ["111.1%", "92.8%", null, null, null, null, null, null],
  "Net Income": [null, "$5.219 billion", "Rs 12,105 crore", null, null, null, null, null],
  "Earnings Per Share (EPS) Growth": [null, "10%", null, null, null, null, null, null],
  "Free Cash Flows": [null, "$1.23 billion", null, null, null, null, null, null],
  "Net Profit": [null, null, "9% rise to ₹12,040 crore", null, null, null, "9% YoY increase", null],
  "Revenue from Operations": [null, null, null, null, null, null, null, null],
  "Dividend Per Share": [null, null, "Rs 10", null, null, null, null, null],
  "USD Revenue": [null, null, "$7,444 million", "$7.51 billion", "$7.210 billion", "$27.927 billion", null, null],
  "Emerging Markets Revenue Growth YoY": [null, null, null, "61.8%", null, null, null, null],
  "Headcount Increase": [null, null, null, null, null, null, "22,600 new employees", null],
  "Attrition Rate": [null, null, null, null, null, null, null, "12.1%"]
}
```

```json
{
  "Financial Metric": ["Operating Margin", "Net Margin", "Cash Flow from Operations as % of Net Profit", "Net Income", "Earnings Per Share (EPS) Growth", "Free Cash Flows", "Net Profit", "Dividend Per Share", "USD Revenue", "Emerging Markets Revenue Growth YoY", "Headcount Increase", "Attrition Rate"],
  "Q3 FY22": ["25.0%", "20.0%", "111.1%", null, null, null, null, null, null, null, null, null],
  "Q1 FY25": [null, "19.2%", "92.8%", "$5.219 billion", "10%", "$1.23 billion", "9% rise to ₹12,040 crore", null, null, null, null, null],
  "Q1": [null, null, null, null, null, null, "Rs 12,105 crore", "Rs 10", "$7,444 million", null, null, null],
  "FY2025": [null, null, null, null, null, null, null, null, "$7.51 billion", "61.8%", null, null],
  "Q2": [null, null, null, null, null, null, null, null, "$7.210 billion", null, null, null],
  "Full-year": [null, null, null, null, null, null, null, null, "$27.927 billion", null, null, null],
  "Various Quarters": ["24.1% to 26.2%", "18.7% to 21.0%", null, null, null, null, "9% YoY increase", null, null, null, "22,600 new employees", null],
  "Trailing Twelve Months as of July 2024": ["25.79%", null, null, null, null, null, null, null, null, null, null, "12.1%"]
}
```
"""

output_data = format_data_with_instructor(data)

print(output_data)