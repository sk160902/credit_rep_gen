from elasticsearch import Elasticsearch
es = Elasticsearch(
    ["https://172.206.12.173:9200"],
    basic_auth=('elastic', 'onfielastic'),
   verify_certs=False
)
