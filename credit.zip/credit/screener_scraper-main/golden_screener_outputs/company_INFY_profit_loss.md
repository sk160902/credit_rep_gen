# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 40,352 | 50,133 | 53,319 | 62,441 | 68,484 | 70,522 | 82,675 | 90,791 | 100,472 | 121,641 | 146,767 | 153,670 | 155,053 |
| Expenses + | 28,814 | 36,743 | 38,436 | 45,362 | 49,880 | 51,700 | 62,505 | 68,524 | 72,583 | 90,150 | 111,637 | 117,245 | 118,255 |
| Operating Profit | 11,538 | 13,390 | 14,883 | 17,079 | 18,604 | 18,822 | 20,170 | 22,267 | 27,889 | 31,491 | 35,130 | 36,425 | 36,798 |
| OPM % | 29% | 27% | 28% | 27% | 27% | 27% | 24% | 25% | 28% | 26% | 24% | 24% | 24% |
| Other Income + | 2,365 | 2,664 | 3,430 | 3,120 | 3,050 | 3,311 | 2,882 | 2,803 | 2,201 | 2,295 | 2,701 | 4,711 | 4,988 |
| Interest | 5 | 9 | 12 | 0 | 0 | 0 | 0 | 170 | 195 | 200 | 284 | 470 | 484 |
| Depreciation | 1,099 | 1,317 | 1,017 | 1,459 | 1,703 | 1,863 | 2,011 | 2,893 | 3,267 | 3,476 | 4,225 | 4,678 | 4,654 |
| Profit before tax | 12,799 | 14,728 | 17,284 | 18,740 | 19,951 | 20,270 | 21,041 | 22,007 | 26,628 | 30,110 | 33,322 | 35,988 | 36,648 |
| Tax % | 26% | 28% | 28% | 28% | 28% | 21% | 27% | 24% | 27% | 26% | 28% | 27% |  |
| Net Profit + | 9,429 | 10,656 | 12,372 | 13,489 | 14,353 | 16,029 | 15,410 | 16,639 | 19,423 | 22,146 | 24,108 | 26,248 | 26,677 |
| EPS in Rs | 20.52 | 23.31 | 26.93 | 29.36 | 31.24 | 36.69 | 35.26 | 38.96 | 45.42 | 52.56 | 58.08 | 63.20 | 64.22 |
| Dividend Payout % | 25% | 34% | 55% | 41% | 41% | 59% | 60% | 45% | 59% | 59% | 58% | 73% |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 35% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 32% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Infosys Ltd. Parent Co. |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 68,017 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 13,818 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 18 |  |  |  |  |  |  |  |
| Infosys BPO Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 3,995 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 552 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 4 |  |  |  |  |  |  |  |
| Infosys Shanghai Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 765 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 27 |  |  |  |  |  |  |  |
| Infosys Poland Sp Z.o.o Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 439 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 102 |  |  |  |  |  |  |  |
| Infosys Public Services Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 387 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 126 |  |  |  |  |  |  |  |
| Infosys McCamish Systems LLC Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 127 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 75 |  |  |  |  |  |  |  |
| Kallidus Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 133 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 60 |  |  |  |  |  |  |  |
| Infosys Mexico Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 128 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 41 |  |  |  |  |  |  |  |
| Controlled Trusts Associate |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 122 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 19 |  |  |  |  |  |  |  |
| Infosys Lodestone Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 217 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 81 |  |  |  |  |  |  |  |
| Portland Group Pty Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 106 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 6 |  |  |  |  |  |  |  |
| Infosys Brasil Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 103 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 2 |  |  |  |  |  |  |  |
| Infosys Nova Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 98 |  |  |  |  |  |  |  |
| Skava Systems Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 73 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 8 |  |  |  |  |  |  |  |
| Panaya Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 68 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 4 |  |  |  |  |  |  |  |
| Infosys (Czech Republic) Limited s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 58 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 12 |  |  |  |  |  |  |  |
| Infosys Consulting AG Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 64 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 5 |  |  |  |  |  |  |  |
| Infosys China Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 105 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 58 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Inc. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 28 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 11 |  |  |  |  |  |  |  |
| Inly Consulting B V Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 25 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 12 |  |  |  |  |  |  |  |
| Infosys Australia Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 36 |  |  |  |  |  |  |  |
| S.C. Infosys Consulting S R. L. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 6 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Infosys Consulting s.r.o. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 4 |  |  |  |  |  |  |  |
| Infy Consulting Company Lid. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Infosys Americas Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Infosys BPO Americas Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 4 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Sweden Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 17 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 18 |  |  |  |  |  |  |  |
| PanayaJapan Co. Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Lodestone Management Consultants GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 2 |  |  |  |  |  |  |  |
| Panaya Gmbh Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting SAS Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Net Assets |  |  | 6 |  |  |  |  |  |  |  |
| Infosys Consulting p. Z.o.o Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 5 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Portugal. Unipessoal, Lda. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting S.R.L. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 1 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 3 |  |  |  |  |  |  |  |
| Infosys Consulting Pte Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 2 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 11 |  |  |  |  |  |  |  |
| Noah Canada Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 2 |  |  |  |  |  |  |  |
| Net Assets |  |  | 14 |  |  |  |  |  |  |  |
| Infosys Management Consulting Pty Limited Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 20 |  |  |  |  |  |  |  |
| Infosys Consulting (Belgium) NV Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 22 |  |  |  |  |  |  |  |
| DWA Nova LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 26 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 30 |  |  |  |  |  |  |  |
| Infosys Consulting Ltda. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 20 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 60 |  |  |  |  |  |  |  |
| Infosys Consulting GmbH Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 30 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 65 |  |  |  |  |  |  |  |
| Noah Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Net Assets |  |  | 23 |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 90 |  |  |  |  |  |  |  |
| Lodestone Management Consultants Co., Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 56 |  |  |  |  |  |  |  |
| Net Assets |  |  | 58 |  |  |  |  |  |  |  |
| Panaya Ltd. Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 161 |  |  |  |  |  |  |  |
| Net Assets |  |  | 283 |  |  |  |  |  |  |  |
| Edge Verve Subsidiary |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 245 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 1 |  |  |  |  |  |  |  |
| Net Assets |  |  | 1,715 |  |  |  |  |  |  |  |
| Adjustment arising out of consolidation |  |  |  |  |  |  |  |  |  |  |
| Share in profit or loss |  |  | 78 |  |  |  |  |  |  |  |
| Share in other comprehensive income |  |  | 257 |  |  |  |  |  |  |  |
| Net Assets |  |  | 3,869 |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 40,352 | 50,133 | 53,319 | 62,441 | 68,484 | 70,522 | 82,675 | 90,791 | 100,472 | 121,641 | 146,767 | 153,670 | 155,053 |
| Expenses + | 28,814 | 36,743 | 38,436 | 45,362 | 49,880 | 51,700 | 62,505 | 68,524 | 72,583 | 90,150 | 111,637 | 117,245 | 118,255 |
| Operating Profit | 11,538 | 13,390 | 14,883 | 17,079 | 18,604 | 18,822 | 20,170 | 22,267 | 27,889 | 31,491 | 35,130 | 36,425 | 36,798 |
| OPM % | 29% | 27% | 28% | 27% | 27% | 27% | 24% | 25% | 28% | 26% | 24% | 24% | 24% |
| Other Income + | 2,365 | 2,664 | 3,430 | 3,120 | 3,050 | 3,311 | 2,882 | 2,803 | 2,201 | 2,295 | 2,701 | 4,711 | 4,988 |
| Interest | 5 | 9 | 12 | 0 | 0 | 0 | 0 | 170 | 195 | 200 | 284 | 470 | 484 |
| Depreciation | 1,099 | 1,317 | 1,017 | 1,459 | 1,703 | 1,863 | 2,011 | 2,893 | 3,267 | 3,476 | 4,225 | 4,678 | 4,654 |
| Profit before tax | 12,799 | 14,728 | 17,284 | 18,740 | 19,951 | 20,270 | 21,041 | 22,007 | 26,628 | 30,110 | 33,322 | 35,988 | 36,648 |
| Tax % | 26% | 28% | 28% | 28% | 28% | 21% | 27% | 24% | 27% | 26% | 28% | 27% |  |
| Net Profit + | 9,429 | 10,656 | 12,372 | 13,489 | 14,353 | 16,029 | 15,410 | 16,639 | 19,423 | 22,146 | 24,108 | 26,248 | 26,677 |
| EPS in Rs | 20.52 | 23.31 | 26.93 | 29.36 | 31.24 | 36.69 | 35.26 | 38.96 | 45.42 | 52.56 | 58.08 | 63.20 | 64.22 |
| Dividend Payout % | 25% | 34% | 55% | 41% | 41% | 59% | 60% | 45% | 59% | 59% | 58% | 73% |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 35% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 32% |  |  |  |  |  |  |  |  |  |  |  |  |

