# Complete Company Data

## Modal Content
About
[
edit
]
Reliance was founded by Dhirubhai Ambani and is now promoted and managed by his elder son, Mukesh Dhirubhai Ambani. Ambani's family has about 50% shareholding in the conglomerate.
Key Points
[
edit
]
OIL-TO-CHEMICALS SEGMENT (~57% of revenues)
[1]
Under the segment, the company primarily refines crude oil to manufacture/ extract transportation fuels, polymers and elastomers, intermediates and polyesters. It has plants and manufacturing assets located across India in Jamnagar, Hazira, Dahej, Nagothane, Vadodara and others.
It has a crude refining capacity of 1.4 million barrels per day. It also has the largest single site refinery complex globally.
[2]
It had a total throughput of ~77 million metric tonnes in FY22 out of which ~89% was meant for sale.
[3]
RETAIL SEGMENT (~23% of revenues)
The company is the largest retailer in India with various store concepts selling consumer electronics, fashion & lifestyle, groceries, pharma and connectivity. It operates ~15,200 retail stores and has a customer base of ~19 crore customers.
[4]
Its store brands include Reliance fresh, digital, smart, Hamleys, Jio Outlets, netmeds, resQ, etc. It also operates various digital commerce platforms including JioMart, milkbasket, Reliance Digital, Ajio, zivame, urban ladder, netmeds and others.
[5]
Some of its acquisitions under the segment include Justdial, 7-Eleven, milkbasket, Manish Malhotra, Clovia, Dunzo, etc.
[5]
Expansion -
Reliance Retail undertook significant expansion in FY22 adding on avg. 7 stores every day and crossed the milestone of 15,000 stores.
[6]
DIGITAL SERVICES BUSINESS (Jio) (~11% of revenues)
Jio Digital is India's largest digital services platform with a total subscriber base of ~41 crore subscribers
[7]
and a market share of 36% in India. It offers wireless connectivity, home broadband and enterprise and SMB broadband under its digital connectivity business.
[8]
It carried ~10% of the global mobile data traffic in 2021.
[9]
Broadband Expansion -
The company became the largest broadband provider in India with a market share of 50% within just 2 years of launch.
[9]
[10]
Shareholders of Jio -
The company holds ~67% stake in Jio Platforms while the rest was sold by Reliance to major multinational corporates such as Meta (Facebook), Google, KKR, Vista Equity and others.
[11]
OIL & GAS E&P BUSINESS(~1% of revenues)
RIL as an integrated E&P Operator is India’s leading Deepwater Operator. Its domestic portfolio comprises of conventional oil and gas blocks in Krishna Godavari and Mahanadi basins and two Coal Bed Methane (CBM) blocks, Sohagpur (East) and Sohagpur (West) in Madhya Pradesh.
[12]
The business saw a significant increase in gas production due to ramp-up of production from KGD6 block located in the Krishna-Godawari Basin.
[13]
It went from producing 2% of India's total gas in Q3FY21 to ~20% in FY22.
[14]
Media & Entertainment Business
The company owns Network 18 Media  which has presence across full spectrum of content genres such as news, entertainment, sports, movies and live entertainment. Its portfolio includes CNBC TV, Colors, MTV, nick, History tv and others. It also owns digital platforms such as moneycontrol, News 18, CNBC, firstpost, voot and bookmyshow.
[15]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 395,957 | 433,521 | 374,372 | 272,583 | 303,954 | 390,823 | 568,337 | 596,679 | 466,307 | 694,673 | 876,396 | 901,064 | 925,289 |
| Expenses + | 362,802 | 398,586 | 336,923 | 230,802 | 257,647 | 326,508 | 484,087 | 507,413 | 385,517 | 586,092 | 734,078 | 738,831 | 762,384 |
| Operating Profit | 33,155 | 34,935 | 37,449 | 41,781 | 46,307 | 64,315 | 84,250 | 89,266 | 80,790 | 108,581 | 142,318 | 162,233 | 162,905 |
| OPM % | 8% | 8% | 10% | 15% | 15% | 16% | 15% | 15% | 17% | 16% | 16% | 18% | 18% |
| Other Income + | 7,757 | 8,865 | 8,528 | 12,212 | 9,222 | 9,869 | 8,406 | 8,570 | 22,432 | 19,600 | 12,020 | 16,057 | 16,438 |
| Interest | 3,463 | 3,836 | 3,316 | 3,691 | 3,849 | 8,052 | 16,495 | 22,027 | 21,189 | 14,584 | 19,571 | 23,118 | 23,199 |
| Depreciation | 11,232 | 11,201 | 11,547 | 11,565 | 11,646 | 16,706 | 20,934 | 22,203 | 26,572 | 29,782 | 40,303 | 50,832 | 52,653 |
| Profit before tax | 26,217 | 28,763 | 31,114 | 38,737 | 40,034 | 49,426 | 55,227 | 53,606 | 55,461 | 83,815 | 94,464 | 104,340 | 103,491 |
| Tax % | 20% | 22% | 24% | 23% | 25% | 27% | 28% | 26% | 3% | 19% | 22% | 25% |  |
| Net Profit + | 20,886 | 22,548 | 23,640 | 29,861 | 29,833 | 36,080 | 39,837 | 39,880 | 53,739 | 67,845 | 74,088 | 79,020 | 78,207 |
| EPS in Rs | 30.31 | 32.62 | 34.14 | 43.03 | 43.11 | 53.39 | 58.55 | 58.20 | 77.50 | 89.74 | 98.59 | 102.90 | 101.61 |
| Dividend Payout % | 13% | 12% | 12% | 10% | 11% | 10% | 10% | 10% | 9% | 9% | 9% | 10% |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Jamnagar Utilities & Power Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electric Power, Fuel and Water |  |  |  | 4,656 | 5,140 | 4,898 |  | 4,503 | 4,657 |
| Revenue from Operations |  |  |  | 200 | 279 | 126 |  | 258 | 350 |
| Deposits |  |  |  |  | 118 | 118 |  | 118 | 118 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 116 | 18 | 38 |  | 80 | 1 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 25 | 62 |
| Other Income |  |  |  | 3 |  | 2 |  | 1 | 1 |
| Purchases / Material Consumed |  |  |  |  | 6 |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 2 |
| Purchases/ Material Consumed |  |  |  | 1 |  |  |  |  |  |
| Reliance Ports and Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales and Distribution Expenses |  | 2,576 | 2,567 |  |  |  |  |  |  |
| Sales & Distribution Expenses | 2,751 |  |  |  |  |  |  |  |  |
| Deposits | 1,050 | 353 | 353 |  |  |  |  |  |  |
| Purchases/ Material Consumed |  | 611 | 623 |  |  |  |  |  |  |
| Hire Charges | 301 | 220 | 387 |  |  |  |  |  |  |
| Purchases / Material Consumed | 241 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  | 166 | 41 |  |  |  |  |  |  |
| Purchase of Fixed Assets | 198 |  |  |  |  |  |  |  |  |
| Revenue from Operations | 2 | 5 | 15 |  |  |  |  |  |  |
| General Expenses | 3 | 12 | 7 |  |  |  |  |  |  |
| Other Income | 1 | 1 | 1 |  |  |  |  |  |  |
| Sikka Ports and Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales and Distribution Expenses |  |  |  | 2,499 | 2,003 | 2,118 |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 1,259 | 1,395 |  |  |  |
| Deposits |  |  |  |  | 353 | 353 |  |  |  |
| Purchases/ Material Consumed |  |  |  | 589 |  |  |  |  |  |
| Hire Charges |  |  |  | 334 | 87 | 97 |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 22 | 216 | 163 |  |  |  |
| Revenue from Operations |  |  |  | 3 | 22 | 19 |  |  |  |
| General Expenses |  |  |  | 12 | 13 | 12 |  |  |  |
| Other Income |  |  |  | 1 |  |  |  |  |  |
| Sikka Ports & Terminals Limited Associate |  |  |  |  |  |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 2,039 | 2,266 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1,417 | 1,571 |
| Deposits |  |  |  |  |  |  |  | 353 | 353 |
| Revenue from Operations |  |  |  |  |  |  |  | 227 | 16 |
| Other Income |  |  |  |  |  |  |  | 1 | 226 |
| Labour Processing and Hire Charges |  |  |  |  |  |  |  | 101 | 54 |
| General Expenses |  |  |  |  |  |  |  | 8 | 9 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 2 | 1 |
| Reliance Utilities and Power Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Electric Power, Fuel and Water | 1,579 | 1,719 | 2,484 |  |  |  |  |  |  |
| Revenue from Operations | 363 | 236 | 286 |  |  |  |  |  |  |
| Deposits | 350 | 118 | 118 |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  | 68 | 192 |  |  |  |  |  |  |
| Purchase of Fixed Assets | 10 |  |  |  |  |  |  |  |  |
| Other Income | 3 | 3 | 3 |  |  |  |  |  |  |
| Capital Advance Returned | 5 |  |  |  |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 4 |  |  |  |  |  |  |
| Reliance Europe Limited Associate |  |  |  |  |  |  |  |  |  |
| Financial Guarantees |  | 1,837 | 1,532 |  | 1,419 | 1,447 |  |  |  |
| Professional Fees | 25 | 34 | 30 | 39 | 29 | 23 |  | 11 | 11 |
| Unsecured Loans |  |  |  |  |  |  |  | 80 | 80 |
| Other Income | 13 | 13 | 17 | 15 | 15 | 16 |  |  |  |
| Finance Costs |  | 1 | 1 | 2 | 2 | 2 |  | 1 | 3 |
| General Expenses | 7 |  |  |  |  | 3 |  |  |  |
| Rent |  |  |  |  |  |  |  |  | 5 |
| Loans and Advances |  | 3 |  |  |  |  |  |  |  |
| Loans & Advances | 3 |  |  |  |  |  |  |  |  |
| Finance Cost | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  |  | 3 |  |  |  |  |  |  |
| Alok Industries Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 3,083 | 3,086 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 92 | 426 |
| Other Income |  |  |  |  |  |  |  |  | 13 |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 6 | 1 |
| General Expenses |  |  |  |  |  |  |  | 1 | 1 |
| East West Pipeline Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales / Transfer / Redemption of Investments |  |  |  |  | 3,768 |  |  |  |  |
| Hire Charges |  |  |  | 475 | 759 |  |  |  |  |
| Other Income |  |  |  | 218 | 229 |  |  |  |  |
| Revenue from Operations |  |  |  | 37 | 34 |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 5 |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 1 |  |  |  |  |
| Reliance Foundation |  |  |  |  |  |  |  |  |  |
| Donations | 737 | 592 | 575 | 698 | 341 | 225 |  | 870 | 912 |
| Revenue from Operations |  | 4 | 1 | 5 | 17 | 11 |  | 37 | 5 |
| General Expenses |  |  |  |  |  |  |  | 5 |  |
| India Gas Solutions Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1,094 | 1,083 |
| Revenue from Operations |  | 5 | 2 | 2 | 3 | 1 |  | 847 | 1,169 |
| Other Income |  |  |  |  |  |  |  |  | 249 |
| Professional Fees |  | 8 | 3 |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 6 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  |  | 5 |
| Sintex Industries Limited JV |  |  |  |  |  |  |  |  |  |
| Financial Guarantees |  |  |  |  |  |  |  |  | 1,900 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1,500 |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| Sanmina-SCI India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1,763 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  |  | 299 |
| Reliance Employees Provident Fund Bombay |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 207 | 222 | 287 | 314 | 320 |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 279 | 299 |
| Reliance Commercial Dealers Limited Associate |  |  |  |  |  |  |  |  |  |
| General Expenses | 282 | 418 | 139 |  |  |  |  |  |  |
| Deposits | 155 | 175 |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 170 |  |  |  |  |  |  |  |
| Loans and Advances |  | 150 |  |  |  |  |  |  |  |
| Revenue from Operations | 16 | 13 | 9 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/ (Returned | 23 |  |  |  |  |  |  |  |  |
| EFS Midstream LLC Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 1,334 |  |  |  |  |  |  |  |
| Gujarat Chemical Port Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 160 | 162 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 142 | 157 |
| Deposits |  |  |  |  | 112 | 71 |  | 49 | 33 |
| Sales and Distribution Expenses |  |  |  |  | 63 | 65 |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 66 | 57 |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 25 | 41 |  |  |  |
| Other Income |  |  |  |  | 1 | 10 |  | 15 | 15 |
| Revenue from Operations |  |  |  |  | 2 | 4 |  | 11 | 4 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  | 1 |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 | 16 |
| GTPL Hathway Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 3 | 92 |  | 126 | 172 |
| Purchase / Subscription of Investments |  |  |  |  | 391 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 105 | 147 |
| Sales and Distribution Expenses |  |  |  |  |  | 49 |  |  |  |
| Other Income |  |  |  |  |  | 1 |  |  | 18 |
| Loans and Advances |  |  |  |  |  |  |  | 1 | 1 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 |  |
| Programming and Telecast Related Expense |  |  |  |  | 1 |  |  |  |  |
| Gujarat Chemical Port Terminal Company Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 111 | 138 | 147 |  |  |  |  |  |  |
| Hire Charges | 90 | 117 | 2 |  |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 90 | 109 |  |  |  |  |  |
| Sales and Distribution Expenses |  | 33 | 52 | 86 |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 22 | 9 |  |  |  |  |  |  |
| Other Income | 10 |  | 6 | 10 |  |  |  |  |  |
| Sales & Distribution Expenses | 16 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given | 12 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  | 10 |  |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 8 |  |  |  |  |  |
| Loans & Advances | 6 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  |  | 4 |  |  |  |  |  |  |
| Revenue from Operations |  |  | 1 | 2 |  |  |  |  |  |
| Purchases / Material Consumed | 3 |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 2 |  |  |  |  |  |  |  |  |
| Reliance Foundation Institution of Education and Research |  |  |  |  |  |  |  |  |  |
| Donations |  |  |  | 1 | 476 | 229 |  | 142 | 207 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 2 |
| R P Chemicals (Malaysia) Sdn. Bhd. Associate |  |  |  |  |  |  |  |  |  |
| Purchases / Material Consumed | 1,052 |  |  |  |  |  |  |  |  |
| Reliance Gas Transportation Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Hire Charges | 194 | 214 | 203 |  |  |  |  |  |  |
| Other Income | 14 |  | 204 |  |  |  |  |  |  |
| Revenue from Operations | 50 | 60 | 32 |  |  |  |  |  |  |
| Purchases / Material Consumed | 3 |  |  |  |  |  |  |  |  |
| RP Chemicals (Malaysia ) Sdn. Bhd. Associate |  |  |  |  |  |  |  |  |  |
| Purchases/ Material Consumed |  | 745 |  |  |  |  |  |  |  |
| Reliance Industrial Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Hire Charges | 37 | 34 | 45 | 40 | 23 | 22 |  |  |  |
| Professional Fees | 17 | 24 | 25 | 26 | 27 | 17 |  |  |  |
| Rent | 8 | 9 | 15 | 11 | 10 | 11 |  | 16 | 17 |
| Purchases / Material Consumed | 19 |  |  |  | 21 | 21 |  |  |  |
| Purchases/ Material Consumed |  | 20 | 13 | 21 |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 22 | 21 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  | 5 | 20 | 8 |  |  |  |
| Labour Processing and Hire Charges |  |  |  |  |  |  |  | 12 | 15 |
| Electric Power, Fuel and Water |  |  |  |  |  |  |  | 14 | 12 |
| Other Income |  |  |  | 2 | 2 | 2 |  | 2 | 2 |
| Revenue from Operations |  | 1 | 3 | 2 | 1 |  |  | 1 | 1 |
| Purchase of Fixed Assets | 8 |  |  |  |  |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 4 | 3 |
| Purchase of Tangible and Intangible Assets |  | 3 | 2 |  |  |  |  |  |  |
| Capital Advance Returned | 3 |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 2 |  |
| Reliance Services and Holdings Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 703 |
| Loans and Advances |  |  |  |  |  | 7 |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 2 |  |  |  |
| Neolync Solutions Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 555 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 20 | 20 |
| Football Sports Development Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 |  | 4 | 9 | 3 |  | 29 | 69 |
| Purchase / Subscription of Investments |  |  | 42 |  |  | 51 |  |  |  |
| Net Loans and Advances, Deposits Given |  |  |  | 42 | 51 |  |  |  |  |
| Loans and Advances |  |  |  |  | 93 |  |  |  |  |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 55 | 22 |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 42 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 42 |  |  |  |  |  |
| Other Income |  |  |  | 2 | 4 |  |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  | 5 |  |  |  |  |
| I P C L Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 98 | 103 | 110 | 109 | 124 |  |  |  |
| Big Tree Entertainment Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 191 |  | 278 |  |  |  |  |
| Revenue from Operations |  |  | 1 |  |  |  |  | 1 | 12 |
| Programming and Telecast Related Expense |  |  |  |  | 7 | 1 |  |  |  |
| Professional Fees |  | 2 | 1 | 1 | 1 | 1 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 3 |
| General Expenses |  |  | 1 |  |  |  |  |  | 1 |
| Sales and Distribution Expenses |  |  |  |  | 1 |  |  |  |  |
| Ashwani Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 65 |  |  |  | 63 | 63 |  | 57 | 54 |
| Purchase / Subscription of Investments |  |  |  |  | 136 |  |  |  |  |
| Rent |  |  |  | 2 | 2 | 2 |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 3 |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Net Loans and Advances, Deposits Given/ (Returned | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 4 | 3 |
| Jamnaben Hirachand Ambani Foundation |  |  |  |  |  |  |  |  |  |
| Donations | 4 | 15 | 19 | 6 | 40 | 66 |  | 101 | 155 |
| Other Income |  |  |  |  | 3 | 3 |  | 4 | 5 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Reliance Retail Limited Employees Provident Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 151 | 269 |
| Honeywell Properties Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 50 | 50 | 50 |  | 50 | 50 |  | 45 | 51 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 5 | 6 |
| The Indian Film Combine Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 340 |  |  |  |  |  |
| Jio Payments Bank Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 92 |  | 70 |  |  | 22 | 80 |
| Revenue from Operations |  |  |  | 1 | 3 | 5 |  | 7 | 7 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 4 | 6 |
| General Expenses |  |  |  |  | 1 | 1 |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 1 |
| Marks and Spencer Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 20 |  | 47 | 81 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 26 | 84 |
| Purchase / Subscription of Investments |  | 15 |  |  |  |  |  |  |  |
| Purchases / Material Consumed |  |  |  |  | 2 | 5 |  |  |  |
| Purchases/ Material Consumed |  |  | 2 | 2 |  |  |  |  |  |
| Einsten Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 43 | 43 | 43 |  | 36 | 36 |  | 36 | 36 |
| Net Loans and Advances, Deposits Returned |  |  |  |  |  | 1 |  |  |  |
| Genesis Luxury Fashion Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 269 |  |  |  |  |  |
| Carin Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 77 |  |  |  | 77 | 77 |  | 77 | 9 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 68 |
| IPCL Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 126 | 121 |
| Chander Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 33 | 34 | 34 |  | 35 | 35 |  | 32 | 36 |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 1 | 1 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 3 | 4 |
| Extramarks Education Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 100 | 125 |  |  |  |  |  |  |
| Other Income | 9 | 5 |  |  |  |  |  |  |  |
| GTPL Kolkata Cable & Broad Band Pariseva Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 60 | 71 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 46 | 57 |
| Shree Salasar Bricks Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 33 | 33 | 33 |  | 33 | 33 |  | 33 | 33 |
| Kaniska Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 23 | 23 | 23 |  | 27 | 30 |  | 40 | 41 |
| Net Loans and Advances, Deposits Given | 1 |  |  | 3 |  | 3 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 3 | 1 |
| Reliance Industries Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 31 |  | 16 | 63 | 100 |  |  |  |
| Reliance Foundation Youth Sports |  |  |  |  |  |  |  |  |  |
| Donations |  |  | 22 | 38 | 41 | 47 |  | 22 | 34 |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Rocky Farms Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 29 | 29 | 29 |  | 29 | 29 |  | 29 | 29 |
| Dunzo Digital Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 200 |
| Shri Nikhil R. Meswani Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 21 | 24 |  | 24 | 25 |
| PaymentToKeyManagementPersonnel/Relative |  | 14 | 17 |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 21 |  |
| Payment To |  |  |  | 20 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 12 |  |  |  |  |  |  |  |  |
| Shri Hital R. Meswani Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 21 | 24 |  | 24 | 25 |
| PaymentToKeyManagementPersonnel/Relative |  | 14 | 17 |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 20 |  |
| Payment To |  |  |  | 20 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 12 |  |  |  |  |  |  |  |  |
| Iconix Lifestyle India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 89 |  |
| General Expenses |  |  |  |  |  |  |  | 16 | 20 |
| Revenue from Operations |  | 2 | 2 | 3 | 3 | 3 |  | 3 | 5 |
| Other Income |  |  |  |  |  | 11 |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  |  | 3 |
| Den Satellite Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 | 19 |  | 21 | 24 |
| Purchase / Subscription of Investments |  |  |  |  | 64 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 8 | 3 |
| General Expenses |  |  |  |  |  | 5 |  |  | 5 |
| Sales and Distribution Expenses |  |  |  |  |  | 5 |  |  |  |
| Cairn Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 77 | 77 |  |  |  |  |  |  |
| IMG Reliance Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 65 | 7 |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 3 | 10 | 18 |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  | 9 | 18 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 9 |  |  |  |  |  |
| Sales and Distribution Expenses |  |  | 1 | 2 |  | 1 |  |  |  |
| Professional Fees |  |  |  |  |  | 2 |  |  |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Prakhar Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 48 |  |  |  | 29 | 30 |  | 29 | 10 |
| Net Loans and Advances, Deposits Returned |  |  |  |  | 19 |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 | 19 |
| Shri Mukesh D. Ambani Key Person |  |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 52 |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 15 | 15 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 15 | 15 |  |  |  |  |  |  |
| Payment To |  |  |  | 15 |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 15 |  |  |  |  |  |  |  |  |
| Eenadu Television Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 |  | 1 | 2 | 10 |  | 10 | 19 |
| Programming and Telecast Related Expense |  |  |  |  | 14 | 26 |  |  |  |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 16 | 20 |
| General Expenses | 7 | 2 | 2 | 2 |  | 1 |  |  | 1 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  | 4 |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 |  |
| Atri Exports Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 19 | 19 | 19 |  | 19 | 19 |  | 19 | 19 |
| Ashwani Commericals Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 65 | 65 |  |  |  |  |  |  |
| Gaurav Overseas Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 17 | 17 | 17 |  | 17 | 17 |  | 17 | 17 |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 1 |
| Viacom18 Media Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 33 | 28 | 30 |  |  |  |  |  |
| General Expenses |  | 13 | 7 |  |  |  |  |  |  |
| Parinita Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 28 | 28 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 22 |  |
| Creative Agrotech Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 15 | 15 | 15 |  | 15 | 15 |  | 15 | 16 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| IndiaCast Media Distribution Private Limited JV |  |  |  |  |  |  |  |  |  |
| General Expenses |  | 48 | 50 |  |  |  |  |  |  |
| Revenue from Operations |  | 5 | 4 |  |  |  |  |  |  |
| Sir HN Hospital Trust |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 42 | 53 |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 4 |
| Other Income |  |  |  |  |  |  |  | 1 | 1 |
| General Expenses |  |  |  |  |  |  |  | 1 |  |
| Diesel Fashion India Reliance Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 3 | 6 | 6 | 6 | 6 |  | 10 | 12 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 11 | 14 |
| Purchase / Subscription of Investments |  | 3 | 1 |  | 6 | 5 |  |  | 4 |
| Purchase/Subscription of Investments |  |  |  | 5 |  |  |  |  |  |
| Purchases/ Material Consumed |  |  | 1 | 1 |  |  |  |  |  |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Purchases / Material Consumed |  |  |  |  | 1 |  |  |  |  |
| Clarks Reliance Footwear Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 51 | 2 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 4 | 25 |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 15 |
| Other Income |  |  |  |  |  |  |  | 1 | 1 |
| Algenol LLC Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 25 | 73 |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  |  |  | 1 |  |  |  |  |  |
| Shri Srikanth Venkatachari Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 14 | 14 |  | 15 | 17 |
| PaymentToKeyManagementPersonnel/Relative |  | 11 | 11 |  |  |  |  |  |  |
| Payment To |  |  |  | 13 |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 2 |  |
| Prakher Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits |  | 48 | 48 |  |  |  |  |  |  |
| Brooks Brothers India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 14 | 24 |
| Revenue from Operations |  |  |  | 3 | 4 | 4 |  | 9 | 17 |
| Purchases / Material Consumed |  |  |  |  | 3 | 1 |  |  |  |
| Purchase / Subscription of Investments |  | 2 | 2 |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Loans and Advances |  |  |  |  |  |  |  |  | 1 |
| Purchase/Subscription of Investments |  |  |  | 1 |  |  |  |  |  |
| Purchases/ Material Consumed |  |  |  | 1 |  |  |  |  |  |
| Sales and Distribution Expenses |  | 1 |  |  |  |  |  |  |  |
| Reliance Jio Infocomm Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  | 20 | 26 | 20 |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 10 |
| Reliance Industries Limited Staff Superannuation Scheme |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 19 | 20 |
| Employee Benefits Expense |  | 10 | 10 | 11 |  |  |  |  |  |
| Ryohin-Keikaku Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 7 |  | 3 | 8 |  | 3 | 3 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 11 | 8 |
| Revenue from Operations |  |  |  | 3 | 2 | 2 |  | 5 | 6 |
| Purchase/Subscription of Investments |  |  |  | 6 |  |  |  |  |  |
| Centura Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 10 | 10 | 10 |  | 10 | 10 |  | 10 | 8 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 2 |
| Television Home Shopping Network Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 61 |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 |  |  |  |  |
| Vishnumaya Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 10 | 10 | 10 |  | 8 | 7 |  | 7 | 7 |
| Net Loans and Advances, Deposits Returned |  |  |  | 2 |  |  |  |  |  |
| Shri Alok Agarwal Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 12 | 12 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 12 | 12 |  |  |  |  |  |  |
| Payment To |  |  |  | 12 |  |  |  |  |  |
| Matrix Genetics LLC Associate |  |  |  |  |  |  |  |  |  |
| General Expenses |  | 27 | 27 | 6 |  |  |  |  |  |
| Reliance-Vision Express Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  | 3 |  | 3 | 5 |  | 6 | 10 |
| Revenue from Operations |  | 2 | 3 | 2 | 3 | 3 |  | 4 | 4 |
| Net Loans and Advances, Deposits Given |  |  |  |  | 3 |  |  |  |  |
| Loans and Advances |  |  |  |  | 3 |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 3 |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Hathway MCN Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 10 |  | 15 | 13 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 7 | 7 |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  |  | 3 |  |  |  |
| Reliance Retail Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 26 | 33 |
| Smt. Nita M. Ambani Relative |  |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 52 |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 2 | 2 |
| Reliance Commercial Trading Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Sales/ Transfer/ Redemption of Investments |  | 42 |  |  |  |  |  |  |  |
| Loans & Advances | 12 |  |  |  |  |  |  |  |  |
| Loans and Advances |  | 6 |  |  |  |  |  |  |  |
| Sale / Transfer / Redemption of Investments | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given | 1 |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  | 6 |  |  |  |  |  |  |  |
| Reliance Gas Transportation and Infrastructure Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 46 |  |  |  |  |  |  |  |  |
| Purchase of Tangible and Intangible Assets |  |  | 8 |  |  |  |  |  |  |
| Netravati Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 6 | 7 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Rakshita Commercials Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 6 | 6 | 6 |  | 6 | 6 |  | 6 | 7 |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  |  | 1 |
| Shri P.M.S. Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 10 | 11 |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 7 | 7 |  |  |  |  |  |  |
| Payment To |  |  |  | 9 |  |  |  |  |  |
| Hathway Sai Star Cable & Datacom Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  | 7 | 6 |
| Purchase / Subscription of Investments |  |  |  |  | 10 |  |  |  |  |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Sales and Distribution Expenses |  |  |  |  |  | 2 |  |  |  |
| Programming and Telecast Related Expense |  |  |  |  |  | 2 |  |  |  |
| Loans and Advances |  |  |  |  |  | 1 |  |  |  |
| DL GTPL Cabnet Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 5 |  | 8 | 9 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 5 | 6 |
| Sales and Distribution Expenses |  |  |  |  |  | 3 |  |  |  |
| Marugandha Land Developers Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 5 | 5 | 5 |  | 5 | 5 |  | 5 | 5 |
| Shri Alok AgarwalAA Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 12 | 13 |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 9 |  |
| GTPL Broadband Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 15 | 18 |
| Indiacast Media Distribution Private Limited JV |  |  |  |  |  |  |  |  |  |
| General Expenses |  |  |  | 25 |  |  |  |  |  |
| Revenue from Operations |  |  |  | 5 |  |  |  |  |  |
| TCO Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 3 | 11 |
| Purchase / Subscription of Investments |  |  |  |  |  | 14 |  |  |  |
| Jaipur Enclave Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 4 | 4 | 4 |  | 4 | 4 |  | 4 | 4 |
| TV18 Home Shopping Network Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 28 |  |  |  |  |  |
| IBN Lokmat News Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 1 |  | 1 | 3 |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 | 4 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 2 |
| Programming and Telecast Related Expense |  |  |  |  | 2 | 2 |  |  |  |
| Other Income |  |  |  |  |  | 1 |  | 1 | 1 |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 1 |
| General Expenses |  |  |  | 1 |  |  |  |  |  |
| GTPL Kolkata Cable & Broadband Pariseva Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  | 2 | 19 |  |  |  |
| Sales and Distribution Expenses |  |  |  |  |  | 6 |  |  |  |
| Jio Platforms Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 26 |
| Shri PMS Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  |  |  | 12 | 14 |
| Reliance Paul & Shark Fashions Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 1 | 1 | 1 |  | 2 | 4 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 2 | 6 |
| Purchase / Subscription of Investments |  |  |  |  | 1 | 1 |  |  |  |
| Purchase/Subscription of Investments |  |  |  | 2 |  |  |  |  |  |
| Net Loans and Advances, Deposits Given |  |  |  |  | 1 |  |  |  |  |
| Loans and Advances |  |  |  |  | 1 |  |  |  |  |
| Vayana Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  | 24 |  |  |  |  |  |  |  |
| Canali India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 4 | 9 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 2 | 6 |
| Purchases / Material Consumed |  |  |  |  | 1 | 1 |  |  |  |
| Pipeline Management Services Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  |  | 2 |
| General Expenses |  |  |  |  |  |  |  |  | 6 |
| Other Income |  |  |  |  |  | 6 |  |  |  |
| Professional Fees |  |  |  |  |  | 4 |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 1 |  |  |  |  |
| DEN ADN Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 6 |  |  |  |
| Revenue from Operations |  |  |  |  |  | 3 |  | 1 | 1 |
| Other Income |  |  |  |  |  | 1 |  | 1 | 2 |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 2 | 1 |
| General Expenses |  |  |  |  |  | 1 |  | 1 | 1 |
| Sales and Distribution Expenses |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 4 |  |
| Reliance Bally India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 1 | 1 | 2 |  | 3 | 4 |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 3 | 4 |
| Purchase/Subscription of Investments |  |  |  | 4 |  |  |  |  |  |
| Zegna South Asia Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 1 | 1 | 2 | 2 | 2 |  | 2 | 2 |
| General Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Purchase / Subscription of Investments |  | 1 | 2 |  |  |  |  |  |  |
| Purchase of Goods / Services |  |  |  |  |  |  |  | 1 | 1 |
| Purchases/ Material Consumed |  | 2 |  |  |  |  |  |  |  |
| Reliance Industries Limited Sta Superannuation Scheme |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  |  | 11 | 11 |  |  |  |
| Hathway Cable MCN Nanded Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 5 |  | 7 | 5 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 2 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Hirachand Govardhandas Ambani Public Charitable Trust |  |  |  |  |  |  |  |  |  |
| Donations | 2 |  |  | 2 | 5 | 6 |  | 3 | 3 |
| Fame Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 3 | 3 | 3 |  | 3 | 3 |  | 3 | 3 |
| Noveltech Agro Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 3 | 3 | 3 |  | 3 | 3 |  | 3 | 3 |
| Shri Pawan Kumar Kapil Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 4 | 4 |  | 4 | 4 |
| Payment To |  |  |  | 3 |  |  |  |  |  |
| HNH Trust and HNH Research Society |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  |  | 8 | 10 |  |  |  |
| Hathway Latur MCN Cable & Datacom Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 4 |  | 5 | 4 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Shri K. Sethuraman Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 2 | 3 |  | 2 |  |
| PaymentToKeyManagementPersonnel/Relative |  | 2 | 2 |  |  |  |  |  |  |
| Payment To |  |  |  | 3 |  |  |  |  |  |
| Clayfin Technologies Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  |  | 11 |
| CCN DEN Network Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 18 |  |  |  |
| Revenue from Operations |  |  |  |  |  | 3 |  | 1 |  |
| Other Income |  |  |  |  |  | 3 |  |  |  |
| Sales and Distribution Expenses |  |  |  |  |  | 2 |  |  |  |
| Selling and Distribution Expenses |  |  |  |  |  |  |  | 1 |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 18 |  |
| IndiaCast UK Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  | 5 | 6 |  |  |  |  |  |  |
| Shri P. M. S. Prasad Key Person |  |  |  |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 6 |  |  |  |  |  |  |  |  |
| Payment of Call Money on Equity Shares |  |  |  |  |  |  |  | 4 |  |
| Future101 Design Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 4 |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  |  | 2 |
| Purchase of Property, Plant and Equipment and Other Intangible Assets |  |  |  |  |  |  |  |  | 1 |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Indospace MET Logistics Park Farukhnagar Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 5 |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 2 |
| Other Income |  |  |  |  |  |  |  |  | 1 |
| Hathway CCN Multinet Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 6 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 1 |  |
| Smt Nita M. Ambani Relative |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  | 2 | 1 |  |  |  |
| Payment To |  |  |  | 2 |  |  |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 1 | 1 |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 1 |  |  |  |  |  |  |  |  |
| GenNext Ventures Investment Advisers LLP Associate |  |  |  |  |  |  |  |  |  |
| Professional Fees | 5 | 1 | 2 |  |  |  |  |  |  |
| Smt. Savithri Parekh Key Person |  |  |  |  |  |  |  |  |  |
| Payment to Key Managerial Personnel / Relative |  |  |  |  |  | 2 |  | 2 | 3 |
| Vadodara Enviro Channel Limited Associate |  |  |  |  |  |  |  |  |  |
| General Expenses |  |  |  |  |  | 3 |  | 2 | 2 |
| Pepino Farms Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Deposits | 1 | 1 | 1 |  | 1 | 1 |  | 1 | 1 |
| Hathway Dattatray Cable Network Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 2 |
| Programming and Telecast Related Expenses |  |  |  |  |  |  |  | 1 | 1 |
| Programming and Telecast Related Expense |  |  |  |  |  | 1 |  |  |  |
| Hathway CCN Entertainment (India) Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 4 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 1 |  |
| Einsten Commericals Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Returned |  |  |  | 6 |  |  |  |  |  |
| Indiacast UK Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  | 6 |  |  |  |  |  |
| Shri P.K.Kapil Key Person |  |  |  |  |  |  |  |  |  |
| PaymentToKeyManagementPersonnel/Relative |  | 3 | 3 |  |  |  |  |  |  |
| HirachandGovardhandasAmbaniPublicCharitableTrust |  |  |  |  |  |  |  |  |  |
| Donations |  | 4 | 2 |  |  |  |  |  |  |
| Burberry India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  | 2 | 2 |
| DEN New Broad Communication Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 1 |
| General Expenses |  |  |  |  |  |  |  |  | 1 |
| Ubona Technologies Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 2 | 2 |
| Ethane Crystal LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Emerald LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Opal LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Pearl LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Sapphire LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Ethane Topaz LLC JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  |  |  |  | 4 |
| Enercent Technologies Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  |  |  | 4 |  |
| ZegnaSouthAsiaPrivateLimited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  |  | 3 |  |  |  |
| General Expenses |  |  |  |  |  | 1 |  |  |  |
| Net 9 Online Hathway Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 3 |  |  |  |  |
| Revenue from Operations |  |  |  |  |  | 1 |  |  |  |
| Reliance Industries Limited Vadodara Unit Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  |  |  | 2 | 1 | 1 |  |  |  |
| Reliance Industries Limited Vadodara Unit |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 2 | 2 |  |  |  |  |  |  |
| RIL Vadodara Unit Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expense |  | 3 |  |  |  |  |  |  |  |
| CAA-Global Brands Reliance Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 2 |
| Konark IP Dossiers Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  | 1 | 1 |
| Reliance Luxury Fashion Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Net Loans and Advances, Deposits Given/(Re-turned) |  |  | 1 |  |  |  |  |  |  |
| Loans and Advances |  |  | 1 |  |  |  |  |  |  |
| Brook Brothers India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  | 2 |  |  |  |  |  |  |
| Ryohin - Keikaku Reliance India Private Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  | 2 |  |  |  |  |  |  |
| Shri P. K. Kapil Key Person |  |  |  |  |  |  |  |  |  |
| Payment To Key Managerial Personnel / Relative | 2 |  |  |  |  |  |  |  |  |
| Hathway Bhawani NDS Network Limited JV |  |  |  |  |  |  |  |  |  |
| Revenue from Operations |  |  |  |  |  |  |  |  | 1 |
| Reliance Industries Limited Vadodara Units Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Employee Benefits Expenses |  |  |  |  |  |  |  | 1 |  |
| IndiaGasSolutionsPrivateLimited JV |  |  |  |  |  |  |  |  |  |
| Other Income |  |  |  |  |  | 1 |  |  |  |
| Hathway CBN Multinet Private Limited JV |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments |  |  |  |  | 1 |  |  |  |  |
| Aurora Algae LLC Associate |  |  |  |  |  |  |  |  |  |
| Purchase / Subscription of Investments | 1 |  |  |  |  |  |  |  |  |
| Wespro Digital Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Revenue from Operations | 1 |  |  |  |  |  |  |  |  |
| Hathway ICE Television Private Limited JV |  |  |  |  |  |  |  |  |  |
| Loans and Advances |  |  |  |  |  | 1 |  |  |  |
| Net Loans and Advances, Deposits Given / (Returned) |  |  |  |  |  |  |  | 1 |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 395,957 | 433,521 | 374,372 | 272,583 | 303,954 | 390,823 | 568,337 | 596,679 | 466,307 | 694,673 | 876,396 | 901,064 | 925,289 |
| Expenses + | 362,802 | 398,586 | 336,923 | 230,802 | 257,647 | 326,508 | 484,087 | 507,413 | 385,517 | 586,092 | 734,078 | 738,831 | 762,384 |
| Operating Profit | 33,155 | 34,935 | 37,449 | 41,781 | 46,307 | 64,315 | 84,250 | 89,266 | 80,790 | 108,581 | 142,318 | 162,233 | 162,905 |
| OPM % | 8% | 8% | 10% | 15% | 15% | 16% | 15% | 15% | 17% | 16% | 16% | 18% | 18% |
| Other Income + | 7,757 | 8,865 | 8,528 | 12,212 | 9,222 | 9,869 | 8,406 | 8,570 | 22,432 | 19,600 | 12,020 | 16,057 | 16,438 |
| Interest | 3,463 | 3,836 | 3,316 | 3,691 | 3,849 | 8,052 | 16,495 | 22,027 | 21,189 | 14,584 | 19,571 | 23,118 | 23,199 |
| Depreciation | 11,232 | 11,201 | 11,547 | 11,565 | 11,646 | 16,706 | 20,934 | 22,203 | 26,572 | 29,782 | 40,303 | 50,832 | 52,653 |
| Profit before tax | 26,217 | 28,763 | 31,114 | 38,737 | 40,034 | 49,426 | 55,227 | 53,606 | 55,461 | 83,815 | 94,464 | 104,340 | 103,491 |
| Tax % | 20% | 22% | 24% | 23% | 25% | 27% | 28% | 26% | 3% | 19% | 22% | 25% |  |
| Net Profit + | 20,886 | 22,548 | 23,640 | 29,861 | 29,833 | 36,080 | 39,837 | 39,880 | 53,739 | 67,845 | 74,088 | 79,020 | 78,207 |
| EPS in Rs | 30.31 | 32.62 | 34.14 | 43.03 | 43.11 | 53.39 | 58.55 | 58.20 | 77.50 | 89.74 | 98.59 | 102.90 | 101.61 |
| Dividend Payout % | 13% | 12% | 12% | 10% | 11% | 10% | 10% | 10% | 9% | 9% | 9% | 10% |  |
| 10 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 36,918 | 43,261 | 34,374 | 38,134 | 49,550 | 71,459 | 42,346 | 94,877 | 26,958 | 110,654 | 115,032 | 158,788 |
| Cash from Investing Activity + | -27,601 | -73,070 | -64,706 | -36,186 | -66,201 | -68,192 | -94,507 | -72,497 | -142,385 | -109,162 | -93,001 | -114,301 |
| Cash from Financing Activity + | 408 | 13,713 | 8,444 | -3,210 | 8,617 | -2,001 | 55,906 | -2,541 | 101,904 | 17,289 | 10,455 | -16,646 |
| Net Cash Flow | 9,725 | -16,096 | -21,888 | -1,262 | -8,034 | 1,266 | 3,745 | 19,839 | -13,523 | 18,781 | 32,486 | 27,841 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 9 | 8 | 5 | 6 | 10 | 16 | 19 | 12 | 15 | 12 | 12 | 13 |
| Inventory Days | 60 | 57 | 66 | 90 | 84 | 83 | 63 | 67 | 102 | 83 | 87 | 95 |
| Days Payable | 55 | 61 | 74 | 117 | 132 | 146 | 100 | 87 | 136 | 123 | 91 | 111 |
| Cash Conversion Cycle | 14 | 4 | -2 | -21 | -38 | -46 | -18 | -9 | -19 | -27 | 7 | -3 |
| Working Capital Days | -1 | -3 | -37 | -117 | -141 | -144 | -67 | -101 | 12 | -13 | -9 | 33 |
| ROCE % | 10% | 10% | 9% | 10% | 10% | 11% | 12% | 11% | 8% | 8% | 9% | 10% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 50.61% | 50.61% | 50.66% | 50.62% | 50.56% | 50.49% | 50.41% | 50.39% | 50.27% | 50.30% | 50.31% | 50.33% |
| FIIs + | 25.41% | 24.75% | 24.23% | 23.90% | 23.58% | 23.48% | 22.49% | 22.55% | 22.60% | 22.13% | 22.06% | 21.75% |
| DIIs + | 13.20% | 13.62% | 14.23% | 14.67% | 14.91% | 15.26% | 16.06% | 16.13% | 15.99% | 16.59% | 16.98% | 17.30% |
| Government + | 0.18% | 0.17% | 0.17% | 0.17% | 0.16% | 0.16% | 0.16% | 0.17% | 0.17% | 0.18% | 0.19% | 0.19% |
| Public + | 10.60% | 10.85% | 10.71% | 10.64% | 10.78% | 10.59% | 10.89% | 10.76% | 10.98% | 10.80% | 10.46% | 10.43% |
| No. of Shareholders | 30,43,511 | 33,06,662 | 33,27,847 | 33,06,732 | 34,85,825 | 33,62,915 | 36,39,396 | 35,06,867 | 36,98,648 | 36,13,814 | 34,63,276 | 34,93,125 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 46.32% | 47.45% | 47.27% | 50.07% | 50.58% | 50.66% | 50.41% | 50.31% | 50.33% |
| FIIs + | 22.58% | 24.46% | 24.39% | 24.08% | 25.66% | 24.23% | 22.49% | 22.06% | 21.75% |
| DIIs + | 11.85% | 11.23% | 11.86% | 13.78% | 12.62% | 14.23% | 16.06% | 16.98% | 17.30% |
| Government + | 0.14% | 0.15% | 0.18% | 0.20% | 0.20% | 0.17% | 0.16% | 0.19% | 0.19% |
| Public + | 19.12% | 16.72% | 16.29% | 11.87% | 10.94% | 10.71% | 10.89% | 10.46% | 10.43% |
| No. of Shareholders | 25,01,302 | 22,66,000 | 22,11,231 | 26,32,168 | 30,31,272 | 33,27,847 | 36,39,396 | 34,63,276 | 34,93,125 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/reliance-industries-ltd/reliance/500325/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 19h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6bd96088-9509-49e3-97cd-1d55e735c65d.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=00159378-6dde-4765-81d0-c03f6ffd3ea8.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f9a31b83-7b56-4537-b6c3-4ddaaa41e0fe.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8a746305-aa98-46af-a73b-870c1530196b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7cb743a2-c7b7-4cec-94d1-5bf6ea42fbce.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b55b5dfc-a3bf-4f24-9d7f-ca09774a1dd9.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500325/74185500325.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500325/68509500325.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250320.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_19_RELIANCE_2012_2013_08052013171218.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_RELIANCE_2011_2012_29062012101059.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500325/5003250311.pdf)

## Credit Ratings
- [Rating update
17 Jul from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/FirstBusinessReceivablesTrust_July%2017_%202024_RR_348259.html)
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407120737_Reliance_Industries_Limited.pdf)
- [Rating update
2 Feb from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=125340)
- [Rating update
19 Jan from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/FirstBusinessReceivablesTrust_January%2019,%202024_RR_335233.html)
- [Rating update
29 Dec 2023 from fitch](https://www.indiaratings.co.in/pressrelease/67886)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/RelianceIndustriesLimited_November%2003,%202023_RR_331173.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=191e6ab9-4751-4017-ba5f-bb63daf2d871.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=24faf885-ece1-4852-b0fe-91fc8643dc1c.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06b05d06-8c38-4aee-aa5b-5e7108ae3871.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0501df4e-7d64-455d-bbb0-4b2118067e51.pdf)
- [REC](https://www.ril.com/investors/events-presentations#webcast-sec)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=de3e8ff3-efca-4266-9bc8-7509f48574a4.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1cb66ca2-dfd5-4f46-986f-03b0661bd486.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ef9baa21-923a-48ad-9fb7-2157af59ae16.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f9c9eba2-4b08-430f-a3a0-0dd5419b7f8f.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7cf2df9a-51bb-45d4-9004-3cad20b5920b.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f2fa506f-675b-46db-9f7b-26303a05d6b9.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dc6d4a06-e2bc-4df4-8b8a-5db0f50b1918.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9c8c3f07-883a-476b-8fb2-8fe74078e9f5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7c228ccc-99ad-4bd9-be72-0a746c30ebee.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfb275bd-fd47-4a38-964e-21a67e26b3c2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1ef9c86c-8f99-4791-a677-ea8a65e4ef28.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=aa7a60c6-791d-4e59-94e6-9f94c3a506fc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d6182ad1-6f8e-4112-b865-984ea1035107.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9e81c058-6b85-4f18-ba5a-bbdd72156edf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bf7646f7-940a-429b-b3eb-0625715f6aeb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7d172a7c-9056-4588-ad0c-d5c114ff902a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6047c516-bdab-4a88-9103-81d6ddad23d5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1008c763-0d31-4432-a031-6dd4afda0c72.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=33e997e6-025e-478e-b71f-fb59dca2a4ef.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b9139079-b211-4486-a604-ef5b85a7985e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=caff4f40-fd8f-49ae-929c-f5dae4c98ec3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4c079f28-425e-4fb4-a830-ae9f4fde355d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c44095c1-55cb-4048-a235-6f776dd054e9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ee845952-2c47-4abc-b15a-ab759c068efe.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ef91573e-ebb9-4257-8209-b684d9380a3e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c9c7754a-ab5a-4463-a5cb-3baafbef135d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8841c2b4-6659-4ea6-aefd-9874fee15705.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a738dab1-1698-4a4f-b863-148b5c5023e0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f6d2f75-5b1f-4c8b-87eb-34e3c8246fb1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bcf1b986-0d58-4126-b3fa-cf67e7b44e14.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=05c527f3-c7ff-4e83-a2b3-d7d92b20969d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=040c976b-6d40-4903-905e-27820f21eb05.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d71a237f-6917-4594-969d-cfd62d1849d9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e0357498-61d2-405d-98c9-02a1e83b556b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a49913c-4798-4f48-ab39-e187ea89caf2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=421cf002-f53b-4c1c-a8be-de2fdda6fd05.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6669EE6F_088E_4C15_9839_E2DBB861749D_110427.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Reliance Industr | 3010.00 | 2036509.67 | 29.59 | 2.56 | 2.20 | 337.77 | 12.74 | 22.03 | 0.30 | 9.99 | 4.70 | 9.23 | 0.54 | 0.44 | 5.46 | 2.12 | 925289.00 | 17.61 | 68748.00 | 231784.00 | 15138.00 | 11.67 | -5.45 | 101.61 | 346142.00 | 50.33 | 0.02 | 5.59 | 10.77 | 0.00 | 6.78 | 6.72 | 2285426.67 | 1.18 | 2.48 | 2.74 | 10.30 | 16.55 | 19.26 | 8.70 | 8.72 | 11.92 | 16.33 | 9.66 | 24.56 | 8.94 | 9.14 | 0.80 | 102.90 | 11.90 | 25.75 | 25.69 | 23.83 | -3.16 | 676.56 |
| 2. | I O C L | 176.75 | 249592.86 | 6.01 | 1.36 | 0.32 | 21.88 | 4.70 | 13.35 | 6.79 | 21.14 | 9.28 | 25.66 | 1.68 | 0.72 | 8.22 | 2.52 | 776351.85 | 9.74 | 41460.24 | 198649.76 | 5148.87 | -2.56 | -49.96 | 29.55 | 132627.56 | 51.50 | 0.00 | 17.09 | 10.77 | 0.00 | -7.77 | 323.40 | 379061.63 | 0.68 | 0.31 | 3.09 | 23.07 | 36.65 | 79.36 | 18.14 | 16.29 | 19.14 | 24.21 | 8.01 | 28.73 | 7.17 | 8.09 | 0.12 | 29.55 | 19.14 | 5.72 | 5.07 | 6.43 | 42.07 | 1412.12 |
| 3. | B P C L | 328.40 | 142476.45 | 7.32 | 1.91 | 0.32 | 9.95 | 5.14 | 13.67 | 6.41 | 32.09 | 13.86 | 41.90 | 2.29 | 0.72 | 8.08 | 2.58 | 448193.16 | 7.52 | 19487.67 | 113094.92 | 2945.19 | 0.10 | -72.40 | 43.92 | 54599.05 | 52.98 | 0.00 | 15.96 | 10.77 | 0.00 | -3.63 | -2.86 | 190789.14 | 0.81 | 0.26 | 7.03 | 37.50 | 12.90 | 71.99 | 24.22 | 23.03 | 28.24 | 28.90 | 8.48 | 24.86 | 6.34 | 6.86 | 0.28 | 61.91 | 28.24 | 8.79 | 6.01 | 9.29 | 20.90 | 433.85 |
| 4. | H P C L | 376.60 | 80133.82 | 5.00 | 1.72 | 0.18 | 47.67 | 5.11 | 15.28 | 7.05 | 21.30 | 9.31 | 40.45 | 2.52 | 1.42 | 9.02 | 3.67 | 433856.51 | 5.75 | 16014.61 | 114677.63 | 2709.31 | 6.13 | -24.91 | 75.26 | 66683.82 | 54.90 | 0.00 | 15.82 | 10.77 | 0.00 | -1.55 | 329.93 | 146344.21 | 0.61 | 0.26 | 14.16 | 30.19 | 27.70 | 92.85 | 13.98 | 16.73 | 19.10 | 14.38 | 9.51 | 22.98 | -18.91 | -8.08 | 0.22 | 75.26 | 20.82 | 4.62 | 4.44 | 4.98 | 14.35 | 212.78 |
| 5. | M R P L | 214.10 | 37523.15 | 14.11 | 2.81 | 0.41 | 7.48 | 7.79 | 31.54 | 0.46 | 25.18 | 10.21 | 31.13 | 2.56 | 0.96 | 4.84 | 2.66 | 92472.42 | 6.74 | 2660.82 | 23247.02 | 73.22 | 10.40 | -92.78 | 15.15 | 12687.04 | 88.58 | 0.00 | 10.16 | 10.77 | 0.00 | -5.24 | 179.67 | 50171.58 | 1.03 | 0.24 | -13.70 | 24.19 | 67.24 | 163.00 | 35.83 | 13.12 | 59.14 | 89.02 | 7.34 | 41.43 | 31.22 | 20.13 | 0.36 | 20.52 | 59.14 | 6.15 | 5.71 | 7.67 | 20.63 | 175.26 |
| 6. | C P C L | 1000.50 | 14898.62 | 5.99 | 1.73 | 0.22 | 5.77 | 4.18 | 39.25 | 5.48 | 35.44 | 15.93 | 36.46 | 3.88 | 0.32 | 16.82 | 1.98 | 68735.62 | 6.09 | 2505.53 | 17094.98 | 342.60 | 15.94 | -37.52 | 168.26 | 2785.90 | 67.29 | 0.00 | 20.18 | 10.77 | 0.00 | 0.61 | 45.39 | 17590.27 | 1.25 | 0.08 | -3.39 | 27.01 | 104.19 | 153.76 | 53.89 | 32.58 | 71.20 | 125.15 | 9.94 | 43.76 | 77.91 | 45.54 | 0.16 | 182.07 | 71.20 | 3.39 | 3.24 | 4.44 | 24.38 | 14.89 |
| 7. | Gandhar Oil Ref. | 212.35 | 2078.30 | 14.80 | 1.81 | 0.51 | -250.37 | 7.18 |  | 0.00 | 21.70 | 9.30 | 14.81 | 2.32 | 0.23 | 4.61 | 1.52 | 4113.21 | 6.78 | 140.52 | 939.24 | 9.14 | -4.81 | -58.81 | 14.36 | 270.99 | 64.63 | 0.00 | 13.12 | 10.77 | 0.00 | 0.83 | -26.11 | 2072.56 | 2.52 | 0.29 | -4.72 | -16.35 |  |  | 22.85 | 20.60 | 51.00 | 11.96 | 2.89 | 22.80 | 30.03 | 37.34 | 1.79 | 14.36 | 5.12 | 10.83 | 10.83 | 10.83 | 62.93 | 8.00 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | Sales | ₹ 9,25,289 Cr. |
| RELIANCE | OPM | 17.6 % |
| RELIANCE | Profit after tax | ₹ 68,748 Cr. |
| RELIANCE | Mar Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Sales Qtr | ₹ 2,31,784 Cr. |
| RELIANCE | PAT Qtr | ₹ 15,138 Cr. |
| RELIANCE | Qtr Sales Var | 11.7 % |
| RELIANCE | Qtr Profit Var | -5.45 % |
| RELIANCE | Price to Earning | 29.6 |
| RELIANCE | Dividend yield | 0.30 % |
| RELIANCE | Price to book value | 2.56 |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | Return on assets | 4.70 % |
| RELIANCE | Debt to equity | 0.44 |
| RELIANCE | Return on equity | 9.23 % |
| RELIANCE | EPS | ₹ 102 |
| RELIANCE | Debt | ₹ 3,46,142 Cr. |
| RELIANCE | Promoter holding | 50.3 % |
| RELIANCE | Change in Prom Hold | 0.02 % |
| RELIANCE | Earnings yield | 5.59 % |
| RELIANCE | Pledged percentage | 0.00 % |
| RELIANCE | Industry PE | 10.8 |
| RELIANCE | Sales growth | 6.78 % |
| RELIANCE | Profit growth | 6.72 % |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | Price to Sales | 2.20 |
| RELIANCE | CMP / FCF | 338 |
| RELIANCE | EVEBITDA | 12.7 |
| RELIANCE | Enterprise Value | ₹ 22,85,427 Cr. |
| RELIANCE | Current ratio | 1.18 |
| RELIANCE | Int Coverage | 5.46 |
| RELIANCE | PEG Ratio | 2.48 |
| RELIANCE | Return over 3months | 2.74 % |
| RELIANCE | Return over 6months | 10.3 % |
| RELIANCE | No. Eq. Shares | 677 |
| RELIANCE | Sales growth 3Years | 24.6 % |
| RELIANCE | Sales growth 5Years | 9.66 % |
| RELIANCE | Profit Var 3Yrs | 16.3 % |
| RELIANCE | Profit Var 5Yrs | 11.9 % |
| RELIANCE | ROE 5Yr | 8.72 % |
| RELIANCE | ROE 3Yr | 8.70 % |
| RELIANCE | Return over 1year | 19.3 % |
| RELIANCE | Return over 3years | 16.6 % |
| RELIANCE | Return over 5years | 22.0 % |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | Sales last year | ₹ 9,01,064 Cr. |
| RELIANCE | OP Ann | ₹ 1,62,233 Cr. |
| RELIANCE | Other Inc Ann | ₹ 16,057 Cr. |
| RELIANCE | EBIDT last year | ₹ 1,78,290 Cr. |
| RELIANCE | Dep Ann | ₹ 50,832 Cr. |
| RELIANCE | EBIT last year | ₹ 1,27,458 Cr. |
| RELIANCE | Interest last year | ₹ 23,118 Cr. |
| RELIANCE | PBT Ann | ₹ 1,04,340 Cr. |
| RELIANCE | Tax last year | ₹ 25,707 Cr. |
| RELIANCE | PAT Ann | ₹ 69,621 Cr. |
| RELIANCE | Extra Ord Item Ann | ₹ 0.00 Cr. |
| RELIANCE | NP Ann | ₹ 79,020 Cr. |
| RELIANCE | Dividend last year | ₹ 6,766 Cr. |
| RELIANCE | Raw Material | 65.0 % |
| RELIANCE | Employee cost | ₹ 25,679 Cr. |
| RELIANCE | OPM last year | 18.0 % |
| RELIANCE | NPM last year | 8.77 % |
| RELIANCE | Operating profit | ₹ 1,62,905 Cr. |
| RELIANCE | Interest | ₹ 23,199 Cr. |
| RELIANCE | Depreciation | ₹ 52,653 Cr. |
| RELIANCE | EPS last year | ₹ 103 |
| RELIANCE | EBIT | ₹ 1,26,690 Cr. |
| RELIANCE | Net profit | ₹ 78,207 Cr. |
| RELIANCE | Current Tax | ₹ 13,268 Cr. |
| RELIANCE | Tax | ₹ 25,381 Cr. |
| RELIANCE | Other income | ₹ 16,438 Cr. |
| RELIANCE | Ann Date | 2,02,403 |
| RELIANCE | Sales Prev Ann | ₹ 8,76,396 Cr. |
| RELIANCE | OP Prev Ann | ₹ 1,42,318 Cr. |
| RELIANCE | Other Inc Prev Ann | ₹ 12,020 Cr. |
| RELIANCE | EBIDT Prev Ann | ₹ 1,54,076 Cr. |
| RELIANCE | Dep Prev Ann | ₹ 40,303 Cr. |
| RELIANCE | EBIT preceding year | ₹ 1,13,773 Cr. |
| RELIANCE | Interest Prev Ann | ₹ 19,571 Cr. |
| RELIANCE | PBT Prev Ann | ₹ 94,464 Cr. |
| RELIANCE | Tax preceding year | ₹ 20,376 Cr. |
| RELIANCE | PAT Prev Ann | ₹ 66,812 Cr. |
| RELIANCE | Extra Ord Prev Ann | ₹ 262 Cr. |
| RELIANCE | NP Prev Ann | ₹ 74,088 Cr. |
| RELIANCE | Dividend Prev Ann | ₹ 6,089 Cr. |
| RELIANCE | OPM preceding year | 16.2 % |
| RELIANCE | NPM preceding year | 8.47 % |
| RELIANCE | EPS preceding year | ₹ 98.6 |
| RELIANCE | Sales Prev 12M | ₹ 9,01,064 Cr. |
| RELIANCE | Profit Prev 12M | ₹ 79,020 Cr. |
| RELIANCE | Med Sales Gwth 10Yrs | 4.99 % |
| RELIANCE | Med Sales Gwth 5Yrs | 4.99 % |
| RELIANCE | Sales growth 7Years | 16.8 % |
| RELIANCE | Sales Var 10Yrs | 7.59 % |
| RELIANCE | EBIDT growth 3Years | 22.2 % |
| RELIANCE | EBIDT growth 5Years | 14.0 % |
| RELIANCE | EBIDT growth 7Years | 18.1 % |
| RELIANCE | EBIDT Var 10Yrs | 15.7 % |
| RELIANCE | EPS growth 3Years | 13.8 % |
| RELIANCE | EPS growth 5Years | 11.9 % |
| RELIANCE | EPS growth 7Years | 13.2 % |
| RELIANCE | EPS growth 10Years | 13.1 % |
| RELIANCE | Profit Var 7Yrs | 12.8 % |
| RELIANCE | Profit Var 10Yrs | 12.9 % |
| RELIANCE | Chg in Prom Hold 3Yr | -0.26 % |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | OP Qtr | ₹ 38,765 Cr. |
| RELIANCE | Other Inc Qtr | ₹ 3,983 Cr. |
| RELIANCE | EBIDT Qtr | ₹ 42,748 Cr. |
| RELIANCE | Dep Qtr | ₹ 13,596 Cr. |
| RELIANCE | EBIT latest quarter | ₹ 29,152 Cr. |
| RELIANCE | Interest Qtr | ₹ 5,918 Cr. |
| RELIANCE | PBT Qtr | ₹ 23,234 Cr. |
| RELIANCE | Tax latest quarter | ₹ 5,786 Cr. |
| RELIANCE | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| RELIANCE | NP Qtr | ₹ 17,445 Cr. |
| RELIANCE | GPM latest quarter | 33.8 % |
| RELIANCE | OPM latest quarter | 16.7 % |
| RELIANCE | NPM latest quarter | 7.53 % |
| RELIANCE | Eq Cap Qtr | ₹ 6,766 Cr. |
| RELIANCE | EPS latest quarter | ₹ 22.4 |
| RELIANCE | OP 2Qtr Bk | ₹ 40,656 Cr. |
| RELIANCE | OP 3Qtr Bk | ₹ 40,968 Cr. |
| RELIANCE | Sales 2Qtr Bk | ₹ 2,25,086 Cr. |
| RELIANCE | Sales 3Qtr Bk | ₹ 2,31,886 Cr. |
| RELIANCE | NP 2Qtr Bk | ₹ 19,641 Cr. |
| RELIANCE | NP 3Qtr Bk | ₹ 19,878 Cr. |
| RELIANCE | Opert Prft Gwth | 14.4 % |
| RELIANCE | Last result date | 2,02,406 |
| RELIANCE | Exp Qtr Sales Var | 6.98 % |
| RELIANCE | Exp Qtr Sales | ₹ 2,48,066 Cr. |
| RELIANCE | Exp Qtr OP | ₹ 43,727 Cr. |
| RELIANCE | Exp Qtr NP | ₹ 23,635 Cr. |
| RELIANCE | Exp Qtr EPS | ₹ 30.3 |
| RELIANCE | Sales Prev Qtr | ₹ 2,36,533 Cr. |
| RELIANCE | OP Prev Qtr | ₹ 42,516 Cr. |
| RELIANCE | Other Inc Prev Qtr | ₹ 4,534 Cr. |
| RELIANCE | EBIDT Prev Qtr | ₹ 47,050 Cr. |
| RELIANCE | Dep Prev Qtr | ₹ 13,569 Cr. |
| RELIANCE | EBIT Prev Qtr | ₹ 33,481 Cr. |
| RELIANCE | Interest Prev Qtr | ₹ 5,761 Cr. |
| RELIANCE | PBT Prev Qtr | ₹ 27,720 Cr. |
| RELIANCE | Tax Prev Qtr | ₹ 6,577 Cr. |
| RELIANCE | PAT Prev Qtr | ₹ 18,951 Cr. |
| RELIANCE | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| RELIANCE | NP Prev Qtr | ₹ 21,243 Cr. |
| RELIANCE | OPM Prev Qtr | 18.0 % |
| RELIANCE | NPM Prev Qtr | 8.98 % |
| RELIANCE | Eq Cap Prev Qtr | ₹ 6,766 Cr. |
| RELIANCE | EPS Prev Qtr | ₹ 28.0 |
| RELIANCE | Sales PY Qtr | ₹ 2,07,559 Cr. |
| RELIANCE | OP PY Qtr | ₹ 38,093 Cr. |
| RELIANCE | Other Inc PY Qtr | ₹ 3,813 Cr. |
| RELIANCE | EBIDT PY Qtr | ₹ 41,906 Cr. |
| RELIANCE | Dep PY Qtr | ₹ 11,775 Cr. |
| RELIANCE | EBIT PY Qtr | ₹ 30,131 Cr. |
| RELIANCE | Interest PY Qtr | ₹ 5,837 Cr. |
| RELIANCE | PBT PY Qtr | ₹ 24,294 Cr. |
| RELIANCE | Tax PY Qtr | ₹ 6,112 Cr. |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | Equity capital | ₹ 6,766 Cr. |
| RELIANCE | Preference capital | ₹ 0.00 Cr. |
| RELIANCE | Reserves | ₹ 7,86,715 Cr. |
| RELIANCE | Secured loan | ₹ 69,924 Cr. |
| RELIANCE | Unsecured loan | ₹ 3,81,740 Cr. |
| RELIANCE | Balance sheet total | ₹ 17,55,986 Cr. |
| RELIANCE | Gross block | ₹ 10,17,992 Cr. |
| RELIANCE | Revaluation reserve | ₹ 0.00 Cr. |
| RELIANCE | Accum Dep | ₹ 2,93,187 Cr. |
| RELIANCE | Net block | ₹ 9,66,458 Cr. |
| RELIANCE | CWIP | ₹ 1,52,382 Cr. |
| RELIANCE | Investments | ₹ 2,25,672 Cr. |
| RELIANCE | Current assets | ₹ 4,70,100 Cr. |
| RELIANCE | Current liabilities | ₹ 3,97,367 Cr. |
| RELIANCE | BV Unq Invest | ₹ 17,926 Cr. |
| RELIANCE | MV Quoted Inv | ₹ 0.00 Cr. |
| RELIANCE | Cont Liab | ₹ 32,635 Cr. |
| RELIANCE | Total Assets | ₹ 17,55,986 Cr. |
| RELIANCE | Working capital | ₹ 1,78,748 Cr. |
| RELIANCE | Lease liabilities | ₹ 21,520 Cr. |
| RELIANCE | Inventory | ₹ 1,52,770 Cr. |
| RELIANCE | Trade receivables | ₹ 31,628 Cr. |
| RELIANCE | Face value | ₹ 10.0 |
| RELIANCE | Cash Equivalents | ₹ 97,225 Cr. |
| RELIANCE | Adv Cust | ₹ 0.00 Cr. |
| RELIANCE | Trade Payables | ₹ 1,78,377 Cr. |
| RELIANCE | No. Eq. Shares PY | 677 |
| RELIANCE | Debt preceding year | ₹ 4,51,664 Cr. |
| RELIANCE | Work Cap PY | ₹ 46,066 Cr. |
| RELIANCE | Net Block PY | ₹ 7,24,805 Cr. |
| RELIANCE | Gross Block PY | ₹ 10,17,992 Cr. |
| RELIANCE | CWIP PY | ₹ 2,93,752 Cr. |
| RELIANCE | Work Cap 3Yr | ₹ 32,491 Cr. |
| RELIANCE | Work Cap 5Yr | ₹ -93,224 Cr. |
| RELIANCE | Work Cap 7Yr | ₹ -1,14,234 Cr. |
| RELIANCE | Work Cap 10Yr | ₹ 34,970 Cr. |
| RELIANCE | Debt 3Years back | ₹ 2,78,962 Cr. |
| RELIANCE | Debt 5Years back | ₹ 3,07,714 Cr. |
| RELIANCE | Debt 7Years back | ₹ 2,17,475 Cr. |
| RELIANCE | Debt 10Years back | ₹ 1,38,761 Cr. |
| RELIANCE | Net Block 3Yrs Back | ₹ 5,41,258 Cr. |
| RELIANCE | Net Block 5Yrs Back | ₹ 3,98,374 Cr. |
| RELIANCE | Net Block 7Yrs Back | ₹ 1,98,526 Cr. |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | CF Operations | ₹ 1,58,788 Cr. |
| RELIANCE | Free Cash Flow | ₹ 21,212 Cr. |
| RELIANCE | CF Investing | ₹ -1,14,301 Cr. |
| RELIANCE | CF Financing | ₹ -16,646 Cr. |
| RELIANCE | Net CF | ₹ 27,841 Cr. |
| RELIANCE | Cash Beginning | ₹ 68,664 Cr. |
| RELIANCE | Cash End | ₹ 97,225 Cr. |
| RELIANCE | FCF Prev Ann | ₹ -16,770 Cr. |
| RELIANCE | CF Operations PY | ₹ 1,15,032 Cr. |
| RELIANCE | CF Investing PY | ₹ -93,001 Cr. |
| RELIANCE | CF Financing PY | ₹ 10,455 Cr. |
| RELIANCE | Net CF PY | ₹ 32,486 Cr. |
| RELIANCE | Cash Beginning PY | ₹ 36,178 Cr. |
| RELIANCE | Cash End PY | ₹ 68,664 Cr. |
| RELIANCE | Free Cash Flow 3Yrs | ₹ 18,088 Cr. |
| RELIANCE | Free Cash Flow 5Yrs | ₹ -39,148 Cr. |
| RELIANCE | Free Cash Flow 7Yrs | ₹ -91,074 Cr. |
| RELIANCE | Free Cash Flow 10Yrs | ₹ -1,55,159 Cr. |
| RELIANCE | CF Opr 3Yrs | ₹ 3,84,474 Cr. |
| RELIANCE | CF Opr 5Yrs | ₹ 5,06,309 Cr. |
| RELIANCE | CF Opr 7Yrs | ₹ 6,20,114 Cr. |
| RELIANCE | CF Opr 10Yrs | ₹ 7,42,172 Cr. |
| RELIANCE | CF Inv 10Yrs | ₹ -8,61,138 Cr. |
| RELIANCE | CF Inv 7Yrs | ₹ -6,94,045 Cr. |
| RELIANCE | CF Inv 5Yrs | ₹ -5,31,346 Cr. |
| RELIANCE | CF Inv 3Yrs | ₹ -3,16,464 Cr. |
| RELIANCE | Cash 3Years back | ₹ 17,397 Cr. |
| RELIANCE | Cash 5Years back | ₹ 11,081 Cr. |
| RELIANCE | Cash 7Years back | ₹ 3,023 Cr. |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | No. Eq. Shares | 677 |
| RELIANCE | Book value | ₹ 1,173 |
| RELIANCE | Inven TO | 4.00 |
| RELIANCE | Quick ratio | 0.80 |
| RELIANCE | Exports percentage | 0.00 % |
| RELIANCE | Piotroski score | 6.00 |
| RELIANCE | G Factor | 3.00 |
| RELIANCE | Asset Turnover | 0.54 |
| RELIANCE | Financial leverage | 2.12 |
| RELIANCE | No. of Share Holders | 34,93,125 |
| RELIANCE | Unpledged Prom Hold | 50.3 % |
| RELIANCE | ROIC | 8.39 % |
| RELIANCE | Debtor days | 12.8 |
| RELIANCE | Industry PBV | 1.87 |
| RELIANCE | Credit rating |  |
| RELIANCE | WC Days | 33.0 |
| RELIANCE | Earning Power | 7.21 % |
| RELIANCE | Graham Number | ₹ 1,637 |
| RELIANCE | Cash Cycle | -3.16 |
| RELIANCE | Days Payable | 111 |
| RELIANCE | Days Receivable | 12.8 |
| RELIANCE | Inventory Days | 95.3 |
| RELIANCE | Public holding | 10.4 % |
| RELIANCE | FII holding | 21.8 % |
| RELIANCE | Chg in FII Hold | -0.31 % |
| RELIANCE | DII holding | 17.3 % |
| RELIANCE | Chg in DII Hold | 0.32 % |
| RELIANCE | B.V. Prev Ann | ₹ 1,058 |
| RELIANCE | ROCE Prev Yr | 9.14 % |
| RELIANCE | ROA Prev Yr | 4.78 % |
| RELIANCE | ROE Prev Ann | 8.94 % |
| RELIANCE | No. of Share Holders Prev Qtr | 34,63,276 |
| RELIANCE | No. Eq. Shares 10 Yrs | 690 |
| RELIANCE | BV 3yrs back | ₹ 1,104 |
| RELIANCE | BV 5yrs back | ₹ 664 |
| RELIANCE | BV 10yrs back | ₹ 317 |
| RELIANCE | Inven TO 3Yr | 3.93 |
| RELIANCE | Inven TO 5Yr | 5.94 |
| RELIANCE | Inven TO 7Yr | 5.14 |
| RELIANCE | Inven TO 10Yr | 5.59 |
| RELIANCE | Export 3Yr | 0.00 % |
| RELIANCE | Export 5Yr | 0.00 % |
| RELIANCE | Div 5Yrs | ₹ 5,380 Cr. |
| RELIANCE | ROCE 3Yr | 9.12 % |
| RELIANCE | ROCE 5Yr | 9.09 % |
| RELIANCE | ROCE 7Yr | 9.76 % |
| RELIANCE | ROCE 10Yr | 9.73 % |
| RELIANCE | ROE 10Yr | 9.70 % |
| RELIANCE | ROE 7Yr | 9.29 % |
| RELIANCE | ROE 5Yr Var | -4.56 % |
| RELIANCE | OPM 5Year | 16.5 % |
| RELIANCE | OPM 10Year | 15.7 % |
| RELIANCE | No. of Share Holders 1Yr | 35,06,867 |
| RELIANCE | Avg Div Payout 3Yrs | 9.25 % |
| RELIANCE | Debtor days 3yrs | 12.4 |
| RELIANCE | Debtor days 3yrs back | 14.9 |
| RELIANCE | Debtor days 5yrs back | 19.3 |
| RELIANCE | ROA 5Yr | 4.41 % |
| RELIANCE | ROA 3Yr | 4.71 % |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | Avg Vol 1Mth | 65,77,748 |
| RELIANCE | Avg Vol 1Wk | 79,46,344 |
| RELIANCE | Volume | 63,47,310 |
| RELIANCE | High price | ₹ 3,218 |
| RELIANCE | Low price | ₹ 2,220 |
| RELIANCE | High price all time | ₹ 3,218 |
| RELIANCE | Low price all time | ₹ 116 |
| RELIANCE | Return over 1day | 0.84 % |
| RELIANCE | Return over 1week | -4.03 % |
| RELIANCE | Return over 1month | -1.43 % |
| RELIANCE | DMA 50 | ₹ 3,017 |
| RELIANCE | DMA 200 | ₹ 2,805 |
| RELIANCE | DMA 50 previous day | ₹ 3,018 |
| RELIANCE | 200 DMA prev. | ₹ 2,803 |
| RELIANCE | RSI | 41.6 |
| RELIANCE | MACD | 7.15 |
| RELIANCE | MACD Previous Day | 16.0 |
| RELIANCE | MACD Signal | 37.2 |
| RELIANCE | MACD Signal Prev | 44.7 |
| RELIANCE | Avg Vol 1Yr | 65,15,543 |
| RELIANCE | Return over 7years | 22.4 % |
| RELIANCE | Return over 10years | 20.6 % |
| RELIANCE | Market Cap | ₹ 20,36,510 Cr. |
| RELIANCE | Current Price | ₹ 3,010 |
| RELIANCE | High / Low | ₹ 3,218 / 2,220 |
| RELIANCE | Stock P/E | 29.6 |
| RELIANCE | Book Value | ₹ 1,173 |
| RELIANCE | Dividend Yield | 0.30 % |
| RELIANCE | ROCE | 9.99 % |
| RELIANCE | ROE | 9.23 % |
| RELIANCE | Face Value | ₹ 10.0 |
| RELIANCE | WC to Sales | 19.3 % |
| RELIANCE | QoQ Profits | -17.9 % |
| RELIANCE | QoQ Sales | -2.01 % |
| RELIANCE | Net worth | ₹ 7,93,481 Cr. |
| RELIANCE | Market Cap to Sales | 2.20 |
| RELIANCE | Interest Coverage | 5.46 |
| RELIANCE | EV / EBIT | 18.0 |
| RELIANCE | Debt Capacity | 0.14 |
| RELIANCE | Debt To Profit | 4.38 |
| RELIANCE | Capital Employed | ₹ 12,97,588 Cr. |
| RELIANCE | CROIC | 0.47 % |
| RELIANCE | debtplus | 0.48 |
| RELIANCE | Leverage | ₹ 2.12 |
| RELIANCE | Dividend Payout | 9.72 % |
| RELIANCE | Intrinsic Value | ₹ 1,041 |
| RELIANCE | CDL | -13.8 % |
| RELIANCE | Cash by market cap | 0.04 |
| RELIANCE | 52w Index | 79.2 % |
| RELIANCE | Down from 52w high | 6.46 % |
| RELIANCE | Up from 52w low | 35.6 % |
| RELIANCE | From 52w high | 0.94 |
| RELIANCE | Mkt Cap To Debt Cap | 1.61 |
| RELIANCE | Dividend Payout | 9.72 % |
| RELIANCE | Graham | ₹ 1,637 |
| RELIANCE | Price to Cash Flow | 12.8 |
| RELIANCE | ROCE3yr avg | 9.12 % |
| RELIANCE | PB X PE | 75.8 |
| RELIANCE | NCAVPS | ₹ 264 |
| RELIANCE | Mar Cap to CF | 12.8 |
| RELIANCE | Altman Z Score | 3.38 |
| RELIANCE | M.Cap / Qtr Profit | 135 |