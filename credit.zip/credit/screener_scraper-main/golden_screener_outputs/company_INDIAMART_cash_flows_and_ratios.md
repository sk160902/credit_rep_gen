# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 7 | -55 | -1 | 179 | 255 | 261 | 322 | 402 | 476 | 559 |
| Cash from Investing Activity + | -4 | -75 | -8 | -165 | -276 | -233 | -1,338 | -335 | -324 | 162 |
| Cash from Financing Activity + | -0 | 133 | 7 | 15 | 14 | -51 | 1,038 | -58 | -143 | -695 |
| Net Cash Flow | 3 | 2 | -1 | 29 | -7 | -23 | 23 | 9 | 9 | 27 |

## Ratios Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 1 | 0 | 1 | 1 | 0 | 1 | 1 | 1 | 3 | 1 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 1 | 0 | 1 | 1 | 0 | 1 | 1 | 1 | 3 | 1 |
| Working Capital Days | -272 | -241 | -243 | -260 | -277 | -258 | -240 | -284 | -300 | -308 |
| ROCE % |  |  |  |  |  | 84% | 39% | 22% | 19% | 24% |