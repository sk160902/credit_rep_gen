# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 10,504 | 12,220 | 13,615 | 14,271 | 15,062 | 16,825 | 19,240 | 20,211 | 21,713 | 29,101 | 34,489 | 35,495 | 35,282 |
| Expenses + | 8,767 | 10,217 | 11,372 | 11,546 | 12,068 | 13,621 | 15,475 | 16,054 | 16,857 | 24,298 | 28,229 | 27,910 | 28,125 |
| Operating Profit | 1,737 | 2,004 | 2,243 | 2,725 | 2,994 | 3,204 | 3,765 | 4,157 | 4,856 | 4,804 | 6,260 | 7,585 | 7,157 |
| OPM % | 17% | 16% | 16% | 19% | 20% | 19% | 20% | 21% | 22% | 17% | 18% | 21% | 20% |
| Other Income + | 114 | 124 | 142 | 213 | 338 | 336 | 274 | 355 | 332 | 296 | 431 | 821 | 786 |
| Interest | 42 | 48 | 42 | 49 | 37 | 41 | 110 | 102 | 92 | 95 | 144 | 205 | 215 |
| Depreciation | 155 | 246 | 266 | 276 | 335 | 360 | 622 | 780 | 791 | 816 | 858 | 853 | 882 |
| Profit before tax | 1,655 | 1,834 | 2,077 | 2,614 | 2,960 | 3,138 | 3,306 | 3,629 | 4,304 | 4,188 | 5,689 | 7,348 | 6,846 |
| Tax % | 30% | 31% | 31% | 32% | 32% | 33% | 33% | 24% | 26% | 26% | 26% | 24% |  |
| Net Profit + | 1,160 | 1,263 | 1,427 | 1,803 | 2,016 | 2,098 | 2,208 | 2,774 | 3,207 | 3,085 | 4,195 | 5,558 | 5,170 |
| EPS in Rs | 11.61 | 12.71 | 14.54 | 18.19 | 20.22 | 21.26 | 22.48 | 28.20 | 32.73 | 31.59 | 42.81 | 56.92 | 52.96 |
| Dividend Payout % | 40% | 42% | 42% | 41% | 51% | 41% | 47% | 43% | 55% | 61% | 60% | 58% |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Others Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 142 | 528 | 579 | 769 |
| Dividend Paid |  |  | 318 | 411 | 355 | 722 |  |  |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 240 | 260 |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 42 | 58 | 73 | 84 |  |  |  |  |
| Purchase of goods | 57 | 50 |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.11 | 13 | 0.28 | 0.18 |  |  |  |  |
| Commission to |  |  |  |  | 2.08 | 1.90 |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 2.08 |  |  |  |  |  |  |
| Remuneration | 0.48 | 0.36 | 0.35 | 0.42 |  |  |  |  |  |  |
| Sale of goods | 0.96 | 0.48 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.46 | 0.44 |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.50 |  |  |  |  |  |  |
| Other non operating income |  |  |  | 0.15 | 0.17 | 0.16 |  |  |  |  |
| Reimbursement of Expenses Paid |  |  |  | 0.08 |  |  |  |  |  |  |
| Security Deposits paid | 0.01 |  |  |  |  |  |  |  |  |  |
| Security Deposits refunded | 0.01 |  |  |  |  |  |  |  |  |  |
| Hitech Corporation Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  | 267 | 342 | 351 | 2.24 | 2.44 |  |  |
| Hitech Plast Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 261 | 238 |  |  |  |  |  |  |  |  |
| PPG Asian Paints Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Dividend received |  |  |  |  |  |  |  |  | 43 | 108 |
| Revenue from sale of products |  |  | 9.50 | 15 |  |  |  |  |  |  |
| Processing of Goods (Income) |  |  |  | 24 |  |  |  |  |  |  |
| Other non operating income |  |  | 8.50 | 11 |  |  |  |  |  |  |
| Processing Income |  |  |  |  |  |  | 13 | -0.13 | 2.86 | 1.98 |
| Processing and service income |  |  | 17 |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 2.59 | 1.67 | 1.04 | 2.67 |
| Purchase of Goods |  |  | 0.12 |  |  |  | 0.38 | 2.06 | 1.23 | 2.15 |
| Royalty Income |  |  |  | 3.94 |  |  | 0.40 | 0.50 | 0.32 | 0.29 |
| Royalty Received |  |  | 3.99 |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  | 0.71 | 0.93 | 0.25 | 0.14 |
| Reimbursement of Expenses Paid |  |  | 0.17 | 1.73 |  |  |  |  |  |  |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  | 0.30 | 0.87 |
| Reimbursement of Expenses - paid |  |  |  |  |  |  | 0.45 |  |  |  |
| Purchase of Assets |  |  |  |  |  |  |  | 0.42 |  | 0.01 |
| Reimbursement of Expenses Received |  |  | 0.19 | 0.24 |  |  |  |  |  |  |
| Reimbursement of Expenses - received |  |  |  |  |  |  | 0.23 |  |  |  |
| Sale of Assets |  |  |  |  |  |  |  |  |  | 0.18 |
| Processing charges |  |  |  |  |  |  | 0.14 | 0.01 |  |  |
| Processing Charges |  |  | 0.11 |  |  |  |  |  |  |  |
| Reimbursement for Expenses incurred by the Group on behalf of the related party |  |  |  |  |  |  |  | 0.08 |  |  |
| Reimbursement of Expenses Paid |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Reimbursement for Expenses incurred by related party on behalf of the Group |  |  |  |  |  |  |  | 0.02 |  |  |
| Smiti Holding And Trading Company Pvt Ltd Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 110 | 146 |
| Sattva Holding and Trading Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 109 | 145 |
| Parekhplast India Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  | 123 | 120 |  |  |  |  |
| Hitech Plast Limited. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 234 |  |  |  |  |  |  |  |
| Hitech Corporation Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 106 | 111 |
| Smiti Holding And Trading Company Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  | 56 | 48 | 99 |  |  |  |  |
| Asian Paints Office Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 9.17 | 10 | 31 |  | 51 | 36 |  | 4.14 | 4.53 | 5.77 |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 33 |  |  | 3.57 |  |  |  |
| Parekh Plast India Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods | 88 | 96 |  |  |  |  |  |  |  |  |
| Sattva Holding and Trading Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 27 | 102 |  |  |
| Dividend Paid |  |  |  | 54 |  |  |  |  |  |  |
| Parekh Plast India Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  | 110 |  |  | 69 |  |  |  |
| Smiti Holding and Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 100 |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 32 | 35 |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | -0.10 |  |  |
| Sattva Holding and Trading Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  |  |  | 47 | 98 |  |  |  |  |
| Asian Paints Factory Employees Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 5.26 | 5.52 | 20 |  | 35 | 29 |  | 2.88 |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 22 |  |  |  |  |  |  |
| PPG Asian Paints Pvt. Ltd. Associate |  |  |  |  |  |  |  |  |  |  |
| Processing of Goods (Income) |  |  |  |  | 20 | 17 |  |  |  |  |
| Revenue from sale of products |  |  |  |  | 18 | 12 |  |  |  |  |
| Other non operating income |  |  |  |  | 11 | 11 |  |  |  |  |
| Royalty Income |  |  |  |  | 3.78 | 3.61 |  |  |  |  |
| Reimbursement oF Expenses-Received |  |  |  |  | 0.33 | 0.92 |  |  |  |  |
| Sale of Assets |  |  |  |  | 0.27 | 0.48 |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  | 0.45 |  |  |  |  |  |
| Reimbursement oF Expenses-Paid |  |  |  |  | 0.12 | 0.13 |  |  |  |  |
| Parekhplast India Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  | 93 |  |  |  |  |  |  |  |
| Smiti Holding And Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 43 |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 27 |  |  |  |
| ISIS Holding and Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid to companies controlled by Directors / Relatives | 32 | 34 |  |  |  |  |  |  |  |  |
| Late Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 51 |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.34 |  |  |
| Nehal Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.42 | 25 | 15 |
| Remuneration |  |  |  |  |  |  |  | 0.03 | 0.42 | 0.42 |
| Asian Paints (I) Limited |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 24 | 19 |
| Shri. K.B.S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 9.72 |  | 12 | 14 |  |  |  |  |
| Retiral Benefits |  |  |  |  |  | 6.36 |  |  |  |  |
| ISIS Holding And Trading Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 42 |  |  |  |  |  |  |  |
| Varun Vakil Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.05 | 15 | 20 |
| Remuneration |  |  |  |  |  |  |  | 0.82 | 0.93 | 1.07 |
| Asian Paints (I) Limited Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  | 38 |  |  |
| Asian Paints (I) Ltd. Employees Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 25 | 10 |  |  |  |  |  |  |  |  |
| Asian Paints (India) Ltd. Employees' Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  | 7 | 26 |  |  |  |  |
| Asian Paints (India) Limited Employees' Gratuity Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  |  |  |  | 17 |  |  |  |
| Contributions during the year |  |  | 10 |  |  |  |  |  |  |  |
| Amit Syngle Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 6.66 | 10 | 8.82 |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  |  | 0.01 |
| Resins and Plastics Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 8.75 | 14 |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.02 | 0.01 |
| Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 6 | 6.58 | 8.90 |
| Remuneration |  |  |  |  |  |  |  | 0.36 | 0.44 | 0.45 |
| Ricinash Renewable Materials Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.58 | 20 |  |  |
| Resins and Plastics Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 6.09 | 10 |  |  |
| Sale of goods | 1.34 | 0.77 |  |  |  |  |  |  |  |  |
| Sale of assets | 0.28 | 0.24 |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | 0.14 |  |  |
| Shri. Jayesh Merchant Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.22 |  | 5.10 | 5.99 |  |  |  |  |
| Retiral Benefits |  |  |  |  |  | 4.18 |  |  |  |  |
| Amrita Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.66 | 5.11 | 6.78 |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.43 |
| Shri. Manish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.06 | 3.48 | 2.80 | 1.75 | 0.38 |  |  |  |
| Retiral Benefits |  |  |  |  | 3.50 |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.16 |  |  |  |
| Commission to |  |  |  |  | 0.22 | 0.29 |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 0.28 |  |  |  |
| Manish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 4.34 | 4.75 | 6.31 |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.46 | 0.46 |
| Late Shri. Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 14 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Retiral benefits |  |  |  |  |  |  | 0.07 |  |  |  |
| Jigish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.62 | 3.97 | 5.27 |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.42 |
| Shri K.B.S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 6.10 | 7.77 |  |  |  |  |  |  |  |  |
| Piramal Swasthya Management and Research Institute |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  |  | 1.55 | 2.30 | 2.46 | 3.21 | 3.51 |
| Asian Paints Management Cadres Superannuation Scheme |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year | 1.98 | 2.28 | 2.52 |  | 2.20 | 1.08 |  | 0.03 |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  | 2.47 |  |  | 0.06 |  |  |  |
| Ricinash Renewable Materials Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.95 | 12 |
| R J Jeyamurugan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 3.06 | 3.69 | 4.31 |
| Shri K. B. S. Anand Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  | 11 |  |  |  |  |  |  |
| ELF Trading And Chemical Manufacturing Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 4.20 | 5.57 |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.24 | 0.03 |
| Shri Jayesh Merchant Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.54 | 2.83 |  | 3.85 |  |  |  |  |  |  |
| Late Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 3.92 | 4.49 |
| Remuneration |  |  |  |  |  |  |  |  | 0.42 | 0.21 |
| Retiral benefits |  |  |  |  |  |  |  |  | 0.07 | 0.04 |
| RupalAnant Bhat Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  |  | 3.83 | 5.08 |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.07 | 0.02 |
| Asian Paints Factory Employees’ Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 3.27 | 3.68 |
| Paladin Paints And Chemicals Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 5.82 | 0.24 |
| Services Received |  |  |  |  |  |  |  |  | 0.09 | 0.02 |
| Shri. Jalaj Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  | 3.03 | 0.60 |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 2.32 |  |  |  |  |  |  |
| Shri Manish Choksi Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.56 | 2.92 |  |  |  |  |  |  |  |  |
| Shri Jalaj Dani Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.37 | 2.77 |  |  |  |  |  |  |  |  |
| Addverb Technologies Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Assets |  |  |  |  | 3.73 |  |  |  |  |  |
| Other Services Paid |  |  |  |  |  | 1.38 |  |  |  |  |
| Shri Amit Syngle Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 4.58 |  |  |  |
| Vikatmev Containers Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 2.23 | 1.53 |  |  |
| Dividend paid |  |  |  |  |  |  |  | 0.20 |  |  |
| Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.58 |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.36 |  |  |
| ELF Trading and Chemical Manufacturing Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  |  | 3.83 |  |  |
| Ankleshwar Industrial Development Society |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  | 3.17 | 0.21 | 0.27 |  |  | 0.01 |
| Services Received |  |  |  |  |  |  |  | -0.01 | -0.01 | 0.15 |
| Stack Pack Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 2.41 | 1.08 |
| Shri R J Jeyamurugan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  | 0.61 | 2.58 |  |  |  |
| Shri. Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.60 |  |  |  |
| Commission to |  |  |  |  | 0.30 | 0.27 |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.30 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.28 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Vikatmev Containers Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 1.02 | 1.59 |
| Dividend paid |  |  |  |  |  |  |  |  | 0.22 | 0.29 |
| Shri. Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 0.96 |  |  |  |
| Commission to |  |  |  |  | 0.35 | 0.32 |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.42 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.32 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.30 |  |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.07 | 0.07 |  |  |  |  |
| Retiral benefits |  |  | 0.07 |  |  |  | 0.07 |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.05 |  |  |  |  |  |  |  |
| Asian Paints Factory Employees' Provident Fund |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year (includes Employees' share and contribution) |  |  |  |  |  |  | 2.78 |  |  |  |
| Port Villa Hardware Ltd Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 1.15 | 1.63 |  |  |  |  |  |  |  |  |
| Shri. Varun Vakil Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  | 0.45 | 0.54 | 0.64 |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.08 |  |  |  |
| Obgenix Software Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  |  |  | 0.26 | 0.62 |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.71 | 0.03 |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  | 0.18 | 0.26 |
| Royalty Income |  |  |  |  |  |  |  |  | 0.13 | 0.03 |
| Al Hasan Engineering Co. SAOG Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 1.42 | 0.78 |  |  |  |  |  |  |  |  |
| Hitech Specialities Solutions Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.18 | 1.86 |  |  |
| Ms. Amrita Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 1.24 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Shardul Amarchand Mangaldas & Co. |  |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  |  |  |  |  | 0.76 |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.70 |  |  |  |
| Other Services Paid |  |  |  |  |  | 0.29 |  |  |  |  |
| Stack Pack Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.34 | 1.40 |  |  |
| Santo Hardware Ltd Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 0.95 | 0.75 |  |  |  |  |  |  |  |  |
| Shri. Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.28 | 0.25 |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.08 | 0.07 |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.07 | 0.06 |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.07 |  |  |  |  |  |  |
| Retiral benefits |  |  | 0.07 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.06 |  |  |  |  |  |  |  |
| Paladin Paints and Chemicals Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  | 1.02 |  |  |
| Services Received |  |  |  |  |  |  |  | 0.56 |  |  |
| Shri. Jigish Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  |  |  |  | 0.97 |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Commission to |  |  |  |  |  | 0.25 |  |  |  |  |
| PPG Industries Securities LLC Associate |  |  |  |  |  |  |  |  |  |  |
| Other Recoveries | 1.03 | 0.19 |  |  |  |  |  |  |  |  |
| Purchase of Assets | 0.03 | 0.19 |  |  |  |  |  |  |  |  |
| Ms. Amrita Amar Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.26 |  |  | 0.28 | 0.25 |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.04 | 0.05 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Addverb Technologies Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Advance given |  |  |  | 0.88 |  |  |  |  |  |  |
| Purchase of Assets |  |  |  | 0.44 |  |  |  |  |  |  |
| Suresh Narayanan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.46 | 0.46 |
| R Seshasayee Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.38 | 0.44 | 0.47 |
| Asian Paints Industrial Coatings Limited |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 0.26 | 0.99 |
| Vibha Paul Rishi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.35 | 0.44 | 0.45 |
| Santo Hardware Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.21 |  |  |  |  |  |  |  |
| Orasscom Construction Industries |  |  |  |  |  |  |  |  |  |  |
| Sale of goods | 0.38 | 0.51 |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 0.32 |  |  |  |  |  |  |  |
| Pallavi Shroff Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.34 | 0.42 | 0.42 |
| Port Villa Hardware Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 1.18 |  |  |  |  |  |  |  |
| Deepak Satwalekar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.40 | 0.50 | 0.25 |
| Milind Sarwate Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.14 | 0.48 | 0.48 |
| Paladin Paints And Chemicals Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.55 |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.52 |  |  |  |
| Navbharat Packaging Industries Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.57 | 0.39 |  |  |
| Shri. Mahendra Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.28 |  |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.28 |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.26 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.06 |  |  |  |  |  |  |  |
| Shri Thakur Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.41 | 0.43 |  |  |  |  |  |  |  |  |
| Shri Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.28 | 0.34 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.07 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.03 | 0.04 |  |  |  |  |  |  |  |  |
| Shri Ashwin Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.26 | 0.30 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.07 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.06 |  |  |  |  |  |  |  |  |
| Shri Abhay Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.26 |  |  |  |  |  |  |  |  |
| Retiral Benefits | 0.07 | 0.08 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.08 |  |  |  |  |  |  |  |  |
| Shardul Amarchand Mangaldas & Co |  |  |  |  |  |  |  |  |  |  |
| Services Received |  |  |  |  |  |  |  |  | 0.44 | 0.31 |
| Late Shri. Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to Non Executive Directors |  |  |  | 0.36 |  |  |  |  |  |  |
| Commission to |  |  |  |  | 0.18 |  |  |  |  |  |
| Retiral Benefits |  |  |  | 0.07 | 0.03 |  |  |  |  |  |
| Shri Mahendra C Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.24 | 0.27 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.05 | 0.06 |  |  |  |  |  |  |  |  |
| Shri Malav Dani Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.22 | 0.27 |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to | 0.04 | 0.05 |  |  |  |  |  |  |  |  |
| Dr. S. Sivaram Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 | 0.18 |  |  |
| Navbharat Packaging Industries Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.30 | 0.22 |
| Shri. Ashwin Choksi Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to Promoter - Non Executive Directors |  |  | 0.34 |  |  |  |  |  |  |  |
| Retiral benefits |  |  | 0.08 |  |  |  |  |  |  |  |
| Sitting Fees Paid to Promoter -Non Executive Directors |  |  | 0.04 |  |  |  |  |  |  |  |
| Mr Thakur Ahuja |  |  |  |  |  |  |  |  |  |  |
| Rent Paid |  |  | 0.45 |  |  |  |  |  |  |  |
| Riash Renewable Materials Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  | -0.88 | 1.31 |
| Addverb Technologies Pvt Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other Services - paid |  |  |  |  |  |  | 0.39 |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  | 0.03 |  |  |  |
| M.K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  | 0.40 |  |  |
| Shri. M.K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.40 |  |  |  |
| Shri. Suresh Narayanan Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.38 |  |  |  |
| Shri. R Seshasayee Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.36 |  |  |  |
| Shri Rajesh T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 | 0.18 |  |  |  |  |  |  |  |  |
| Shri Monesh T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 | 0.18 |  |  |  |  |  |  |  |  |
| Shri. Deepak Satwalekar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Mrs. Pallavi Shroff Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| Mrs. Vibha Paul Rishi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  | 0.34 |  |  |  |
| LKP Hardware |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products |  |  | 0.32 |  |  |  |  |  |  |  |
| Ireena Vittal Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  |  |  | 0.28 |
| AR Intertect Design Private Ltd. |  |  |  |  |  |  |  |  |  |  |
| Other services - Paid | 0.11 | 0.17 |  |  |  |  |  |  |  |  |
| Pratham Education Foundation |  |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility Expenses |  |  |  |  |  | 0.22 | 0.03 |  |  |  |
| Addverb Technologies Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from sale of products & services |  |  |  |  |  |  |  |  |  | 0.20 |
| Services Received |  |  |  |  |  |  |  |  |  | 0.03 |
| Shri Thakur T. Ahuja Associate |  |  |  |  |  |  |  |  |  |  |
| Security Deposits paid | 0.18 |  |  |  |  |  |  |  |  |  |
| Other services - Paid | 0.05 |  |  |  |  |  |  |  |  |  |
| Soumitra Bhattacharya Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration |  |  |  |  |  |  |  |  |  | 0.18 |
| ARI Designs LLP |  |  |  |  |  |  |  |  |  |  |
| Other Services Paid |  |  | 0.10 | 0.04 | 0.03 |  |  |  |  |  |
| Resins & Plastics Limited. |  |  |  |  |  |  |  |  |  |  |
| Sale of Asset |  |  | 0.15 |  |  |  |  |  |  |  |
| Smiti Holding And Trading Company Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.14 |  |
| Addverb Technologies Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | 0.07 |  |  |
| Services Received |  |  |  |  |  |  |  | 0.07 |  |  |
| Shri M K Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.08 | 0.06 |  |  |  |  |
| Gujarat Organics Limited |  |  |  |  |  |  |  |  |  |  |
| Sale of assets | 0.12 |  |  |  |  |  |  |  |  |  |
| Hydra Trading Pvt Ltd |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  |  | 0.11 |  |
| Pragati Chemicals Ltd. |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  | 0.10 |  |  |  |
| Sale of assets | 0.01 |  |  |  |  |  |  |  |  |  |
| M/s. MRJ Industries Associate |  |  |  |  |  |  |  |  |  |  |
| Rent Paid | 0.05 | 0.01 |  |  |  |  |  |  |  |  |
| Security Deposits refunded | 0.02 | 0.02 |  |  |  |  |  |  |  |  |
| Shri. M. K. Sharma Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.08 |  |  |  |  |  |  |
| M/s. Ess Ess Industries Associate |  |  |  |  |  |  |  |  |  |  |
| Sale of assets |  | 0.08 |  |  |  |  |  |  |  |  |
| Ricinash Oil Mills Ltd. |  |  |  |  |  |  |  |  |  |  |
| Sale of assets | 0.08 |  |  |  |  |  |  |  |  |  |
| Shri Mahendra Shah Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to |  |  |  |  | 0.07 |  |  |  |  |  |
| Shri. Mahendra Shah Key Person |  |  |  |  |  |  |  |  |  |  |
| Sitting Fees Paid to Non Executive Directors |  |  |  | 0.06 |  |  |  |  |  |  |
| Asian Paints Management Cadres’ Superannuation Scheme |  |  |  |  |  |  |  |  |  |  |
| Contributions during the year |  |  |  |  |  |  |  |  | 0.04 |  |
| Shri Amar A Vakil Key Person |  |  |  |  |  |  |  |  |  |  |
| Commission to | 0.03 |  |  |  |  |  |  |  |  |  |
| Revocoat India Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other Non Operating Income |  |  |  |  |  |  |  | 0.02 | -0.02 | 0.01 |
| Reimbursement of Expenses Received |  |  |  |  |  |  |  |  |  | 0.01 |
| Hitech Specialities Solutions Ltd |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods |  |  |  |  |  |  |  |  | 0.01 | 0.01 |
| Hydra Trading Pvt. Ltd. |  |  |  |  |  |  |  |  |  |  |
| Revenue from Sale of Products |  |  |  |  |  |  |  | -0.14 |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 10,504 | 12,220 | 13,615 | 14,271 | 15,062 | 16,825 | 19,240 | 20,211 | 21,713 | 29,101 | 34,489 | 35,495 | 35,282 |
| Expenses + | 8,767 | 10,217 | 11,372 | 11,546 | 12,068 | 13,621 | 15,475 | 16,054 | 16,857 | 24,298 | 28,229 | 27,910 | 28,125 |
| Operating Profit | 1,737 | 2,004 | 2,243 | 2,725 | 2,994 | 3,204 | 3,765 | 4,157 | 4,856 | 4,804 | 6,260 | 7,585 | 7,157 |
| OPM % | 17% | 16% | 16% | 19% | 20% | 19% | 20% | 21% | 22% | 17% | 18% | 21% | 20% |
| Other Income + | 114 | 124 | 142 | 213 | 338 | 336 | 274 | 355 | 332 | 296 | 431 | 821 | 786 |
| Interest | 42 | 48 | 42 | 49 | 37 | 41 | 110 | 102 | 92 | 95 | 144 | 205 | 215 |
| Depreciation | 155 | 246 | 266 | 276 | 335 | 360 | 622 | 780 | 791 | 816 | 858 | 853 | 882 |
| Profit before tax | 1,655 | 1,834 | 2,077 | 2,614 | 2,960 | 3,138 | 3,306 | 3,629 | 4,304 | 4,188 | 5,689 | 7,348 | 6,846 |
| Tax % | 30% | 31% | 31% | 32% | 32% | 33% | 33% | 24% | 26% | 26% | 26% | 24% |  |
| Net Profit + | 1,160 | 1,263 | 1,427 | 1,803 | 2,016 | 2,098 | 2,208 | 2,774 | 3,207 | 3,085 | 4,195 | 5,558 | 5,170 |
| EPS in Rs | 11.61 | 12.71 | 14.54 | 18.19 | 20.22 | 21.26 | 22.48 | 28.20 | 32.73 | 31.59 | 42.81 | 56.92 | 52.96 |
| Dividend Payout % | 40% | 42% | 42% | 41% | 51% | 41% | 47% | 43% | 55% | 61% | 60% | 58% |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 31% |  |  |  |  |  |  |  |  |  |  |  |  |

