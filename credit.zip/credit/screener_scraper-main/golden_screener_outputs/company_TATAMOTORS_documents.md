# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/tata-motors-ltd/tatamotors/500570/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ac3751f4-c163-438d-abc8-790a54405490.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation
19 Jul - Read with Schedule III of Part A of para A of the SEBI (LODR) Regulations, 2015 and with further reference to our letter bearing sc …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d134a6fb-ee5a-4ca8-aee3-572188a741b2.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 18 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=090a4611-19e4-42de-b980-580f136c92d3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ccf6d5c2-2b2b-4e2f-a816-2332b4002462.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23bd9f51-3d07-4e7b-9303-6e000dd0b052.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0913b647-b205-4a3c-ad9b-8c493f97f972.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\b089df52-72ff-4b10-9c63-8375fa1f7d7e.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500570/73198500570.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500570/68662500570_30_06_21.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_792_TATAMOTORS_2012_2013_29072013120804.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500570/5005700311.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/apr-2015/tata-motors-limited_29517.html)

## Credit Ratings
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407140700_Tata_Motors_Limited.pdf)
- [Rating update
13 Jun from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128075)
- [Rating update
13 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TataMotorsLimited_June%2013_%202024_RR_345536.html)
- [Rating update
2 Apr from care](https://www.careratings.com/upload/CompanyFiles/PR/202404130426_Tata_Motors_Limited.pdf)
- [Rating update
13 Mar from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=126168)
- [](https://www.careratings.com/upload/CompanyFiles/PR/202403150317_Tata_Motors_Limited.pdf)

## Concalls
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/06/tata-motors-group-investor-day-presentation.pdf)
- [Transcript](https://www.bseindia.com/xml-data/corpfiling/AttachLive/cfd0020f-d9cc-4148-9606-10eb86705ffd.pdf)
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/05/q4fy24-presentation-1.pdf)
- [PPT](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/05/q4fy24-presentation-1.pdf)
- [Transcript](https://www.bseindia.com/xml-data/corpfiling/AttachHis/c11e47a4-1619-4267-ab64-7a9a14e11ed8.pdf)
- [PPT](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/02/Tata-Motors-Investor-presentation-Q3-FY24.pdf)
- [PPT](https://www.tatamotors.com/wp-content/uploads/2024/02/Tata-Motors-Investor-presentation-Q3-FY24.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3a82121b-4528-440d-ad7f-22728f47a946.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ceb2ac38-d83d-4813-9e2f-00a2cff253c0.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/11/q2fy24-presentation.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/07/tata-motors-group-earnings-call-transcript-q1-fy24.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f58e98cb-d41f-4c7d-94eb-b3975f3d31d5.pdf)
- [](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/01/q1fy24-earnings-call-transcript.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2023/07/tata-motors-group-investor-presentation-Q1FY24.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0c81a1b7-bdef-4df1-bd2e-7cb362f50beb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d3a17db2-17f5-43db-b69c-d272318bf3b7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f4edb2c0-78a7-4290-8dea-57f978bb853d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a16e0aea-e5b0-499e-a8a5-f0911a51e244.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94c9b207-6c8c-4952-b062-f2066cb94cd7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b0c9d9f9-4979-497e-8d29-b2f0ccf23fdb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5fd9edb5-f6fe-4b62-995e-064e36132674.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfe41f3c-ac3b-44b4-8fb0-ed1053c02ac9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b95fcfc0-d452-417f-bb4f-e20ea498ad12.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=27b1a9d0-5db1-4b19-a21e-b1a1cb7d4bba.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=937faf1d-7146-49da-a10e-d51814b31845.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d63bde0d-0952-4676-88a6-6d33b4bb2fc1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1663bbdd-d52f-4b86-8748-f1bd32c2a511.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8f9c4280-a237-4f49-9330-8a4e248ec7aa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9ce25fee-c848-4a6b-909b-698598cd175a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=155a79a8-fe08-44fe-bff0-d40f096a4b19.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2022/02/Q3-FY22-earnings-call-transcript.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/11/tata-motors-q2-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d17cbf0c-457f-4102-ae50-a849dedf1088.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3e09439f-c4dc-425b-8426-8cb2cfabbec4.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/10/22093739/ev-business-analyst-investor-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=edb3c3f4-8baa-4472-b2e4-17400549c8bd.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/08/03093742/Earnings-Call-Transcript-Q1FY22.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8859359d-1248-468e-b7e4-aa9974c5e124.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/05/31080653/tata-motors-group-analyst-call-transcript-q4fy21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5cc79501-158a-4991-bc24-5650ba5b4b0b.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2021/02/05110935/TATA-Motors-Analyst-Jan29-2021.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2020/11/04071425/TM-Concall-Transcript-Q2FY21.pdf)
- [](https://www.tatamotors.com/wp-content/uploads/2020/08/14045300/Tata-Motors-Webcast-Audio-31-July-2020.pdf)
- [](https://aicl-mum-bucket.s3.ap-south-1.amazonaws.com/Production/www-tatamotors-com-NEW/wp-content/uploads/2024/03/Results-Concall-Transcript-TML-Q1-FY-17.pdf)

