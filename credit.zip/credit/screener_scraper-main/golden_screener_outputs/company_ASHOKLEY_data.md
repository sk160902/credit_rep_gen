About
[
edit
]
Ashok Leyland is the flagship Company of the Hinduja group, having a long-standing presence in the domestic medium and heavy commercial vehicle (M&HCV) segment. The company has a strong brand and well-diversified distribution and service network across the country and has a presence in 50 countries, it is one of the most fully-integrated manufacturing companies. Its headquarter is in Chennai
[1]
They manage driver training institutes across India and have trained over 8,00,000 drivers since inception.
[1]
Key Points
[
edit
]
Market Leadership
The Company is the second largest manufacturer of commercial vehicles in India in the medium and heavy commercial vehicle segment, fourth largest manufacturer of buses in the world and the fifteenth largest manufacturer of trucks globally.
[1]
Segment Performance
M&HCV Truck Segment
The Co.’s sales in the M&HCV Trucks segment (excluding Defence vehicles) in India grew by ~44% in FY22. It enhanced its product portfolio with CNG models in the ICV trucks segment to cater to the boost in demand for alternate fuels in ecommerce and last-mile delivery applications. Further, product enhancements like High Horsepower Mining Tipper and Surface Tipper, helped the Co. to strengthen its presence in the Construction and Mining industry. It pioneered in launching 8x2 Multi-Axle Truck with Dual Tyre Lift Axle and 6x2 Multi-Axle Truck with Single Tyre Lift Axle.
[2]
M&HCV Bus Segment
The Co.’s sales in the M&HCV Bus segment (excluding Defence vehicles) in India grew by ~11% in FY22. It was able to achieve a market share of ~27% in the M&HCV Bus and Truck segment.
[2]
LCV Segment
The Co. continues to deliver best-in-industry SSI/CSI, lowest defect product, low warranty cost and high service retention through its network of 547 outlets, achieving a service market share of 70.0%. Its new product ‘Bada Dost’ was awarded ‘CV of Year’ and ‘Pick up of the Year 2021-22’. It is on track to launch 3 new products in FY23 for the domestic market.
[3]
Defense
In FY22, the Co. supplied all time high 1,125 units of completely built-up units (CBUs) including bullet proof vehicles and 600 kits. It completed the execution of 711 Ambulances in record time under emergency procurement of the Indian Army. Further, it is expanding its portfolio in Light Vehicles, new applications on the Super Stallion platform and products specific to export markets.
[3]
Foundry Division
The Foundry Division of the Co. mainly caters to the automotive industry in product segments of Cylinder Block, Head and Tractor Housings. In FY22, the Foundry division increased production by 20% and achieved a sales growth of 12% as compared to FY21.
[3]
Revenue Mix FY22
Commercial Vehicle - 88%
Financial Service - 12%
[4]
Geographical Split FY22
India - 89%
Outside India - 11%
[4]
International market
The Co. focused on expanding its global footprint across retail markets in Africa, and continued strengthening its network in SAARC and GCC countries. It observed overall I/O sales growth of 37% over FY21. Penetration in LCV portfolio across geographies was achieved while retaining market leadership position in MDV bus segment in SAARC and GCC countries.
[2]
Manufacturing Facilities
The Co. has 5 manufacturing plants in India, and 1 each in UAE, Bangladesh and Srilanka.
[5]
[6]
Distribution Network
The Co. added 71 new outlets during FY22, increasing the total count to 907 primary touch-points. To keep up with the rising commercial vehicle operations in Northern and Eastern regions of India, it opened more than half of the new outlets in these regions.
[3]
Fundraise
During FY22, the Co. issued and allotted on private placement basis, secured redeemable non-convertible debentures (NCDs) aggregating to Rs. 200 Crores. Additionally, fresh secured rupee term loans of Rs. 450 Crores were availed during the year. It repaid rupee term loan installments amounting to Rs. 12.50 Crores on the due date during the year.
[7]
Subsidiary
Hinduja Tech Limited (HTL) has ceased to be a wholly owned subsidiary of the Co., consequent to the exercise of stock options by HTL employees pursuant to ‘Hinduja Tech Limited Employees Stock Option Plan 2017’. It currently holds 98.91% in the paid up equity share capital of HTL.
[8]
Transfer of Business
During FY22, the Co. transferred its Electric Vehicle business to Switch Mobility Automotive Limited, step-down subsidiary of the Co. on slump sale basis. Further, it is in the process of transferring its E-MaaS business to Ohm Global Mobility Private Limited, a fellow subsidiary, on a slump sale basis.
[8]
Capex
During FY22, the Co. incurred Rs. 400 Crores towards capital expenditure predominantly towards:
a) Improving manufacturing capacity and capability covering LCV Engines, Frame Side member, SG Cast Iron, Cab Paint &Trim and Chassis Assembly;
b) New products covering Project Vayu (CNG vehicles development), Low Cost EATS development & Emission migration Projects (BS Construction Equipment Vehicle {CEV IV} and BS VI Phase 2); and
c) Unit replacement & maintenance capex for sustenance
[9]
Changes in KMP
Mr. Vipin Sondhi, Managing Director and CEO of the Company stepped down from the Board with effect from December 31, 2021. The BOD at their meeting held on November 26, 2021 appointed Mr. Dheeraj G Hinduja as the Executive Chairman (Whole-time) of the Company, for a period of three years commencing from November 26, 2021 to November 25, 2024.
[8]
Investments
In FY22, the Co. invested Rs. 10 Crores in Gro Digital, Rs. 4 Crores in Ashley Aviation and Rs. 3 Crores in Ashley Alteams. Therefore, it has invested Rs. 17 Crores in aggregate by cash in joint venture/associates/subsidiaries. In addition, Rs. 4 Crore loan has been converted into equity in Albonair GmBH. It has done an impairment reversal of equity investment in Optare Plc for Rs. 781 Crores. There had also been impairments of Rs. 350 Crores during FY22 (Hinduja Energy Rs. 107 Crores, Albonair GmbH Rs. 239 Crores and Ashley Aviation Rs. 4 Crores).
[9]
Last edited 5 months, 4 weeks ago
Request an update
© Protected by Copyright
