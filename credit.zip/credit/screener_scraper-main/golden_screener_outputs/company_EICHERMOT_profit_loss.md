# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Dec 2012 | Dec 2013 | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 6,390 | 6,810 | 8,738 | 6,173 | 7,033 | 8,965 | 9,797 | 9,154 | 8,720 | 10,298 | 14,442 | 16,536 |
| Expenses + | 5,840 | 6,094 | 7,621 | 4,484 | 4,859 | 6,156 | 6,893 | 6,971 | 6,937 | 8,120 | 10,996 | 12,209 |
| Operating Profit | 550 | 715 | 1,118 | 1,690 | 2,174 | 2,809 | 2,904 | 2,183 | 1,783 | 2,178 | 3,446 | 4,327 |
| OPM % | 9% | 11% | 13% | 27% | 31% | 31% | 30% | 24% | 20% | 21% | 24% | 26% |
| Other Income + | 136 | 93 | 105 | 326 | 416 | 536 | 701 | 572 | 482 | 496 | 908 | 1,524 |
| Interest | 4 | 8 | 10 | 2 | 4 | 5 | 7 | 19 | 16 | 19 | 28 | 51 |
| Depreciation | 82 | 130 | 220 | 137 | 154 | 223 | 300 | 382 | 451 | 452 | 526 | 598 |
| Profit before tax | 600 | 671 | 993 | 1,877 | 2,433 | 3,116 | 3,297 | 2,355 | 1,798 | 2,203 | 3,800 | 5,202 |
| Tax % | 21% | 22% | 29% | 29% | 30% | 30% | 33% | 22% | 25% | 24% | 23% | 23% |
| Net Profit + | 475 | 525 | 702 | 1,338 | 1,667 | 1,960 | 2,203 | 1,827 | 1,347 | 1,677 | 2,914 | 4,001 |
| EPS in Rs | 12.01 | 14.57 | 22.71 | 49.27 | 61.27 | 71.89 | 80.75 | 66.91 | 49.28 | 61.32 | 106.55 | 146.13 |
| Dividend Payout % | 17% | 21% | 22% | 20% | 16% | 15% | 15% | 19% | 34% | 34% | 35% | 35% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 37% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 47% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 24% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Dec 2014 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| VE Commercial Vehicles Limited JV |  |  |  |  |  |  |  |  |  |
| Investment in equity share capital |  |  | 1,571 |  |  |  |  |  |  |
| Purchase of raw materials and components / services |  |  |  | 160 | 172 | 147 | 127 | 1.51 | 2.41 |
| Bills discounted |  |  |  |  |  |  | 459 | 6.77 | 5.89 |
| Purchase of finished goods/services |  |  | 146 |  |  |  |  |  |  |
| Trade payables |  |  |  |  | 51 | 35 | 30 | 0.42 | 0.56 |
| Payables |  |  | 33 |  |  |  |  |  |  |
| Corporate service charges paid |  |  | 2.60 | 2.43 | 2.53 | 1.58 | 1.69 | 0.02 | 0.02 |
| Discount on bills |  |  |  |  |  |  | 9.52 | 0.34 | 0.40 |
| Expenses reimbursed |  |  | 0.43 | 0.35 | 0.49 | 0.50 | 0.22 |  |  |
| Tooling advance given |  |  |  |  |  | 0.60 |  |  |  |
| Advances |  |  |  |  |  | 0.60 |  |  |  |
| Expenses recovered |  |  |  |  |  |  |  | 0.01 | 0.02 |
| Eicher Polaris Private Limited JV |  |  |  |  |  |  |  |  |  |
| Investment in equity share capital |  |  | 175 |  | 30 | 0.99 |  |  |  |
| Investment in equity share capital (including |  |  | 46 |  |  |  |  |  |  |
| Investment in equity share capital (including advance given in previous year) |  |  |  | 28 |  |  |  |  |  |
| Advance given for subscription of equity shares |  |  | 11 |  |  |  |  |  |  |
| Advances |  |  | 11 |  |  |  |  |  |  |
| Rent income |  |  | 2.78 | 2.92 | 0.26 |  |  |  |  |
| Expenses recovered |  |  | 1.07 | 0.05 |  |  |  |  |  |
| Investment in equity share capital - Allotted |  |  |  |  |  |  | 0.99 |  |  |
| Purchase of fixed assets |  |  |  |  |  | 0.55 |  |  |  |
| Eicher Group Foundation JV |  |  |  |  |  |  |  |  |  |
| Corporate social responsibility expenditure |  |  |  | 25 | 43 | 53 | 56 | 0.53 | 0.45 |
| Contribution for CSR expenditure |  |  | 18 |  |  |  |  |  |  |
| Receivable of surplus on CSR unspent fund |  |  |  |  |  |  |  | 0.02 |  |
| EGPL |  |  |  |  |  |  |  |  |  |
| Brand fees | 27 | 51 |  |  |  |  |  |  |  |
| Payables | 26 | 47 |  |  |  |  |  |  |  |
| Rent Paid | 11 | 14 |  |  |  |  |  |  |  |
| Security deposit receivable | 4.60 | 4.60 |  |  |  |  |  |  |  |
| Expenses reimbursed |  | 2.38 |  |  |  |  |  |  |  |
| Corporate service charges paid |  | 0.91 |  |  |  |  |  |  |  |
| Purchase of finished goods/services |  | 0.03 |  |  |  |  |  |  |  |
| Eicher Goodearth India Private Limited |  |  |  |  |  |  |  |  |  |
| Brand fees |  |  |  | 6.31 | 24 | 23 | 22 | 0.25 | 0.05 |
| Trade payables |  |  |  | 6.31 | 24 | 23 | 22 | 0.25 | 0.05 |
| AB Volvo |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 26 | 67 |  |  |  |  |  |  |  |
| Eicher Goodearth Private Limited |  |  |  |  |  |  |  |  |  |
| Rent |  |  |  | 3.42 | 4.69 | 4.81 | 4.72 | 0.05 | 0.04 |
| Brand fees paid |  |  | 18 |  |  |  |  |  |  |
| Trade payables |  |  |  | 16 |  |  |  |  |  |
| Brand fees |  |  |  | 16 |  |  |  |  |  |
| Expenses reimbursed |  |  | 6.28 |  |  |  |  |  |  |
| Corporate service charges paid |  |  | 0.83 | 0.88 | 1.16 | 0.97 | 0.73 | 0.01 | 0.01 |
| Security deposits receivable |  |  |  | 1.09 | 1.09 | 1.09 | 1.09 | 0.01 | 0.01 |
| Rent paid |  |  | 3.33 |  |  |  |  |  |  |
| Security deposit receivable |  |  | 1.09 |  |  |  |  |  |  |
| Payables |  |  | 0.23 |  |  |  |  |  |  |
| Rent payable |  |  |  |  |  |  | 0.19 |  |  |
| Sunshine Automobiles Relative |  |  |  |  |  |  |  |  |  |
| Sale of motorcycles, spares, Apparel and accessories |  |  |  |  |  | 34 | 31 |  |  |
| Advances received towards Vehicles, spares, apparel and accessories sales |  |  |  |  |  | 1.31 |  |  |  |
| Advances received towards vehicles, spares, apparel and accessories sales |  |  |  |  |  |  | 0.93 | 0.01 |  |
| Payment for Free service coupon and warranty claims |  |  |  |  |  | 0.46 | 0.41 |  | 0.01 |
| Security deposit payable |  |  |  |  |  |  | 0.02 |  |  |
| Security deposit received |  |  |  |  |  |  | 0.01 |  |  |
| Security deposits receivable |  |  |  |  |  | 0.01 |  |  |  |
| Mr. Vinod K. Dasari Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  | 28 | 15 | 0.12 |  |
| Share based payments |  |  |  |  |  |  | 10 | 0.13 |  |
| Variable pay |  |  |  |  |  |  | 4.03 |  |  |
| Commission payable |  |  |  |  |  | 3.73 |  |  |  |
| Post-employment benefits |  |  |  |  |  | 0.39 | 0.40 |  |  |
| Other long-term benefits |  |  |  |  |  | 0.12 | 0.16 |  |  |
| Mr. Siddhartha Lal Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  | 4.20 |  | 5.28 | 5.07 | 7.62 | 0.09 | 0.12 |
| Salary (including perquisites) |  |  |  |  |  |  | 14 | 0.13 | 0.14 |
| Short-term benefits |  |  | 9.20 |  |  |  |  |  |  |
| Commission |  |  |  |  |  |  | 6.70 | 0.08 | 0.10 |
| Statutory contributions |  |  |  |  |  |  | 1.81 | 0.03 | 0.03 |
| Post-employment benefits |  |  | 0.33 |  |  |  |  |  |  |
| Other long-term benefits |  |  | 0.17 |  |  |  |  |  |  |
| Mr. Siddhartha Lai Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  | 10 | 13 | 19 |  |  |  |
| Commission payable |  |  |  | 4.80 |  |  |  |  |  |
| Post-employment benefits |  |  |  | 0.14 | 0.06 |  |  |  |  |
| Other long-term benefits |  |  |  | 0.05 | 0.06 |  |  |  |  |
| VE CommercialVehicles Limited JV |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  | 46 |  |  |  |  |  |
| EPPL JV |  |  |  |  |  |  |  |  |  |
| Sale of finished goods/services | 6.39 | 7.51 |  |  |  |  |  |  |  |
| Rental income | 2.49 | 3.28 |  |  |  |  |  |  |  |
| Receivables | 0.45 | 0.36 |  |  |  |  |  |  |  |
| Expenses recovered | 0.38 | 0.08 |  |  |  |  |  |  |  |
| Corporate service charges recovered | 0.15 | 0.02 |  |  |  |  |  |  |  |
| Others |  | 0.08 |  |  |  |  |  |  |  |
| Advance from customer |  | 0.03 |  |  |  |  |  |  |  |
| Eicher Executive Provident Fund |  |  |  |  |  |  |  |  |  |
| Contribution to provident fund |  |  |  | 3.55 | 4.71 | 6.57 | 0.59 | 0.01 | 0.01 |
| Contribution |  |  | 2.59 |  |  |  |  |  |  |
| Mr Siddhartha Lal Key Person |  |  |  |  |  |  |  |  |  |
| Managerial remuneration | 5.37 | 8.49 |  |  |  |  |  |  |  |
| Mr. Lalit Malik Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  | 2.51 | 2.06 | 4.68 | 3.69 | 0.28 |  |  |
| Post-employment benefits |  |  | 0.05 | 0.04 | 0.04 | 0.07 |  |  |  |
| Other long-term benefits |  |  | 0.05 |  | 0.03 | 0.06 |  |  |  |
| Eicher Motors Limited Employees Gratuity Trust |  |  |  |  |  |  |  |  |  |
| Contribution to gratuity fund |  |  |  |  | 4.35 | 4.70 | 4.31 |  |  |
| Sale of motorcycles, spares, Apparel and accessories |  |  |  |  |  |  |  | 0.36 | 0.42 |
| Benefits paid |  |  |  |  | -1.42 | -2.64 | -2.61 | -0.04 | -0.04 |
| Mr. Manhar Kapoor Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  | 0.82 | 0.88 | 1.98 | 1.28 | 1.38 | 0.01 |  |
| Post-employment benefits |  |  | 0.02 | 0.01 | 0.02 | 0.02 | 0.02 |  |  |
| Other long-term benefits |  |  | 0.01 | 0.01 | 0.02 | 0.02 | 0.02 |  |  |
| Non-executive and independent directors Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  |  | 0.96 | 0.92 | 0.79 | 0.87 | 0.01 | 0.01 |
| Eicher Motors Limited Employee Gratuity Trusts |  |  |  |  |  |  |  |  |  |
| Contribution |  |  |  | 4.50 |  |  |  |  |  |
| Benefits paid |  |  |  | -1.39 |  |  |  |  |  |
| Mr. S. Sandilya Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.48 | 0.53 | 0.57 | 0.57 | 0.63 |  |  |
| Sitting fees |  |  | 0.03 | 0.03 | 0.04 | 0.05 | 0.06 |  |  |
| Mr. Kaleeswaran Arunachalam Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  | 1.85 | 0.02 | 0.01 |
| Other long-term benefits |  |  |  |  |  |  | 0.02 |  |  |
| Post-employment benefits |  |  |  |  |  |  | 0.02 |  |  |
| Eicher Tractors Executive Staff Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Contribution to superannuation fund |  |  |  |  | 0.33 | 0.44 | 0.02 |  |  |
| Contribution |  |  | 0.25 |  |  |  |  |  |  |
| Contribution to gratuity fund |  |  |  |  |  |  |  | 0.08 | 0.14 |
| Non-Executive and Independent Directors Key Person |  |  |  |  |  |  |  |  |  |
| Commission payable |  |  | 1.02 |  |  |  |  |  |  |
| Nicobar Design Private Limited |  |  |  |  |  |  |  |  |  |
| Rent income |  |  |  |  | 0.99 |  |  |  |  |
| EML Employees Company Gratuity Scheme |  |  |  |  |  |  |  |  |  |
| Contribution |  |  | 1 |  |  |  |  |  |  |
| Benefits paid |  |  | -0.25 |  |  |  |  |  |  |
| Mr R.L. Ravichandran Key Person |  |  |  |  |  |  |  |  |  |
| Managerial remuneration | 0.68 |  |  |  |  |  |  |  |  |
| Ms. Manvi Sinha Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 |  | 0.11 | 0.11 | 0.12 |  |  |
| Sitting fees |  |  | 0.01 |  | 0.03 | 0.05 | 0.05 |  |  |
| Mr. Prateek Jalan Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.21 |  | 0.18 |  |  |  |  |
| Sitting fees |  |  | 0.03 |  | 0.02 |  |  |  |  |
| Mr. Inder Mohan Singh Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  |  | 0.04 | 0.11 | 0.12 |  |  |
| Sitting fees |  |  |  |  | 0.01 | 0.05 | 0.06 |  |  |
| EicherTractors Executive Staff Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Contribution to superannuation fund |  |  |  | 0.31 |  |  |  |  |  |
| Ms. Natasha Jamal Relative |  |  |  |  |  |  |  |  |  |
| Sale of vehicle |  |  |  |  |  | 0.30 |  |  |  |
| Mr. Prateekjalan Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  | 0.23 |  |  |  |  |  |
| Sitting fees |  |  |  | 0.03 |  |  |  |  |  |
| Mr. M.J. Subbaiah Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 | 0.10 |  |  |  |  |  |
| Sitting fees |  |  | 0.02 | 0.02 |  |  |  |  |  |
| Mr. Priya Brat Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  | 0.09 |  | 0.02 |  |  |  |  |
| Sitting fees |  |  | 0.03 | 0.01 |  |  |  |  |  |
| Ms. ManviSinha Key Person |  |  |  |  |  |  |  |  |  |
| Commission |  |  |  | 0.10 |  |  |  |  |  |
| Sitting fees |  |  |  | 0.02 |  |  |  |  |  |
| Mr. B Govindarajan Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  |  | 0.03 | 0.05 |
| Other long-term benefits |  |  |  |  |  |  |  |  | 0.01 |
| Post-employment benefits |  |  |  |  |  |  |  |  | 0.01 |
| Shardul Amarchand Mangaldas & Co. |  |  |  |  |  |  |  |  |  |
| Professional charges |  |  |  |  |  |  |  |  | 0.01 |
| Ms. Vidhya Srinivasan Key Person |  |  |  |  |  |  |  |  |  |
| Short-term benefits |  |  |  |  |  |  |  |  | 0.01 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2007 | Mar 2008 | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown | Unknown |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales | Amount
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 1,662 | 1,885 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 198 | 240 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 119 | 108 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | 35 | 73 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Less: Intersegment | -23 | -29 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Profit before Tax & Int | Amount
Margin %
Growth % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 5% | 5% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 1% | 2% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 5% | -3% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | -35% | -9% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital Employed | Amount
ROCE % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial Vehicles | 36% | 33% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Two Wheelers | 5% | 22% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components (Including Gears) | 11% | -5% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Others | % | -45% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unallocated | 3% | 2% |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 27% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 37% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 47% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

