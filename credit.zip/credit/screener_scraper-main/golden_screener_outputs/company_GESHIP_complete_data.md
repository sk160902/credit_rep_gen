# Complete Company Data

## Modal Content
About
[
edit
]
Great Eastern Shipping Company Ltd, along with its subsidiaries is a major player in the Indian shipping and Oil drilling services industry.
[1]
Key Points
[
edit
]
Overview
[1]
GE Shipping was founded in 1948 with the purchase of a Liberty ship. As of FY24, GES is India’s largest private sector shipping company, owning and operating 43 ships and 23 offshore assets.
Business Segment
Shipping Business:
The shipping business is involved in the transportation of crude oil, petroleum products, gas, and dry bulk commodities.
Offshore Business:
The company is involved in the offshore services business through its wholly-owned subsidiary
Greatship India Ltd.
It provides offshore oilfield services with the principal activity of owning and/or operating offshore supply vessels and mobile offshore drilling rigs.
[2]
Segment-Wise Revenue Split
Shipping: ~81% in FY22 vs ~81% in FY21
Offshore: ~19% in FY22 vs ~19% in FY21
[3]
Geography Wise Revenue Split
India: 44% in FY22 vs 50% in FY21
Outside India: 56% in FY22 vs 50% in FY21
[3]
Fleet Profile FY24
[4]
Company has a total fleet of 43 vessels.
Shipping Business -
A Tankers - (i) Crude (6), Products (19) and LPG (4)
B Dry Bulk (14)
Offshore Business (through WOS Greatship (India) Limited)-
C Logistics (19)
D Drilling (4)
Order Book as % of Fleet FY22
Presently, the company has one of the lowest order book-to-fleet ratios in its business.
Bulkers: 7.4%
Product Tankers: 4.8%
Crude Tankers: 3.6%
[5]
Jackup Rigs: 4.1%
Platform Supply vessels and anchor handling tugs: 3%
[6]
Strong Cash Flows
[7]
Company moved from Debt of USD 360 mn in FY19 to cash positive of USD 300 mn in 9MFY24.
New Vessel
[8]
In April,24, Company took delivery of 2010 built Medium Range product tanker “Jag Priya” of about 49,999 dwt. The Company had contracted to buy the vessel in Q4 FY24.
Sale of a vessel
[9]
In April,24, they contracted to sell its 2004 Medium Range Product Tanker, Jag Pahel of about 46,319 dwt to an unaffiliated third party.
NCDs
In Q3FY24, company raised ~Rs. 2150 crs. through NCDs.  Funds raised through NCDs have been swapped into USD using INR-FCY swaps, thus creating synthetic fixed rate USD loans.
[10]
Last edited 3 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 3,007 | 3,092 | 3,438 | 3,808 | 3,117 | 3,038 | 3,547 | 3,687 | 3,337 | 3,509 | 5,690 | 5,255 |
| Expenses + | 2,042 | 1,660 | 2,005 | 1,823 | 1,686 | 1,838 | 2,480 | 2,470 | 1,683 | 1,969 | 2,563 | 2,234 |
| Operating Profit | 965 | 1,432 | 1,433 | 1,985 | 1,431 | 1,200 | 1,067 | 1,217 | 1,653 | 1,540 | 3,128 | 3,022 |
| OPM % | 32% | 46% | 42% | 52% | 46% | 40% | 30% | 33% | 50% | 44% | 55% | 58% |
| Other Income + | 556 | 242 | 276 | 119 | 506 | 102 | 269 | 211 | 232 | 148 | 481 | 664 |
| Interest | 345 | 375 | 301 | 288 | 378 | 455 | 521 | 450 | 242 | 370 | 343 | 265 |
| Depreciation | 592 | 665 | 610 | 608 | 678 | 769 | 773 | 743 | 700 | 698 | 712 | 726 |
| Profit before tax | 584 | 633 | 798 | 1,208 | 882 | 79 | 42 | 235 | 943 | 620 | 2,554 | 2,694 |
| Tax % | 8% | 9% | 6% | 9% | 14% | 367% | 151% | 12% | 3% | -2% | -1% | 3% |
| Net Profit + | 538 | 574 | 748 | 1,097 | 755 | -210 | -21 | 207 | 919 | 630 | 2,575 | 2,614 |
| EPS in Rs | 35.30 | 38.07 | 49.63 | 72.76 | 50.07 | -13.96 | -1.42 | 14.09 | 62.50 | 44.09 | 180.36 | 183.11 |
| Dividend Payout % | 21% | 24% | 22% | 19% | 20% | -52% | -380% | 57% | 14% | 22% | 16% | 24% |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -8% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 194% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 42% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 76% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 21% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mr. Ravi K. Sheth Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 10 |  |  |  |  |  |  |  |  |  |
| Mr. K. M. Sheth Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 2.32 |  |  |  |  |  |  |  |  |  |
| Mr. Tapas Icot Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 1.43 |  |  |  |  |  |  |  |  |  |
| Mr. Bharat K. Sheth Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 1.40 |  |  |  |  |  |  |  |  |  |
| Mr. Jayesh Trivedi Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 0.93 |  |  |  |  |  |  |  |  |  |
| Mr. G. Shivakumar Key Person |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 0.40 |  |  |  |  |  |  |  |  |  |
| Ms. Nirja B. Sheth Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 0.17 |  |  |  |  |  |  |  |  |  |
| Bhavna Doshi Associates LLP |  |  |  |  |  |  |  |  |  |  |
| Professional fees paid |  |  |  |  |  |  |  |  |  | 0.06 |
| Mr. Rahul R. Sheth Relative |  |  |  |  |  |  |  |  |  |  |
| Remuneration | 0.05 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 3,007 | 3,092 | 3,438 | 3,808 | 3,117 | 3,038 | 3,547 | 3,687 | 3,337 | 3,509 | 5,690 | 5,255 |
| Expenses + | 2,042 | 1,660 | 2,005 | 1,823 | 1,686 | 1,838 | 2,480 | 2,470 | 1,683 | 1,969 | 2,563 | 2,234 |
| Operating Profit | 965 | 1,432 | 1,433 | 1,985 | 1,431 | 1,200 | 1,067 | 1,217 | 1,653 | 1,540 | 3,128 | 3,022 |
| OPM % | 32% | 46% | 42% | 52% | 46% | 40% | 30% | 33% | 50% | 44% | 55% | 58% |
| Other Income + | 556 | 242 | 276 | 119 | 506 | 102 | 269 | 211 | 232 | 148 | 481 | 664 |
| Interest | 345 | 375 | 301 | 288 | 378 | 455 | 521 | 450 | 242 | 370 | 343 | 265 |
| Depreciation | 592 | 665 | 610 | 608 | 678 | 769 | 773 | 743 | 700 | 698 | 712 | 726 |
| Profit before tax | 584 | 633 | 798 | 1,208 | 882 | 79 | 42 | 235 | 943 | 620 | 2,554 | 2,694 |
| Tax % | 8% | 9% | 6% | 9% | 14% | 367% | 151% | 12% | 3% | -2% | -1% | 3% |
| Net Profit + | 538 | 574 | 748 | 1,097 | 755 | -210 | -21 | 207 | 919 | 630 | 2,575 | 2,614 |
| EPS in Rs | 35.30 | 38.07 | 49.63 | 72.76 | 50.07 | -13.96 | -1.42 | 14.09 | 62.50 | 44.09 | 180.36 | 183.11 |
| Dividend Payout % | 21% | 24% | 22% | 19% | 20% | -52% | -380% | 57% | 14% | 22% | 16% | 24% |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -8% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 194% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 42% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 41% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 76% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 19% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 21% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 1,256 | 1,358 | 1,445 | 2,151 | 1,522 | 969 | 1,096 | 1,481 | 1,534 | 1,323 | 2,975 | 2,808 |
| Cash from Investing Activity + | -409 | -348 | -725 | -440 | -1,548 | -412 | 429 | 622 | -882 | -337 | 39 | -868 |
| Cash from Financing Activity + | -442 | -1,697 | -228 | -1,677 | 713 | -1,158 | -1,020 | -1,872 | -505 | -1,189 | -1,893 | -1,330 |
| Net Cash Flow | 405 | -688 | 491 | 34 | 687 | -602 | 505 | 230 | 147 | -203 | 1,120 | 610 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 45 | 32 | 36 | 30 | 24 | 30 | 31 | 34 | 30 | 33 | 37 | 45 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 45 | 32 | 36 | 30 | 24 | 30 | 31 | 34 | 30 | 33 | 37 | 45 |
| Working Capital Days | -216 | -239 | -211 | -161 | -187 | -143 | -132 | -35 | 1 | 13 | 23 | 28 |
| ROCE % | 6% | 7% | 8% | 11% | 8% | 4% | 4% | 4% | 9% | 7% | 21% | 19% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 29.21% | 29.21% | 30.06% | 30.07% | 30.08% | 30.08% | 30.08% | 30.08% | 30.08% | 30.08% | 30.08% | 30.08% |
| FIIs + | 19.58% | 20.64% | 21.94% | 22.06% | 23.92% | 25.07% | 25.94% | 26.18% | 27.30% | 26.75% | 27.41% | 24.51% |
| DIIs + | 23.95% | 21.83% | 20.36% | 20.64% | 18.58% | 17.13% | 17.04% | 16.66% | 15.91% | 16.39% | 16.60% | 17.36% |
| Government + | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% |
| Public + | 27.25% | 28.31% | 27.63% | 27.21% | 27.41% | 27.71% | 26.93% | 27.08% | 26.72% | 26.76% | 25.91% | 28.05% |
| No. of Shareholders | 80,465 | 80,763 | 75,428 | 71,251 | 73,126 | 79,342 | 79,041 | 85,121 | 95,757 | 98,047 | 1,00,251 | 1,24,075 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 30.22% | 29.66% | 29.66% | 28.83% | 29.21% | 30.06% | 30.08% | 30.08% | 30.08% |
| FIIs + | 23.16% | 21.77% | 19.19% | 22.02% | 18.66% | 21.94% | 25.94% | 27.41% | 24.51% |
| DIIs + | 19.45% | 22.27% | 25.06% | 22.04% | 25.13% | 20.36% | 17.04% | 16.60% | 17.36% |
| Government + | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.01% | 0.00% | 0.00% |
| Public + | 26.89% | 26.29% | 26.08% | 27.11% | 26.98% | 27.63% | 26.93% | 25.91% | 28.05% |
| Others + | 0.27% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% | 0.00% |
| No. of Shareholders | 71,393 | 64,218 | 64,301 | 61,021 | 64,255 | 75,428 | 79,041 | 1,00,251 | 1,24,075 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/great-eastern-shipping-company-ltd/geship/500620/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Credit Rating
13h - Listing Obligations and Disclosures Regulations), 2015, we wish to inform you about revision in credit rating.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2de4a1d4-6c42-4048-8754-3029f44dedb9.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 23h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=805e2088-b66b-400d-910b-41dca7c0ec30.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation
1d - Company will meet on Thursday, August 01, 2024, to inter- alia consider the Financial Results for the quarter ended June 30, 2024. An Earnings Call …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4d691dd0-70ed-4083-a0bb-e368a6a1884d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=96332bfa-8133-4ec5-be38-1615a6e2ba29.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=70548a3e-3560-4135-af5c-cc2b9b6ae4c5.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fc0cafe0-c0a9-46a3-8e38-95d32ceaad20.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\81d9e7ac-4252-4ecf-846f-81724b6bddc0.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500620/73428500620.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500620/68769500620_07_07_21.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_GESHIP_2010_2011_21072011092559.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500620/5006200311.pdf)

## Credit Ratings
- [Rating update
26 Jun from care](https://www.careratings.com/upload/CompanyFiles/PR/202406130630_The_Great_Eastern_Shipping_Company_Limited.pdf)
- [Rating update
19 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TheGreatEasternShippingCompanyLimited_June%2019_%202024_RR_344345.html)
- [Rating update
8 Jan from brickwork](https://www.brickworkratings.com/Admin/PressRelease/THE-GREAT-EASTERN-SHIPPING-COMPANY-8Jan2024.pdf)
- [Rating update
27 Jun 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202306120637_The_Great_Eastern_Shipping_Company_Limited.pdf)
- [Rating update
21 Jun 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TheGreatEasternShippingCompanyLimited_June%2021,%202023_RR_320643.html)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/TheGreatEasternShippingCompanyLimited_June%2002,%202023_RR_319376.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e5a69f08-6fba-4cb0-9813-d447af2b5a0d.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0b25831c-4ea5-4fec-8e0d-ceb4f5cb5bd9.pdf)
- [REC](https://www.greatship.com/upload/investors/transcripts/AudioTranscriptsQ4FY24.mp3)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c642a27a-d089-41d7-9317-07baa9b907bf.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=86b0c831-d5ac-438d-8dcb-7de9055a30e3.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0d0bcbc9-e502-40df-b33a-23a8c7870896.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91e90725-7242-40bd-93ac-2fc06ffdf4e1.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=87f31b93-6cd4-468a-a37a-ac59d2e6aa7e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0dbd096b-0342-47bc-861d-1777dd6ed2d6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5aa52d1-fd09-4078-b6de-122a0ba4c9d9.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6e8a268e-7004-4784-943e-b8a689448cb5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b596b56d-b526-45cc-b408-3ec7b8913174.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5ac93995-e6b1-4743-b5cb-833f2749e819.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=df1f497a-364f-42c9-a99b-f9a3e3adc024.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=444167be-be61-4c25-9108-a51f6c0bf5a4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b19ed44b-77a7-4392-ae8a-036ace5ff0b2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=be69fe9b-8e1e-45f8-91e4-2daf17e8fd8a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4621826b-efec-4be6-a0dd-58cb67288aa2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=49a514a2-0d25-4457-833a-7732dc48dabb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95b07ae7-0c55-4d17-8a0a-34f52c1ef9fd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e04c4976-9af4-4db3-98d3-c44f9572a8ec.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=969f5ecb-f74b-478a-bd8f-b6c8743ad3d1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95ec6661-b3c0-48c0-aeba-9679453a4524.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6a5de9b7-a675-4f90-b1e4-8adfee808931.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5c776f34-a129-4da3-85b0-16a7305ae41e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0631a5ab-3165-4ef3-9501-ec162821c4f0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5254a070-6675-4ba4-b926-b29cbae91987.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=42867f4f-fc46-4edc-aa57-5ed9d6542068.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=404ec260-7c24-4efe-8019-c04ef5c5692b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f44ec08a-5fdd-49d5-aa5f-7e61d6e60753.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=46ebee51-39f7-4749-a0e1-504a16918ba5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1bbe9b30-bd83-4e10-b5f8-7272df6b90a6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0dd30255-cbc5-452c-b2cc-3365c160dbad.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f703ba63-3fe2-4dd5-a316-7ad223c0a6be.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Transcript_-_4Q21_Results_7May21.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a1e2306-7de2-4341-9afd-f5d756217437.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Transcripts_Q3FY21_Final.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=22ef3ebc-c92a-4d93-931e-21bf0939f2c5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5e07858b-532a-4627-921d-11313bbb9530.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Transcripts_Q1FY21_Earnings_Call1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=065fc23f-4000-46bb-a3ce-7ec64c460955.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Q4FY20_Earnings_Call_Transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c39a929c-df9d-44f8-92bb-bdf1f2aa7abf.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Transcripts_12Feb20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fae3f86f-79f7-49a4-ab76-bee25d283ba4.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/GE_Shipping_-_Transcripts_-_Q2FY20_.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d8280d26-28cc-4c42-ae58-40ce74b3d734.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/GEShipping-Transcripts-Q1FY20.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4079f20b-276d-4e0d-a10b-c475ee742147.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Q4FY19_Transcripts_(1).pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=df397915-645f-4b81-a895-59a9cdf93142.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/Transcripts_Q3FY192.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0fc0da6d-2135-45d5-b583-7b3270d33d33.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/01_2Q19ConcallTranscript_2Nov18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5dd52192-46f7-4afd-983f-c4a65494fe8c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9cf479af-e9ea-4a9f-af9b-09ad4fb4a56a.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/02_EarningsCallTranscriptsQ1FY2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23bc7b4f-e0e6-4a4d-b79f-bb0150a62dc3.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/03_EarningsCall_Q4FY18Transcripts.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=699c26d0-beb7-49c6-a3d1-f6986fa4919b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fc922c5d-f742-44c6-96cb-cbd773fc579a.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/04_3Q18EarningsConcallTranscript_12Feb18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e88371ad-b769-4344-9346-aebb3cadba78.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/01_TheGreatEasternEarnings_13Nov2017_V2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4ef7d2f7-8bab-4ab9-b206-37a5295ee7ca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4ae49d0e-763f-42ae-9bf4-ab85e9a2cb50.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/02_TranscriptsQ1FY18.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25959dd5-7f7f-4e75-bf7c-e9166ca7bad8.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/03_GEShippingEarningsCallTranscripts5May2017.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2a160435-1f82-4702-aa71-0619c3414dc9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=12A1D6F0_FF79_49A6_9FF6_B26288B1C948_164522.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/05_GEShippingEarnings_Transcripts.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/06_Transcript_Q1_FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9F036E28_40AA_4613_BBC6_C93DEA47310F_122756.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/01_EarningsCallTranscriptQ4FY16final.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8CE77C1D_9BE2_4B2E_87BF_E371FC8985BA_122613.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1188A5EB_8CC1_4792_A5F3_6FEC68E9D00C_164016.pdf)
- [](https://www.greatship.com/upload/investors/transcripts/02_EarningsCallTranscriptQ3FY16final.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B88E6936_0C82_4BC1_B668_CEA8A647624F_183618.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | GE Shipping Co | 1343.00 | 19173.63 | 8.05 | 1.56 | 3.65 | 9.50 | 5.03 | 40.87 | 2.13 | 18.51 | 14.88 | 21.01 | 0.33 | 0.25 | 10.27 | 1.29 | 5255.17 | 57.50 | 2381.87 | 1497.33 | 905.08 | 2.84 | 25.38 | 183.11 | 3048.30 | 30.07 | 0.00 | 15.69 | 26.88 | 0.00 | -7.65 | -3.15 | 17331.14 | 4.09 | 0.04 | 23.20 | 33.29 | 53.79 | 76.22 | 19.14 | 14.97 | 193.64 | 41.83 | 8.18 | 16.35 | 26.84 | 20.87 | 3.93 | 183.11 | 196.87 | 7.60 | 6.40 | 9.08 | 44.93 | 14.28 |
| 2. | S C I | 279.80 | 13033.04 | 21.35 | 1.86 | 2.58 | 15.72 | 8.93 | 65.06 | 0.16 | 7.95 | 5.46 | 9.18 | 0.45 | 0.42 | 4.38 | 1.61 | 5046.04 | 28.21 | 612.15 | 1412.34 | 291.99 | -0.41 | -18.85 | 13.14 | 2914.22 | 63.75 | 0.00 | 5.11 | 26.88 | 0.00 | -12.91 | -23.08 | 14633.14 | 1.25 | 0.51 | 20.95 | 34.24 | 48.50 | 188.69 | 11.32 | 8.89 | 41.68 | -0.32 | 5.43 | 10.86 | 13.32 | 10.29 | 1.19 | 13.14 | 41.68 | 7.13 | 7.73 | 8.22 | 102.02 | 46.58 |
| 3. | Essar Shipping | 57.00 | 1179.75 |  |  | 58.29 | 3.33 | -823.82 | 45.30 | 0.00 | -150.86 | -11.98 |  | 0.02 |  | -0.45 | -0.35 | 20.24 | -330.98 | -117.25 | 2.54 | -65.32 | -81.50 | -232.83 | -5.71 | 2641.98 | 73.75 | 0.00 | -0.97 | 26.88 | 0.00 | -66.64 | -1086.91 | 3797.82 | 0.30 |  | 88.09 | 77.54 | 73.30 | 418.09 |  |  | 9.71 | 21.73 | -56.56 | -65.00 |  |  | 0.30 | -5.71 | 9.71 | 5.25 | 5.25 | 5.25 | 336.51 | 20.70 |
| 4. | Shreyas Shipping | 398.65 | 875.42 |  | 1.15 | 3.10 | -8.49 | 18.13 | 24.94 | 0.37 | -0.80 | -3.89 | -6.40 | 0.22 | 0.53 | -0.27 | 1.70 | 282.39 | 8.45 | -50.69 | 89.62 | 2.38 | 10.52 | -86.81 | -23.23 | 405.24 | 70.44 | 0.00 | -0.80 | 26.88 | 0.00 | -41.63 | -127.51 | 1263.55 | 1.32 |  | 30.19 | 40.86 | 20.55 | 9.44 | 16.56 | 13.99 |  |  | -14.69 | -20.40 | 25.45 | 18.79 | 1.25 | -23.23 |  | 6.70 | 4.22 | 7.49 | 10.20 | 2.20 |
| 5. | ABS Marine | 326.00 | 800.31 | 32.99 |  | 5.92 | 71.48 | 18.33 |  | 0.00 | 20.01 | 14.53 | 23.02 | 0.75 | 0.39 | 6.67 | 1.54 | 135.16 | 33.20 | 24.25 |  |  |  |  |  | 45.68 | 63.42 |  | 3.92 | 26.88 | 0.00 | 21.13 | 176.41 | 838.93 | 1.73 |  |  |  |  |  | 12.22 |  |  | 164.55 |  | 15.14 | 9.90 | 10.57 | 1.73 |  |  |  |  |  | 86.58 |  |
| 6. | Seacoast Ship. | 6.80 | 366.31 | 18.05 | 2.87 | 0.98 | -22.60 | 11.29 |  | 0.00 | 28.33 | 8.50 | 21.45 | 1.57 | 0.24 | 17.56 | 1.88 | 374.16 | 9.39 | 20.29 | 125.02 | 7.50 | 8.24 | 514.75 | 0.38 | 30.30 | 0.04 | 0.00 | 9.26 | 26.88 | 0.00 | -12.90 | 2.42 | 396.60 | 1.78 | 0.05 | 69.19 | 15.30 | -31.56 | 76.57 | 21.78 | 24.06 | 358.62 | 22.27 | 324.95 | 15.45 | 36.11 | 38.41 | 1.78 | 0.38 |  | 14.13 | 14.19 | 14.13 | 312.67 | 53.87 |
| 7. | Sadhav | 224.50 | 322.23 | 35.23 | 3.66 | 3.82 | -13.36 | 18.31 |  | 0.00 | 17.15 | 7.87 | 22.35 | 0.72 | 0.76 | 3.81 | 2.84 | 84.25 | 24.24 | 9.15 | 50.56 | 2.13 |  |  | 6.38 | 67.03 | 69.44 |  | 4.47 | 26.88 | 0.00 | 8.28 | 27.44 | 382.28 | 1.67 |  | 2.74 |  |  |  | 17.20 |  |  | 40.35 |  | 11.63 | 18.90 | 17.52 | 1.67 | 6.38 |  | 34.34 | 34.34 | 34.34 | 38.25 |  |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | Sales | ₹ 5,255 Cr. |
| GESHIP | OPM | 57.5 % |
| GESHIP | Profit after tax | ₹ 2,382 Cr. |
| GESHIP | Mar Cap | ₹ 19,239 Cr. |
| GESHIP | Sales Qtr | ₹ 1,497 Cr. |
| GESHIP | PAT Qtr | ₹ 905 Cr. |
| GESHIP | Qtr Sales Var | 2.84 % |
| GESHIP | Qtr Profit Var | 25.4 % |
| GESHIP | Price to Earning | 8.08 |
| GESHIP | Dividend yield | 2.12 % |
| GESHIP | Price to book value | 1.57 |
| GESHIP | ROCE | 18.5 % |
| GESHIP | Return on assets | 14.9 % |
| GESHIP | Debt to equity | 0.25 |
| GESHIP | Return on equity | 21.0 % |
| GESHIP | EPS | ₹ 183 |
| GESHIP | Debt | ₹ 3,048 Cr. |
| GESHIP | Promoter holding | 30.1 % |
| GESHIP | Change in Prom Hold | 0.00 % |
| GESHIP | Earnings yield | 15.7 % |
| GESHIP | Pledged percentage | 0.00 % |
| GESHIP | Industry PE | 26.9 |
| GESHIP | Sales growth | -7.65 % |
| GESHIP | Profit growth | -3.15 % |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | Price to Sales | 3.66 |
| GESHIP | CMP / FCF | 9.53 |
| GESHIP | EVEBITDA | 5.05 |
| GESHIP | Enterprise Value | ₹ 17,396 Cr. |
| GESHIP | Current ratio | 4.09 |
| GESHIP | Int Coverage | 10.3 |
| GESHIP | PEG Ratio | 0.04 |
| GESHIP | Return over 3months | 23.2 % |
| GESHIP | Return over 6months | 33.3 % |
| GESHIP | No. Eq. Shares | 14.3 |
| GESHIP | Sales growth 3Years | 16.4 % |
| GESHIP | Sales growth 5Years | 8.18 % |
| GESHIP | Profit Var 3Yrs | 41.8 % |
| GESHIP | Profit Var 5Yrs | 194 % |
| GESHIP | ROE 5Yr | 15.0 % |
| GESHIP | ROE 3Yr | 19.1 % |
| GESHIP | Return over 1year | 76.2 % |
| GESHIP | Return over 3years | 53.8 % |
| GESHIP | Return over 5years | 40.9 % |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | Sales last year | ₹ 5,255 Cr. |
| GESHIP | OP Ann | ₹ 3,022 Cr. |
| GESHIP | Other Inc Ann | ₹ 664 Cr. |
| GESHIP | EBIDT last year | ₹ 3,445 Cr. |
| GESHIP | Dep Ann | ₹ 726 Cr. |
| GESHIP | EBIT last year | ₹ 2,719 Cr. |
| GESHIP | Interest last year | ₹ 265 Cr. |
| GESHIP | PBT Ann | ₹ 2,694 Cr. |
| GESHIP | Tax last year | ₹ 80.2 Cr. |
| GESHIP | PAT Ann | ₹ 2,382 Cr. |
| GESHIP | Extra Ord Item Ann | ₹ 240 Cr. |
| GESHIP | NP Ann | ₹ 2,614 Cr. |
| GESHIP | Dividend last year | ₹ 625 Cr. |
| GESHIP | Raw Material | 0.00 % |
| GESHIP | Employee cost | ₹ 886 Cr. |
| GESHIP | OPM last year | 57.5 % |
| GESHIP | NPM last year | 45.3 % |
| GESHIP | Operating profit | ₹ 3,022 Cr. |
| GESHIP | Interest | ₹ 265 Cr. |
| GESHIP | Depreciation | ₹ 726 Cr. |
| GESHIP | EPS last year | ₹ 183 |
| GESHIP | EBIT | ₹ 2,719 Cr. |
| GESHIP | Net profit | ₹ 2,614 Cr. |
| GESHIP | Current Tax | ₹ 59.2 Cr. |
| GESHIP | Tax | ₹ 80.2 Cr. |
| GESHIP | Other income | ₹ 664 Cr. |
| GESHIP | Ann Date | 2,02,403 |
| GESHIP | Sales Prev Ann | ₹ 5,690 Cr. |
| GESHIP | OP Prev Ann | ₹ 3,128 Cr. |
| GESHIP | Other Inc Prev Ann | ₹ 481 Cr. |
| GESHIP | EBIDT Prev Ann | ₹ 3,491 Cr. |
| GESHIP | Dep Prev Ann | ₹ 712 Cr. |
| GESHIP | EBIT preceding year | ₹ 2,779 Cr. |
| GESHIP | Interest Prev Ann | ₹ 343 Cr. |
| GESHIP | PBT Prev Ann | ₹ 2,554 Cr. |
| GESHIP | Tax preceding year | ₹ -21.5 Cr. |
| GESHIP | PAT Prev Ann | ₹ 2,459 Cr. |
| GESHIP | Extra Ord Prev Ann | ₹ 117 Cr. |
| GESHIP | NP Prev Ann | ₹ 2,575 Cr. |
| GESHIP | Dividend Prev Ann | ₹ 411 Cr. |
| GESHIP | OPM preceding year | 55.0 % |
| GESHIP | NPM preceding year | 43.2 % |
| GESHIP | EPS preceding year | ₹ 180 |
| GESHIP | Sales Prev 12M | ₹ 5,214 Cr. |
| GESHIP | Profit Prev 12M | ₹ 2,431 Cr. |
| GESHIP | Med Sales Gwth 10Yrs | 3.94 % |
| GESHIP | Med Sales Gwth 5Yrs | 3.94 % |
| GESHIP | Sales growth 7Years | 7.75 % |
| GESHIP | Sales Var 10Yrs | 5.45 % |
| GESHIP | EBIDT growth 3Years | 24.2 % |
| GESHIP | EBIDT growth 5Years | 21.9 % |
| GESHIP | EBIDT growth 7Years | 9.93 % |
| GESHIP | EBIDT Var 10Yrs | 7.78 % |
| GESHIP | EPS growth 3Years | 43.2 % |
| GESHIP | EPS growth 5Years | 197 % |
| GESHIP | EPS growth 7Years | 22.2 % |
| GESHIP | EPS growth 10Years | 16.8 % |
| GESHIP | Profit Var 7Yrs | 21.3 % |
| GESHIP | Profit Var 10Yrs | 16.2 % |
| GESHIP | Chg in Prom Hold 3Yr | 0.86 % |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | OP Qtr | ₹ 937 Cr. |
| GESHIP | Other Inc Qtr | ₹ 229 Cr. |
| GESHIP | EBIDT Qtr | ₹ 1,166 Cr. |
| GESHIP | Dep Qtr | ₹ 166 Cr. |
| GESHIP | EBIT latest quarter | ₹ 1,000 Cr. |
| GESHIP | Interest Qtr | ₹ 58.5 Cr. |
| GESHIP | PBT Qtr | ₹ 942 Cr. |
| GESHIP | Tax latest quarter | ₹ 36.8 Cr. |
| GESHIP | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| GESHIP | NP Qtr | ₹ 905 Cr. |
| GESHIP | GPM latest quarter | 93.0 % |
| GESHIP | OPM latest quarter | 62.6 % |
| GESHIP | NPM latest quarter | 60.4 % |
| GESHIP | Eq Cap Qtr | ₹ 143 Cr. |
| GESHIP | EPS latest quarter | ₹ 63.4 |
| GESHIP | OP 2Qtr Bk | ₹ 643 Cr. |
| GESHIP | OP 3Qtr Bk | ₹ 792 Cr. |
| GESHIP | Sales 2Qtr Bk | ₹ 1,229 Cr. |
| GESHIP | Sales 3Qtr Bk | ₹ 1,284 Cr. |
| GESHIP | NP 2Qtr Bk | ₹ 595 Cr. |
| GESHIP | NP 3Qtr Bk | ₹ 576 Cr. |
| GESHIP | Opert Prft Gwth | -3.39 % |
| GESHIP | Last result date | 2,02,403 |
| GESHIP | Exp Qtr Sales Var | -7.12 % |
| GESHIP | Exp Qtr Sales | ₹ 1,192 Cr. |
| GESHIP | Exp Qtr OP | ₹ 700 Cr. |
| GESHIP | Exp Qtr NP | ₹ 475 Cr. |
| GESHIP | Exp Qtr EPS | ₹ 33.2 |
| GESHIP | Sales Prev Qtr | ₹ 1,245 Cr. |
| GESHIP | OP Prev Qtr | ₹ 650 Cr. |
| GESHIP | Other Inc Prev Qtr | ₹ 151 Cr. |
| GESHIP | EBIDT Prev Qtr | ₹ 801 Cr. |
| GESHIP | Dep Prev Qtr | ₹ 194 Cr. |
| GESHIP | EBIT Prev Qtr | ₹ 607 Cr. |
| GESHIP | Interest Prev Qtr | ₹ 66.9 Cr. |
| GESHIP | PBT Prev Qtr | ₹ 540 Cr. |
| GESHIP | Tax Prev Qtr | ₹ 1.50 Cr. |
| GESHIP | PAT Prev Qtr | ₹ 538 Cr. |
| GESHIP | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| GESHIP | NP Prev Qtr | ₹ 538 Cr. |
| GESHIP | OPM Prev Qtr | 52.2 % |
| GESHIP | NPM Prev Qtr | 43.2 % |
| GESHIP | Eq Cap Prev Qtr | ₹ 143 Cr. |
| GESHIP | EPS Prev Qtr | ₹ 37.7 |
| GESHIP | Sales PY Qtr | ₹ 1,456 Cr. |
| GESHIP | OP PY Qtr | ₹ 847 Cr. |
| GESHIP | Other Inc PY Qtr | ₹ 94.7 Cr. |
| GESHIP | EBIDT PY Qtr | ₹ 942 Cr. |
| GESHIP | Dep PY Qtr | ₹ 167 Cr. |
| GESHIP | EBIT PY Qtr | ₹ 774 Cr. |
| GESHIP | Interest PY Qtr | ₹ 76.8 Cr. |
| GESHIP | PBT PY Qtr | ₹ 698 Cr. |
| GESHIP | Tax PY Qtr | ₹ -24.4 Cr. |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | Equity capital | ₹ 143 Cr. |
| GESHIP | Preference capital | ₹ 0.00 Cr. |
| GESHIP | Reserves | ₹ 12,255 Cr. |
| GESHIP | Secured loan | ₹ 1,738 Cr. |
| GESHIP | Unsecured loan | ₹ 1,310 Cr. |
| GESHIP | Balance sheet total | ₹ 16,808 Cr. |
| GESHIP | Gross block | ₹ 14,803 Cr. |
| GESHIP | Revaluation reserve | ₹ 0.00 Cr. |
| GESHIP | Accum Dep | ₹ 6,473 Cr. |
| GESHIP | Net block | ₹ 8,329 Cr. |
| GESHIP | CWIP | ₹ 59.2 Cr. |
| GESHIP | Investments | ₹ 1,970 Cr. |
| GESHIP | Current assets | ₹ 6,165 Cr. |
| GESHIP | Current liabilities | ₹ 1,506 Cr. |
| GESHIP | BV Unq Invest | ₹ 0.00 Cr. |
| GESHIP | MV Quoted Inv | ₹ 341 Cr. |
| GESHIP | Cont Liab | ₹ 571 Cr. |
| GESHIP | Total Assets | ₹ 16,808 Cr. |
| GESHIP | Working capital | ₹ 5,292 Cr. |
| GESHIP | Lease liabilities | ₹ 17.3 Cr. |
| GESHIP | Inventory | ₹ 247 Cr. |
| GESHIP | Trade receivables | ₹ 647 Cr. |
| GESHIP | Face value | ₹ 10.0 |
| GESHIP | Cash Equivalents | ₹ 4,891 Cr. |
| GESHIP | Adv Cust | ₹ 30.0 Cr. |
| GESHIP | Trade Payables | ₹ 456 Cr. |
| GESHIP | No. Eq. Shares PY | 14.3 |
| GESHIP | Debt preceding year | ₹ 3,649 Cr. |
| GESHIP | Work Cap PY | ₹ 4,161 Cr. |
| GESHIP | Net Block PY | ₹ 8,450 Cr. |
| GESHIP | Gross Block PY | ₹ 14,607 Cr. |
| GESHIP | CWIP PY | ₹ 34.8 Cr. |
| GESHIP | Work Cap 3Yr | ₹ 2,758 Cr. |
| GESHIP | Work Cap 5Yr | ₹ 1,642 Cr. |
| GESHIP | Work Cap 7Yr | ₹ 1,868 Cr. |
| GESHIP | Work Cap 10Yr | ₹ 299 Cr. |
| GESHIP | Debt 3Years back | ₹ 5,047 Cr. |
| GESHIP | Debt 5Years back | ₹ 5,999 Cr. |
| GESHIP | Debt 7Years back | ₹ 6,816 Cr. |
| GESHIP | Debt 10Years back | ₹ 6,119 Cr. |
| GESHIP | Net Block 3Yrs Back | ₹ 9,042 Cr. |
| GESHIP | Net Block 5Yrs Back | ₹ 9,617 Cr. |
| GESHIP | Net Block 7Yrs Back | ₹ 10,304 Cr. |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | CF Operations | ₹ 2,808 Cr. |
| GESHIP | Free Cash Flow | ₹ 2,373 Cr. |
| GESHIP | CF Investing | ₹ -868 Cr. |
| GESHIP | CF Financing | ₹ -1,330 Cr. |
| GESHIP | Net CF | ₹ 610 Cr. |
| GESHIP | Cash Beginning | ₹ 2,678 Cr. |
| GESHIP | Cash End | ₹ 4,891 Cr. |
| GESHIP | FCF Prev Ann | ₹ 2,776 Cr. |
| GESHIP | CF Operations PY | ₹ 2,975 Cr. |
| GESHIP | CF Investing PY | ₹ 38.8 Cr. |
| GESHIP | CF Financing PY | ₹ -1,893 Cr. |
| GESHIP | Net CF PY | ₹ 1,120 Cr. |
| GESHIP | Cash Beginning PY | ₹ 1,558 Cr. |
| GESHIP | Cash End PY | ₹ 3,799 Cr. |
| GESHIP | Free Cash Flow 3Yrs | ₹ 6,059 Cr. |
| GESHIP | Free Cash Flow 5Yrs | ₹ 8,457 Cr. |
| GESHIP | Free Cash Flow 7Yrs | ₹ 9,436 Cr. |
| GESHIP | Free Cash Flow 10Yrs | ₹ 10,844 Cr. |
| GESHIP | CF Opr 3Yrs | ₹ 7,105 Cr. |
| GESHIP | CF Opr 5Yrs | ₹ 10,120 Cr. |
| GESHIP | CF Opr 7Yrs | ₹ 12,185 Cr. |
| GESHIP | CF Opr 10Yrs | ₹ 17,302 Cr. |
| GESHIP | CF Inv 10Yrs | ₹ -4,123 Cr. |
| GESHIP | CF Inv 7Yrs | ₹ -1,410 Cr. |
| GESHIP | CF Inv 5Yrs | ₹ -1,427 Cr. |
| GESHIP | CF Inv 3Yrs | ₹ -1,167 Cr. |
| GESHIP | Cash 3Years back | ₹ 2,749 Cr. |
| GESHIP | Cash 5Years back | ₹ 2,922 Cr. |
| GESHIP | Cash 7Years back | ₹ 3,467 Cr. |
| GESHIP | Market Cap | ₹ 19,239 Cr. |
| GESHIP | Current Price | ₹ 1,348 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.08 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.12 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | No. Eq. Shares | 14.3 |
| GESHIP | Book value | ₹ 868 |
| GESHIP | Inven TO | 1.92 |
| GESHIP | Quick ratio | 3.93 |
| GESHIP | Exports percentage | 0.00 % |
| GESHIP | Piotroski score | 7.00 |
| GESHIP | G Factor | 6.00 |
| GESHIP | Asset Turnover | 0.33 |
| GESHIP | Financial leverage | 1.29 |
| GESHIP | No. of Share Holders | 1,24,075 |
| GESHIP | Unpledged Prom Hold | 30.1 % |
| GESHIP | ROIC | 19.4 % |
| GESHIP | Debtor days | 44.9 |
| GESHIP | Industry PBV | 2.04 |
| GESHIP | Credit rating |  |
| GESHIP | WC Days | 27.8 |
| GESHIP | Earning Power | 16.2 % |
| GESHIP | Graham Number | ₹ 1,891 |
| GESHIP | Cash Cycle | 44.9 |
| GESHIP | Days Payable |  |
| GESHIP | Days Receivable | 44.9 |
| GESHIP | Inventory Days |  |
| GESHIP | Public holding | 28.0 % |
| GESHIP | FII holding | 24.5 % |
| GESHIP | Chg in FII Hold | -2.90 % |
| GESHIP | DII holding | 17.4 % |
| GESHIP | Chg in DII Hold | 0.76 % |
| GESHIP | B.V. Prev Ann | ₹ 720 |
| GESHIP | ROCE Prev Yr | 20.9 % |
| GESHIP | ROA Prev Yr | 16.9 % |
| GESHIP | ROE Prev Ann | 26.8 % |
| GESHIP | No. of Share Holders Prev Qtr | 1,00,251 |
| GESHIP | No. Eq. Shares 10 Yrs | 15.1 |
| GESHIP | BV 3yrs back | ₹ 524 |
| GESHIP | BV 5yrs back | ₹ 462 |
| GESHIP | BV 10yrs back | ₹ 493 |
| GESHIP | Inven TO 3Yr | 1.71 |
| GESHIP | Inven TO 5Yr | 2.76 |
| GESHIP | Inven TO 7Yr | 2.16 |
| GESHIP | Inven TO 10Yr | 3.62 |
| GESHIP | Export 3Yr | 0.00 % |
| GESHIP | Export 5Yr | 0.00 % |
| GESHIP | Div 5Yrs | ₹ 286 Cr. |
| GESHIP | ROCE 3Yr | 15.6 % |
| GESHIP | ROCE 5Yr | 12.0 % |
| GESHIP | ROCE 7Yr | 9.65 % |
| GESHIP | ROCE 10Yr | 9.40 % |
| GESHIP | ROE 10Yr | 11.2 % |
| GESHIP | ROE 7Yr | 11.2 % |
| GESHIP | ROE 5Yr Var | 166 % |
| GESHIP | OPM 5Year | 49.2 % |
| GESHIP | OPM 10Year | 46.0 % |
| GESHIP | No. of Share Holders 1Yr | 85,121 |
| GESHIP | Avg Div Payout 3Yrs | 20.8 % |
| GESHIP | Debtor days 3yrs | 38.2 |
| GESHIP | Debtor days 3yrs back | 29.6 |
| GESHIP | Debtor days 5yrs back | 31.2 |
| GESHIP | ROA 5Yr | 8.50 % |
| GESHIP | ROA 3Yr | 12.0 % |
| GESHIP | Market Cap | ₹ 19,174 Cr. |
| GESHIP | Current Price | ₹ 1,343 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.05 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.13 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | Avg Vol 1Mth | 29,23,100 |
| GESHIP | Avg Vol 1Wk | 22,36,186 |
| GESHIP | Volume | 11,86,966 |
| GESHIP | High price | ₹ 1,544 |
| GESHIP | Low price | ₹ 725 |
| GESHIP | High price all time | ₹ 1,544 |
| GESHIP | Low price all time | ₹ 131 |
| GESHIP | Return over 1day | -0.01 % |
| GESHIP | Return over 1week | 3.74 % |
| GESHIP | Return over 1month | 12.6 % |
| GESHIP | DMA 50 | ₹ 1,220 |
| GESHIP | DMA 200 | ₹ 1,023 |
| GESHIP | DMA 50 previous day | ₹ 1,215 |
| GESHIP | 200 DMA prev. | ₹ 1,019 |
| GESHIP | RSI | 57.0 |
| GESHIP | MACD | 45.5 |
| GESHIP | MACD Previous Day | 48.3 |
| GESHIP | MACD Signal | 55.8 |
| GESHIP | MACD Signal Prev | 58.4 |
| GESHIP | Avg Vol 1Yr | 8,63,274 |
| GESHIP | Return over 7years | 19.2 % |
| GESHIP | Return over 10years | 13.9 % |
| GESHIP | Market Cap | ₹ 19,174 Cr. |
| GESHIP | Current Price | ₹ 1,343 |
| GESHIP | High / Low | ₹ 1,544 / 725 |
| GESHIP | Stock P/E | 8.05 |
| GESHIP | Book Value | ₹ 868 |
| GESHIP | Dividend Yield | 2.13 % |
| GESHIP | ROCE | 18.5 % |
| GESHIP | ROE | 21.0 % |
| GESHIP | Face Value | ₹ 10.0 |
| GESHIP | WC to Sales | 101 % |
| GESHIP | QoQ Profits | 68.2 % |
| GESHIP | QoQ Sales | 20.2 % |
| GESHIP | Net worth | ₹ 12,397 Cr. |
| GESHIP | Market Cap to Sales | 3.65 |
| GESHIP | Interest Coverage | 10.3 |
| GESHIP | EV / EBIT | 6.37 |
| GESHIP | Debt Capacity | 0.53 |
| GESHIP | Debt To Profit | 1.17 |
| GESHIP | Capital Employed | ₹ 13,680 Cr. |
| GESHIP | CROIC | 13.8 % |
| GESHIP | debtplus | 0.29 |
| GESHIP | Leverage | ₹ 1.29 |
| GESHIP | Dividend Payout | 23.9 % |
| GESHIP | Intrinsic Value | ₹ 1,382 |
| GESHIP | CDL | 6.63 % |
| GESHIP | Cash by market cap | 0.23 |
| GESHIP | 52w Index | 75.5 % |
| GESHIP | Down from 52w high | 13.0 % |
| GESHIP | Up from 52w low | 85.2 % |
| GESHIP | From 52w high | 0.87 |
| GESHIP | Mkt Cap To Debt Cap | 0.76 |
| GESHIP | Dividend Payout | 23.9 % |
| GESHIP | Graham | ₹ 1,891 |
| GESHIP | Price to Cash Flow | 6.83 |
| GESHIP | ROCE3yr avg | 15.6 % |
| GESHIP | PB X PE | 12.6 |
| GESHIP | NCAVPS | ₹ 371 |
| GESHIP | Mar Cap to CF | 6.83 |
| GESHIP | Altman Z Score | 4.08 |
| GESHIP | M.Cap / Qtr Profit | 21.2 |