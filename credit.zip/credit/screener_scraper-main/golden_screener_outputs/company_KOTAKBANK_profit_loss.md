# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 10,838 | 11,986 | 13,319 | 20,402 | 22,324 | 25,131 | 29,831 | 33,474 | 32,820 | 33,741 | 42,151 | 56,237 | 59,204 |
| Interest | 6,024 | 6,312 | 6,966 | 11,123 | 11,458 | 12,467 | 15,187 | 15,901 | 12,967 | 11,554 | 14,411 | 22,567 | 24,538 |
| Expenses + | 6,603 | 7,053 | 9,718 | 11,541 | 14,832 | 16,805 | 19,758 | 22,578 | 29,812 | 30,699 | 33,485 | 47,052 | 49,803 |
| Financing Profit | -1,789 | -1,379 | -3,366 | -2,263 | -3,965 | -4,141 | -5,114 | -5,005 | -9,958 | -8,512 | -5,746 | -13,382 | -15,137 |
| Financing Margin % | -17% | -12% | -25% | -11% | -18% | -16% | -17% | -15% | -30% | -25% | -14% | -24% | -26% |
| Other Income + | 5,112 | 5,282 | 8,152 | 7,631 | 11,660 | 13,682 | 16,148 | 16,892 | 23,588 | 24,941 | 25,991 | 38,037 | 43,225 |
| Depreciation | 179 | 208 | 237 | 345 | 362 | 383 | 458 | 465 | 461 | 480 | 599 | 792 | 0 |
| Profit before tax | 3,144 | 3,695 | 4,550 | 5,024 | 7,332 | 9,158 | 10,576 | 11,422 | 13,168 | 15,948 | 19,646 | 23,863 | 28,088 |
| Tax % | 30% | 32% | 33% | 32% | 32% | 33% | 33% | 25% | 25% | 25% | 25% | 25% |  |
| Net Profit + | 2,238 | 2,527 | 3,105 | 3,524 | 5,019 | 6,258 | 7,204 | 8,593 | 9,990 | 12,089 | 14,925 | 18,213 | 21,511 |
| EPS in Rs | 14.66 | 16.00 | 19.72 | 18.86 | 26.84 | 32.54 | 37.74 | 44.92 | 50.41 | 60.91 | 75.13 | 91.62 | 108.23 |
| Dividend Payout % | 2% | 2% | 2% | 3% | 2% | 2% | 2% | 0% | 2% | 2% | 2% | 2% |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Phoenix ARC Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investments | 99 | 101 | 101 |  |  |  |  |  |  |  |
| Purchase of / subscription to Investments | 46 | 31 |  |  |  |  |  |  |  |  |
| Loan Disbursed during the year | 30 |  |  |  |  |  |  |  |  |  |
| Loan Repaid during the year | 30 |  |  |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.52 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.50 | 0.01 |  |  |  |  |  |  |  |
| Reimbursements received | 0.11 | 0.10 | 0.03 |  |  |  |  |  |  |  |
| Sale of Fixed Assets | 0.20 |  |  |  |  |  |  |  |  |  |
| Premium Income |  | 0.01 | 0.02 |  |  |  |  |  |  |  |
| ACE Derivatives and Commodity Exchange Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Investments | 48 | 48 | 48 |  |  |  |  |  |  |  |
| Loan Disbursed during the year | 1 | 3 |  |  |  |  |  |  |  |  |
| Loan Repaid during the year |  | 4 |  |  |  |  |  |  |  |  |
| Purchase of / subscription to Investments | 2.23 |  |  |  |  |  |  |  |  |  |
| Diminution on investments |  | 0.78 | 0.78 |  |  |  |  |  |  |  |
| Reimbursements received | 0.51 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.37 | 0.01 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.22 |  |  |  |  |  |  |  |  |  |
| Assets - Others | 0.02 | 0.02 | 0.02 |  |  |  |  |  |  |  |
| Deposits given during the year | 0.02 | 0.02 |  |  |  |  |  |  |  |  |
| Infina Finance Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 25 | 26 | 61 |  |  |  |  |  |  |  |
| Brokerage Income | 1.68 | 2.24 | 3.47 |  |  |  |  |  |  |  |
| Other liabilities |  | 0.78 | 0.08 |  |  |  |  |  |  |  |
| Assets - Others | 0.48 | 0.04 | 0.01 |  |  |  |  |  |  |  |
| Reimbursements made | 0.21 | 0.21 | 0.09 |  |  |  |  |  |  |  |
| Reimbursements received | 0.11 | 0.11 | 0.12 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.08 | 0.09 |  |  |  |  |  |  |  |
| Mr. Uday Kotak Key Person |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 24 | 28 | 31 |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 2.47 | 2.70 | 2.85 |  |  |  |  |  |  |  |
| USK Benefit Trust II |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 6.22 | 21 | 19 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 0.89 | 0.87 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.83 |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 0.03 |  |  |  |  |  |  |  |
| Kotak Education Foundation Associate |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 5.63 | 13 | 17 |  |  |  |  |  |  |  |
| Others Key Person |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 5.02 | 9.91 | 8.31 |  |  |  |  |  |  |  |
| Investments | 3.45 | 2.43 | 3.42 |  |  |  |  |  |  |  |
| Expenses - Others | 0.09 | 0.89 | 0.84 |  |  |  |  |  |  |  |
| Reimbursements made | 0.03 | 0.44 | 0.15 |  |  |  |  |  |  |  |
| Assets - Others | 0.08 | 0.26 |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.10 | 0.13 | 0.08 |  |  |  |  |  |  |  |
| Premium Income | 0.07 |  | 0.06 |  |  |  |  |  |  |  |
| Reimbursements received |  | 0.12 |  |  |  |  |  |  |  |  |
| Other liabilities | 0.04 | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Brokerage Income | 0.01 | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Sale of Fixed Assets | 0.02 |  |  |  |  |  |  |  |  |  |
| Fee and Other Income |  |  | 0.01 |  |  |  |  |  |  |  |
| Others Fee and Other Income | 0.01 |  |  |  |  |  |  |  |  |  |
| Kotak Commodity Services Private Limited |  |  |  |  |  |  |  |  |  |  |
| Interest Paid |  | 5.34 | 6.51 |  |  |  |  |  |  |  |
| Fee and Other Income |  | 2.32 | 2.82 |  |  |  |  |  |  |  |
| Reimbursements received |  | 2.08 | 1.94 |  |  |  |  |  |  |  |
| Reimbursements made |  | 1.04 | 1.58 |  |  |  |  |  |  |  |
| Assets - Others |  | 0.15 | 0.28 |  |  |  |  |  |  |  |
| Other liabilities |  | 0.14 | 0.03 |  |  |  |  |  |  |  |
| Premium Income |  | 0.01 | 0.06 |  |  |  |  |  |  |  |
| Brokerage Income |  | 0.01 | 0.02 |  |  |  |  |  |  |  |
| Deposits taken during the year |  | 0.01 | 0.01 |  |  |  |  |  |  |  |
| Deposits repaid during the year |  | 0.01 |  |  |  |  |  |  |  |  |
| Aero Agencies Limited |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 4.30 | 6.91 | 6.12 |  |  |  |  |  |  |  |
| Other liabilities | 0.10 | 0.02 | 0.01 |  |  |  |  |  |  |  |
| Mr. Dipak Gupta Key Person |  |  |  |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 4.01 | 4.15 | 4.20 |  |  |  |  |  |  |  |
| Kotak Commodity Services Limited |  |  |  |  |  |  |  |  |  |  |
| Interest Paid | 5.35 |  |  |  |  |  |  |  |  |  |
| Others Fee and Other Income | 2.16 |  |  |  |  |  |  |  |  |  |
| Reimbursements received | 1.54 |  |  |  |  |  |  |  |  |  |
| Reimbursements made | 0.48 |  |  |  |  |  |  |  |  |  |
| Other liabilities | 0.06 |  |  |  |  |  |  |  |  |  |
| Premium Income | 0.02 |  |  |  |  |  |  |  |  |  |
| Deposits taken during the year | 0.02 |  |  |  |  |  |  |  |  |  |
| Purchase of Fixed Assets | 0.01 |  |  |  |  |  |  |  |  |  |
| Mr. C. Jayaram Key Person |  |  |  |  |  |  |  |  |  |  |
| Salaries (Includes ESOP cost) | 3 | 4.14 | 0.78 |  |  |  |  |  |  |  |
| Old Mutual Life Assurance Company (South Africa) Limited |  |  |  |  |  |  |  |  |  |  |
| Other liabilities | 0.62 | 0.52 | 0.60 |  |  |  |  |  |  |  |
| Matrix Business Services India Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Expenses - Others | 0.90 |  |  |  |  |  |  |  |  |  |
| Other liabilities |  | 0.01 | 0.12 |  |  |  |  |  |  |  |
| Reimbursements made | 0.05 | 0.04 | 0.03 |  |  |  |  |  |  |  |
| Kotak & Company Private Limited |  |  |  |  |  |  |  |  |  |  |
| Reimbursements made | 0.39 |  |  |  |  |  |  |  |  |  |
| Ms. Indira Kotak Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.10 | 0.11 | 0.12 |  |  |  |  |  |  |  |
| Old Mutual PLC |  |  |  |  |  |  |  |  |  |  |
| Reimbursements received |  |  | 0.21 |  |  |  |  |  |  |  |
| Ms. Pallavi Kotak Relative |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid | 0.04 | 0.05 | 0.06 |  |  |  |  |  |  |  |
| Suresh A Kotak HUF |  |  |  |  |  |  |  |  |  |  |
| Dividend Paid |  |  | 0.01 |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 10,838 | 11,986 | 13,319 | 20,402 | 22,324 | 25,131 | 29,831 | 33,474 | 32,820 | 33,741 | 42,151 | 56,237 | 59,204 |
| Interest | 6,024 | 6,312 | 6,966 | 11,123 | 11,458 | 12,467 | 15,187 | 15,901 | 12,967 | 11,554 | 14,411 | 22,567 | 24,538 |
| Expenses + | 6,603 | 7,053 | 9,718 | 11,541 | 14,832 | 16,805 | 19,758 | 22,578 | 29,812 | 30,699 | 33,485 | 47,052 | 49,803 |
| Financing Profit | -1,789 | -1,379 | -3,366 | -2,263 | -3,965 | -4,141 | -5,114 | -5,005 | -9,958 | -8,512 | -5,746 | -13,382 | -15,137 |
| Financing Margin % | -17% | -12% | -25% | -11% | -18% | -16% | -17% | -15% | -30% | -25% | -14% | -24% | -26% |
| Other Income + | 5,112 | 5,282 | 8,152 | 7,631 | 11,660 | 13,682 | 16,148 | 16,892 | 23,588 | 24,941 | 25,991 | 38,037 | 43,225 |
| Depreciation | 179 | 208 | 237 | 345 | 362 | 383 | 458 | 465 | 461 | 480 | 599 | 792 | 0 |
| Profit before tax | 3,144 | 3,695 | 4,550 | 5,024 | 7,332 | 9,158 | 10,576 | 11,422 | 13,168 | 15,948 | 19,646 | 23,863 | 28,088 |
| Tax % | 30% | 32% | 33% | 32% | 32% | 33% | 33% | 25% | 25% | 25% | 25% | 25% |  |
| Net Profit + | 2,238 | 2,527 | 3,105 | 3,524 | 5,019 | 6,258 | 7,204 | 8,593 | 9,990 | 12,089 | 14,925 | 18,213 | 21,511 |
| EPS in Rs | 14.66 | 16.00 | 19.72 | 18.86 | 26.84 | 32.54 | 37.74 | 44.92 | 50.41 | 60.91 | 75.13 | 91.62 | 108.23 |
| Dividend Payout % | 2% | 2% | 2% | 3% | 2% | 2% | 2% | 0% | 2% | 2% | 2% | 2% |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |

