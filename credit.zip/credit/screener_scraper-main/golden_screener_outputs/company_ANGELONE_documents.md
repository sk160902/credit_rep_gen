# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/angel-one-ltd/angelone/543235/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS
20h - Allotment of 23,770 equity shares having face value of Rs. 10 each under Angel Broking Employee Long Term incentive Plan 2021.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b048b744-298b-4299-a000-f6b1eacabd7d.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd284372-86d3-4a07-9791-846445c47ce3.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
19 Jul - Newspaper Adverstisement of notice of 28th Annual General Meeting of the Company](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9942656e-e0fb-4def-acc0-2a2d96a2cdd9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c43e39b6-e9ee-4678-bca3-7cef9d9cb97d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b04f1756-3d4e-4b07-9917-54a6664500be.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b04f1756-3d4e-4b07-9917-54a6664500be.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\36cfd4ef-c9ff-4142-850d-cc014c9f4810.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/543235/72977543235_12_05_22.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/543235/68537543235_11_06_21.pdf)

## Credit Ratings
- [Rating update
29 Mar from care](https://www.careratings.com/upload/CompanyFiles/PR/202403120343_Angel_One_Limited.pdf)
- [Rating update
29 Feb from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_February%2029,%202024_RR_336376.html)
- [Rating update
25 Sep 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_September%2025,%202023_RR_328411.html)
- [Rating update
21 Aug 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_August%2021,%202023_RR_326282.html)
- [Rating update
18 Aug 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202308130809_Angel_One_Limited.pdf)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AngelOneLimited_July%2024,%202023_RR_324214.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd284372-86d3-4a07-9791-846445c47ce3.pdf)
- [PPT](https://w3assets.angelone.in/wp-content/uploads/pdfs/15072024_Investorpresentation.pdf?_gl=1*1ue6c4p*_gcl_aw*R0NMLjE3MjEzMjI0MTIuQ2owS0NRanctdUswQmhDMEFSSXNBTlF0Z0dOTGg5QmJUa2ZSVTdTSVlNSEJ5YVRJX0RGR2tBakc2UXhzTktRV0R4UmpnUW5hWUZxNUZKOGFBdUk1RUFMd193Y0I.*_gcl_au*OTQ3MzYzNDU5LjE3MjEzMjI0MTI.*_ga*OTIwOTUyNTcxLjE3MjEzMjI0MTI.*_ga_CDX93S7LDP*MTcyMTU1MTYzMy4zLjEuMTcyMTU1MTYzNy41Ni4wLjA.)
- [REC](https://www.youtube.com/embed/SkbbeULGpZE)
- [Transcript](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q1-Angel-One-Earnings-Transcript.pdf?_gl=1*1v7yet3*_gcl_au*MTE5NjA0MDQ2My4xNzE5NzY0NTA3*_ga*MTM5MTczNTM3Ni4xNzE5NzY0NTA4*_ga_CDX93S7LDP*MTcyMTA2MDAyNC4yLjAuMTcyMTA2MDAyNC42MC4wLjA.)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06d01fbc-b45d-4627-9c99-2822aa7cd86b.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2bfcc32-033d-4731-a3ef-84d4b6eeb2d9.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=22fb4db9-1502-4f89-b3f2-fa60561f5abf.pdf)
- [REC](https://www.youtube.com/embed/M_1z9y_X9RU)
- [Transcript](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q4-Angel-One-Earnings-Transcript.pdf?_gl=1*1d76xjr*_ga*MTEzOTc5MDc4LjE3MTM5ODg5NjQ.*_ga_CDX93S7LDP*MTcxMzk4ODk2NC4xLjAuMTcxMzk4ODk3MC41NC4wLjA.)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=40a2c66a-435b-47d3-9cc8-251587753a7b.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=559d4564-7587-4585-8164-3bffaaec23ab.pdf)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q3-Angel-One-Earnings-Transcript.pdf?_gl=1*j935kx*_ga*OTA5NjI4OTc0LjE3MDExNjgxOTk.*_ga_CDX93S7LDP*MTcxMzI2OTYzMS4xMzMuMS4xNzEzMjY5NzgxLjUwLjAuMA..)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/FY24-Q3-Angel-One-Earnings-Transcript.pdf?_gl=1*oz3ter*_ga*MjY1NTc2NTczLjE2OTYxNjYwMTU.*_ga_CDX93S7LDP*MTcxMDg0ODA2OC43LjEuMTcxMDg0ODEyOC42MC4wLjA.)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=85c564da-d5d7-4eb5-830e-f50c765a42be.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f83ab91c-6008-481e-8a65-c093da231d7a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=71b064e2-b841-498f-8848-3e5514084cbf.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11d1ed03-7fe1-4ffb-ac98-166a6323a3fb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=08762938-73c5-4494-ba39-859dbcfacf03.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9f107916-849d-4684-bc17-ce4ee3958522.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3cb1b6a-cfed-45a7-a183-1b65ff9f6796.pdf)
- [](https://w3assets.angelone.in/wp-content/uploads/pdfs/InvestorPresentation_17042023.pdf?_gl=1*1izgdac*_ga*MTE1NDgyMzkwMi4xNjg4NjI1MTIw*_ga_CDX93S7LDP*MTY4ODYyNTEyMC4xLjEuMTY4ODYyNTE3OS4xLjAuMA..)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=681690ec-8c63-4a58-a598-cd0d93ce2ddb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b50b4bd-9c4d-4428-be9e-ff1f5bd2817e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2d5abc0b-ba0c-498a-ba71-1ce3ffef6c5b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1e16a454-7f0f-49c0-8888-acd16f0dbe95.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4983972a-851f-444e-9045-07765d10f1a9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=10d51121-97af-4179-8a78-ddbb71afe7ea.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=76d33349-a2c6-4781-a90e-b3b86fb1d3cb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f72083ce-031d-4452-aaee-ad633978c821.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cf8486ca-7962-4734-91a6-f1b0eebb509a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da32bdac-bf62-41e0-b9b8-23749e11624f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=26d98ade-39fd-4013-bbfd-1a8108e7dd0a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c1621c2c-f975-4907-82dd-5fd40d5918a5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a9e28445-5372-4636-a575-67d613739cd5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d23e14ca-de16-42e8-b55b-420ae99431e0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5df52c26-e851-46d8-a042-1bf8612d9e52.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1494adb2-39da-43bb-8bac-b2a2bd7661e7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2831bcf9-cf80-424f-828a-1a2fedfb4d1e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bf8583-c2de-402c-8bd7-80262df4cadd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=be4a2d33-74f9-405f-b658-93232761c9ca.pdf)
- [](https://www.angelone.in/get-pdf-report-wp/Earning-calls-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2cc8329-a0fc-4c44-bb86-ed76926c7594.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3bbb3c2-2eee-45a4-b684-e7439ff71618.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=662402b2-5a96-42b3-afaa-53a9a9fae35d.pdf)
- [](https://www.angelone.in/get-pdf-report-wp/November1FilingoftranscriptofEarningscall.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=515759ae-3b26-4f86-80bb-f3946e53f3c4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28bbd273-ab15-40b3-8bb3-62188a712757.pdf)

