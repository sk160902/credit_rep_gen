# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/indiamart-intermesh-ltd/indiamart/542726/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation
2d - With Part A of Schedule III of the Regulation, the Company has scheduled an Earnings Conference Call for investors and analysts on Tuesday, July 30, …](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c507083d-27ec-43cb-9f0b-e575dc7e5eca.pdf)
- [Closure of Trading Window 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2f6b4910-e9fe-49f7-b8a2-6c6e305afef4.pdf)
- [Board Meeting Intimation for Consideration And Approval Of The Audited Standalone And Consolidated Financial Results ('Financial Results') Of The Company For The Quarter Ended June 30, 2024 And Closure Of Trading Window](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57bb2439-5710-4432-a858-a32d44cca712.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6686a16b-c9e8-4ace-91e1-007ab403940e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=334c968b-65b7-4bb4-b1ea-23ec3f5f53c4.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ba5c19f8-b5a8-474f-a9a0-6ade1a4d3cb5.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\77fe5099-871e-4d9d-84f9-a5c4c93a6acf.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/542726/74710542726_06_09_22.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/542726/69302542726.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/542726/5427260320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/542726/5427260319.pdf)
- [DRHP](https://www.sebi.gov.in/filings/public-issues/jun-2019/indiamart-intermesh-ltd_43513.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=410304a4-b128-400e-85a0-cc77566b5c84.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01314bc4-6637-4706-8ad1-1a48ae649607.pdf)
- [REC](https://www.youtube.com/watch?v=-9D0bLhh3Sk)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=482b1170-89cf-42c3-8c6c-3ddf4f0d32b7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2e4c0081-f1ea-4e3f-824f-1dfbf8a164df.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=931c7a54-e958-4147-8b95-4eb297d789b7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b174001b-93f8-4cb2-a1e8-69157b46c2d6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=299ee5de-8163-49d7-9e7a-b265640d5ef4.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a864e8ce-9257-4011-9eeb-c839b613626a.pdf)
- [REC](https://www.youtube.com/watch?v=wM4qky1LnIE&list=PL2o4J51MqpL2CVbYxVR530XdzJyddiSbz&ab_channel=IndiaMARTInterMESHLtd)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e4d1b690-a5a5-4091-9904-3e6e13668d94.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8cc6837d-489c-4a7e-a536-6514ebddd3d8.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0c08771-95af-4324-8349-7f809c848c4e.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=64a1c770-aa3f-4a60-aebc-aab5ec201694.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1f8db735-75c9-4d57-bbc3-67bb1059e2ca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=792aa0e0-8af0-4b63-a99b-c4a03dd122c3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cc9c5005-c891-41e8-8487-8571b5091cf9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ff8d127e-a441-4f3e-a4ec-9090cf6f2ed0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e45b2589-4d2f-4490-ae82-765dee7c0f7b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7ae54d63-b1f2-4ba0-ad9e-b20c4dac57f1.pdf)
- [](https://investor.indiamart.com/z_Indiamart/files/IndiaMART_Q3FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=840dcfd5-ed3b-47ac-af47-842d3b4c0da2.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2_FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=37bf1a62-d4d0-4530-899a-01a8c6758cdd.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q1_FY22_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8bd09808-0891-4500-8d39-28c33b10067e.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q4_FY21_Earnings_Webinar_Transcript_Final.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e693c6d9-5966-4ebd-9458-f32437ba50ee.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q3_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b64c41af-6df7-45de-9f4c-7584cd3d0bd6.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ab291016-8a4f-4665-91f1-e75ca4cb2ab3.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/Indiamart_Q1_FY21_Earnings_Webinar_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f49d0ed7-02e7-4f47-ba0a-7ac4ed1b825e.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/results_pdf/2019-20/IndiaMART_Q4_FY20_Earnings_Call_Transcript_18th_May_2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b478416d-7c56-4032-aa0d-55f02b2290c5.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/results_pdf/2019-20/IndiaMART_Q3FY20_Earnings_Concall_Transcript_31012020.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Q2FY20_Earnings_Concall_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ff790f8f-e8b6-46eb-8bae-ae6febc6e83d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3adf150b-220f-4877-ace8-c196052c7314.pdf)
- [](https://www.primeinfobase.in/z_Indiamart/files/IndiaMART_Concall_Transcript_Q1FY2020__1_.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9d826cc4-c08a-4786-add4-0de55024c60d.pdf)

