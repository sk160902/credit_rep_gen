# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 38,210 | 51,220 | 52,972 | 41,546 | 55,604 | 71,933 | 84,757 | 73,326 | 79,839 | 146,371 | 165,960 | 175,006 | 175,736 |
| Expenses + | 31,698 | 42,051 | 43,608 | 35,124 | 43,296 | 57,017 | 65,827 | 61,513 | 59,661 | 107,257 | 147,490 | 146,849 | 149,186 |
| Operating Profit | 6,512 | 9,169 | 9,364 | 6,422 | 12,308 | 14,916 | 18,930 | 11,813 | 20,178 | 39,114 | 18,470 | 28,157 | 26,550 |
| OPM % | 17% | 18% | 18% | 15% | 22% | 21% | 22% | 16% | 25% | 27% | 11% | 16% | 15% |
| Other Income + | -307 | -1,630 | 103 | -1,966 | 18 | -177 | 196 | -289 | 473 | 1,600 | 1,561 | 1,500 | 1,426 |
| Interest | 1,967 | 3,048 | 3,493 | 3,601 | 3,768 | 3,701 | 3,917 | 4,265 | 3,957 | 4,968 | 6,902 | 8,105 | 8,215 |
| Depreciation | 2,237 | 3,183 | 3,434 | 3,323 | 3,430 | 3,387 | 4,041 | 4,246 | 4,679 | 6,001 | 7,474 | 8,172 | 8,481 |
| Profit before tax | 1,999 | 1,308 | 2,539 | -2,468 | 5,128 | 7,651 | 11,168 | 3,013 | 12,015 | 29,745 | 5,655 | 13,380 | 11,280 |
| Tax % | 42% | 70% | 32% | -80% | 33% | 20% | 33% | -30% | 34% | 30% | 27% | 33% |  |
| Net Profit + | 929 | 402 | 1,722 | -481 | 3,467 | 6,113 | 7,524 | 3,919 | 7,873 | 20,938 | 4,139 | 8,973 | 7,412 |
| EPS in Rs | 4.32 | 1.87 | 7.43 | -1.39 | 14.57 | 25.71 | 31.60 | 16.67 | 32.73 | 85.49 | 17.14 | 36.03 | 29.94 |
| Dividend Payout % | 30% | 74% | 19% | -67% | 19% | 16% | 16% | 15% | 25% | 25% | 25% | 25% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 36% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| JSW International Tradecorp PTE Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 12,146 | 35,907 |  |  |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 18,418 | 15,478 |  |  |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 17,972 |  |  |  |  |  |  |
| Purchase of goods / power and fuel / services |  | 3,480 | 6,659 |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 2,995 | 158 |
| Others Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 6,093 | 6,986 |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 2,812 | 6,603 |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 458 |  | 3,023 | 3,371 |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 2,146 | 2,250 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 3,141 |  |  |
| Purchase of goods / power and fuel / services |  | 1,340 | 1,560 |  |  |  |  |  |  |  |
| Trade payables |  | 82 | 124 |  | 311 | 647 | 555 | 923 |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 1,932 |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 869 | 662 |  |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 1,213 |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 340 | 454 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 540 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 530 |  |  |  |  |  |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 176 | 239 | 3 | 5 |
| Dividend paid |  |  |  | 53 | 76 | 99 | 48 | 121 |  |  |
| Purchase of assets |  | 5.11 | 3.38 |  | 50 | 136 | 4 | 2 | 52 | 114 |
| Investments held by the group |  | 169 | 167 |  |  |  |  |  |  |  |
| Finance lease obligation |  |  | 177 |  |  |  |  |  |  |  |
| Trade receivables |  | 19 | 18 |  | 48 | 6 | 43 | 37 |  |  |
| Recovery of expenses incurred by us on their behalf |  | 7.44 | 5.45 |  | 23 | 33 | 41 |  |  |  |
| TRADE PAYABLES | 100 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 95 |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 44 | 49 |  |  |
| Capital / revenue advance |  | 22 | 71 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 34 | 49 |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 10 | 67 |
| Lease interest cost |  |  |  |  |  | 17 | 17 | 17 | 3 | 8 |
| Loan and advances given |  | 0.01 | 0.13 |  | 20 | 19 | 16 | 4 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 45 | 11 |
| Other income/ Interest income/ Dividend income |  |  |  |  | 13 | 25 | 18 |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 46 |  |  |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  | 8 | 26 | 11 |  |  |  |
| TRADE RECEIVABLES | 45 |  |  |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 42 |  |  |
| Capital / revenue advances aiven |  |  |  |  | 1 | 39 |  |  |  |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 35 |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 12 | 15 |  |  |  |  |  |  |  |
| PURCHASE OF ASSETS | 25 |  |  |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 12 | 13 |  |  |
| Lease & other deposit received |  |  |  |  | 12 | 12 |  |  |  |  |
| Security deposits given |  |  |  |  |  |  |  |  | 21 | 1 |
| Capital / Revenue advance |  |  |  |  | 7 | 14 |  |  |  |  |
| Loan given received back |  |  |  |  |  |  | 3 | 10 | 2 |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 12 |  |  |  |  |  |  |
| Advance received from customers |  | 0.10 |  |  |  |  | 7 | 4 |  |  |
| Interest receivable |  |  |  |  |  | 1 | 8 | 1 |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 7.86 |  |  |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 7 |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 2 | 4 |
| Loan given |  |  |  |  | 5 | 1 |  |  |  |  |
| Purchase of Assets |  |  |  | 6 |  |  |  |  |  |  |
| Advance Given/(Received Back) |  |  |  | 4 |  |  |  |  |  |  |
| Finance lease obligation repayment |  |  |  | 4 |  |  |  |  |  |  |
| Lease and other deposit received |  | 1.24 | 1.36 |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 2.07 |  |  |  |  |  |  |  |  |  |
| Lease and other deposit received back |  |  |  |  | 1 | 1 |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 2 |  |  |  |  |  |  |  |  |  |
| Interest expenses |  | 1.18 |  |  |  |  |  |  |  |  |
| Investments / share application money given during the year |  | 0.43 | 0.73 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 1 |  |  |  |  |  |
| Share application money given |  | 0.37 | 0.42 |  |  |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  | 0.29 | 0.44 |  |  |  |  |  |  |  |
| Advance given/(received back) |  |  | 0.27 |  |  |  |  |  |  |  |
| REIMBURSEMENT OF EXPENSES INCURRED ON BEHALF OF THE GROUP | 0.27 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS/SHARE APPLICATION MONEY GIVEN DURING THE YEAR | 0.27 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.26 |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.20 |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 0.04 |  |  |  |  |  |  |  |  |  |
| JSW Energy Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of Goods/ Power & fuel/ Services/ Branding expenses |  |  |  |  | 2,944 | 2,489 |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 3,189 | 1,695 |
| Purchase of Goods / Power & fuel / Services / Branding expenses |  |  |  |  |  |  | 1,811 | 2,418 |  |  |
| Purchase of goods / power and fuel / services |  | 1,203 | 2,182 |  |  |  |  |  |  |  |
| Purchase of Goods / Power & Fuel / Services |  |  |  | 2,269 |  |  |  |  |  |  |
| Trade payables |  | 158 | 355 |  | 245 | 377 | 8 | 384 |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 1,491 |  |  |  |  |  |  |  |  |  |
| Investments held by the group |  | 707 | 637 |  |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 525 | 404 |  |  |  |  |
| Sales of goods / power and fuel |  | 153 | 380 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 464 |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 412 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 347 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 252 |  |  |  |  |  |  |  |  |  |
| Trade receivables |  |  |  |  |  |  | 148 |  |  |  |
| Capital / revenue advances given |  |  |  |  |  |  | 81 |  |  |  |
| TRADE PAYABLES | 80 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 27 | 24 |
| Other income/ interest income/ dividend income |  | 26 | 24 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 2.22 | 1.83 |  | 19 | 9 |  |  |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 28 |  |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 21 | 4 |
| Lease & other deposits received |  |  |  |  |  |  | 11 | 11 |  |  |
| Lease & other deposit received |  |  |  |  | 11 | 11 |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 21 |  |  |
| Lease and other deposit received |  | 10 | 10 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 17 |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  | 3 |  |  |  | 4 | 3 | 3 |
| Other income/ Interest income/ Dividend income |  |  |  |  | 2 | 11 |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  | 2.16 | 2.07 |  | 3 | 3 | 1 |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 10 |  |  |  |  |  |  |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 6 |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 3 |  |  |  |  |  |  |
| INTEREST EXPENSES | 2.98 |  |  |  |  |  |  |  |  |  |
| REIMBURSEMENT OF EXPENSES INCURRED ON BEHALF OF THE GROUP | 2.66 |  |  |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 1.18 |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  | 1 |  |  |  |  |  |
| Lease and other deposit given |  | 0.29 | 0.29 |  |  |  |  |  |  |  |
| JSW Projects Limited |  |  |  |  |  |  |  |  |  |  |
| Finance lease obligation |  | 1,842 | 1,666 |  |  |  |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  | 1,280 | 1,052 |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 797 | 512 | 318 |  |
| Loan and advances given |  |  |  |  | 300 | 415 | 315 | 225 |  |  |
| Loan given |  |  |  | 300 | 300 | 130 | 200 |  |  |  |
| Purchase of assets |  |  |  |  |  |  |  |  |  | 858 |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  | 204 | 228 | 255 |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 614 |  |  |  |  |  |  |  |  |  |
| Finance lease interest cost |  | 195 | 197 | 177 |  |  |  |  |  |  |
| Finance lease obligation repayment |  | 169 | 176 | 183 |  |  |  |  |  |  |
| Loan given received back |  |  |  |  |  | 15 | 300 | 90 | 105 |  |
| Lease interest cost |  |  |  |  | 156 | 132 | 105 | 75 | 41 |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 500 |  |  |  |  |  |  |  |  |  |
| Loan given Received back |  |  |  | 300 |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 50 | 49 |  |  |  |  |
| Capital / revenue advance |  | 49 | 49 |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 49 | 49 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 2 | 40 | 36 |  |  |  |
| TRADE PAYABLES | 75 |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 36 |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 20 | 12 |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 26 |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 15 |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 5.43 | 6.38 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Jindal Saw Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 1,128 |  | 3,249 | 3,194 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 1,198 | 1,165 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 1,534 |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 792 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 658 |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 485 | 71 |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  |  |  | 55 | 94 | 90 | 139 |
| Trade receivables |  |  | 0.01 |  | 34 | 34 |  | 74 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  |  | 55 |
| Lease & other deposit received |  |  |  |  | 5 | 5 |  |  |  |  |
| Lease and other deposit received |  | 4.13 | 4.55 |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 5 |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 5 |  |  |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Advance received from customers |  | 0.08 |  |  |  | 1 | 1 |  |  |  |
| Notes payable |  |  | 0.40 |  |  |  |  |  |  |  |
| Bhushan power & Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Guarantees and collaterals provided by |  |  |  |  |  |  | 10,800 |  |  |  |
| JSW International Trade Corp PTE Limited |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 370 | 546 |  | 1,398 | 1,499 |  | 5,434 |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 149 |  |  |
| TRADE PAYABLES | 27 |  |  |  |  |  |  |  |  |  |
| Epsilon Carbon Private Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 345 |  | 1,035 | 864 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 543 | 530 |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 846 |  |  |
| Trade receivables |  | 55 | 64 |  | 124 | 109 | 106 | 124 |  |  |
| Sales of goods / power and fuel |  | 276 | 246 |  |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 345 |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 319 |  |  |  |  |  |  |
| TRADE RECEIVABLES | 44 |  |  |  |  |  |  |  |  |  |
| JSW International Tradecorp Pte Limited |  |  |  |  |  |  |  |  |  |  |
| PURCHASE OF GOODS/POWER AND FUEL/SERVICES | 3,629 |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  |  |  |  | 1,192 |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  |  | 119 | 68 |  |  |  |
| Jindal Industries Private Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 214 |  | 831 | 1,127 |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 646 | 374 |  |  |  |  |
| Sales of goods / power and fuel |  | 609 | 287 |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 458 |  |  |  |  |  |  |
| SALES OF GOODS/POWER AND FUEL | 356 |  |  |  |  |  |  |  |  |  |
| Trade receivables |  | 23 |  |  | 24 | 8 |  |  |  |  |
| TRADE RECEIVABLES | 31 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.18 |  |  |  |  |  |  |  |
| JSW Techno Projects Management Limited |  |  |  |  |  |  |  |  |  |  |
| Lease liabilities |  |  |  |  |  |  | 997 | 946 | 57 | 78 |
| Lease liabilities / Finance lease obligation |  |  |  |  | 567 | 550 |  |  |  |  |
| Lease interest cost |  |  |  |  | 54 | 84 | 95 | 118 | 112 | 119 |
| Dividend paid |  |  |  | 52 | 74 | 101 | 51 | 172 |  |  |
| Loan given |  |  |  | 447 |  |  |  |  |  |  |
| Loan given received back |  |  |  |  |  | 96 |  |  |  |  |
| Finance lease interest cost |  |  | 13 | 25 |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 11 | 8 |  |  |  |  |
| Lease liabilities / Finance lease obligation repayment |  |  |  |  |  |  | 17 |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 13 |  |  |  |  |  |  |
| Interest expenses |  |  |  |  |  | 2 |  | 4 | 4 |  |
| Interest receivable |  |  |  |  |  | 9 |  |  |  |  |
| Loan refunded |  |  |  |  |  | 6 |  |  |  |  |
| Finance lease obligation repayment |  |  | 2.41 |  |  |  |  |  |  |  |
| ADVANCE GIVEN | 0.03 |  |  |  |  |  |  |  |  |  |
| JSW Ispat Special Products Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 711 |  | 1,166 | 443 |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 968 |  |  |
| Loan and advances given |  |  |  |  |  |  | 215 | 215 |  |  |
| Trade receivables |  |  |  |  |  |  | 13 | 192 |  |  |
| Interest receivable |  |  |  |  |  |  | 45 | 68 |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 48 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 27 | 9 |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 26 |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  | 1 |  |  |
| JSW Severfield Structures Limited JV |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  | 416 | 762 | 228 | 141 | 530 | 499 |
| Purchase of Assets |  |  |  | 136 |  |  |  |  |  |  |
| Investments / Share Application Money given during the year |  |  |  | 45 |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 42 |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  | 38 |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 13 | 13 |  |  |
| Lease & other deposit received |  |  |  |  | 13 | 13 |  |  |  |  |
| JSW Paints Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Purchase of goods/powerS fuel/ services/branding expenses/ demurrage |  |  |  |  |  |  |  |  | 780 | 908 |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 200 | 250 |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 300 |  |  |
| Capital / revenue advances received back |  |  |  |  |  |  | 10 | 70 |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 70 |  |  |  |
| Capital / revenue advances given |  |  |  |  |  |  | 45 |  |  |  |
| Lease deposit received |  |  | 4.19 |  |  |  |  |  |  |  |
| Lease and other deposit received |  |  | 4.19 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  | 3.35 |  |  |  |  |  |  |  |
| JSW Cement Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  | 4.14 | 25 |  | 148 | 243 | 157 | 258 | 275 | 139 |
| Recovery of expenses incurred by |  |  |  |  |  |  |  |  | 110 | 121 |
| Recovery of expenses incurred by us on their behalf |  | 7.03 | 8.89 |  | 43 | 45 | 71 |  |  |  |
| Capital / revenue advance |  | 72 | 73 |  |  |  |  |  |  |  |
| SALE OF FIXED ASSETS | 118 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their Behalf |  |  |  |  |  |  |  | 96 |  |  |
| Security and other deposits taken |  |  |  |  |  |  |  | 92 |  |  |
| Security deposits given |  |  |  |  |  |  |  | 90 |  |  |
| CAPITAL/REVENUE ADVANCES GIVEN | 70 |  |  |  |  |  |  |  |  |  |
| Purchase of Assets |  |  |  | 51 |  |  |  |  |  |  |
| Security deposits taken |  |  |  |  |  |  |  |  | 33 | 8 |
| TRADE RECEIVABLES | 27 |  |  |  |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  | 11 | 11 |  |  |
| Lease & other deposit received |  |  |  |  | 11 | 11 |  |  |  |  |
| Trade receivables |  | 6.64 | 13 |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 17 |  |  |  |  |  |  |
| Lease deposit received |  |  |  |  | 11 |  |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  | 5 |  |  |  |  |  |
| Lease and other deposit received back |  |  |  |  |  |  | 1 |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.53 |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  | 0.25 |  |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.10 |  |  |  |  |  |  |  |  |  |
| JSW Ml Steel Service Centre Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  |  |  | 854 | 1,039 |
| Sale of assets |  |  |  |  |  |  |  |  |  | 36 |
| JSW Shipping and Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Lease and other deposits given |  |  |  |  | 59 | 175 | 247 | 300 |  |  |
| Lease liabilities |  |  |  |  |  |  | 137 | 298 | 32 | 35 |
| Security deposit given |  |  |  |  | 59 | 116 |  |  |  |  |
| Security deposits given |  |  |  |  |  |  | 71 | 53 |  |  |
| Loan and advances given |  |  |  |  | 105 |  |  |  |  |  |
| Lease interest cost |  |  |  |  |  |  | 2 | 27 | 27 | 24 |
| Interest receivable |  |  |  |  |  |  | 28 | 27 |  |  |
| Bhushan Power and Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/ Services/Assets |  |  |  |  |  |  |  | 1,296 |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 11 |  |  |  |
| JSW Vallabh Tin Plate Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/ Power & fuel/ Services/ Assets |  |  |  |  | 431 | 312 |  |  |  |  |
| Sales of Goods/Power & Fuel |  |  |  | 332 |  |  |  |  |  |  |
| Trade receivables |  | 25 | 68 |  | 83 |  |  |  |  |  |
| India Flysafe Aviation Limited |  |  |  |  |  |  |  |  |  |  |
| Lease and other deposits given |  |  |  |  | 203 | 193 | 183 | 171 |  |  |
| Advance Given/(Received Back) |  |  |  | 214 |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 21 | 20 | 20 |  |  |  |
| Lease and other deposit received back |  |  |  |  | 10 | 10 | 10 | 11 | 7 | 6 |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 12 | 10 |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 14 |  |  |  |  |  |  |
| JSW Foundation |  |  |  |  |  |  |  |  |  |  |
| Donation/CSR expenses |  |  |  |  |  |  |  |  | 321 | 326 |
| Donation/ CSR expenses |  | 3.60 | 3.02 |  | 26 | 75 | 83 | 264 |  |  |
| Donation/ CSR Expenses |  |  |  | 11 |  |  |  |  |  |  |
| DONATION/ CSR EXPENSES | 1.83 |  |  |  |  |  |  |  |  |  |
| JSW Dharamatar Port Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  | 200 | 200 |  |  |
| Capital/revenue advances received back |  |  |  |  |  |  |  |  | 200 |  |
| Capital / Revenue advance |  |  |  |  |  | 200 |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  |  | 138 |  |  |  |  |
| Lease interest cost |  |  |  |  |  |  |  |  | 12 | 20 |
| Lease liabilities |  |  |  |  |  |  |  |  | 9 | 20 |
| Jindal Steel & Power Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  | 110 | 47 |  | 228 | 238 |  | 159 |  |  |
| PURCHASE OF ASSETS | 107 |  |  |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 33 |  |  |  |  |  |
| Purchase of Assets |  |  |  | 25 |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.91 |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  | 0.48 |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.10 |  |  |  |  |  |  |  |
| Sapphire Airlines Private Limited |  |  |  |  |  |  |  |  |  |  |
| Security deposits given |  |  |  |  |  |  |  | 147 | 191 | 193 |
| Lease and other deposits given |  |  |  |  |  |  |  | 147 |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 22 | 44 |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 3 |  |  |
| Interest receivable |  |  |  |  |  |  |  | 2 |  |  |
| Jindal Steel S Power Limited |  |  |  |  |  |  |  |  |  |  |
| Purchase of assets |  |  |  |  |  |  | 87 |  | 374 | 217 |
| St. James Investment Limited |  |  |  |  |  |  |  |  |  |  |
| Notes payable |  | 285 | 22 |  |  |  |  |  |  |  |
| NOTES PAYABLE | 269 |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 79 |  |  |  |  |  |  |  |  |
| Interest expenses |  | 12 |  |  |  |  |  |  |  |  |
| INTEREST EXPENSES | 8.79 |  |  |  |  |  |  |  |  |  |
| JSW Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Loans/advances/deposits taken |  | 122 | 87 |  |  |  |  |  |  |  |
| LOANS AND ADVANCES TAKEN | 186 |  |  |  |  |  |  |  |  |  |
| Lease and other advances refunded |  | 37 | 47 |  | 53 |  |  |  |  |  |
| Lease and Other Advances refunded |  |  |  | 48 |  |  |  |  |  |  |
| ADVANCE TAKEN REFUNDED | 37 |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 1.73 | 4.38 |  | 6 | 7 |  |  |  |  |
| Liabilities written back |  |  |  |  | 11 |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 6 |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.10 |  |  |  |  |  |  |  |  |  |
| Brahmani River Pellets Limited |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 646 |  |  |  |
| Monnet Ispat & Energy Limited JV |  |  |  |  |  |  |  |  |  |  |
| Loan and advances given |  |  |  |  | 125 | 215 |  |  |  |  |
| Loan given |  |  |  |  | 125 | 90 |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 1 | 36 |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 7 | 16 |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  | 15 | 1 |  |  |  |  |
| JSW MI Steel Service Centre Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of Goods/Power & Fuel/Services/ Assets |  |  |  |  |  |  | 433 |  |  |  |
| Trade receivables |  |  |  |  | 42 | 44 |  |  |  |  |
| Investments / share application money given during the year |  | 12 | 24 |  |  |  |  |  |  |  |
| Share application money given |  |  | 24 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  | 1 |  |  |  |  |  |
| JSW Vallabh Tinplate Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Sales of goods / power and fuel |  | 250 | 273 |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  | 2.99 | 3.32 |  |  |  |  |  |  |  |
| JSW Severeld Structures Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments held by the group |  | 115 | 115 |  |  |  |  |  |  |  |
| Purchase of assets |  | 138 | 45 |  |  |  |  |  |  |  |
| Lease and other deposit received |  | 11 | 12 |  |  |  |  |  |  |  |
| Trade receivables |  | 0.42 | 21 |  |  |  |  |  |  |  |
| Jindal Steel & power Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances aiven |  |  |  |  |  | 200 |  |  |  |  |
| Capital / revenue advances received back |  |  |  |  |  | 200 |  |  |  |  |
| Creixent Special Steels Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  | 370 |  |  |  |  |  |
| Loan given |  |  |  |  |  |  | 2 | 1 | 4 |  |
| JSW Holdings Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 40 | 57 | 73 | 36 | 118 |  |  |
| Piombino Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  |  |  | 137 |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 123 |  |  |
| Loan given |  |  |  |  |  |  |  | 4 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 3 |  |  |  |
| JSW Realty & Infrastructure Private Limited |  |  |  |  |  |  |  |  |  |  |
| INVESTMENTS HELD BY THE GROUP | 199 |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 40 |  |  |  |  |  |  |  |  |  |
| JSW MI Steel Service Center Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Trade receivables |  |  |  |  |  |  | 50 | 71 |  |  |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 83 |  |  |
| Sahyog Holdings Private Limited |  |  |  |  |  |  |  |  |  |  |
| Dividend paid |  |  |  | 25 | 35 | 46 | 22 | 73 |  |  |
| JSW Dharmatar Port Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advances aiven |  |  |  |  |  | 200 |  |  |  |  |
| JSW One Platform Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 156 |  |
| Investments / Share Application Money given during the period |  |  |  |  |  |  |  | 8 |  |  |
| JSW Renewable Energy (Vijayanagar) Limited |  |  |  |  |  |  |  |  |  |  |
| Investments/Share Application Money given |  |  |  |  |  |  |  |  | 77 | 76 |
| Bhushan Power & Steel Limited JV |  |  |  |  |  |  |  |  |  |  |
| Loan and advances given |  |  |  |  |  |  | 134 |  |  |  |
| Interest expenses |  |  |  |  |  |  |  | 4 |  |  |
| Rohne Coal Company Private Limited JV |  |  |  |  |  |  |  |  |  |  |
| Capital / revenue advance |  | 42 | 14 |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 19 | 22 |  |  |  |  |
| Capital / revenue advances (including other receivables) |  |  |  |  |  |  |  | 28 |  |  |
| SHARE APPLICATION MONEY | 3.93 |  |  |  |  |  |  |  |  |  |
| Investments / Share application money given |  |  |  |  |  | 1 |  |  |  |  |
| Share application money given |  | 0.03 | 0.02 |  |  |  |  |  |  |  |
| JSW Ispat Special Steels Limited JV |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  |  |  |  |  |  |  | 119 |  |  |
| South West Port Limited |  |  |  |  |  |  |  |  |  |  |
| Trade payables |  | 24 | 75 |  |  |  |  |  |  |  |
| Liabilities written back |  |  |  |  | 3 |  |  |  |  |  |
| JSW Severfield Stuructures Limited JV |  |  |  |  |  |  |  |  |  |  |
| PURCHASE OF ASSETS | 99 |  |  |  |  |  |  |  |  |  |
| Dolvi Minerals & Metals Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| TRADE PAYABLES | 41 |  |  |  |  |  |  |  |  |  |
| INVESTMENTS/SHARE APPLICATION MONEY GIVEN DURING THE YEAR | 40 |  |  |  |  |  |  |  |  |  |
| JSW Jaigarh Port Limited |  |  |  |  |  |  |  |  |  |  |
| Lease liabilities / Finance lease obligation |  |  |  |  |  | 46 |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  |  |  | 7 | 3 |  |  |  |  |
| Lease and other deposit received |  | 3.50 | 3.50 |  |  |  |  |  |  |  |
| Recovery of Expenses incurred by us on their behalf |  |  |  | 5 |  |  |  |  |  |  |
| Lease & other deposits received |  |  |  |  |  |  |  | 4 |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 3.50 |  |  |  |  |  |  |  |  |  |
| JSW Global Business Solutions Limited |  |  |  |  |  |  |  |  |  |  |
| Advance given/(received back) |  | 10 | 29 |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  | 6 | 6 |  |  |  |  |
| Other Income/ Interest Income/ Dividend Income |  |  |  | 7 |  |  |  |  |  |  |
| Loan and advances given |  |  | 5.11 |  |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  |  | 1 | 3 |
| Reimbursement of expenses incurred on our behalf by |  |  | 2.81 |  |  |  | 1 |  |  |  |
| Loan refunded |  |  |  |  |  |  |  | 3 |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.64 |  |  |  |  |  |  |  |  |  |
| St .James Investment limited |  |  |  |  |  |  |  |  |  |  |
| TRADE PAYABLES | 63 |  |  |  |  |  |  |  |  |  |
| JSW Shipping S Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Other income/lnterest income/ Dividend Income |  |  |  |  |  |  |  |  | 25 | 35 |
| JSW Power Trading Company Limited |  |  |  |  |  |  |  |  |  |  |
| Trade receivables |  | 49 |  |  |  |  |  |  |  |  |
| TRADE RECEIVABLES | 1.64 |  |  |  |  |  |  |  |  |  |
| RECOVERY OF EXPENSES INCURRED BY THE GROUP ON BEHALF OF OTHERS | 0.61 |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.37 |  |  |  |  |  |  |  |
| JSW Shipping & Logistics Private Limited |  |  |  |  |  |  |  |  |  |  |
| Other income/ Interest income/ Dividend Income |  |  |  |  |  |  |  | 27 |  |  |
| Other income/ Interest income/ Dividend income |  |  |  |  |  |  | 20 |  |  |  |
| JSW Praxair Oxygen Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| OTHER INCOME/ INTEREST INCOME/ DIVIDEND INCOME | 38 |  |  |  |  |  |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 3.83 |  |  |  |  |  |  |  |  |  |
| JSW Industrial Gases Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| Other income/ interest income/ dividend income |  | 15 | 11 |  |  |  |  |  |  |  |
| Lease and other deposit received |  | 3.83 |  |  |  |  |  |  |  |  |
| JSW IP Holdings Private Limited |  |  |  |  |  |  |  |  |  |  |
| Capital / Revenue advance |  |  |  |  | 18 | 10 |  |  |  |  |
| Mr. Sajjan Jindal Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 26 |  |  |  |  |  |  |  |  |  |
| Dolvi Coke Projects Limited Associate |  |  |  |  |  |  |  |  |  |  |
| TRADE RECEIVABLES | 22 |  |  |  |  |  |  |  |  |  |
| JSW Steel EPF Trust |  |  |  |  |  |  |  |  |  |  |
| Contribution to post employment benefit entities |  |  |  |  |  |  | 21 |  |  |  |
| Brahmani River Pellet Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  | 13 | 7 |  |  |
| Geo Steel LLC JV |  |  |  |  |  |  |  |  |  |  |
| OTHER ADVANCES GIVEN | 14 |  |  |  |  |  |  |  |  |  |
| AcciaItalia S.p.A. JV |  |  |  |  |  |  |  |  |  |  |
| Investments / share application money given during the year |  |  | 13 |  |  |  |  |  |  |  |
| JSW Global Business Solutions Private Limited |  |  |  |  |  |  |  |  |  |  |
| Loan given received back |  |  |  |  | 11 | 2 |  |  |  |  |
| JSW MI Steel Service Centre JV |  |  |  |  |  |  |  |  |  |  |
| Share application money given |  | 12 |  |  |  |  |  |  |  |  |
| JSW Cements Limited |  |  |  |  |  |  |  |  |  |  |
| Reimbursement of Expenses incurred on our behalf by |  |  |  |  |  |  |  | 2 | 4 |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  |  |  | 5 |  |  |  |
| JSW Steel Group Gratuity Trust |  |  |  |  |  |  |  |  |  |  |
| Contribution to post employment benefit entities |  |  |  |  |  |  | 7 | 3 |  |  |
| JSW Severfield structures limited JV |  |  |  |  |  |  |  |  |  |  |
| LEASE AND OTHER DEPOSIT RECEIVED | 6.50 |  |  |  |  |  |  |  |  |  |
| JSW Energy (Kutehr) Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  |  | 5 |  |  |
| Mr. Seshagiri Rao M V S Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 4.14 |  |  |  |  |  |  |  |  |  |
| JSW One Platforms Limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  |  | 4 |  |  |
| Gourangdih Coal Limited JV |  |  |  |  |  |  |  |  |  |  |
| Share application money given |  |  |  |  |  | 1 | 1 | 1 |  |  |
| Loan and advances given |  | 0.38 | 0.38 |  |  |  |  |  |  |  |
| JSoft Solutions Limited |  |  |  |  |  |  |  |  |  |  |
| Recovery of expenses incurred by us on their behalf |  |  | 3.50 |  |  |  |  |  |  |  |
| Dr. Vinod Nowal Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 3.04 |  |  |  |  |  |  |  |  |  |
| Jindal Rail Infrastructure Limited |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  |  | 3 |  |  |  |
| Mr. Jayant Acharya Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 2.63 |  |  |  |  |  |  |  |  |  |
| JSW Structural Metal Decking Limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  | 1 | 1 |  |  |  |
| Monnet ipat & Energy limited JV |  |  |  |  |  |  |  |  |  |  |
| Advance received from customers |  |  |  |  |  | 2 |  |  |  |  |
| Mr. Rajeev Pai Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 1.27 |  |  |  |  |  |  |  |  |  |
| JSW Praxair Company Private Limited Associate |  |  |  |  |  |  |  |  |  |  |
| INTEREST EXPENSES | 1.17 |  |  |  |  |  |  |  |  |  |
| JSW Cement, FZE |  |  |  |  |  |  |  |  |  |  |
| Reimbursement of expenses incurred on our behalf by |  |  |  |  |  | 1 |  |  |  |  |
| Mr. Lancy Varghese Key Person |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 0.46 |  |  |  |  |  |  |  |  |  |
| Jindal Saw USA LLC |  |  |  |  |  |  |  |  |  |  |
| Notes payable |  |  | 0.25 |  |  |  |  |  |  |  |
| ADVANCE RECEIVED FROM CUSTOMERS | 0.17 |  |  |  |  |  |  |  |  |  |
| Rohne Coal Company Limited JV |  |  |  |  |  |  |  |  |  |  |
| Investments / share application money refunded during the year |  | 0.37 |  |  |  |  |  |  |  |  |
| O.P. Jindal Foundation |  |  |  |  |  |  |  |  |  |  |
| DONATION/ CSR EXPENSES | 0.17 |  |  |  |  |  |  |  |  |  |
| Mr. Parth Jindal Relative |  |  |  |  |  |  |  |  |  |  |
| REMUNERATION TO KEY MANAGERIAL PERSONNEL | 0.07 |  |  |  |  |  |  |  |  |  |
| JSL Architecture Limited |  |  |  |  |  |  |  |  |  |  |
| ADVANCE GIVEN | 0.02 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 38,210 | 51,220 | 52,972 | 41,546 | 55,604 | 71,933 | 84,757 | 73,326 | 79,839 | 146,371 | 165,960 | 175,006 | 175,736 |
| Expenses + | 31,698 | 42,051 | 43,608 | 35,124 | 43,296 | 57,017 | 65,827 | 61,513 | 59,661 | 107,257 | 147,490 | 146,849 | 149,186 |
| Operating Profit | 6,512 | 9,169 | 9,364 | 6,422 | 12,308 | 14,916 | 18,930 | 11,813 | 20,178 | 39,114 | 18,470 | 28,157 | 26,550 |
| OPM % | 17% | 18% | 18% | 15% | 22% | 21% | 22% | 16% | 25% | 27% | 11% | 16% | 15% |
| Other Income + | -307 | -1,630 | 103 | -1,966 | 18 | -177 | 196 | -289 | 473 | 1,600 | 1,561 | 1,500 | 1,426 |
| Interest | 1,967 | 3,048 | 3,493 | 3,601 | 3,768 | 3,701 | 3,917 | 4,265 | 3,957 | 4,968 | 6,902 | 8,105 | 8,215 |
| Depreciation | 2,237 | 3,183 | 3,434 | 3,323 | 3,430 | 3,387 | 4,041 | 4,246 | 4,679 | 6,001 | 7,474 | 8,172 | 8,481 |
| Profit before tax | 1,999 | 1,308 | 2,539 | -2,468 | 5,128 | 7,651 | 11,168 | 3,013 | 12,015 | 29,745 | 5,655 | 13,380 | 11,280 |
| Tax % | 42% | 70% | 32% | -80% | 33% | 20% | 33% | -30% | 34% | 30% | 27% | 33% |  |
| Net Profit + | 929 | 402 | 1,722 | -481 | 3,467 | 6,113 | 7,524 | 3,919 | 7,873 | 20,938 | 4,139 | 8,973 | 7,412 |
| EPS in Rs | 4.32 | 1.87 | 7.43 | -1.39 | 14.57 | 25.71 | 31.60 | 16.67 | 32.73 | 85.49 | 17.14 | 36.03 | 29.94 |
| Dividend Payout % | 30% | 74% | 19% | -67% | 19% | 16% | 16% | 15% | 25% | 25% | 25% | 25% |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 30% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 38% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 2% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 36% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 22% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |

