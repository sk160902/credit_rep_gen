# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,145 | 8,778 | 9,720 | 8,968 | 10,400 | 628 | 356 | 342 | 34 | 88 | 154 | 66 |
| Expenses + | 844 | 1,141 | 1,777 | 1,490 | 1,806 | 517 | 1,200 | 1,274 | 503 | 25 | 64 | 21 |
| Operating Profit | 7,301 | 7,637 | 7,943 | 7,478 | 8,594 | 112 | -844 | -932 | -469 | 64 | 91 | 44 |
| OPM % | 90% | 87% | 82% | 83% | 83% | 18% | -237% | -273% | -1,364% | 72% | 59% | 68% |
| Other Income + | 3 | 12 | -0 | -2,640 | -3 | 984 | -107 | 31 | 171 | 61 | 4,545 | 1,016 |
| Interest | 4,676 | 5,055 | 5,658 | 5,736 | 6,650 | 1 | 6 | 3 | 10 | 0 | 0 | 7 |
| Depreciation | 34 | 31 | -61 | 62 | 149 | 13 | 14 | 32 | 3 | 0 | 0 | 0 |
| Profit before tax | 2,594 | 2,563 | 2,346 | -959 | 1,791 | 1,082 | -970 | -936 | -311 | 125 | 4,635 | 1,054 |
| Tax % | 29% | 29% | 25% | -38% | 27% | 18% | -15% | 6% | 8% | 48% | 8% | 1% |
| Net Profit + | 1,844 | 1,826 | 1,728 | -657 | 1,240 | 885 | -822 | -996 | -337 | 64 | 4,244 | 1,046 |
| EPS in Rs | 12.12 | 11.89 | 10.72 | -5.86 | 4.38 | 5.44 | -5.26 | -6.23 | -2.10 | 0.40 | 26.52 | 6.53 |
| Dividend Payout % | 21% | 22% | 24% | 0% | 6% | 14% | 0% | -51% | 0% | 249% | 45% | 0% |
| 10 Years: | -39% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -29% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -58% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 62% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 140% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 8% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Millennium City Expressways Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding Equity Investment | 177 | 90 | 218 |  |  |  |  |  |  |
| Advances recoverable - balance outstanding |  | 60 | 386 |  |  |  |  |  |  |
| Loans given | 422 |  |  |  |  |  |  |  |  |
| Purchase / subscription of Investments | 177 | 11 | 24 |  |  |  |  |  |  |
| Interest income | 36 | 6.57 | 39 |  |  |  |  |  |  |
| Interest accrued on loans - balance outstanding | 3.67 |  |  |  |  |  |  |  |  |
| Outstanding other receivables | 0.17 |  |  |  |  |  |  |  |  |
| Galaxy Mercantiles Limited Subsidiary |  |  |  |  |  |  |  |  |  |
| Redemption receipt of OCDs | 261 |  |  |  |  |  |  |  |  |
| Interest income | 14 |  |  |  |  |  |  |  |  |
| Feedback Infra Private Limited Associate |  |  |  |  |  |  |  |  |  |
| Advances recoverable - balance outstanding |  |  | 126 |  |  |  |  |  |  |
| Outstanding Equity Investment | 20 |  | 20 |  |  |  |  |  |  |
| Outstanding Investment in debentures | 40 |  |  |  |  |  |  |  |  |
| Interest income | 6.67 |  | 12 |  |  |  |  |  |  |
| Interest accrued on loans - balance outstanding | 15 |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  |  | 1.96 |  |  |  |  |  |  |
| Dividend | 0.81 |  | 0.60 |  |  |  |  |  |  |
| Fees |  |  | 1.12 |  |  |  |  |  |  |
| Amount received in advance | 0.84 |  |  |  |  |  |  |  |  |
| Interest unrealised |  |  | 0.31 |  |  |  |  |  |  |
| Interest expense |  |  | 0.06 |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.01 |  |  |  |  |  |  |
| IDFC Foundation Subsidiary |  |  |  |  |  |  |  |  |  |
| Corporate Social Responsibility | 46 | 27 | 10 |  |  |  |  |  |  |
| Advances recoverable - balance outstanding | 21 | 20 | 19 |  |  |  |  |  |  |
| Outstanding Equity Investment |  | 33 | 13 |  |  |  |  |  |  |
| Advances recovered | 0.50 | 1.50 | 0.76 |  |  |  |  |  |  |
| Interest expense |  | 0.03 | 2.62 |  |  |  |  |  |  |
| Shared Service Cost |  | 0.36 | 0.24 |  |  |  |  |  |  |
| Fees paid | 0.44 |  |  |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.13 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.02 |  |  |  |  |  |  |
| Jetpur Somnath Tollways Limited Associate |  |  |  |  |  |  |  |  |  |
| Outstanding Equity Investment |  |  | 98 |  |  |  |  |  |  |
| Purchase / subscription of Investments |  |  | 8.06 |  |  |  |  |  |  |
| IDFC Foundation Limited Subsidiary |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 30 | 32 |  |  |  |  |  |  |
| Current account balance |  | 5.24 | 0.04 |  |  |  |  |  |  |
| Purchase of fixed assets |  | 0.03 |  |  |  |  |  |  |  |
| Infrastructure Development Corporation (Karnataka) Limited JV |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 7.98 | 9.35 |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.39 | 1.46 | 5.19 |  |  |  |  |  |  |
| Interest expense |  | 0.08 | 0.71 |  |  |  |  |  |  |
| Current account balance |  | 0.37 | 0.01 |  |  |  |  |  |  |
| Fees paid | 0.32 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.07 |  |  |  |  |  |  |
| Rent paid | 0.02 | 0.01 |  |  |  |  |  |  |  |
| Mr. Vikram Limaye Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid | 3.91 | 5.16 | 5.41 |  |  |  |  |  |  |
| 80CCF Bonds outstanding | 0.01 |  |  |  |  |  |  |  |  |
| Dr. Rajiv B. Lall Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid |  | 4.32 | 4.65 |  |  |  |  |  |  |
| Dr. Rajiv B.Lall Key Person |  |  |  |  |  |  |  |  |  |
| Remuneration paid | 4.40 |  |  |  |  |  |  |  |  |
| Delhi Integrated Multi-Modal Transit System Limited JV |  |  |  |  |  |  |  |  |  |
| Fixed deposits placed |  | 0.11 | 2.12 |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.06 | 0.30 | 0.24 |  |  |  |  |  |  |
| Interest expense |  |  | 0.11 |  |  |  |  |  |  |
| Current account balance |  | 0.08 | 0.01 |  |  |  |  |  |  |
| Fees paid | 0.02 |  |  |  |  |  |  |  |  |
| Interest accrued on term deposit |  |  | 0.01 |  |  |  |  |  |  |
| Uttarakhand Infrastructure Development Company Limited JV |  |  |  |  |  |  |  |  |  |
| Fees paid | 0.18 |  |  |  |  |  |  |  |  |
| Trade Payable- Balance outstanding | 0.15 |  |  |  |  |  |  |  |  |
| Mr. Bharat Mukund Limaye Relative |  |  |  |  |  |  |  |  |  |
| 80CCF Bonds outstanding | 0.01 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 8,145 | 8,778 | 9,720 | 8,968 | 10,400 | 628 | 356 | 342 | 34 | 88 | 154 | 66 |
| Expenses + | 844 | 1,141 | 1,777 | 1,490 | 1,806 | 517 | 1,200 | 1,274 | 503 | 25 | 64 | 21 |
| Operating Profit | 7,301 | 7,637 | 7,943 | 7,478 | 8,594 | 112 | -844 | -932 | -469 | 64 | 91 | 44 |
| OPM % | 90% | 87% | 82% | 83% | 83% | 18% | -237% | -273% | -1,364% | 72% | 59% | 68% |
| Other Income + | 3 | 12 | -0 | -2,640 | -3 | 984 | -107 | 31 | 171 | 61 | 4,545 | 1,016 |
| Interest | 4,676 | 5,055 | 5,658 | 5,736 | 6,650 | 1 | 6 | 3 | 10 | 0 | 0 | 7 |
| Depreciation | 34 | 31 | -61 | 62 | 149 | 13 | 14 | 32 | 3 | 0 | 0 | 0 |
| Profit before tax | 2,594 | 2,563 | 2,346 | -959 | 1,791 | 1,082 | -970 | -936 | -311 | 125 | 4,635 | 1,054 |
| Tax % | 29% | 29% | 25% | -38% | 27% | 18% | -15% | 6% | 8% | 48% | 8% | 1% |
| Net Profit + | 1,844 | 1,826 | 1,728 | -657 | 1,240 | 885 | -822 | -996 | -337 | 64 | 4,244 | 1,046 |
| EPS in Rs | 12.12 | 11.89 | 10.72 | -5.86 | 4.38 | 5.44 | -5.26 | -6.23 | -2.10 | 0.40 | 26.52 | 6.53 |
| Dividend Payout % | 21% | 22% | 24% | 0% | 6% | 14% | 0% | -51% | 0% | 249% | 45% | 0% |
| 10 Years: | -39% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -29% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -58% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 31% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 62% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 140% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 4% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 26% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -6% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 8% |  |  |  |  |  |  |  |  |  |  |  |

