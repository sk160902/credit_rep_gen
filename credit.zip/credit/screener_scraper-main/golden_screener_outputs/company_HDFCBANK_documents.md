# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/hdfc-bank-ltd/hdfcbank/500180/corp-announcements/)
- [Intimation Under Regulation 30 Of The SEBI (LODR) Regulations, 2015 2m](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91898dcf-4fd7-4d6f-96af-a2179b2e9ff9.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
17h - Transcript of Earnings call for the quarter ended June 30, 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94d03650-9410-4870-b9ba-d4c553d2740b.pdf)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e47bef7e-d747-4557-9b29-257bdd078551.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=54667276-2161-476a-9729-df57637b5d97.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a390e197-60e6-49cf-a197-b7aa88f2a9f7.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2160dea5-d49e-4409-83a4-c2b111a3bd12.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\0fb0e6bd-7110-44c3-a750-76933ddf105c.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/73256500180.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/68609500180.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_HDFCBANK_2011_2012_20062012100212.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500180/5001800311.pdf)

## Credit Ratings
- [Rating update
1 Jul from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128559)
- [Rating update
28 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/HDFCBankLimited_June%2028_%202024_RR_346791.html)
- [Rating update
7 Mar from care](https://www.careratings.com/upload/CompanyFiles/PR/202403120301_HDFC_Bank_Limited.pdf)
- [Rating update
5 Dec 2023 from fitch](https://www.indiaratings.co.in/pressrelease/67483)
- [Rating update
13 Nov 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202311121153_HDFC_Bank_Limited.pdf)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=120819)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94d03650-9410-4870-b9ba-d4c553d2740b.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdf)
- [REC](https://www.youtube.com/watch?v=bi_jiwKLKnQ)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdfhttps://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/About%20Investor%20Relations/pdf/2024/july/Q1FY25_Earnings_Presentation.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=880ee466-e764-4e05-9ef3-3d9bb8e485f4.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/20April/Q4FY24-Earnings-Presentation.pdf)
- [REC](https://youtu.be/xh0oa926udk?si=WQGaj1nPMlGJcHpr)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=12bab14e-f504-46e9-90cd-0881a76dd4a6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d34bd589-124e-40f2-80b5-82f360a98639.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=163829d1-3b5f-41f7-bd9e-9f3509869245.pdf)
- [Transcript](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/23/Earnings-Call-Transcript-Jan16-2024.pdf)
- [PPT](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2024/16/Q3FY24_Earnings_Presentation.pdf)
- [REC](https://www.youtube.com/watch?v=j6_jnIErxXE)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/Financial%20Information/PDF/HDFC-Bank-Day/1.%20HDFCB_Day_30Oct23_vF.pdf)
- [](https://www.youtube.com/watch?v=APkBOH4Y2Jw)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d420b35c-488c-4ea9-84ca-6183de7e29f4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7931b031-359d-4da8-8425-b4f26c2d2547.pdf)
- [](https://www.youtube.com/watch?v=sDUS9GSyRqc&t=1s)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/oct/HDFC-EarningsCall-Oct16-2023_CallTranscript.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/oct/Q2FY24%20Earnings%20Presentation.pdf)
- [](https://www.youtube.com/watch?v=eFTe9K7T9Pk)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d28f086c-3d7a-4a6d-a138-a0c2123a963a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=989cf3a5-9a81-458e-b0ec-7ea60cc482a7.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/july/HDFCB_Q1FY24_Earnings_Presentation.pdf)
- [](https://www.youtube.com/watch?v=KfKI0xSaKxw)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=57e720ab-83b3-4b34-bb81-0c364e88c938.pdf)
- [](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Footer/About%20Us/Investor%20Relation/Detail%20PAges/financial%20results/PDFs/2023/Q4FY23-Earnings-Presentation.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=42e79ecc-a641-4f9d-8fdc-a4dde6cefb16.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e9327050-8f62-42f3-a539-bd91f156647d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5ad442e-6916-47c7-ac65-c42c31df289f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25b7a31b-fd86-456f-8a27-51b4119fe7ce.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=27bf8aa3-9098-4724-9192-7f384e76f3c2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b3087c6b-5b89-43bd-bea9-4250ab026f85.pdf)

