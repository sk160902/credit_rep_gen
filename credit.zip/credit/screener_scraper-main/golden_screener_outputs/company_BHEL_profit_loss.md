# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 48,903 | 39,561 | 31,323 | 25,505 | 28,465 | 28,827 | 30,441 | 21,463 | 17,309 | 21,211 | 23,365 | 23,893 |
| Expenses + | 39,420 | 34,982 | 29,183 | 26,862 | 27,370 | 27,174 | 28,409 | 21,596 | 20,357 | 20,383 | 22,557 | 23,280 |
| Operating Profit | 9,483 | 4,579 | 2,141 | -1,357 | 1,095 | 1,653 | 2,032 | -133 | -3,049 | 828 | 807 | 613 |
| OPM % | 19% | 12% | 7% | -5% | 4% | 6% | 7% | -1% | -18% | 4% | 3% | 3% |
| Other Income + | 1,132 | 1,617 | 1,221 | 1,492 | 753 | 679 | 662 | 590 | 393 | 405 | 544 | 610 |
| Interest | 128 | 133 | 92 | 360 | 413 | 330 | 378 | 613 | 467 | 448 | 612 | 731 |
| Depreciation | 957 | 985 | 1,082 | 937 | 850 | 787 | 476 | 503 | 473 | 314 | 260 | 249 |
| Profit before tax | 9,531 | 5,078 | 2,187 | -1,161 | 586 | 1,215 | 1,840 | -659 | -3,596 | 470 | 479 | 243 |
| Tax % | 30% | 31% | 34% | -39% | 22% | 64% | 46% | 123% | -25% | 5% | 0% | -16% |
| Net Profit + | 6,693 | 3,502 | 1,450 | -706 | 455 | 438 | 1,002 | -1,468 | -2,700 | 445 | 477 | 282 |
| EPS in Rs | 18.23 | 9.54 | 3.96 | -1.92 | 1.25 | 1.20 | 2.89 | -4.21 | -7.75 | 1.28 | 1.37 | 0.81 |
| Dividend Payout % | 20% | 20% | 20% | -14% | 85% | 151% | 69% | 0% | 0% | 31% | 29% | 31% |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 72% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 201% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 1% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RPCL JV |  |  |  |  |  |  |  |  |  |
| Amounts due to BHEL at the end of the year |  |  | 472 | 485 | 511 | 542 | 552 | 551 | 637 |
| Sales of Goods and services |  |  | 130 | 91 | 35 | 17 | 7.80 | 3.27 | 9.42 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 28 | 17 | 11 | 9.30 | 7.67 | 21 | 21 |
| Rendering of Services |  |  | 106 |  |  |  |  |  |  |
| Purchase of shares |  |  |  | 75 |  |  |  |  |  |
| Provision for Doubtful debts & advances |  |  |  |  |  |  | 20 | 20 | 21 |
| Purchase of Goods and Services |  |  |  |  |  | 22 |  |  |  |
| NBPPL JV |  |  |  |  |  |  |  |  |  |
| Amounts due to BHEL at the end of the year |  |  | 309 | 310 | 281 | 263 | 196 | 264 | 225 |
| Provision for Doubtful debts & advances |  |  |  |  |  |  | 188 | 189 | 190 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 92 | 91 | 83 | 79 | 57 | 68 | 24 |
| Sales of Goods and services |  |  | 359 | 77 | 6.08 | 2.80 | 11 | 3.83 | 2.21 |
| Provision for doubtful debts & advances |  |  |  | 23 | 1.64 |  |  |  |  |
| Purchase of Goods and Services |  |  | 1.43 | 7.38 | 4.83 | 3.05 | 0.75 | 1.52 |  |
| Provision for Doubtful advances |  |  | 12 |  |  |  |  |  |  |
| Receiving of Services |  |  | 8.06 |  |  |  |  |  |  |
| Rendering of Services |  |  | 2.43 |  |  |  |  |  |  |
| Provision for Doubtful debts |  |  | 0.70 |  |  |  |  |  |  |
| BGGTS Subsidiary |  |  |  |  |  |  |  |  |  |
| Sales of Goods and services |  |  | 188 | 196 | 278 | 170 | 216 | 281 | 239 |
| Amounts due to BHEL at the end of the year |  |  | 43 | 48 | 77 | 29 | 69 | 144 | 112 |
| Dividend income |  |  | 13 | 15 | 16 | 16 | 21 | 30 | 26 |
| Provision for Doubtful debts & advances |  |  |  |  |  |  |  |  | 10 |
| Royalty income |  |  | 1.47 | 0.90 | 1.17 | 1.10 | 1.46 | 1.80 | 1.85 |
| Purchase of Goods and Services |  |  | 0.56 | 1.02 | 0.98 | 0.86 | 1.96 | 1.04 | 0.87 |
| Amounts due from BHEL (incl. advances) at the end of the year |  |  | 0.16 | 0.08 | 0.35 | 0.24 | 0.15 | 0.11 | 0.44 |
| Provision for doubtful debts & advances |  |  |  | 0.22 | 0.70 |  |  |  |  |
| Employees Superannuation Fund |  |  |  |  |  |  |  |  |  |
| Pension Fund |  |  |  |  |  |  | 280 | 115 | 247 |
| BFIEL EPF Trust,Ranipur,Hardwar |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 52 | 55 | 58 |
| BHEL Employee Provident Fund-Trichy |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 53 | 53 | 56 |
| BFIEL Employee Provident Fund Bhopal |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 51 | 53 | 56 |
| Gratuity Trust JV |  |  |  |  |  |  |  |  |  |
| Gratuity |  |  |  |  |  |  | 154 |  |  |
| BHEL New Delhi Employees Provident Fund Trust |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 39 | 41 | 44 |
| BHEL Employee Provident Fund-Hyderabad |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 39 | 41 | 42 |
| BHEL Employee Provident Fund-Bengaluru |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 29 | 28 | 29 |
| BHEL PPD EPF Trust.Chennai |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 26 | 28 | 31 |
| BHEL (BAP Unit) EPF Trust.Ranipet |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 19 | 19 | 18 |
| PRMB Trust |  |  |  |  |  |  |  |  |  |
| Post Retirement medical scheme |  |  |  |  |  |  | 42 |  |  |
| BHEL Employee Provident Fund Trust Jhansi |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 13 | 13 | 14 |
| Bharat Heavy Plates b Vessels Limited Employee Contributory Provident Fund-Vizag |  |  |  |  |  |  |  |  |  |
| Provident Fund |  |  |  |  |  |  | 5.45 | 5.81 | 6.50 |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 48,903 | 39,561 | 31,323 | 25,505 | 28,465 | 28,827 | 30,441 | 21,463 | 17,309 | 21,211 | 23,365 | 23,893 |
| Expenses + | 39,420 | 34,982 | 29,183 | 26,862 | 27,370 | 27,174 | 28,409 | 21,596 | 20,357 | 20,383 | 22,557 | 23,280 |
| Operating Profit | 9,483 | 4,579 | 2,141 | -1,357 | 1,095 | 1,653 | 2,032 | -133 | -3,049 | 828 | 807 | 613 |
| OPM % | 19% | 12% | 7% | -5% | 4% | 6% | 7% | -1% | -18% | 4% | 3% | 3% |
| Other Income + | 1,132 | 1,617 | 1,221 | 1,492 | 753 | 679 | 662 | 590 | 393 | 405 | 544 | 610 |
| Interest | 128 | 133 | 92 | 360 | 413 | 330 | 378 | 613 | 467 | 448 | 612 | 731 |
| Depreciation | 957 | 985 | 1,082 | 937 | 850 | 787 | 476 | 503 | 473 | 314 | 260 | 249 |
| Profit before tax | 9,531 | 5,078 | 2,187 | -1,161 | 586 | 1,215 | 1,840 | -659 | -3,596 | 470 | 479 | 243 |
| Tax % | 30% | 31% | 34% | -39% | 22% | 64% | 46% | 123% | -25% | 5% | 0% | -16% |
| Net Profit + | 6,693 | 3,502 | 1,450 | -706 | 455 | 438 | 1,002 | -1,468 | -2,700 | 445 | 477 | 282 |
| EPS in Rs | 18.23 | 9.54 | 3.96 | -1.92 | 1.25 | 1.20 | 2.89 | -4.21 | -7.75 | 1.28 | 1.37 | 0.81 |
| Dividend Payout % | 20% | 20% | 20% | -14% | 85% | 151% | 69% | 0% | 0% | 31% | 29% | 31% |
| 10 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -5% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 2% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -22% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 7% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 72% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 201% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 0% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | -2% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 1% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 1% |  |  |  |  |  |  |  |  |  |  |  |

