# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/bharat-petroleum-corporation-ltd/bpcl/500547/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c74453cf-ca84-4824-b05a-b5f303441d11.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Outcome
20 Jul - Audio recording of conference call for unaudited financial results for 30th June 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2c0af5f-ebf9-4dc8-abfa-f12145f19743.pdf)
- [Record Date For The Final Dividend For FY 2023-24 20 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=35a20fec-dc98-4e0c-8de8-61760f6c26d6.pdf)
- [Announcement under Regulation 30 (LODR)-Change in Directorate](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=760b60e4-9e48-429f-aecf-bafe8c2eb7cc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81d00c63-ce6f-4cd0-af13-efe62917d128.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\a62598f2-46e7-4505-8452-c7c0c424d377.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/74036500547.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/70756500547.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/66174500547.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_1216_BPCL_2012_2013_27082013105529.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_BPCL_2010_2011_11102011031717.zip)

## Credit Ratings
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407120723_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
28 Feb from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatPetroleumCorporationLimited_February%2028,%202024_RR_337761.html)
- [Rating update
10 Aug 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202308130820_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
23 Jun 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202306120646_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
14 Mar 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=118525)
- [](https://www.careratings.com/upload/CompanyFiles/PR/03032023075820_Bharat_Petroleum_Corporation_Limited.pdf)

## Concalls
- [Transcript](https://www.bharatpetroleum.in/images/files/Concall-Transcript-Q4.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation_FY%202023-24.pdf)
- [REC](https://www.bharatpetroleum.in/pdf/ConferenceCallRecording/MFG0220240510152830-f1f2b2.mp3)
- [Transcript](https://www.bharatpetroleum.in/images/files/Concall%20Transcript%20Q2.pdf)
- [Transcript](https://www.bharatpetroleum.in/images/files/BPCL%201QFY24%20transcript-Final.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%202023-24.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20%20FY%2022-23.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2022-23.pdf)
- [](https://www.bharatpetroleum.in/images/files/Presentation-to-investors-01-Sept-2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2022-23.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%2023.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20FY%2021%20final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2021%20final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2021.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY21.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY20%20December%202019(2).pdf)
- [](https://www.bharatpetroleum.in/images/files/BPCL%20Investor%20Presentation%20December%202019.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q1FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q4FY19_final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY19%20-%2010th%20Feb%202019.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY19(1).pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q1FY19.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q4FY18%20-%2027th%20June%202018.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY18%20-%2018th%20February%202018.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY18%20-%2014th%20November%202017.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investorpresentation-Q1FY18-18thAugust2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investorpresentation-Q4FY17-1stjune2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ3FY1713thFebruary2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ2FY179thNovember2016(1).pdf)
- [](https://www.bharatpetroleum.in/pdf/Investorpresentation-Q1FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6322AACD_A6CE_4C02_8682_1F4E20D05F1F_160404.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ4FY1629thMay2016.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ3FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor-presentation-Q2FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor-presentation-Q1FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor_presentation_Q4FY15.pdf)

