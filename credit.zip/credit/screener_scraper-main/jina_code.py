import requests
from itertools import cycle

API_KEYS = [
    "jina_5c1aed9e58c7439181b39bedd6e33d3bnxRWmc7pmMhV1RkEEVY-MhRWRi8Y"
]

def make_request(url, headers):
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        return response.json()  # Assuming the response is JSON
    except requests.RequestException as e:
        print(f"Request failed: {e}")
        return None

def search_using_jina(query):
    print("Searching Query",query)
    search_url = f"https://s.jina.ai/{query}"
    for api_key in cycle(API_KEYS):
        headers = {"Authorization": f"Bearer {api_key}",
                   "Accept": "application/json",
            "X-Return-Format": "text"}

        result = make_request(search_url, headers)
        if result is not None:
            return result
    return {"error": "All API keys failed"}

def reader_using_jina(url):
    print("Reading URL",url)
    reader_url = f"https://r.jina.ai/{url}"
    for api_key in cycle(API_KEYS):
        headers = {"Authorization": f"Bearer {api_key}",
                   "Accept": "application/json",
                   "X-Return-Format": "text"}
        result = make_request(reader_url, headers)
        if result is not None:
            return result
    return {"error": "All API keys failed"}

# Example usage:
query_result = search_using_jina("google stocks")
print(query_result)

reader_result = reader_using_jina("https://example.com")
print(reader_result)
