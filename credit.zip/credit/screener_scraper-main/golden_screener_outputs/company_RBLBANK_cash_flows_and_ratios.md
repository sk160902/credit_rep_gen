# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 3,434 | -2,556 | 78 | -5,173 | 7,631 | 6,449 | -11,031 | 4,955 |
| Cash from Investing Activity + | -142 | -165 | -202 | -223 | -174 | -264 | -234 | -193 |
| Cash from Financing Activity + | -1,656 | 2,994 | 2,567 | 7,698 | -4,207 | -109 | 2,235 | 843 |
| Net Cash Flow | 1,635 | 273 | 2,443 | 2,302 | 3,251 | 6,076 | -9,030 | 5,604 |

## Ratios Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % |  | 11% | 12% | 6% | 5% | -1% | 7% | 9% |