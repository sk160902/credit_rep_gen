About
[
edit
]
Reliance was founded by Dhirubhai Ambani and is now promoted and managed by his elder son, Mukesh Dhirubhai Ambani. Ambani's family has about 50% shareholding in the conglomerate.
Key Points
[
edit
]
OIL-TO-CHEMICALS SEGMENT (~57% of revenues)
[1]
Under the segment, the company primarily refines crude oil to manufacture/ extract transportation fuels, polymers and elastomers, intermediates and polyesters. It has plants and manufacturing assets located across India in Jamnagar, Hazira, Dahej, Nagothane, Vadodara and others.
It has a crude refining capacity of 1.4 million barrels per day. It also has the largest single site refinery complex globally.
[2]
It had a total throughput of ~77 million metric tonnes in FY22 out of which ~89% was meant for sale.
[3]
RETAIL SEGMENT (~23% of revenues)
The company is the largest retailer in India with various store concepts selling consumer electronics, fashion & lifestyle, groceries, pharma and connectivity. It operates ~15,200 retail stores and has a customer base of ~19 crore customers.
[4]
Its store brands include Reliance fresh, digital, smart, Hamleys, Jio Outlets, netmeds, resQ, etc. It also operates various digital commerce platforms including JioMart, milkbasket, Reliance Digital, Ajio, zivame, urban ladder, netmeds and others.
[5]
Some of its acquisitions under the segment include Justdial, 7-Eleven, milkbasket, Manish Malhotra, Clovia, Dunzo, etc.
[5]
Expansion -
Reliance Retail undertook significant expansion in FY22 adding on avg. 7 stores every day and crossed the milestone of 15,000 stores.
[6]
DIGITAL SERVICES BUSINESS (Jio) (~11% of revenues)
Jio Digital is India's largest digital services platform with a total subscriber base of ~41 crore subscribers
[7]
and a market share of 36% in India. It offers wireless connectivity, home broadband and enterprise and SMB broadband under its digital connectivity business.
[8]
It carried ~10% of the global mobile data traffic in 2021.
[9]
Broadband Expansion -
The company became the largest broadband provider in India with a market share of 50% within just 2 years of launch.
[9]
[10]
Shareholders of Jio -
The company holds ~67% stake in Jio Platforms while the rest was sold by Reliance to major multinational corporates such as Meta (Facebook), Google, KKR, Vista Equity and others.
[11]
OIL & GAS E&P BUSINESS(~1% of revenues)
RIL as an integrated E&P Operator is India’s leading Deepwater Operator. Its domestic portfolio comprises of conventional oil and gas blocks in Krishna Godavari and Mahanadi basins and two Coal Bed Methane (CBM) blocks, Sohagpur (East) and Sohagpur (West) in Madhya Pradesh.
[12]
The business saw a significant increase in gas production due to ramp-up of production from KGD6 block located in the Krishna-Godawari Basin.
[13]
It went from producing 2% of India's total gas in Q3FY21 to ~20% in FY22.
[14]
Media & Entertainment Business
The company owns Network 18 Media  which has presence across full spectrum of content genres such as news, entertainment, sports, movies and live entertainment. Its portfolio includes CNBC TV, Colors, MTV, nick, History tv and others. It also owns digital platforms such as moneycontrol, News 18, CNBC, firstpost, voot and bookmyshow.
[15]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright
