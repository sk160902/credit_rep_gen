# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/itc-ltd/itc/500875/corp-announcements/)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 18h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6687839f-ece7-470e-b424-6fc7ccdc78dd.pdf)
- [Announcement under Regulation 30 (LODR)-Allotment of ESOP / ESPS
1d - Allotment of Shares under the Employee Stock Option Scheme of the Company](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d19190d0-d68a-4d7e-a67b-c617971b8587.pdf)
- [Announcement under Regulation 30 (LODR)-Acquisition
1d - Incorporation of a new step-down subsidiary](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8bdc0678-404b-4473-8da9-4da0011c99dd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e0b5341-4e69-4542-91a0-6b54e5394689.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=abb630cb-3d0d-4c5b-9c5d-d8452123a027.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f0d1e906-3c13-4993-ad06-e04ad1d3edf9.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\139aec7a-7a7c-458f-ac5a-29f6dbe67c93.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/73265500875.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/68921500875.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_78_ITC_2012_2013_14062013150845.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500875/5008750312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_ITC_2011_2012_19062012102526.zip)

## Credit Ratings
- [Rating update
30 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123920)
- [Rating update
25 Aug 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_August%2025,%202023_RR_326644.html)
- [Rating update
30 May 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_May%2030,%202022_RR_285350.html)
- [Rating update
30 Nov 2021 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=108456)
- [Rating update
22 Mar 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/ITCLimited_March%2022,%202021_RR_266798.html)
- [](https://www.icra.in/Rationale/ShowRationaleReport/?Id=99619)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=454583fe-e8a2-460f-ba6c-a1a1a18cb212.pdf)
- [PPT](https://www.itcportal.com/investor/pdf/ITC-Quarterly-Result-Presentation-Q3-FY2024.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=15fd926d-385d-48cb-b633-2881957ea931.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48d23504-9689-4992-84d0-3fa3d87f1292.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cd6cc39f-c7ae-4992-a507-cf03c161331c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd8c529d-569d-48b3-a6a5-20775e32469a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d3fdc92d-c38c-47e8-970f-3a3cd3029ad3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fcf710b0-8cea-4618-b926-529b0b507173.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b85d79fe-a90f-4658-a40f-694c2129b575.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=130deaf2-2b61-45d8-a8ef-f32fc5101725.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e5729d2a-7bba-4fa9-aee5-e54e02af782a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9acadc1b-6a34-4f24-9a60-beae911c443f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ce674fb0-b609-40ba-ba6d-a83a52ecb99f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cadd3c07-476f-48d0-a4d2-4191b0526c6f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7e129185-3494-413a-bf72-82dafec0466b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=86bb35bf-feea-4dde-81b0-3d76fd7b8ac1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28198f4c-275e-41f7-86ae-7762089286b1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8708013f-f5bf-43a2-b5ac-5697dcd7b1d5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e7c9402-6b1a-44fd-8f94-0c40d68a9f73.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=00d9271e-d28e-41af-8e44-c261de2e56a8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=20533893-3b74-46d2-a05b-f4056bc43fa7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2603809a-76e9-4152-ac56-8272825a9ad7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1c378d93-a1bd-4728-b6e1-5c876a6c8b4e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=582a7a17-ead9-45cd-9eb2-2524f42b99e3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=83ea3cbd-781f-4e97-b0d5-f2065db99dec.pdf)

