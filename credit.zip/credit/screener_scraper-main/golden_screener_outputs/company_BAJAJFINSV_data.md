About
[
edit
]
Bajaj Finserv Ltd. is the holding company for the various financial services businesses under the Bajaj group. It serves millions of customers by providing solutions for asset acquisition through financing, asset protection through general insurance, family and income protection in the form of life and health insurance, and retirement and savings solutions.
[1]
Key Points
[
edit
]
Revenue Split
Life Insurance: 25% in FY22 vs 55% in FY18
General Insurance: 28% in FY22 vs 0% in FY18
Retail Financing: 45% in FY22 vs 43% in FY18
Investment:1% in FY22 vs 2% in FY18.
[1]
[2]
[3]
Group
[4]
The co. offers both general & life insurance, and lending solutions to its customers through its subsidiaries namely
Bajaj Allianz General Insurance Company Limited, Bajaj Allianz Life Insurance Company Limited, Bajaj Finance Limited, Bajaj Housing Finance Limited and Bajaj Finserv Asset Management.
Bajaj Finserv Limited (BFS) is the financial services arm under Bajaj Holdings and Investment Ltd (BHIL)
.
Platforms
1 Bajaj Finserv Direct Limited - Digital Marketplace & Technology Services
2 Bajaj Finserv Health Limited - Health-tech Platform
3 Bajaj Financial Securities Limited - Digital Stockbroker
Bajaj Allianz General Insurance Company Limited
- Diversified product portfolio offering across retail and corporate segments. Multi channel distribution network encompassing multiline agents, bancassurance, motor dealers’ broking, direct, and ecommerce network servingall segments. It is focused on penetrating small towns (Geo model) and retail segment.
[5]
Business Mix 9MFY24
Motor (Retail) - 28%
Health (Retail) - 4%
Group Health - 14%
Govt health - 16%
Property, Liability, Engg - 17%
Agri (Crop Insurance) - 12%
Others - 9%
[6]
Channel Mix
[7]
Direct Business - 40%
Brokers - 34%
Individual Agents - 15%
Others - 11%
Bajaj Allianz Life Insurance
- It is the fastest growing private Life Insurance co. and in Top 10 Players in FY23 & 9M FY24. It has the highest solvency ratio in the industry and covered  2.76 crore group lives in FY23. The company has a Pan India distribution reach with a presence of 500+ branches. It has 1.43 Lakh+ agents.
[8]
Product Mix
Individual - 58% Group - 42%
IRNB Mix
Unit Linked -38%
Annuity - 5%
Non Par Protection - 4%
Non Par Savings - 25%
Par - 28%
[9]
Bajaj Finserv Health Limited
- Health Management platform to solve for Access and Financing of healthcare to Indian consumers.
100,000+ Doctors on platform, 5,500+ lab touch points and 2,100+ hospitals on network.
Bajaj MARKETS
- BFSI marketplace is a unique & diversified Marketplace for Financial Services which attracts large number of consumers and cross-sells products by leveraging Technology & Analytics. Its an open Architecture platform offers Financial products’ variants across Loans, Cards, Insurance, Investments & Payments in partnership with leading industry players. It offers a wide choice from offerings of ~81 manufacturers and  ~121 financial products.
[10]
Bajaj Finserv AMC
- Bajaj Finserv Asset Management Limited filed for its first 7 products with SEBI in Mar-23 and Apr23.Total Assets Under Managements stood at $ 770 MM.
Network
General Insurance
: The co’s general insurance business has over 238 Bank partners, 47,600+ agents, 36 NBFCs, 5 SFBs, 1 Payments Bank, 138 Co-operative banks, 9 RRBs, and over 9000 networks of automobile dealers across pan India, 34,800+ active CSC centers, 17+ partnerships across insurance companies, aggregators, wallets such as Phone Pe, payments bank, etc.
Lending
: As of Q3FY24, the consolidated AUM for lending mix for Urban was 34%, Rural,9% ,Commercial - 13%, SME - 13%, Commercial - 13% and mortgages - 31%.
[11]
Co-Branded Offerings
Bajaj Finserv RBL Bank co-branded credit card users stood at 2.75 Mn as of 31 March 2022.
Bajaj Finserv Mobikwik active wallet users stood at 22.1 Mn as of 31 March 2022 who have linked EMI card to wallet.
[12]
Key Digital Initiatives
The company undertook many digital initiatives to increase customer satisfaction and ease. Few of these initiatives include DigiSwasth, WhatsApp + BOING 2.0, Data Lake, Smart Assist, etc.
[13]
[14]
Stock Split
[15]
In July,22, Bajaj Finserv Limited announced a 5:1 Stock Split along with a 1:1 Bonus Issue.
Strategic Acquisition
[16]
The company acquired Vidal Health Care Services (VHC) for $ 39.16 MM to be settled in cash. It is One of the top health services management Companies and amongst the largest third-party administrators (TPA) in India.
Last edited 3 months, 2 weeks ago
Request an update
© Protected by Copyright
