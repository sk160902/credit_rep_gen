# Complete Company Data

## Modal Content
About
[
edit
]
Bharat Petroleum Corporation is a public sector company which is engaged in the business of refining of crude oil and marketing of petroleum products.
[1]
Key Points
[
edit
]
Refineries Capacity
Total Capacity - 35.3 MMTPA
Refinery Locations:
Mumbai - 12 MMTPA
Kochi - 15.5 MMTPA
Bina, Madhya Pradesh - 7.8 MMTPA
[1]
It possesses 14-15% of the country's total refining capacity.
[2]
Expansion
BPCL, on a consolidated basis, intends to spend around ₹10,000 crore in FY23, of which it will spend around ₹2,100 crore on refinery and on the Petchem project in Kerala, ₹5,200 crore on marketing, ₹800 crore on CGD/GAS, ₹1,400 crore on upstream and ₹500 crore on other projects (including pipeline).
[3]
Revenue Breakup FY22
High speed diesel (HSD) accounts for ~52% of revenues, followed by Motor spirit (23.4%) and Liquefied Petroleum Gas (11.3%).
[4]
Presence Across Value Chain
Retail (Petroleum) -
The company owns 82 retail depots and operates ~20,000 retail outlets across India.
Presently, it has a market share of ~26% in the domestic petroleum market.
LPG -
The company owns and operates 54 LPG bottling plants and serves over 6,200 distributors of LPG in India.
It has a base of ~9 crore customers with a market share of 27%.
Industrial/ Commercial -
The company serves 8,000+ customers and provides them with a reliable supply of industrial and commercial petroleum products.
Aviation -
The company has 56 aviation service stations across airports in India and has a 21% market share in ATF (Aviation Turbine Fuel) in the domestic market.
Lubricants -
The company sells more than 400 grades of lubricant products through its own brand MAK Lubricants. It has a market share of ~25% through a base of over 18,000 customers.
Gas -
The company has a customer base of 55+ major LNG customers. The company undertakes this business through its wholly owned subsidiary Bharat Gas Resources Ltd which has business interest in 50 GAs (geographical areas).
[5]
Exploration Activities
BPRL has Participating Interest (PI) in 18 blocks, of which nine are in India and nine overseas, along with equity stake in two Russian entities holding the license to four producing blocks in Russia.
The blocks of BPRL are in various stages of exploration, appraisal, development and production. The total acreage held by BPRL and its subsidiaries is around 22,000 sq. km, of which approximately 49% is offshore.
[6]
Listed Joint Ventures
Petronet LNG Limited :-
The company was formed in 1998 for importing LNG and setting up a LNG terminal with facilities like jetty, storage, regasification etc. to supply natural gas to various industries in the country.
It was promoted by 4 public sector companies viz. BPCL, IOCL, ONGC and GAIL which owns 12.5% each in the company. BPCL’s equity investment in PLL currently stands at ~₹ 100 crore.
[7]
Indraprastha Gas Limited:- ** It is a leading CGD (city gas distribution) company in India, supplying natural gas to transport, domestic, commercial and industrial consumers. The operations of IGL spread over NCT of Delhi, Noida & Greater Noida, Ghaziabad & Hapur, Gurugram, Meerut, Shamli, Muzaffarnagar, Karnal and Rewari.
It is a JV with Gail India wherein the company holds 22.5% stake.**
[8]
Amalgamation
On June 22, 2022, MCA approved the amalgamation of Bharat Oman Refineries Ltd. with BPCL. The Order has been filed with ROC and BORL stands merged with BPCL effective July 1, 2022.
BGRL, a wholly owned subsidiary of BPCL, was incorporated for handling Natural Gas business. In March 2021, the Board of Directors approved the amalgamation of BGRL with BPCL. Thereafter, the companies filed a petition with the MCA for amalgamation. The process is in an advanced stage now.
[9]
Privatization of the Company
The Government of India vide its letter dated June 3, 2022 has advised to call off the present process for strategic disinvestment of BPCL and accordingly, all the activities in connection with the disinvestment have been discontinued.
[9]
Sale of stake in Numaligarh Facility
In 2021, The company sold its entire ~61.6% stake in Numaligarh Refinery Ltd for Rs. 9,876 crores. It operates a 3 MMTPA refinery in the state of Assam.
Buyers include Oil India Ltd, Engineers India Ltd, and the Govt. of Assam.
[10]
Changes in KMP
Shri Arun Kumar Singh, Director (Marketing), took over charge of Chairman & Managing Director w.e.f. 07.09.2021 and Shri Vetsa Ramakrishna Gupta was appointed as Chief Financial Officer of the Company w.e.f. 01.08.2021.
[11]
Last edited 1 year, 10 months ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 242,181 | 264,421 | 242,598 | 187,815 | 201,251 | 235,895 | 298,226 | 284,572 | 230,171 | 346,791 | 473,187 | 448,083 | 448,193 |
| Expenses + | 235,472 | 255,007 | 232,818 | 174,844 | 187,468 | 220,578 | 283,113 | 275,597 | 209,170 | 327,654 | 462,288 | 404,001 | 414,472 |
| Operating Profit | 6,709 | 9,414 | 9,780 | 12,971 | 13,783 | 15,317 | 15,112 | 8,975 | 21,001 | 19,137 | 10,899 | 44,082 | 33,721 |
| OPM % | 3% | 4% | 4% | 7% | 7% | 6% | 5% | 3% | 9% | 6% | 2% | 10% | 8% |
| Other Income + | 1,492 | 1,344 | 2,117 | 1,913 | 2,721 | 2,927 | 2,975 | 1,393 | 7,489 | 4,939 | 2,036 | 3,033 | 2,823 |
| Interest | 2,518 | 1,982 | 1,180 | 680 | 696 | 1,186 | 1,764 | 2,637 | 1,723 | 2,606 | 3,745 | 4,149 | 3,749 |
| Depreciation | 2,463 | 2,611 | 3,027 | 2,072 | 2,108 | 2,885 | 3,418 | 4,080 | 4,334 | 5,434 | 6,369 | 6,771 | 6,843 |
| Profit before tax | 3,220 | 6,166 | 7,690 | 12,132 | 13,700 | 14,174 | 12,905 | 3,652 | 22,432 | 16,037 | 2,821 | 36,194 | 25,951 |
| Tax % | 40% | 34% | 34% | 33% | 31% | 31% | 34% | -0% | 23% | 27% | 24% | 26% |  |
| Net Profit + | 1,936 | 4,053 | 5,082 | 8,089 | 9,507 | 9,792 | 8,528 | 3,666 | 17,320 | 11,682 | 2,131 | 26,859 | 19,056 |
| EPS in Rs | 4.34 | 9.01 | 11.08 | 18.64 | 20.10 | 20.76 | 17.98 | 7.04 | 37.26 | 26.93 | 4.91 | 61.91 | 43.92 |
| Dividend Payout % | 42% | 31% | 34% | 25% | 49% | 46% | 48% | 106% | 102% | 29% | 40% | 17% |  |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 72% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 42% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kannur International Airport Limited |  |  |  |  |  |  |  |  |  |
| Investment and Advance for Investments | 50 | 50 |  |  |  |  |  |  |  |
| BPCL-KIAL Fuel Farm Facility Private Limited |  |  |  |  |  |  |  |  |  |
| Investment and Advance for Investments |  | 4.44 |  |  |  |  |  |  |  |
| Videocon Energy Brazil Limited |  |  |  |  |  |  |  |  |  |
| Reimbursement of Expenditure | 0.61 | 2.67 |  |  |  |  |  |  |  |
| Bharat Renewable Energy Limited |  |  |  |  |  |  |  |  |  |
| Investment and Advance for Investments | 0.75 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sales + | 242,181 | 264,421 | 242,598 | 187,815 | 201,251 | 235,895 | 298,226 | 284,572 | 230,171 | 346,791 | 473,187 | 448,083 | 448,193 |
| Expenses + | 235,472 | 255,007 | 232,818 | 174,844 | 187,468 | 220,578 | 283,113 | 275,597 | 209,170 | 327,654 | 462,288 | 404,001 | 414,472 |
| Operating Profit | 6,709 | 9,414 | 9,780 | 12,971 | 13,783 | 15,317 | 15,112 | 8,975 | 21,001 | 19,137 | 10,899 | 44,082 | 33,721 |
| OPM % | 3% | 4% | 4% | 7% | 7% | 6% | 5% | 3% | 9% | 6% | 2% | 10% | 8% |
| Other Income + | 1,492 | 1,344 | 2,117 | 1,913 | 2,721 | 2,927 | 2,975 | 1,393 | 7,489 | 4,939 | 2,036 | 3,033 | 2,823 |
| Interest | 2,518 | 1,982 | 1,180 | 680 | 696 | 1,186 | 1,764 | 2,637 | 1,723 | 2,606 | 3,745 | 4,149 | 3,749 |
| Depreciation | 2,463 | 2,611 | 3,027 | 2,072 | 2,108 | 2,885 | 3,418 | 4,080 | 4,334 | 5,434 | 6,369 | 6,771 | 6,843 |
| Profit before tax | 3,220 | 6,166 | 7,690 | 12,132 | 13,700 | 14,174 | 12,905 | 3,652 | 22,432 | 16,037 | 2,821 | 36,194 | 25,951 |
| Tax % | 40% | 34% | 34% | 33% | 31% | 31% | 34% | -0% | 23% | 27% | 24% | 26% |  |
| Net Profit + | 1,936 | 4,053 | 5,082 | 8,089 | 9,507 | 9,792 | 8,528 | 3,666 | 17,320 | 11,682 | 2,131 | 26,859 | 19,056 |
| EPS in Rs | 4.34 | 9.01 | 11.08 | 18.64 | 20.10 | 20.76 | 17.98 | 7.04 | 37.26 | 26.93 | 4.91 | 61.91 | 43.92 |
| Dividend Payout % | 42% | 31% | 34% | 25% | 49% | 46% | 48% | 106% | 102% | 29% | 40% | 17% |  |
| 10 Years: | 5% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 8% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -4% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 28% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 29% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | -3% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 72% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 24% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 42% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 5,926 | 9,588 | 20,742 | 11,119 | 9,041 | 11,068 | 10,157 | 7,881 | 23,455 | 20,336 | 12,466 | 35,936 |
| Cash from Investing Activity + | -3,604 | -6,881 | -10,536 | -9,233 | -15,274 | -7,066 | -10,451 | -11,135 | -2,474 | -8,138 | -7,806 | -10,521 |
| Cash from Financing Activity + | -846 | -3,736 | -9,792 | -1,332 | 4,804 | -4,218 | 207 | 3,583 | -13,981 | -17,672 | -4,402 | -25,427 |
| Net Cash Flow | 1,476 | -1,029 | 414 | 555 | -1,429 | -215 | -87 | 329 | 7,000 | -5,474 | 257 | -12 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 7 | 6 | 4 | 4 | 9 | 8 | 8 | 7 | 12 | 10 | 5 | 7 |
| Inventory Days | 33 | 35 | 29 | 34 | 45 | 41 | 32 | 32 | 52 | 51 | 32 | 42 |
| Days Payable | 15 | 20 | 22 | 19 | 24 | 27 | 25 | 19 | 32 | 37 | 20 | 27 |
| Cash Conversion Cycle | 25 | 22 | 12 | 19 | 30 | 21 | 16 | 20 | 33 | 24 | 17 | 21 |
| Working Capital Days | 14 | 10 | -17 | -18 | -16 | -6 | -3 | -7 | -15 | -8 | -5 | -2 |
| ROCE % | 12% | 16% | 17% | 25% | 24% | 21% | 18% | 9% | 18% | 16% | 7% | 32% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% |
| FIIs + | 11.97% | 12.66% | 13.69% | 13.17% | 12.96% | 12.53% | 12.57% | 12.55% | 13.01% | 14.21% | 16.79% | 15.04% |
| DIIs + | 21.73% | 21.14% | 19.85% | 20.70% | 20.90% | 21.80% | 22.59% | 23.10% | 22.53% | 22.13% | 21.30% | 21.31% |
| Government + | 0.86% | 0.86% | 0.86% | 0.86% | 0.94% | 0.94% | 0.94% | 0.94% | 0.94% | 0.94% | 0.94% | 0.94% |
| Public + | 12.15% | 12.05% | 12.31% | 11.98% | 12.23% | 11.44% | 10.61% | 10.12% | 10.21% | 9.44% | 8.00% | 9.73% |
| Others + | 0.32% | 0.32% | 0.32% | 0.32% | 0.00% | 0.32% | 0.32% | 0.32% | 0.32% | 0.32% | 0.00% | 0.00% |
| No. of Shareholders | 7,69,895 | 8,37,456 | 9,30,486 | 9,41,242 | 9,42,635 | 9,09,717 | 8,58,136 | 8,16,721 | 8,17,339 | 7,49,213 | 7,23,571 | 10,39,006 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 54.93% | 54.31% | 53.29% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% | 52.98% |
| FIIs + | 22.53% | 19.81% | 15.64% | 12.28% | 12.42% | 13.69% | 12.57% | 16.79% | 15.04% |
| DIIs + | 6.74% | 10.03% | 15.32% | 19.61% | 23.31% | 19.85% | 22.59% | 21.30% | 21.31% |
| Government + | 0.86% | 0.86% | 0.86% | 0.86% | 0.86% | 0.86% | 0.94% | 0.94% | 0.94% |
| Public + | 14.93% | 14.99% | 14.88% | 14.27% | 8.43% | 12.31% | 10.61% | 8.00% | 9.73% |
| Others + | 0.00% | 0.00% | 0.00% | 0.00% | 2.00% | 0.32% | 0.32% | 0.00% | 0.00% |
| No. of Shareholders | 1,25,579 | 1,56,443 | 1,78,718 | 2,23,139 | 4,68,377 | 9,30,486 | 8,58,136 | 7,23,571 | 10,39,006 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/bharat-petroleum-corporation-ltd/bpcl/500547/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c74453cf-ca84-4824-b05a-b5f303441d11.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Outcome
20 Jul - Audio recording of conference call for unaudited financial results for 30th June 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c2c0af5f-ebf9-4dc8-abfa-f12145f19743.pdf)
- [Record Date For The Final Dividend For FY 2023-24 20 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=35a20fec-dc98-4e0c-8de8-61760f6c26d6.pdf)
- [Announcement under Regulation 30 (LODR)-Change in Directorate](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=760b60e4-9e48-429f-aecf-bafe8c2eb7cc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81d00c63-ce6f-4cd0-af13-efe62917d128.pdf)

## Annual Reports
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\a62598f2-46e7-4505-8452-c7c0c424d377.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/74036500547.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/70756500547.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/66174500547.pdf)
- [Financial Year 2019
from bse](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470314.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_1216_BPCL_2012_2013_27082013105529.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500547/5005470311.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_BPCL_2010_2011_11102011031717.zip)

## Credit Ratings
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407120723_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
28 Feb from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/BharatPetroleumCorporationLimited_February%2028,%202024_RR_337761.html)
- [Rating update
10 Aug 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202308130820_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
23 Jun 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202306120646_Bharat_Petroleum_Corporation_Limited.pdf)
- [Rating update
14 Mar 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=118525)
- [](https://www.careratings.com/upload/CompanyFiles/PR/03032023075820_Bharat_Petroleum_Corporation_Limited.pdf)

## Concalls
- [Transcript](https://www.bharatpetroleum.in/images/files/Concall-Transcript-Q4.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation_FY%202023-24.pdf)
- [REC](https://www.bharatpetroleum.in/pdf/ConferenceCallRecording/MFG0220240510152830-f1f2b2.mp3)
- [Transcript](https://www.bharatpetroleum.in/images/files/Concall%20Transcript%20Q2.pdf)
- [Transcript](https://www.bharatpetroleum.in/images/files/BPCL%201QFY24%20transcript-Final.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%202023-24.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20%20FY%2022-23.pdf)
- [PPT](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2022-23.pdf)
- [](https://www.bharatpetroleum.in/images/files/Presentation-to-investors-01-Sept-2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2022-23.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%2023.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY%2022.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4%20FY%2021%20final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q3%20FY%2021%20final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q2%20FY%2021.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q1%20FY21.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20Presentation%20Q4FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY20%20December%202019(2).pdf)
- [](https://www.bharatpetroleum.in/images/files/BPCL%20Investor%20Presentation%20December%202019.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q1FY20.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q4FY19_final.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY19%20-%2010th%20Feb%202019.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY19(1).pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q1FY19.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q4FY18%20-%2027th%20June%202018.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q3FY18%20-%2018th%20February%202018.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investor%20presentation%20-%20Q2FY18%20-%2014th%20November%202017.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investorpresentation-Q1FY18-18thAugust2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/Investorpresentation-Q4FY17-1stjune2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ3FY1713thFebruary2017.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ2FY179thNovember2016(1).pdf)
- [](https://www.bharatpetroleum.in/pdf/Investorpresentation-Q1FY17.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6322AACD_A6CE_4C02_8682_1F4E20D05F1F_160404.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ4FY1629thMay2016.pdf)
- [](https://www.bharatpetroleum.in/images/files/InvestorpresentationQ3FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor-presentation-Q2FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor-presentation-Q1FY16.pdf)
- [](https://www.bharatpetroleum.in/pdf/Investor_presentation_Q4FY15.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | Reliance Industr | 3013.65 | 2038979.21 | 29.60 | 2.59 | 2.20 | 338.18 | 12.76 | 22.03 | 0.30 | 9.99 | 4.70 | 9.23 | 0.54 | 0.44 | 5.46 | 2.12 | 925289.00 | 17.61 | 68748.00 | 231784.00 | 15138.00 | 11.67 | -5.45 | 101.61 | 346142.00 | 50.33 | 0.02 | 5.59 | 10.77 | 0.00 | 6.78 | 6.72 | 2287896.21 | 1.18 | 2.48 | 2.74 | 10.30 | 16.55 | 19.26 | 8.70 | 8.72 | 11.92 | 16.33 | 9.66 | 24.56 | 8.94 | 9.14 | 0.80 | 102.90 | 11.90 | 25.75 | 25.69 | 23.83 | -3.16 | 676.56 |
| 2. | I O C L | 176.40 | 249098.62 | 6.00 | 1.36 | 0.32 | 21.84 | 4.69 | 13.35 | 6.80 | 21.14 | 9.28 | 25.66 | 1.68 | 0.72 | 8.22 | 2.52 | 776351.85 | 9.74 | 41460.24 | 198649.76 | 5148.87 | -2.56 | -49.96 | 29.55 | 132627.56 | 51.50 | 0.00 | 17.09 | 10.77 | 0.00 | -7.77 | 323.40 | 378567.39 | 0.68 | 0.31 | 3.09 | 23.07 | 36.65 | 79.36 | 18.14 | 16.29 | 19.14 | 24.21 | 8.01 | 28.73 | 7.17 | 8.09 | 0.12 | 29.55 | 19.14 | 5.72 | 5.07 | 6.43 | 42.07 | 1412.12 |
| 3. | B P C L | 328.30 | 142433.06 | 7.32 | 1.91 | 0.32 | 9.94 | 5.14 | 13.67 | 6.42 | 32.09 | 13.86 | 41.90 | 2.29 | 0.72 | 8.08 | 2.58 | 448193.16 | 7.52 | 19487.67 | 113094.92 | 2945.19 | 0.10 | -72.40 | 43.92 | 54599.05 | 52.98 | 0.00 | 15.96 | 10.77 | 0.00 | -3.63 | -2.86 | 190745.75 | 0.81 | 0.26 | 7.03 | 37.50 | 12.90 | 71.99 | 24.22 | 23.03 | 28.24 | 28.90 | 8.48 | 24.86 | 6.34 | 6.86 | 0.28 | 61.91 | 28.24 | 8.79 | 6.01 | 9.29 | 20.90 | 433.85 |
| 4. | H P C L | 376.30 | 80069.99 | 5.01 | 1.72 | 0.18 | 47.63 | 5.11 | 15.28 | 7.06 | 21.30 | 9.31 | 40.45 | 2.52 | 1.42 | 9.02 | 3.67 | 433856.51 | 5.75 | 16014.61 | 114677.63 | 2709.31 | 6.13 | -24.91 | 75.26 | 66683.82 | 54.90 | 0.00 | 15.82 | 10.77 | 0.00 | -1.55 | 329.93 | 146280.38 | 0.61 | 0.26 | 14.16 | 30.19 | 27.70 | 92.85 | 13.98 | 16.73 | 19.10 | 14.38 | 9.51 | 22.98 | -18.91 | -8.08 | 0.22 | 75.26 | 20.82 | 4.62 | 4.44 | 4.98 | 14.35 | 212.78 |
| 5. | M R P L | 214.80 | 37645.81 | 14.13 | 2.81 | 0.41 | 7.50 | 7.81 | 31.54 | 0.46 | 25.18 | 10.21 | 31.13 | 2.56 | 0.96 | 4.84 | 2.66 | 92472.42 | 6.74 | 2660.82 | 23247.02 | 73.22 | 10.40 | -92.78 | 15.15 | 12687.04 | 88.58 | 0.00 | 10.16 | 10.77 | 0.00 | -5.24 | 179.67 | 50294.24 | 1.03 | 0.24 | -13.70 | 24.19 | 67.24 | 163.00 | 35.83 | 13.12 | 59.14 | 89.02 | 7.34 | 41.43 | 31.22 | 20.13 | 0.36 | 20.52 | 59.14 | 6.15 | 5.71 | 7.67 | 20.63 | 175.26 |
| 6. | C P C L | 999.10 | 14877.77 | 5.99 | 1.73 | 0.22 | 5.76 | 4.18 | 39.25 | 5.49 | 35.44 | 15.93 | 36.46 | 3.88 | 0.32 | 16.82 | 1.98 | 68735.62 | 6.09 | 2505.53 | 17094.98 | 342.60 | 15.94 | -37.52 | 168.26 | 2785.90 | 67.29 | 0.00 | 20.18 | 10.77 | 0.00 | 0.61 | 45.39 | 17569.42 | 1.25 | 0.08 | -3.39 | 27.01 | 104.19 | 153.76 | 53.89 | 32.58 | 71.20 | 125.15 | 9.94 | 43.76 | 77.91 | 45.54 | 0.16 | 182.07 | 71.20 | 3.39 | 3.24 | 4.44 | 24.38 | 14.89 |
| 7. | Gandhar Oil Ref. | 212.70 | 2081.73 | 14.83 | 1.81 | 0.51 | -250.78 | 7.19 |  | 0.00 | 21.70 | 9.30 | 14.81 | 2.32 | 0.23 | 4.61 | 1.52 | 4113.21 | 6.78 | 140.52 | 939.24 | 9.14 | -4.81 | -58.81 | 14.36 | 270.99 | 64.63 | 0.00 | 13.12 | 10.77 | 0.00 | 0.83 | -26.11 | 2075.99 | 2.52 | 0.29 | -4.72 | -16.35 |  |  | 22.85 | 20.60 | 51.00 | 11.96 | 2.89 | 22.80 | 30.03 | 37.34 | 1.79 | 14.36 | 5.12 | 10.83 | 10.83 | 10.83 | 62.93 | 8.00 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | Sales | ₹ 4,48,193 Cr. |
| BPCL | OPM | 7.52 % |
| BPCL | Profit after tax | ₹ 19,488 Cr. |
| BPCL | Mar Cap | ₹ 1,42,585 Cr. |
| BPCL | Sales Qtr | ₹ 1,13,095 Cr. |
| BPCL | PAT Qtr | ₹ 2,945 Cr. |
| BPCL | Qtr Sales Var | 0.10 % |
| BPCL | Qtr Profit Var | -72.4 % |
| BPCL | Price to Earning | 7.33 |
| BPCL | Dividend yield | 6.41 % |
| BPCL | Price to book value | 1.91 |
| BPCL | ROCE | 32.1 % |
| BPCL | Return on assets | 13.9 % |
| BPCL | Debt to equity | 0.72 |
| BPCL | Return on equity | 41.9 % |
| BPCL | EPS | ₹ 43.9 |
| BPCL | Debt | ₹ 54,599 Cr. |
| BPCL | Promoter holding | 53.0 % |
| BPCL | Change in Prom Hold | 0.00 % |
| BPCL | Earnings yield | 16.0 % |
| BPCL | Pledged percentage | 0.00 % |
| BPCL | Industry PE | 10.8 |
| BPCL | Sales growth | -3.63 % |
| BPCL | Profit growth | -2.86 % |
| BPCL | Current Price | ₹ 329 |
| BPCL | Price to Sales | 0.32 |
| BPCL | CMP / FCF | 9.96 |
| BPCL | EVEBITDA | 5.14 |
| BPCL | Enterprise Value | ₹ 1,90,898 Cr. |
| BPCL | Current ratio | 0.81 |
| BPCL | Int Coverage | 8.08 |
| BPCL | PEG Ratio | 0.26 |
| BPCL | Return over 3months | 7.03 % |
| BPCL | Return over 6months | 37.5 % |
| BPCL | No. Eq. Shares | 434 |
| BPCL | Sales growth 3Years | 24.9 % |
| BPCL | Sales growth 5Years | 8.48 % |
| BPCL | Profit Var 3Yrs | 28.9 % |
| BPCL | Profit Var 5Yrs | 28.2 % |
| BPCL | ROE 5Yr | 23.0 % |
| BPCL | ROE 3Yr | 24.2 % |
| BPCL | Return over 1year | 72.0 % |
| BPCL | Return over 3years | 12.9 % |
| BPCL | Return over 5years | 13.7 % |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | Sales last year | ₹ 4,48,083 Cr. |
| BPCL | OP Ann | ₹ 44,082 Cr. |
| BPCL | Other Inc Ann | ₹ 3,033 Cr. |
| BPCL | EBIDT last year | ₹ 47,382 Cr. |
| BPCL | Dep Ann | ₹ 6,771 Cr. |
| BPCL | EBIT last year | ₹ 40,611 Cr. |
| BPCL | Interest last year | ₹ 4,149 Cr. |
| BPCL | PBT Ann | ₹ 36,194 Cr. |
| BPCL | Tax last year | ₹ 9,336 Cr. |
| BPCL | PAT Ann | ₹ 27,057 Cr. |
| BPCL | Extra Ord Item Ann | ₹ -268 Cr. |
| BPCL | NP Ann | ₹ 26,859 Cr. |
| BPCL | Dividend last year | ₹ 4,486 Cr. |
| BPCL | Raw Material | 83.9 % |
| BPCL | Employee cost | ₹ 3,577 Cr. |
| BPCL | OPM last year | 9.84 % |
| BPCL | NPM last year | 6.04 % |
| BPCL | Operating profit | ₹ 33,721 Cr. |
| BPCL | Interest | ₹ 3,749 Cr. |
| BPCL | Depreciation | ₹ 6,843 Cr. |
| BPCL | EPS last year | ₹ 61.9 |
| BPCL | EBIT | ₹ 30,292 Cr. |
| BPCL | Net profit | ₹ 19,056 Cr. |
| BPCL | Current Tax | ₹ 7,035 Cr. |
| BPCL | Tax | ₹ 6,895 Cr. |
| BPCL | Other income | ₹ 2,823 Cr. |
| BPCL | Ann Date | 2,02,403 |
| BPCL | Sales Prev Ann | ₹ 4,73,187 Cr. |
| BPCL | OP Prev Ann | ₹ 10,899 Cr. |
| BPCL | Other Inc Prev Ann | ₹ 2,036 Cr. |
| BPCL | EBIDT Prev Ann | ₹ 14,573 Cr. |
| BPCL | Dep Prev Ann | ₹ 6,369 Cr. |
| BPCL | EBIT preceding year | ₹ 8,205 Cr. |
| BPCL | Interest Prev Ann | ₹ 3,745 Cr. |
| BPCL | PBT Prev Ann | ₹ 2,821 Cr. |
| BPCL | Tax preceding year | ₹ 690 Cr. |
| BPCL | PAT Prev Ann | ₹ 3,344 Cr. |
| BPCL | Extra Ord Prev Ann | ₹ -1,638 Cr. |
| BPCL | NP Prev Ann | ₹ 2,131 Cr. |
| BPCL | Dividend Prev Ann | ₹ 852 Cr. |
| BPCL | OPM preceding year | 2.30 % |
| BPCL | NPM preceding year | 0.71 % |
| BPCL | EPS preceding year | ₹ 4.91 |
| BPCL | Sales Prev 12M | ₹ 4,48,083 Cr. |
| BPCL | Profit Prev 12M | ₹ 26,859 Cr. |
| BPCL | Med Sales Gwth 10Yrs | -4.58 % |
| BPCL | Med Sales Gwth 5Yrs | -4.58 % |
| BPCL | Sales growth 7Years | 12.1 % |
| BPCL | Sales Var 10Yrs | 5.42 % |
| BPCL | EBIDT growth 3Years | 26.8 % |
| BPCL | EBIDT growth 5Years | 21.2 % |
| BPCL | EBIDT growth 7Years | 16.2 % |
| BPCL | EBIDT Var 10Yrs | 15.9 % |
| BPCL | EPS growth 3Years | 28.9 % |
| BPCL | EPS growth 5Years | 28.2 % |
| BPCL | EPS growth 7Years | 17.5 % |
| BPCL | EPS growth 10Years | 21.3 % |
| BPCL | Profit Var 7Yrs | 17.5 % |
| BPCL | Profit Var 10Yrs | 21.3 % |
| BPCL | Chg in Prom Hold 3Yr | 0.00 % |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | OP Qtr | ₹ 5,627 Cr. |
| BPCL | Other Inc Qtr | ₹ 807 Cr. |
| BPCL | EBIDT Qtr | ₹ 6,576 Cr. |
| BPCL | Dep Qtr | ₹ 1,686 Cr. |
| BPCL | EBIT latest quarter | ₹ 4,890 Cr. |
| BPCL | Interest Qtr | ₹ 889 Cr. |
| BPCL | PBT Qtr | ₹ 3,859 Cr. |
| BPCL | Tax latest quarter | ₹ 1,017 Cr. |
| BPCL | Extra Ord Item Qtr | ₹ -142 Cr. |
| BPCL | NP Qtr | ₹ 2,842 Cr. |
| BPCL | GPM latest quarter | 11.0 % |
| BPCL | OPM latest quarter | 4.98 % |
| BPCL | NPM latest quarter | 2.60 % |
| BPCL | Eq Cap Qtr | ₹ 4,273 Cr. |
| BPCL | EPS latest quarter | ₹ 6.55 |
| BPCL | OP 2Qtr Bk | ₹ 6,199 Cr. |
| BPCL | OP 3Qtr Bk | ₹ 12,941 Cr. |
| BPCL | Sales 2Qtr Bk | ₹ 1,15,499 Cr. |
| BPCL | Sales 3Qtr Bk | ₹ 1,03,044 Cr. |
| BPCL | NP 2Qtr Bk | ₹ 3,181 Cr. |
| BPCL | NP 3Qtr Bk | ₹ 8,244 Cr. |
| BPCL | Opert Prft Gwth | 3.77 % |
| BPCL | Last result date | 2,02,406 |
| BPCL | Exp Qtr Sales Var | -3.47 % |
| BPCL | Exp Qtr Sales | ₹ 99,468 Cr. |
| BPCL | Exp Qtr OP | ₹ 9,234 Cr. |
| BPCL | Exp Qtr NP | ₹ 6,807 Cr. |
| BPCL | Exp Qtr EPS | ₹ 15.7 |
| BPCL | Sales Prev Qtr | ₹ 1,16,555 Cr. |
| BPCL | OP Prev Qtr | ₹ 8,955 Cr. |
| BPCL | Other Inc Prev Qtr | ₹ 403 Cr. |
| BPCL | EBIDT Prev Qtr | ₹ 9,462 Cr. |
| BPCL | Dep Prev Qtr | ₹ 1,722 Cr. |
| BPCL | EBIT Prev Qtr | ₹ 7,740 Cr. |
| BPCL | Interest Prev Qtr | ₹ 967 Cr. |
| BPCL | PBT Prev Qtr | ₹ 6,669 Cr. |
| BPCL | Tax Prev Qtr | ₹ 1,880 Cr. |
| BPCL | PAT Prev Qtr | ₹ 4,862 Cr. |
| BPCL | Extra Ord Prev Qtr | ₹ -104 Cr. |
| BPCL | NP Prev Qtr | ₹ 4,790 Cr. |
| BPCL | OPM Prev Qtr | 7.68 % |
| BPCL | NPM Prev Qtr | 4.17 % |
| BPCL | Eq Cap Prev Qtr | ₹ 2,129 Cr. |
| BPCL | EPS Prev Qtr | ₹ 11.0 |
| BPCL | Sales PY Qtr | ₹ 1,12,985 Cr. |
| BPCL | OP PY Qtr | ₹ 15,785 Cr. |
| BPCL | Other Inc PY Qtr | ₹ 1,003 Cr. |
| BPCL | EBIDT PY Qtr | ₹ 16,823 Cr. |
| BPCL | Dep PY Qtr | ₹ 1,614 Cr. |
| BPCL | EBIT PY Qtr | ₹ 15,209 Cr. |
| BPCL | Interest PY Qtr | ₹ 1,071 Cr. |
| BPCL | PBT PY Qtr | ₹ 14,103 Cr. |
| BPCL | Tax PY Qtr | ₹ 3,458 Cr. |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | Equity capital | ₹ 2,136 Cr. |
| BPCL | Preference capital | ₹ 0.00 Cr. |
| BPCL | Reserves | ₹ 73,499 Cr. |
| BPCL | Secured loan | ₹ 4,685 Cr. |
| BPCL | Unsecured loan | ₹ 64,691 Cr. |
| BPCL | Balance sheet total | ₹ 2,02,418 Cr. |
| BPCL | Gross block | ₹ 1,14,274 Cr. |
| BPCL | Revaluation reserve | ₹ 0.00 Cr. |
| BPCL | Accum Dep | ₹ 27,599 Cr. |
| BPCL | Net block | ₹ 98,322 Cr. |
| BPCL | CWIP | ₹ 8,680 Cr. |
| BPCL | Investments | ₹ 26,631 Cr. |
| BPCL | Current assets | ₹ 65,694 Cr. |
| BPCL | Current liabilities | ₹ 80,883 Cr. |
| BPCL | BV Unq Invest | ₹ 0.00 Cr. |
| BPCL | MV Quoted Inv | ₹ 4,950 Cr. |
| BPCL | Cont Liab | ₹ 11,713 Cr. |
| BPCL | Total Assets | ₹ 2,02,418 Cr. |
| BPCL | Working capital | ₹ 3,932 Cr. |
| BPCL | Lease liabilities | ₹ 9,114 Cr. |
| BPCL | Inventory | ₹ 42,836 Cr. |
| BPCL | Trade receivables | ₹ 8,342 Cr. |
| BPCL | Face value | ₹ 10.0 |
| BPCL | Cash Equivalents | ₹ 6,286 Cr. |
| BPCL | Adv Cust | ₹ 1,106 Cr. |
| BPCL | Trade Payables | ₹ 28,306 Cr. |
| BPCL | No. Eq. Shares PY | 434 |
| BPCL | Debt preceding year | ₹ 69,376 Cr. |
| BPCL | Work Cap PY | ₹ -3,364 Cr. |
| BPCL | Net Block PY | ₹ 86,675 Cr. |
| BPCL | Gross Block PY | ₹ 1,14,274 Cr. |
| BPCL | CWIP PY | ₹ 16,249 Cr. |
| BPCL | Work Cap 3Yr | ₹ -1,244 Cr. |
| BPCL | Work Cap 5Yr | ₹ -1,542 Cr. |
| BPCL | Work Cap 7Yr | ₹ -6,845 Cr. |
| BPCL | Work Cap 10Yr | ₹ 9,438 Cr. |
| BPCL | Debt 3Years back | ₹ 54,532 Cr. |
| BPCL | Debt 5Years back | ₹ 44,839 Cr. |
| BPCL | Debt 7Years back | ₹ 35,725 Cr. |
| BPCL | Debt 10Years back | ₹ 33,152 Cr. |
| BPCL | Net Block 3Yrs Back | ₹ 64,098 Cr. |
| BPCL | Net Block 5Yrs Back | ₹ 49,315 Cr. |
| BPCL | Net Block 7Yrs Back | ₹ 33,684 Cr. |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | CF Operations | ₹ 35,936 Cr. |
| BPCL | Free Cash Flow | ₹ 26,606 Cr. |
| BPCL | CF Investing | ₹ -10,521 Cr. |
| BPCL | CF Financing | ₹ -25,427 Cr. |
| BPCL | Net CF | ₹ -12.0 Cr. |
| BPCL | Cash Beginning | ₹ 2,313 Cr. |
| BPCL | Cash End | ₹ 6,286 Cr. |
| BPCL | FCF Prev Ann | ₹ 4,514 Cr. |
| BPCL | CF Operations PY | ₹ 12,466 Cr. |
| BPCL | CF Investing PY | ₹ -7,806 Cr. |
| BPCL | CF Financing PY | ₹ -4,402 Cr. |
| BPCL | Net CF PY | ₹ 257 Cr. |
| BPCL | Cash Beginning PY | ₹ 2,056 Cr. |
| BPCL | Cash End PY | ₹ 2,574 Cr. |
| BPCL | Free Cash Flow 3Yrs | ₹ 42,968 Cr. |
| BPCL | Free Cash Flow 5Yrs | ₹ 53,083 Cr. |
| BPCL | Free Cash Flow 7Yrs | ₹ 56,123 Cr. |
| BPCL | Free Cash Flow 10Yrs | ₹ 66,408 Cr. |
| BPCL | CF Opr 3Yrs | ₹ 68,737 Cr. |
| BPCL | CF Opr 5Yrs | ₹ 1,00,073 Cr. |
| BPCL | CF Opr 7Yrs | ₹ 1,21,299 Cr. |
| BPCL | CF Opr 10Yrs | ₹ 1,62,201 Cr. |
| BPCL | CF Inv 10Yrs | ₹ -92,633 Cr. |
| BPCL | CF Inv 7Yrs | ₹ -57,590 Cr. |
| BPCL | CF Inv 5Yrs | ₹ -40,074 Cr. |
| BPCL | CF Inv 3Yrs | ₹ -26,465 Cr. |
| BPCL | Cash 3Years back | ₹ 8,110 Cr. |
| BPCL | Cash 5Years back | ₹ 663 Cr. |
| BPCL | Cash 7Years back | ₹ 1,885 Cr. |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | No. Eq. Shares | 434 |
| BPCL | Book value | ₹ 174 |
| BPCL | Inven TO | 9.30 |
| BPCL | Quick ratio | 0.28 |
| BPCL | Exports percentage | 0.00 % |
| BPCL | Piotroski score | 8.00 |
| BPCL | G Factor | 7.00 |
| BPCL | Asset Turnover | 2.29 |
| BPCL | Financial leverage | 2.58 |
| BPCL | No. of Share Holders | 10,39,006 |
| BPCL | Unpledged Prom Hold | 53.0 % |
| BPCL | ROIC | 29.5 % |
| BPCL | Debtor days | 6.80 |
| BPCL | Industry PBV | 1.87 |
| BPCL | Credit rating |  |
| BPCL | WC Days | -1.92 |
| BPCL | Earning Power | 15.0 % |
| BPCL | Graham Number | ₹ 415 |
| BPCL | Cash Cycle | 20.9 |
| BPCL | Days Payable | 27.5 |
| BPCL | Days Receivable | 6.80 |
| BPCL | Inventory Days | 41.6 |
| BPCL | Public holding | 9.73 % |
| BPCL | FII holding | 15.0 % |
| BPCL | Chg in FII Hold | -1.75 % |
| BPCL | DII holding | 21.3 % |
| BPCL | Chg in DII Hold | 0.01 % |
| BPCL | B.V. Prev Ann | ₹ 123 |
| BPCL | ROCE Prev Yr | 6.86 % |
| BPCL | ROA Prev Yr | 1.78 % |
| BPCL | ROE Prev Ann | 6.34 % |
| BPCL | No. of Share Holders Prev Qtr | 7,23,571 |
| BPCL | No. Eq. Shares 10 Yrs | 434 |
| BPCL | BV 3yrs back | ₹ 123 |
| BPCL | BV 5yrs back | ₹ 84.2 |
| BPCL | BV 10yrs back | ₹ 52.0 |
| BPCL | Inven TO 3Yr | 7.76 |
| BPCL | Inven TO 5Yr | 11.3 |
| BPCL | Inven TO 7Yr | 9.33 |
| BPCL | Inven TO 10Yr | 10.8 |
| BPCL | Export 3Yr | 0.00 % |
| BPCL | Export 5Yr | 0.00 % |
| BPCL | Div 5Yrs | ₹ 5,705 Cr. |
| BPCL | ROCE 3Yr | 18.2 % |
| BPCL | ROCE 5Yr | 16.2 % |
| BPCL | ROCE 7Yr | 17.2 % |
| BPCL | ROCE 10Yr | 18.7 % |
| BPCL | ROE 10Yr | 24.2 % |
| BPCL | ROE 7Yr | 23.2 % |
| BPCL | ROE 5Yr Var | 15.2 % |
| BPCL | OPM 5Year | 5.84 % |
| BPCL | OPM 10Year | 5.80 % |
| BPCL | No. of Share Holders 1Yr | 8,16,721 |
| BPCL | Avg Div Payout 3Yrs | 28.6 % |
| BPCL | Debtor days 3yrs | 7.40 |
| BPCL | Debtor days 3yrs back | 12.4 |
| BPCL | Debtor days 5yrs back | 8.45 |
| BPCL | ROA 5Yr | 6.83 % |
| BPCL | ROA 3Yr | 7.28 % |
| BPCL | Market Cap | ₹ 1,42,585 Cr. |
| BPCL | Current Price | ₹ 329 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.33 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.41 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | Avg Vol 1Mth | 1,56,74,147 |
| BPCL | Avg Vol 1Wk | 2,61,90,550 |
| BPCL | Volume | 3,27,78,754 |
| BPCL | High price | ₹ 344 |
| BPCL | Low price | ₹ 166 |
| BPCL | High price all time | ₹ 344 |
| BPCL | Low price all time | ₹ 17.2 |
| BPCL | Return over 1day | 0.77 % |
| BPCL | Return over 1week | 7.36 % |
| BPCL | Return over 1month | 9.30 % |
| BPCL | DMA 50 | ₹ 307 |
| BPCL | DMA 200 | ₹ 273 |
| BPCL | DMA 50 previous day | ₹ 306 |
| BPCL | 200 DMA prev. | ₹ 273 |
| BPCL | RSI | 62.6 |
| BPCL | MACD | 2.43 |
| BPCL | MACD Previous Day | 1.10 |
| BPCL | MACD Signal | 0.67 |
| BPCL | MACD Signal Prev | 0.23 |
| BPCL | Avg Vol 1Yr | 91,61,961 |
| BPCL | Return over 7years | 4.62 % |
| BPCL | Return over 10years | 13.0 % |
| BPCL | Market Cap | ₹ 1,42,433 Cr. |
| BPCL | Current Price | ₹ 328 |
| BPCL | High / Low | ₹ 344 / 166 |
| BPCL | Stock P/E | 7.32 |
| BPCL | Book Value | ₹ 174 |
| BPCL | Dividend Yield | 6.42 % |
| BPCL | ROCE | 32.1 % |
| BPCL | ROE | 41.9 % |
| BPCL | Face Value | ₹ 10.0 |
| BPCL | WC to Sales | 0.88 % |
| BPCL | QoQ Profits | -40.7 % |
| BPCL | QoQ Sales | -2.97 % |
| BPCL | Net worth | ₹ 75,635 Cr. |
| BPCL | Market Cap to Sales | 0.32 |
| BPCL | Interest Coverage | 8.08 |
| BPCL | EV / EBIT | 6.30 |
| BPCL | Debt Capacity | 0.28 |
| BPCL | Debt To Profit | 2.03 |
| BPCL | Capital Employed | ₹ 1,10,935 Cr. |
| BPCL | CROIC | 11.3 % |
| BPCL | debtplus | 0.88 |
| BPCL | Leverage | ₹ 2.58 |
| BPCL | Dividend Payout | 16.7 % |
| BPCL | Intrinsic Value | ₹ 352 |
| BPCL | CDL | -42.1 % |
| BPCL | Cash by market cap | 0.03 |
| BPCL | 52w Index | 91.2 % |
| BPCL | Down from 52w high | 4.56 % |
| BPCL | Up from 52w low | 98.1 % |
| BPCL | From 52w high | 0.95 |
| BPCL | Mkt Cap To Debt Cap | 0.57 |
| BPCL | Dividend Payout | 16.7 % |
| BPCL | Graham | ₹ 415 |
| BPCL | Price to Cash Flow | 3.96 |
| BPCL | ROCE3yr avg | 18.2 % |
| BPCL | PB X PE | 14.0 |
| BPCL | NCAVPS | ₹ 9.06 |
| BPCL | Mar Cap to CF | 3.96 |
| BPCL | Altman Z Score | 4.38 |
| BPCL | M.Cap / Qtr Profit | 48.4 |