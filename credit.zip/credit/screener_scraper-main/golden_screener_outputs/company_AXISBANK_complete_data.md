# Complete Company Data

## Modal Content
About
[
edit
]
Incorporated  in  December  1993,  Axis  Bank  Limited  is  a  private  sector  bank.It  has  the  third-largest network of branches among private sector banks and an international presence through branches in DIFC (Dubai) and Singapore along with representative offices in Abu Dhabi, Sharjah, Dhaka and Dubai and an offshore banking unit in GIFT City.
[1]
Key Points
[
edit
]
Market Leadership
<h1>3rd largest private sector bank in India.
[1]
</h1>
<h1>4th largest issuer of credit cards
[2]
</h1>
<h1>19.8% market share in FY24.
[3]
</h1>
Ratios FY24
[4]
Capital Adequacy Ratio - 16.63%
Net Interest Margin - 4.07%
Gross NPA - 1.43 %
Net NPA - 0.31%
CASA Ratio - 43%
Branch Network
[5]
In FY24, Bank added 475 branches (125 in Q4FY24) to its network. At present, it has a total of 5377 branches, 16,026 ATMs and Cash recyclers. The region-wise breakup of branches is as follows:
[6]
Metro - 31%
Semi-urban - 29%
Urban - 23%
Rural - 17%
Revenue Mix FY24
[7]
Treasury: ~15%
Corporate/Wholesale Banking: ~22%
Retail Banking: ~61%
Other Banking Business: ~2%
Loan Book
[8]
Retail loans account for 60% of bank's loan book and corporate 29% & SME loans 11%.
[9]
Retail Book
Home loans account for 28% of retail book, followed by rural loans (16%), LAP(11%), Auto loans(10%), personal loans(12%) , small business banking (10%), credit cards (7%), Comm Equipment (2%) & others (4%).
[10]
Market Share FY24
Bank has 5.5% market share in assets, 5% in deposits & 5.9% in advances.
[1]
14% in credit cards circulation in India.
[11]
5.2% market share in personal loan.
[12]
. 8.4% RTGS, 30% NEFT, 38.9% IMPS Market share (by volume),20% Market share in BBPS. 11.4% Foreign LC Market Share.
[13]
8.4% market share of MSME credit.
[14]
Retail Fee Mix Q4FY24
Bank earns retail fees from various mediums. 74% of total fees. Retail cards account for 42% of fees, followed by third party products (27%), retail assets (17%), and the rest 14% fees come from retail liabilities and other mediums.
[15]
Digital Banking
96% of Digital transactions. 87% of Credit cards issued, 70% of new savings accounts, 74% of New MF SIP Volume, 53% of Personal loan disbursed were sourced digitally in FY24.
[16]
2. Axis Capital Ltd -
Provide focused and customized solutions in Investment Banking and Institutional Equities. 90 IB deals closed in FY24 that include 52 ECM and 7 M&A deals. 2nd rank in ECM deals
[17]
3. A.Treds Ltd (67% shareholding) -
It is engaged in the business of facilitating financing of trade receivables.
It is one of the three entities allowed by RBI to set up the Trade Receivables Discounting System (TReDS), an electronic platform for facilitating cash flows for MSMEs.
Its digital invoice discounting platform ‘Invoicemart’ has set a new benchmark by facilitating financing of MSME invoices of ~Rs. 1,04,000 Crs.
[18]
4. Axis Asset Management Co. Ltd (75% shareholding) -
PMS,AIF & Mutual Funds. 5% AUM market share. AUM:~Rs.2,74,265 Cr.
[17]
5. Axis Trustee Services Ltd -
It is registered with the SEBI and has been successfully executing various trusteeship activities including debenture trustee, security trustee, security agent, lenders’ agent, trustee for securitisation and escrow agent, among others. Assets under Trust: Rs. 39,04,153 Cr. 24% (AUM) market share in Debenture Trustee segment - 2nd Rank
[19]
6. Axis Securities Ltd -
3rd largest bank led retail brokerage in terms of customer base with customer base of 5.45 Mn.
[20]
7. Freecharge -
It is in the business of providing merchant acquiring services, payment aggregation services, payment support services, and business correspondent to a Bank / Financial Institution, distribution of Mutual Funds.
[18]
8. Axis Mutual Fund Trustee Ltd (75% shareholding) -
It acts as the trustee for the mutual fund business.
9. Axis Bank UK Ltd -
It is the banking subsidiary of the Bank in the UK and undertakes the activities of banking.
10. Max Life Insurance Co. Ltd.(16.22% shareholding)
[21]
Updates
1. During the Q3FY24 upon receipt of the final closing statement from Citibank N.A. and Citicorp Finance (India) Limited. The Bank has completed the settlement of the purchase price true up amount relating to the aforesaid acquisition. The final determined purchase price amounted to ~11,932.39 crores as against the estimated adjusted purchase price of ~11,949.08 crores recognised in FY23.
[22]
2.
Fund raising
Bank to consider fund raising through debt or equity.
[23]
3. Bank has subscribed 14,25,79,161 shares of Max Life @ Rs. 113.06 for ~Rs 1,612 Cr.
[21]
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 27,202 | 30,736 | 35,727 | 41,409 | 45,175 | 46,614 | 56,044 | 63,716 | 64,397 | 68,846 | 87,448 | 112,759 | 117,672 |
| Interest | 17,513 | 18,703 | 21,341 | 24,344 | 26,789 | 27,604 | 33,883 | 37,996 | 34,627 | 34,923 | 43,389 | 61,391 | 64,680 |
| Expenses + | 8,538 | 9,944 | 11,521 | 13,869 | 24,327 | 29,717 | 28,020 | 35,976 | 32,621 | 31,216 | 30,641 | 40,032 | 43,581 |
| Financing Profit | 1,151 | 2,089 | 2,865 | 3,196 | -5,941 | -10,706 | -5,860 | -10,256 | -2,851 | 2,707 | 13,418 | 11,336 | 9,411 |
| Financing Margin % | 4% | 7% | 8% | 8% | -13% | -23% | -10% | -16% | -4% | 4% | 15% | 10% | 8% |
| Other Income + | 6,833 | 7,766 | 8,838 | 9,955 | 12,422 | 11,863 | 14,189 | 16,342 | 13,577 | 17,268 | 18,349 | 25,230 | 26,219 |
| Depreciation | 359 | 375 | 420 | 461 | 527 | 591 | 737 | 806 | 976 | 1,046 | 13,146 | 1,388 | 0 |
| Profit before tax | 7,625 | 9,479 | 11,283 | 12,690 | 5,954 | 566 | 7,592 | 5,280 | 9,750 | 18,929 | 18,621 | 35,178 | 35,630 |
| Tax % | 31% | 33% | 34% | 34% | 33% | 18% | 34% | 64% | 26% | 25% | 42% | 25% |  |
| Net Profit + | 5,235 | 6,311 | 7,450 | 8,358 | 3,967 | 464 | 5,047 | 1,879 | 7,252 | 14,207 | 10,919 | 26,492 | 26,846 |
| EPS in Rs | 22.37 | 26.86 | 31.42 | 35.04 | 16.51 | 1.78 | 19.59 | 6.57 | 23.49 | 45.99 | 35.16 | 85.49 | 86.63 |
| Dividend Payout % | 16% | 15% | 15% | 14% | 30% | 0% | 5% | 0% | 0% | 2% | 3% | 1% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transactions |  |  |  |  |  |  |  |  |  |  |
| Dividend paid | 276 | 300 | 355 | 345 |  | 46 |  |  | 29 | 25 |
| Interest paid | 811 | 645 | 667 | 546 | 555 | 553 | 326 | 174 | 165 | 400 |
| Interest received | 0.17 | 0.41 | 2.16 | 0.79 | 1.22 | 0.45 | 0.26 | 0.33 | 0.09 | 0.04 |
| Investment of related party in the Bank | 139 | 144 | 142 | 138 | 136 | 94 | 89 | 81 | 49 | 0.14 |
| Remuneration paid |  |  |  | 12 | 18 | 16 | 13 | 14 | 15 | 18 |
| Contribution to employee benefit fund | 16 | 16 | 16 | 16 | 17 | 15 | 14 | 14 | 14 | 16 |
| Advance repaid | 0.23 | 0.66 | 0.20 | 6.54 | 7.83 | 11 | 0.94 | 3.10 | 7.65 | 0.42 |
| Receiving of services | 78 | 79 | 101 | 110 | 129 | 207 | 264 | 402 | 114 | 97 |
| Rendering of services | 2.18 | 2.79 | 2.48 | 33 | 28 | 30 | 52 | 47 | 54 | 91 |
| Sale/ Purchase of foreign exchange currency to/from related party |  |  |  |  |  |  | 0.51 |  | 2.79 | 0.22 |
| Other reimbursements to related party | 0.37 | 0.40 | 0.41 |  | 0.66 | 0.19 | 0.25 | 0.25 | 0.08 | 1.14 |
| Deposits with the Bank | 13,960 | 12,123 | 9,018 | 10,176 | 17,107 | 16,680 | 11,730 | 15,179 | 9,803 | 16 |
| Advances | 52 | 21 | 36 | 35 | 175 | 23 | 14 | 91 | 9.56 | 1.04 |
| Redemptionof Hybrid capital/Bonds of the Bank |  |  |  |  |  |  |  |  | 958 |  |
| Placement of deposits | 0.30 | 0.41 | 0.38 |  |  |  |  |  | 0.22 |  |
| Other reimbursements from related party |  |  |  |  | 0.10 |  | 0.06 |  | 43 |  |
| Placement of security deposits |  |  |  | 0.43 | 0.43 | 0.31 | 1.90 | 1.90 | 2.11 |  |
| Non-funded commitments | 3.13 | 3.19 | 3.21 |  | 3.35 | 3.33 |  | 3.32 | 3.25 |  |
| Investment of related party in Hybrid capital/ Bonds of the Bank |  |  | 4,300 |  | 2,790 | 2,760 | 2,760 |  | 500 |  |
| Other receivables (net) |  |  |  | 0.25 | 0.03 | 0.32 | 0.04 | 0.02 | 16 |  |
| Other payables (net) |  |  |  |  |  |  |  |  | 1.32 |  |
| Investment of related party in Hybrid capital/Bonds of the Bank |  |  | 1,050 |  | 4,300 | 2,815 | 2,760 | 2,760 | 1,458 |  |
| Sale of investments | 659 | 325 | 762 | 870 | 857 | 1,318 | 2,228 | 585 |  |  |
| Repayment of deposit |  |  |  |  |  |  |  | 0.01 |  |  |
| Advance granted (net) | 0.04 | 1.05 | 0.67 | 7.99 |  |  | 0.90 | 7.25 |  |  |
| Sale/Purchase of foreign exchange currency to/from related party |  |  |  |  |  |  |  | 1.11 |  |  |
| Investment in non-equity instrument of related party |  |  | 110 |  | 341 | 290 |  | 0.02 |  |  |
| Investment in non |  |  |  |  |  |  | 0.02 |  |  |  |
| Non-funded commitment |  |  |  |  |  |  | 3.32 |  |  |  |
| Redemption of Hybrid capital/Bonds of the Bank |  |  | 70 |  | 1,510 | 55 |  |  |  |  |
| Sale of foreign exchange currency to related party |  |  |  |  | 1.36 | 1.51 |  |  |  |  |
| Investment in non-equity instruments of related party |  |  | 56 |  | 290 | 0.02 |  |  |  |  |
| Purchase of investments |  |  |  | 189 | 205 |  |  |  |  |  |
| Repayment of security deposits by related party |  |  |  |  | 0.12 |  |  |  |  |  |
| Payable under management contracts | 0.90 | 1.64 | 1.37 | 3.70 | 3.70 |  |  |  |  |  |
| Investment in nonequity instrument of |  |  |  | 393 |  |  |  |  |  |  |
| Nonfunded commitments (issued) |  |  |  | 0.20 |  |  |  |  |  |  |
| Sale of foreign exchange currency to |  |  |  | 1.29 |  |  |  |  |  |  |
| Other reimbursements from |  |  |  | 6.09 |  |  |  |  |  |  |
| Other reimbursements to |  |  |  | 0.75 |  |  |  |  |  |  |
| Investment in nonequity instruments of related party |  |  |  | 206 |  |  |  |  |  |  |
| Nonfunded commitments |  |  |  | 3.39 |  |  |  |  |  |  |
| Investment of related party in Hybrid capital/ Bonds of the |  |  |  | 4,300 |  |  |  |  |  |  |
| Investment in nonequity instrument of the Bank |  |  |  | 393 |  |  |  |  |  |  |
| Investment of related party in Hybrid capital/Bonds |  |  |  | 4,300 |  |  |  |  |  |  |
| Management contracts | 12 | 13 | 11 |  |  |  |  |  |  |  |
| Non-funded commitments (issued) |  |  | 0.05 |  |  |  |  |  |  |  |
| Investment in non-equity instrument of the Bank |  |  | 110 |  |  |  |  |  |  |  |
| Investment of related party in Hybrid Capital/Bonds of the Bank |  |  | 4,355 |  |  |  |  |  |  |  |
| Redemption of Subordinated Debt |  | 50 |  |  |  |  |  |  |  |  |
| Non-funded commitments (net) | 0.08 | 0.05 |  |  |  |  |  |  |  |  |
| Investment of related party in Subordinated Debt/Hybrid Capital/Bonds of the Bank | 3,370 | 3,370 |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | TTM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 27,202 | 30,736 | 35,727 | 41,409 | 45,175 | 46,614 | 56,044 | 63,716 | 64,397 | 68,846 | 87,448 | 112,759 | 117,672 |
| Interest | 17,513 | 18,703 | 21,341 | 24,344 | 26,789 | 27,604 | 33,883 | 37,996 | 34,627 | 34,923 | 43,389 | 61,391 | 64,680 |
| Expenses + | 8,538 | 9,944 | 11,521 | 13,869 | 24,327 | 29,717 | 28,020 | 35,976 | 32,621 | 31,216 | 30,641 | 40,032 | 43,581 |
| Financing Profit | 1,151 | 2,089 | 2,865 | 3,196 | -5,941 | -10,706 | -5,860 | -10,256 | -2,851 | 2,707 | 13,418 | 11,336 | 9,411 |
| Financing Margin % | 4% | 7% | 8% | 8% | -13% | -23% | -10% | -16% | -4% | 4% | 15% | 10% | 8% |
| Other Income + | 6,833 | 7,766 | 8,838 | 9,955 | 12,422 | 11,863 | 14,189 | 16,342 | 13,577 | 17,268 | 18,349 | 25,230 | 26,219 |
| Depreciation | 359 | 375 | 420 | 461 | 527 | 591 | 737 | 806 | 976 | 1,046 | 13,146 | 1,388 | 0 |
| Profit before tax | 7,625 | 9,479 | 11,283 | 12,690 | 5,954 | 566 | 7,592 | 5,280 | 9,750 | 18,929 | 18,621 | 35,178 | 35,630 |
| Tax % | 31% | 33% | 34% | 34% | 33% | 18% | 34% | 64% | 26% | 25% | 42% | 25% |  |
| Net Profit + | 5,235 | 6,311 | 7,450 | 8,358 | 3,967 | 464 | 5,047 | 1,879 | 7,252 | 14,207 | 10,919 | 26,492 | 26,846 |
| EPS in Rs | 22.37 | 26.86 | 31.42 | 35.04 | 16.51 | 1.78 | 19.59 | 6.57 | 23.49 | 45.99 | 35.16 | 85.49 | 86.63 |
| Dividend Payout % | 16% | 15% | 15% | 14% | 30% | 0% | 5% | 0% | 0% | 2% | 3% | 1% |  |
| 10 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 21% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 15% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 39% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 54% |  |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 23% |  |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 10% |  |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 11% |  |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 14% |  |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 18% |  |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 2,573 | 14,464 | -15,162 | -34,495 | 32,209 | -38,390 | 37,125 | 30,416 | 12,633 | 28,137 | 22,075 | -5,555 |
| Cash from Investing Activity + | -10,939 | -14,166 | -7,972 | 9,211 | -12,458 | -10,007 | -18,674 | -9,485 | -54,288 | -27,112 | -32,351 | -9,001 |
| Cash from Financing Activity + | 14,931 | 7,785 | 31,045 | 22,495 | -2,487 | 41,342 | 5,643 | 8,865 | 7,279 | 47,894 | 6,641 | 22,341 |
| Net Cash Flow | 6,566 | 8,082 | 7,910 | -2,789 | 17,263 | -7,055 | 24,094 | 29,795 | -34,375 | 48,919 | -3,636 | 7,785 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % | 19% | 18% | 18% | 17% | 7% | 1% | 8% | 2% | 8% | 13% | 9% | 18% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 11.64% | 9.71% | 9.70% | 9.70% | 9.69% | 8.19% | 8.16% | 8.19% | 8.22% | 8.20% | 8.22% | 8.31% |
| FIIs + | 51.38% | 47.44% | 46.93% | 46.58% | 46.12% | 49.45% | 49.05% | 52.00% | 53.00% | 54.68% | 53.84% | 53.43% |
| DIIs + | 25.32% | 30.21% | 30.50% | 31.47% | 32.26% | 31.51% | 32.01% | 29.91% | 29.03% | 28.83% | 30.12% | 31.63% |
| Public + | 11.66% | 12.64% | 12.87% | 12.25% | 11.95% | 10.83% | 10.79% | 9.91% | 9.76% | 8.27% | 7.81% | 6.63% |
| No. of Shareholders | 6,17,836 | 8,52,514 | 8,13,530 | 9,16,563 | 8,50,806 | 8,09,805 | 8,46,261 | 8,01,209 | 7,85,601 | 7,85,502 | 7,86,166 | 7,69,651 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 30.13% | 27.60% | 18.70% | 16.00% | 13.58% | 9.70% | 8.16% | 8.22% | 8.31% |
| FIIs + | 50.54% | 49.90% | 49.62% | 45.49% | 51.43% | 46.93% | 49.05% | 53.84% | 53.43% |
| DIIs + | 8.84% | 13.41% | 21.24% | 24.94% | 23.27% | 30.50% | 32.01% | 30.12% | 31.63% |
| Public + | 10.49% | 9.09% | 10.44% | 13.56% | 11.72% | 12.87% | 10.79% | 7.81% | 6.63% |
| No. of Shareholders | 4,48,287 | 3,53,088 | 3,36,023 | 5,58,989 | 6,20,618 | 8,13,530 | 8,46,261 | 7,86,166 | 7,69,651 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/axis-bank-ltd/axisbank/532215/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
20h - Newspaper Publication - Unaudited Financial Results for the quarter ended 30th June 2024](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a637ad77-d83f-47fd-9e1a-53f740461f4c.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Outcome 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5b706376-7158-46dd-a940-dadcbc08b366.pdf)
- [Announcement under Regulation 30 (LODR)-Press Release / Media Release 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b996e02d-f565-4215-8ac7-1ece11323017.pdf)
- [Announcement under Regulation 30 (LODR)-Investor Presentation](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f962b87c-49fa-4f20-8b43-4159690037b8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f425601d-1bf3-4f4a-9f58-c6255723644a.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=93457ea2-9cfe-4d6c-98ec-12e62c07ff0b.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\90b930a8-4c38-4490-afd8-3eb51a9331c8.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/532215/73342532215.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/532215/68747532215.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150313.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_1193_AXISBANK_2012_2013_28082013100357.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/532215/5322150311.pdf)

## Credit Ratings
- [Rating update
22 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123612)
- [Rating update
22 Nov 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AxisBankLimited_November%2022,%202023_RR_331735.html)
- [Rating update
9 Oct 2023 from fitch](https://www.indiaratings.co.in/pressrelease/66404)
- [Rating update
3 Oct 2023 from fitch](https://www.indiaratings.co.in/pressrelease/66327)
- [Rating update
29 Sep 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202309130939_Axis_Bank_Limited.pdf)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/AxisBankLimited_March%2013,%202023_RR_314381.html)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f962b87c-49fa-4f20-8b43-4159690037b8.pdf)
- [Transcript](https://www.axisbank.com/docs/default-source/call-transcript/q4fy24-media-conference-call-transcript.pdf)
- [Transcript](https://www.axisbank.com/docs/default-source/call-transcript/q4fy24-media-conference-call-transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c3f57013-8624-44b7-94d7-f1eec2495a47.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=447bbcb4-3eda-40c4-a079-f4c3f850db5f.pdf)
- [Transcript](https://www.axisbank.com/docs/default-source/call-transcript/q3fy24-earnings-call-transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=daed5096-8c45-488e-8040-8cefe737885f.pdf)
- [Transcript](https://www.axisbank.com/docs/default-source/call-transcript/q2fy24-earnings-call-transcript.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d1c07ce3-5438-4f85-8c67-b0c1d41f4259.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q1fy24-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=cefb501c-ded9-4737-b8a0-829713d31ae8.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q4fy23-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=94eda175-cad4-4349-a689-2adbc17f7064.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q3fy23-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d99e9b9a-5ae7-443c-86e2-001ddc4998bd.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q2fy23-earnings-call-transcript.pdf)
- [](https://www.axisbank.com/docs/default-source/investor-presentations/investor-presentation-q2fy23-2022.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q1fy23-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=84070222-ad0b-4f7a-a8e7-1605164804c0.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=da931a47-60de-491b-aaa0-08aadd88c4b3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c8fc58a1-81b1-47f6-b6ca-ee686f61e0c2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a2f34353-126f-49d5-a19e-a5b1bde47191.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e74fd7c8-d8b5-47e5-8f91-e9bddea048f1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fc1f25aa-2cc5-4d0a-bbaf-772c2803b639.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=24d6169b-cc60-48fd-8f4b-340449af5292.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/axis-banks-q4fy22-earnings-call-script.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c1d289b3-5006-4540-9645-f69975ab3709.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d6c48e3b-6d3a-4f29-b5a4-6aa8593c72df.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d438ed48-791d-4f0b-ad6a-5f99f2e10f31.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5ea6a360-bd02-44ae-a099-4edae0960a60.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=46eeab9f-5763-4e8f-8c92-ad1347037ac4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=639fc1e4-3647-4693-b1d2-528ecbefecf4.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0b0d4282-0e2e-420a-903e-58e3dec1aaa6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b83b4e33-88ff-46a5-a137-c19acfef027a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4d8dfc4c-aa4d-43db-8851-6f03d4de75b2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dc338646-a5e7-41ac-bc61-4eaba1840d2e.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/axis-bank-q3fy22-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ffd5b62e-e9d5-4acc-b0c5-3301af09076d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48ef07fd-1525-45cf-a826-6ee92a887c46.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=91a0ebe3-400a-418b-a5d0-e97106e1cc8b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=af8f189c-7673-476f-8fd1-dda6412e874b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f6f32e49-4b67-41bb-ac42-1cc90df7674d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=47b3a006-3c02-4f70-b1b8-faee43dd13db.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=73497445-1f13-4762-bcfc-c9a55c8c861c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6487bec1-cf42-4550-920f-3e8e562d88f6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a4b16856-db73-4a95-9be7-779ac37b018a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e5ac19d6-3313-4c7d-9609-df52f91fe28b.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q2fy22-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0b6ce4c7-27e4-4e01-a9b1-db46733a8ad6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=989c2a62-f07f-44a5-8c07-f52a51ba7960.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7a44631f-a8b4-4829-b1af-bde7c3bf15a5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01bd70e3-c122-472b-af01-1df39a1a8539.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=147b1102-2a34-4899-9413-d6efa500bed9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c4f9cfc-6cb1-420c-ae5a-1a195096b96c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a77d272b-03d6-47c0-a100-23d9caa2670a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=99bb4fde-ec67-4801-8d74-0649a58702e5.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5b9f47cb-076d-49fd-9c60-33e9466927dd.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c983eeb4-ea44-4252-b513-f33399ad686a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=44c27cb0-0dba-4b85-8bda-157285c73717.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=74d6e63c-82bf-469f-9bc7-b1feef417673.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=66beaaaf-5b8e-4363-8bbe-df0ab650339f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=904f75b3-5fc5-469e-b212-096c109a704d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a4b2c752-8753-45cc-8d89-7dd43a9a08d9.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q1fy22-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=584f92b1-80b7-49e9-bdde-4cf098a94da6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c532c60f-15c5-4900-bbfe-38b955b80ede.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6eb17c3b-1fb8-47fe-bc5c-d2e90103c921.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d559eba9-e25b-44ab-a006-63edaca2ff3b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=bcba6d09-a40e-4144-8b68-98dd9eb62785.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q4fy21-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1d03e323-5ac6-4f3d-8cfb-4cd0a9a3ccfa.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88423adb-21cd-4b38-a360-fc19ff31ddbe.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q3fy21-earnings-call-transcript.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q2fy21-earnings-call-transcript.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q1fy21-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3e8456ee-2ef6-4d00-a271-90d97084b34c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=523879d9-b6dd-4c5e-b28a-e56b25bfb47b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c9bd5d54-6435-4499-933b-024b71cfd956.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q2fy18-earnings-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=29c452dc-d324-4126-98f4-ca38d2e2f9cc.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q4-fy-17-call-transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5BD16B05_0958_488A_9F40_B4E4889DB473_162717.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=C6813C45_99D0_49C8_9883_8490A7DBE0E1_165844.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=D66CBB7A_D814_4013_8079_B805DAEA9180_165659.pdf)
- [](https://www.axisbank.com/docs/default-source/call-transcript/q4-fy16-results-call-script.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B78F470B_2AFC_4673_9AFF_6638F45C9C53_175020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=E236B060_55EC_47B3_A06F_FF4760AA14C3_164746.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=BA3B1A9B_B8FD_44E6_9422_8C10850DE279_145345.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | HDFC Bank | 1619.35 | 1232021.28 | 18.06 | 2.69 | 3.92 | 204.24 | 16.09 | 7.26 | 1.22 | 7.67 | 1.99 | 17.14 | 0.09 | 6.81 | 1.48 | 7.19 | 314027.08 | 33.60 | 68166.51 | 81546.20 | 16474.85 | 59.37 | 33.18 | 89.75 | 3107502.74 | 0.00 | 0.00 | 6.22 | 12.00 | 0.00 | 70.07 | 39.72 | 4110689.51 | 2.50 | 0.77 | 7.07 | 12.66 | 3.94 | -3.38 | 16.99 | 16.85 | 23.42 | 26.19 | 21.95 | 30.19 | 17.11 | 6.24 | 2.50 | 84.33 | 15.48 | 21.14 | 19.93 | 24.91 | 0.00 | 557.97 |
| 2. | ICICI Bank | 1206.20 | 848960.53 | 19.14 | 3.95 | 5.32 | 12.48 | 15.58 | 23.57 | 0.83 | 8.37 | 2.35 | 20.63 | 0.08 | 6.53 | 1.83 | 9.13 | 159515.92 | 36.37 | 44256.37 | 42606.72 | 11671.52 | 23.72 | 18.46 | 63.02 | 1399893.96 | 0.00 | 0.00 | 6.44 | 12.00 | 0.00 | 31.76 | 30.17 | 2112398.00 | 2.20 | 0.32 | 8.12 | 18.61 | 20.92 | 20.97 | 17.74 | 15.61 | 59.74 | 34.01 | 17.25 | 21.40 | 17.15 | 6.32 | 2.20 | 63.02 | 57.03 | 22.48 | 19.58 | 22.46 | 0.00 | 698.28 |
| 3. | Axis Bank | 1176.90 | 363775.46 | 13.57 | 2.33 | 3.09 | 27.63 | 15.38 | 10.01 | 0.09 | 7.06 | 1.85 | 18.40 | 0.08 | 8.25 | 1.55 | 9.12 | 117671.83 | 62.96 | 26731.28 | 31158.52 | 6436.43 | 18.72 | 5.67 | 86.63 | 1295301.95 | 8.31 | 0.09 | 6.50 | 12.00 | 0.00 | 24.52 | 17.09 | 1542584.23 | 2.68 | 0.35 | 4.03 | 12.82 | 17.13 | 22.50 | 13.57 | 10.97 | 39.18 | 54.17 | 15.01 | 20.53 | 8.73 | 5.12 | 2.68 | 85.49 | 34.19 | 20.56 | 14.40 | 30.77 | 0.00 | 307.69 |
| 4. | Kotak Mah. Bank | 1813.70 | 360554.77 | 19.41 | 2.75 | 6.09 | 53.91 | 16.71 | 3.26 | 0.11 | 7.86 | 2.62 | 15.06 | 0.08 | 4.00 | 1.99 | 5.34 | 59204.49 | 15.88 | 18642.68 | 15836.79 | 4579.66 | 23.06 | 10.35 | 108.22 | 520374.37 | 25.89 | -0.01 | 6.04 | 12.00 | 0.00 | 29.11 | 14.23 | 815722.75 | 1.97 | 0.95 | 10.36 | 0.38 | 1.49 | -5.26 | 14.32 | 14.06 | 20.42 | 22.27 | 13.52 | 19.66 | 14.31 | 6.86 | 1.97 | 91.62 | 19.45 | 29.26 | 26.25 | 34.60 | 0.00 | 198.66 |
| 5. | IDBI Bank | 103.50 | 111287.30 | 17.66 | 2.20 | 4.24 | 777.45 | 17.37 | 26.64 | 1.42 | 6.23 | 1.65 | 11.77 | 0.08 | 5.77 | 1.71 | 6.81 | 26251.87 | 68.52 | 6293.17 | 6669.84 | 1734.32 | -2.82 | 41.09 | 5.85 | 294448.21 | 94.71 | 0.00 | 5.79 | 12.00 | 0.00 | 15.06 | 51.03 | 379726.03 | 2.23 | 0.93 | 14.51 | 21.51 | 38.73 | 75.54 | 8.98 | 0.32 | 18.98 | 55.84 | 3.65 | 9.84 | 8.34 | 4.79 | 2.23 | 5.38 | 17.89 | 17.67 | 17.02 | 17.67 | 0.00 | 1075.24 |
| 6. | IndusInd Bank | 1404.45 | 109368.09 | 12.18 | 1.96 | 2.39 | -23.11 | 11.82 | -0.52 | 1.20 | 8.42 | 1.95 | 16.39 | 0.10 | 7.06 | 1.48 | 8.38 | 45748.21 | 60.52 | 8949.78 | 12198.53 | 2346.84 | 21.73 | 15.01 | 114.99 | 385449.37 | 15.79 | -0.02 | 8.50 | 12.00 | 45.48 | 25.79 | 21.08 | 438306.32 | 4.57 | 0.55 | -4.65 | -8.79 | 12.22 | -2.58 | 13.85 | 12.76 | 22.07 | 46.69 | 15.50 | 16.41 | 14.45 | 6.91 | 4.57 | 114.99 | 15.98 | 15.48 | 14.42 | 19.35 | 0.00 | 77.59 |
| 7. | Yes Bank | 25.01 | 78370.45 | 53.96 | 1.74 | 2.71 | 44.14 | 18.17 | -23.83 | 0.00 | 5.83 | 0.34 | 3.18 | 0.07 | 8.41 | 1.09 | 9.24 | 28885.91 | 58.49 | 1454.52 | 7725.41 | 516.00 | 19.86 | 48.84 | 0.49 | 346737.14 | 0.00 | 0.00 | 5.52 | 12.00 | 0.00 | 20.30 | 89.30 | 405789.14 | 4.42 | -9.78 | -5.85 | -0.93 | 23.56 | 45.25 | 2.79 | -10.37 | -5.52 | 33.31 | -1.40 | 11.27 | 1.99 | 4.94 | 4.42 | 0.45 | -42.92 | 50.33 | 52.98 | 27.25 | 0.00 | 2875.48 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| AXISBANK | Market Cap | ₹ 3,63,945 Cr. |
| AXISBANK | Current Price | ₹ 1,177 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | Sales | ₹ 1,17,672 Cr. |
| AXISBANK | OPM | 63.0 % |
| AXISBANK | Profit after tax | ₹ 26,731 Cr. |
| AXISBANK | Mar Cap | ₹ 3,63,945 Cr. |
| AXISBANK | Sales Qtr | ₹ 31,159 Cr. |
| AXISBANK | PAT Qtr | ₹ 6,436 Cr. |
| AXISBANK | Qtr Sales Var | 18.7 % |
| AXISBANK | Qtr Profit Var | 5.67 % |
| AXISBANK | Price to Earning | 13.6 |
| AXISBANK | Dividend yield | 0.09 % |
| AXISBANK | Price to book value | 2.33 |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | Return on assets | 1.85 % |
| AXISBANK | Debt to equity | 8.25 |
| AXISBANK | Return on equity | 18.4 % |
| AXISBANK | EPS | ₹ 86.6 |
| AXISBANK | Debt | ₹ 12,95,302 Cr. |
| AXISBANK | Promoter holding | 8.31 % |
| AXISBANK | Change in Prom Hold | 0.09 % |
| AXISBANK | Earnings yield | 6.50 % |
| AXISBANK | Pledged percentage | 0.00 % |
| AXISBANK | Industry PE | 12.0 |
| AXISBANK | Sales growth | 24.5 % |
| AXISBANK | Profit growth | 17.1 % |
| AXISBANK | Current Price | ₹ 1,177 |
| AXISBANK | Price to Sales | 3.09 |
| AXISBANK | CMP / FCF | 27.6 |
| AXISBANK | EVEBITDA | 15.4 |
| AXISBANK | Enterprise Value | ₹ 15,42,754 Cr. |
| AXISBANK | Current ratio | 2.68 |
| AXISBANK | Int Coverage | 1.55 |
| AXISBANK | PEG Ratio | 0.35 |
| AXISBANK | Return over 3months | 4.03 % |
| AXISBANK | Return over 6months | 12.8 % |
| AXISBANK | No. Eq. Shares | 309 |
| AXISBANK | Sales growth 3Years | 20.5 % |
| AXISBANK | Sales growth 5Years | 15.0 % |
| AXISBANK | Profit Var 3Yrs | 54.2 % |
| AXISBANK | Profit Var 5Yrs | 39.2 % |
| AXISBANK | ROE 5Yr | 11.0 % |
| AXISBANK | ROE 3Yr | 13.6 % |
| AXISBANK | Return over 1year | 22.5 % |
| AXISBANK | Return over 3years | 17.1 % |
| AXISBANK | Return over 5years | 10.0 % |
| AXISBANK | Market Cap | ₹ 3,63,945 Cr. |
| AXISBANK | Current Price | ₹ 1,177 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | Sales last year | ₹ 1,12,759 Cr. |
| AXISBANK | OP Ann | ₹ 72,727 Cr. |
| AXISBANK | Other Inc Ann | ₹ 25,230 Cr. |
| AXISBANK | EBIDT last year | ₹ 97,962 Cr. |
| AXISBANK | Dep Ann | ₹ 1,388 Cr. |
| AXISBANK | EBIT last year | ₹ 96,573 Cr. |
| AXISBANK | Interest last year | ₹ 61,391 Cr. |
| AXISBANK | PBT Ann | ₹ 35,178 Cr. |
| AXISBANK | Tax last year | ₹ 8,754 Cr. |
| AXISBANK | PAT Ann | ₹ 26,390 Cr. |
| AXISBANK | Extra Ord Item Ann | ₹ -4.42 Cr. |
| AXISBANK | NP Ann | ₹ 26,492 Cr. |
| AXISBANK | Dividend last year | ₹ 309 Cr. |
| AXISBANK | Raw Material | 0.00 % |
| AXISBANK | Employee cost | ₹ 12,205 Cr. |
| AXISBANK | OPM last year | 64.5 % |
| AXISBANK | NPM last year | 23.5 % |
| AXISBANK | Operating profit | ₹ 74,090 Cr. |
| AXISBANK | Interest | ₹ 64,680 Cr. |
| AXISBANK | Depreciation | ₹ 0.00 Cr. |
| AXISBANK | EPS last year | ₹ 85.5 |
| AXISBANK | EBIT | ₹ 1,00,310 Cr. |
| AXISBANK | Net profit | ₹ 26,846 Cr. |
| AXISBANK | Current Tax | ₹ 8,855 Cr. |
| AXISBANK | Tax | ₹ 8,855 Cr. |
| AXISBANK | Other income | ₹ 26,219 Cr. |
| AXISBANK | Ann Date | 2,02,403 |
| AXISBANK | Sales Prev Ann | ₹ 87,448 Cr. |
| AXISBANK | OP Prev Ann | ₹ 56,807 Cr. |
| AXISBANK | Other Inc Prev Ann | ₹ 18,349 Cr. |
| AXISBANK | EBIDT Prev Ann | ₹ 75,164 Cr. |
| AXISBANK | Dep Prev Ann | ₹ 13,146 Cr. |
| AXISBANK | EBIT preceding year | ₹ 62,018 Cr. |
| AXISBANK | Interest Prev Ann | ₹ 43,389 Cr. |
| AXISBANK | PBT Prev Ann | ₹ 18,621 Cr. |
| AXISBANK | Tax preceding year | ₹ 7,769 Cr. |
| AXISBANK | PAT Prev Ann | ₹ 10,823 Cr. |
| AXISBANK | Extra Ord Prev Ann | ₹ -7.69 Cr. |
| AXISBANK | NP Prev Ann | ₹ 10,919 Cr. |
| AXISBANK | Dividend Prev Ann | ₹ 308 Cr. |
| AXISBANK | OPM preceding year | 65.0 % |
| AXISBANK | NPM preceding year | 12.5 % |
| AXISBANK | EPS preceding year | ₹ 35.2 |
| AXISBANK | Sales Prev 12M | ₹ 1,12,759 Cr. |
| AXISBANK | Profit Prev 12M | ₹ 26,492 Cr. |
| AXISBANK | Med Sales Gwth 10Yrs | 13.7 % |
| AXISBANK | Med Sales Gwth 5Yrs | 13.7 % |
| AXISBANK | Sales growth 7Years | 14.0 % |
| AXISBANK | Sales Var 10Yrs | 13.9 % |
| AXISBANK | EBIDT growth 3Years | 29.3 % |
| AXISBANK | EBIDT growth 5Years | 18.3 % |
| AXISBANK | EBIDT growth 7Years | 16.7 % |
| AXISBANK | EBIDT Var 10Yrs | 13.1 % |
| AXISBANK | EPS growth 3Years | 53.8 % |
| AXISBANK | EPS growth 5Years | 34.2 % |
| AXISBANK | EPS growth 7Years | 26.5 % |
| AXISBANK | EPS growth 10Years | 12.3 % |
| AXISBANK | Profit Var 7Yrs | 31.2 % |
| AXISBANK | Profit Var 10Yrs | 15.4 % |
| AXISBANK | Chg in Prom Hold 3Yr | -3.38 % |
| AXISBANK | Market Cap | ₹ 3,63,945 Cr. |
| AXISBANK | Current Price | ₹ 1,177 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | OP Qtr | ₹ 19,267 Cr. |
| AXISBANK | Other Inc Qtr | ₹ 6,637 Cr. |
| AXISBANK | EBIDT Qtr | ₹ 25,904 Cr. |
| AXISBANK | Dep Qtr | ₹ 0.00 Cr. |
| AXISBANK | EBIT latest quarter | ₹ 25,904 Cr. |
| AXISBANK | Interest Qtr | ₹ 17,261 Cr. |
| AXISBANK | PBT Qtr | ₹ 8,643 Cr. |
| AXISBANK | Tax latest quarter | ₹ 2,193 Cr. |
| AXISBANK | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| AXISBANK | NP Qtr | ₹ 6,467 Cr. |
| AXISBANK | GPM latest quarter | 100 % |
| AXISBANK | OPM latest quarter | 61.8 % |
| AXISBANK | NPM latest quarter | 20.8 % |
| AXISBANK | Eq Cap Qtr | ₹ 618 Cr. |
| AXISBANK | EPS latest quarter | ₹ 20.8 |
| AXISBANK | OP 2Qtr Bk | ₹ 18,359 Cr. |
| AXISBANK | OP 3Qtr Bk | ₹ 17,358 Cr. |
| AXISBANK | Sales 2Qtr Bk | ₹ 28,865 Cr. |
| AXISBANK | Sales 3Qtr Bk | ₹ 27,418 Cr. |
| AXISBANK | NP 2Qtr Bk | ₹ 6,520 Cr. |
| AXISBANK | NP 3Qtr Bk | ₹ 6,230 Cr. |
| AXISBANK | Opert Prft Gwth | 22.2 % |
| AXISBANK | Last result date | 2,02,406 |
| AXISBANK | Exp Qtr Sales Var | 24.7 % |
| AXISBANK | Exp Qtr Sales | ₹ 34,191 Cr. |
| AXISBANK | Exp Qtr OP | ₹ 21,573 Cr. |
| AXISBANK | Exp Qtr NP | ₹ 4,301 Cr. |
| AXISBANK | Exp Qtr EPS | ₹ 13.8 |
| AXISBANK | Sales Prev Qtr | ₹ 30,231 Cr. |
| AXISBANK | OP Prev Qtr | ₹ 19,107 Cr. |
| AXISBANK | Other Inc Prev Qtr | ₹ 7,606 Cr. |
| AXISBANK | EBIDT Prev Qtr | ₹ 26,712 Cr. |
| AXISBANK | Dep Prev Qtr | ₹ 0.00 Cr. |
| AXISBANK | EBIT Prev Qtr | ₹ 26,712 Cr. |
| AXISBANK | Interest Prev Qtr | ₹ 16,727 Cr. |
| AXISBANK | PBT Prev Qtr | ₹ 9,985 Cr. |
| AXISBANK | Tax Prev Qtr | ₹ 2,371 Cr. |
| AXISBANK | PAT Prev Qtr | ₹ 7,599 Cr. |
| AXISBANK | Extra Ord Prev Qtr | ₹ 0.00 Cr. |
| AXISBANK | NP Prev Qtr | ₹ 7,630 Cr. |
| AXISBANK | OPM Prev Qtr | 63.2 % |
| AXISBANK | NPM Prev Qtr | 25.2 % |
| AXISBANK | Eq Cap Prev Qtr | ₹ Cr. |
| AXISBANK | EPS Prev Qtr | ₹ 24.6 |
| AXISBANK | Sales PY Qtr | ₹ 26,246 Cr. |
| AXISBANK | OP PY Qtr | ₹ 16,515 Cr. |
| AXISBANK | Other Inc PY Qtr | ₹ 5,648 Cr. |
| AXISBANK | EBIDT PY Qtr | ₹ 22,164 Cr. |
| AXISBANK | Dep PY Qtr | ₹ 0.00 Cr. |
| AXISBANK | EBIT PY Qtr | ₹ 22,164 Cr. |
| AXISBANK | Interest PY Qtr | ₹ 13,972 Cr. |
| AXISBANK | PBT PY Qtr | ₹ 8,192 Cr. |
| AXISBANK | Tax PY Qtr | ₹ 2,093 Cr. |
| AXISBANK | Market Cap | ₹ 3,63,945 Cr. |
| AXISBANK | Current Price | ₹ 1,177 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | Equity capital | ₹ 617 Cr. |
| AXISBANK | Preference capital | ₹ 0.00 Cr. |
| AXISBANK | Reserves | ₹ 1,56,406 Cr. |
| AXISBANK | Secured loan | ₹ 2,28,200 Cr. |
| AXISBANK | Unsecured loan | ₹ 10,67,102 Cr. |
| AXISBANK | Balance sheet total | ₹ 15,18,239 Cr. |
| AXISBANK | Gross block | ₹ 26,505 Cr. |
| AXISBANK | Revaluation reserve | ₹ 0.00 Cr. |
| AXISBANK | Accum Dep | ₹ 20,645 Cr. |
| AXISBANK | Net block | ₹ 5,860 Cr. |
| AXISBANK | CWIP | ₹ 267 Cr. |
| AXISBANK | Investments | ₹ 3,32,354 Cr. |
| AXISBANK | Current assets | ₹ 1,74,990 Cr. |
| AXISBANK | Current liabilities | ₹ 65,414 Cr. |
| AXISBANK | BV Unq Invest | ₹ 7,017 Cr. |
| AXISBANK | MV Quoted Inv | ₹ 0.00 Cr. |
| AXISBANK | Cont Liab | ₹ 19,85,668 Cr. |
| AXISBANK | Total Assets | ₹ 15,18,239 Cr. |
| AXISBANK | Working capital | ₹ 1,09,576 Cr. |
| AXISBANK | Lease liabilities | ₹ 0.00 Cr. |
| AXISBANK | Inventory | ₹ 0.00 Cr. |
| AXISBANK | Trade receivables | ₹ 0.00 Cr. |
| AXISBANK | Face value | ₹ 2.00 |
| AXISBANK | Cash Equivalents | ₹ 1,16,493 Cr. |
| AXISBANK | Adv Cust | ₹ 0.00 Cr. |
| AXISBANK | Trade Payables | ₹ 6,714 Cr. |
| AXISBANK | No. Eq. Shares PY | 308 |
| AXISBANK | Debt preceding year | ₹ 11,52,038 Cr. |
| AXISBANK | Work Cap PY | ₹ 1,14,183 Cr. |
| AXISBANK | Net Block PY | ₹ 5,000 Cr. |
| AXISBANK | Gross Block PY | ₹ 24,606 Cr. |
| AXISBANK | CWIP PY | ₹ 142 Cr. |
| AXISBANK | Work Cap 3Yr | ₹ 90,998 Cr. |
| AXISBANK | Work Cap 5Yr | ₹ 87,353 Cr. |
| AXISBANK | Work Cap 7Yr | ₹ 64,814 Cr. |
| AXISBANK | Work Cap 10Yr | ₹ 22,026 Cr. |
| AXISBANK | Debt 3Years back | ₹ 8,50,551 Cr. |
| AXISBANK | Debt 5Years back | ₹ 7,11,996 Cr. |
| AXISBANK | Debt 7Years back | ₹ 5,27,437 Cr. |
| AXISBANK | Debt 10Years back | ₹ 3,33,280 Cr. |
| AXISBANK | Net Block 3Yrs Back | ₹ 4,501 Cr. |
| AXISBANK | Net Block 5Yrs Back | ₹ 3,842 Cr. |
| AXISBANK | Net Block 7Yrs Back | ₹ 3,518 Cr. |
| AXISBANK | Market Cap | ₹ 3,63,435 Cr. |
| AXISBANK | Current Price | ₹ 1,176 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | CF Operations | ₹ -5,555 Cr. |
| AXISBANK | Free Cash Flow | ₹ -7,931 Cr. |
| AXISBANK | CF Investing | ₹ -9,001 Cr. |
| AXISBANK | CF Financing | ₹ 22,341 Cr. |
| AXISBANK | Net CF | ₹ 7,785 Cr. |
| AXISBANK | Cash Beginning | ₹ 1,08,708 Cr. |
| AXISBANK | Cash End | ₹ 1,16,493 Cr. |
| AXISBANK | FCF Prev Ann | ₹ 20,697 Cr. |
| AXISBANK | CF Operations PY | ₹ 22,075 Cr. |
| AXISBANK | CF Investing PY | ₹ -32,351 Cr. |
| AXISBANK | CF Financing PY | ₹ 6,641 Cr. |
| AXISBANK | Net CF PY | ₹ -3,636 Cr. |
| AXISBANK | Cash Beginning PY | ₹ 1,12,344 Cr. |
| AXISBANK | Cash End PY | ₹ 1,08,708 Cr. |
| AXISBANK | Free Cash Flow 3Yrs | ₹ 39,502 Cr. |
| AXISBANK | Free Cash Flow 5Yrs | ₹ 80,548 Cr. |
| AXISBANK | Free Cash Flow 7Yrs | ₹ 77,615 Cr. |
| AXISBANK | Free Cash Flow 10Yrs | ₹ 57,395 Cr. |
| AXISBANK | CF Opr 3Yrs | ₹ 44,657 Cr. |
| AXISBANK | CF Opr 5Yrs | ₹ 87,706 Cr. |
| AXISBANK | CF Opr 7Yrs | ₹ 86,441 Cr. |
| AXISBANK | CF Opr 10Yrs | ₹ 68,992 Cr. |
| AXISBANK | CF Inv 10Yrs | ₹ -1,72,139 Cr. |
| AXISBANK | CF Inv 7Yrs | ₹ -1,60,919 Cr. |
| AXISBANK | CF Inv 5Yrs | ₹ -1,32,237 Cr. |
| AXISBANK | CF Inv 3Yrs | ₹ -68,464 Cr. |
| AXISBANK | Cash 3Years back | ₹ 63,424 Cr. |
| AXISBANK | Cash 5Years back | ₹ 68,004 Cr. |
| AXISBANK | Cash 7Years back | ₹ 50,966 Cr. |
| AXISBANK | Market Cap | ₹ 3,63,435 Cr. |
| AXISBANK | Current Price | ₹ 1,176 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | No. Eq. Shares | 309 |
| AXISBANK | Book value | ₹ 509 |
| AXISBANK | Inven TO |  |
| AXISBANK | Quick ratio | 2.68 |
| AXISBANK | Exports percentage | 0.00 % |
| AXISBANK | Piotroski score | 4.00 |
| AXISBANK | G Factor | 5.00 |
| AXISBANK | Asset Turnover | 0.08 |
| AXISBANK | Financial leverage | 9.12 |
| AXISBANK | No. of Share Holders | 7,69,651 |
| AXISBANK | Unpledged Prom Hold | 8.31 % |
| AXISBANK | ROIC | 7.06 % |
| AXISBANK | Debtor days | 0.00 |
| AXISBANK | Industry PBV | 1.87 |
| AXISBANK | Credit rating |  |
| AXISBANK | WC Days | -22.4 |
| AXISBANK | Earning Power | 6.61 % |
| AXISBANK | Graham Number | ₹ 996 |
| AXISBANK | Cash Cycle | 0.00 |
| AXISBANK | Days Payable |  |
| AXISBANK | Days Receivable | 0.00 |
| AXISBANK | Inventory Days |  |
| AXISBANK | Public holding | 6.63 % |
| AXISBANK | FII holding | 53.4 % |
| AXISBANK | Chg in FII Hold | -0.41 % |
| AXISBANK | DII holding | 31.6 % |
| AXISBANK | Chg in DII Hold | 1.51 % |
| AXISBANK | B.V. Prev Ann | ₹ 422 |
| AXISBANK | ROCE Prev Yr | 5.12 % |
| AXISBANK | ROA Prev Yr | 0.86 % |
| AXISBANK | ROE Prev Ann | 8.73 % |
| AXISBANK | No. of Share Holders Prev Qtr | 7,86,166 |
| AXISBANK | No. Eq. Shares 10 Yrs | 237 |
| AXISBANK | BV 3yrs back | ₹ 338 |
| AXISBANK | BV 5yrs back | ₹ 306 |
| AXISBANK | BV 10yrs back | ₹ 190 |
| AXISBANK | Inven TO 3Yr |  |
| AXISBANK | Inven TO 5Yr |  |
| AXISBANK | Inven TO 7Yr |  |
| AXISBANK | Inven TO 10Yr |  |
| AXISBANK | Export 3Yr | 0.00 % |
| AXISBANK | Export 5Yr | 0.00 % |
| AXISBANK | Div 5Yrs | ₹ 185 Cr. |
| AXISBANK | ROCE 3Yr | 5.78 % |
| AXISBANK | ROCE 5Yr | 5.47 % |
| AXISBANK | ROCE 7Yr | 5.36 % |
| AXISBANK | ROCE 10Yr | 5.89 % |
| AXISBANK | ROE 10Yr | 10.4 % |
| AXISBANK | ROE 7Yr | 9.73 % |
| AXISBANK | ROE 5Yr Var | 19.2 % |
| AXISBANK | OPM 5Year | 57.1 % |
| AXISBANK | OPM 10Year | 55.3 % |
| AXISBANK | No. of Share Holders 1Yr | 8,01,209 |
| AXISBANK | Avg Div Payout 3Yrs | 2.06 % |
| AXISBANK | Debtor days 3yrs | 0.00 |
| AXISBANK | Debtor days 3yrs back | 0.00 |
| AXISBANK | Debtor days 5yrs back | 0.00 |
| AXISBANK | ROA 5Yr | 0.99 % |
| AXISBANK | ROA 3Yr | 1.33 % |
| AXISBANK | Market Cap | ₹ 3,63,435 Cr. |
| AXISBANK | Current Price | ₹ 1,176 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | Avg Vol 1Mth | 1,03,32,855 |
| AXISBANK | Avg Vol 1Wk | 1,50,25,442 |
| AXISBANK | Volume | 3,36,06,672 |
| AXISBANK | High price | ₹ 1,340 |
| AXISBANK | Low price | ₹ 921 |
| AXISBANK | High price all time | ₹ 1,340 |
| AXISBANK | Low price all time | ₹ 43.2 |
| AXISBANK | Return over 1day | -0.01 % |
| AXISBANK | Return over 1week | -9.01 % |
| AXISBANK | Return over 1month | -8.52 % |
| AXISBANK | DMA 50 | ₹ 1,227 |
| AXISBANK | DMA 200 | ₹ 1,117 |
| AXISBANK | DMA 50 previous day | ₹ 1,229 |
| AXISBANK | 200 DMA prev. | ₹ 1,116 |
| AXISBANK | RSI | 31.2 |
| AXISBANK | MACD | 5.84 |
| AXISBANK | MACD Previous Day | 15.2 |
| AXISBANK | MACD Signal | 20.8 |
| AXISBANK | MACD Signal Prev | 24.6 |
| AXISBANK | Avg Vol 1Yr | 1,02,46,695 |
| AXISBANK | Return over 7years | 12.5 % |
| AXISBANK | Return over 10years | 11.5 % |
| AXISBANK | Market Cap | ₹ 3,63,435 Cr. |
| AXISBANK | Current Price | ₹ 1,176 |
| AXISBANK | High / Low | ₹ 1,340 / 921 |
| AXISBANK | Stock P/E | 13.6 |
| AXISBANK | Book Value | ₹ 509 |
| AXISBANK | Dividend Yield | 0.09 % |
| AXISBANK | ROCE | 7.06 % |
| AXISBANK | ROE | 18.4 % |
| AXISBANK | Face Value | ₹ 2.00 |
| AXISBANK | WC to Sales | 93.1 % |
| AXISBANK | QoQ Profits | -15.2 % |
| AXISBANK | QoQ Sales | 3.07 % |
| AXISBANK | Net worth | ₹ 1,57,024 Cr. |
| AXISBANK | Market Cap to Sales | 3.09 |
| AXISBANK | Interest Coverage | 1.55 |
| AXISBANK | EV / EBIT | 15.4 |
| AXISBANK | Debt Capacity | -2.18 |
| AXISBANK | Debt To Profit | 48.9 |
| AXISBANK | Capital Employed | ₹ 1,15,703 Cr. |
| AXISBANK | CROIC | 0.96 % |
| AXISBANK | debtplus | 20.9 |
| AXISBANK | Leverage | ₹ 9.12 |
| AXISBANK | Dividend Payout | 1.17 % |
| AXISBANK | Intrinsic Value | ₹ 951 |
| AXISBANK | CDL | -871 % |
| AXISBANK | Cash by market cap | 0.31 |
| AXISBANK | 52w Index | 60.9 % |
| AXISBANK | Down from 52w high | 12.2 % |
| AXISBANK | Up from 52w low | 27.7 % |
| AXISBANK | From 52w high | 0.88 |
| AXISBANK | Mkt Cap To Debt Cap | 1.66 |
| AXISBANK | Dividend Payout | 1.17 % |
| AXISBANK | Graham | ₹ 996 |
| AXISBANK | Price to Cash Flow | -65.4 |
| AXISBANK | ROCE3yr avg | 5.78 % |
| AXISBANK | PB X PE | 31.6 |
| AXISBANK | NCAVPS | ₹ 354 |
| AXISBANK | Mar Cap to CF | -65.4 |
| AXISBANK | Altman Z Score | 0.91 |
| AXISBANK | M.Cap / Qtr Profit | 56.5 |