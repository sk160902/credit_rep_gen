About
[
edit
]
Angel One Ltd is a diversified financial services company and is primarily engaged in the business  of stock, commodity and currency broking, institutional broking, providing margin trading facility, depository services and distribution of mutual funds, lending as a NBFC and corporate agents of insurance companies.
[1]
Key Points
[
edit
]
Service Offerings
The company's financial products and service offerings include broking services, research services, investment advisory, margin trading facility, loan against shares, distribution of third party financial products and investor education.
[1]
KPIs Q4FY24
[2]
Total Client Base - 22.2 Mn
Gross Client Acquisition - 2.9 Mn
NSE Active Client Base - 6.1 Mn
Number of Orders - 471 Mn
Average Daily Turnover - Rs. 44.4 Trn
Client base <25 yrs. age - 48%
Client base >25 yrs. age - 52%
Market Share
[2]
Share in India’s Demat Accounts - ~15%
Share in NSE Active Client Base - ~15%
Revenue Breakup Q4FY24
[3]
Gross Broking - 68%
Interest on Deposits - 18%
Ancillary Transaction - 8%
Depository - 4%
Distribution - 1%
Others - 1%
Gross Broking Revenue Split Q4FY24
F&O - 85%
Cash - 11%
Commodity - 4%
3rd Party Products
The company has partnership with various 3rd party such as vested, smallcase, Sensibull, Streak, Quicko & Marketsmojo.
[4]
QIP
[5]
In April,24, the company raised Rs. 1500 crs. through QIP for  Rs. 2,555.01 per equity share, with a FV of Rs. 10/-. The company raised the funds for funding the margin obligations that are fulfilled on behalf of its clients and the margin trading facility provided to its clients; and future growth requirements.
Key Investors - Motilal Oswal MF, Whiteoak, Nippon MF,Goldman Sachs Asset Management etc.
[6]
Restructure
[7]
The company is planning to restructure the group by demerging Broking: Assisted Business into Angel Securities Ltd. and Broking: Direct Clients business into Angel Crest Ltd.
Focus
The company is expanding their assisted business through channels and products and foraying into wealth management.
[8]
Last edited 2 months, 3 weeks ago
Request an update
© Protected by Copyright
