# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/infosys-ltd/infy/500209/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Acquisition 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=ea219bb0-e2ee-4ed9-ab6d-6ab7a26b6c9e.pdf)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript 2d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25353afa-0919-47a5-bd94-d149fef7d700.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=98e837de-fd40-4151-b61d-acf3aa6dd057.pdf)
- [Auditors Report With UDIN For The Quarter Ended June 30, 2024 19 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d4997946-6db9-415b-9305-3df118cfa658.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4bc2fca6-c0ba-447c-bb1a-5a7260667b32.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25cc7fbc-154b-4463-928d-c95f2d8c5c9c.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\3ba3c011-0411-49ba-a250-f746a5b9d940.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500209/73015500209_29_06_22.pdf)
- [Financial Year 2021
from web](https://www.infosys.com/investors/reports-filings/annual-report/annual/documents/infosys-ar-21.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500209/68476500209_09_06_21.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500209/5002090311.pdf)

## Credit Ratings
- [Rating update
28 Jun from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_June%2028_%202024_RR_346454.html)
- [Rating update
4 Jul 2023 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_July%2004,%202023_RR_322119.html)
- [Rating update
20 Jul 2022 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_July%2020,%202022_RR_288283.html)
- [Rating update
23 Nov 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_November%2023,%202021_RR_278951.html)
- [Rating update
5 Jan 2021 from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/InfosysLimited_January%2005,%202021_RR.html)
- [](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/Infosys_Limited_January_21_2020_RR.html)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=25353afa-0919-47a5-bd94-d149fef7d700.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=77f16d60-73b2-4877-80fb-c641f2529a70.pdf)
- [REC](https://www.infosys.com/investors/reports-filings/quarterly-results/2023-2024/q4/earningscall.html)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3c3e2ca9-f0a0-4aa3-a03f-01864f720f74.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5bbf010d-5cd7-4d88-a75f-28e72e22c6ab.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=318c3091-9847-46ea-b9ae-1a54441e99e6.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=e7de8466-119e-4bdc-b3c4-bd706d87f104.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c94d45c5-a44a-49d9-89af-6ef6532c4a30.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=01712d63-9662-4355-8b54-0534f66678d8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=48580c91-e22d-4d3c-aa9f-56c255914c14.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=55d91053-dd92-4ca3-bd1d-4e419043f37a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c07b78e8-687e-47ef-a212-41f9057b81ea.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=28eec8d6-de9e-4e4d-92d8-beff066c9b25.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=32e14b77-f2f7-486b-b01f-1b64ab965d41.pdf)
- [](https://www.infosys.com/investors/reports-filings/quarterly-results/2021-2022/q1/documents/transcripts/press-conference.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b4351d41-294f-4958-918d-8aadbe7d85fa.pdf)
- [](https://www.infosys.com/investors/reports-filings/quarterly-results/2020-2021/q3/documents/transcripts/earningscall.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6d098032-b341-4fb0-afdd-ef1f4c7a2993.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d206ef44-722a-428e-b305-0ff3ae64627f.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1186b66a-e330-4893-85d3-e0d1cf3651d7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51df047f-a5f4-433e-9590-85f7e4eb3e1e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=099b31b8-af67-4383-abaf-57f0586a9fc9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f4f9e6fe-28aa-4c0e-a8c9-391529bb8470.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f22533cc-2858-4970-87e5-d73ee33be876.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d248deb8-646e-421e-98a9-19786e4b5e7c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f39ce20f-2791-447f-8b82-6bf8cb2d824a.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=47dce35f-9841-4e10-a7b7-873a36b66c96.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d55691d6-ecda-4bef-8154-e9f900d04ff6.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fac181a4-d43d-43f5-9938-10ea02cf513b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9b397865-58d5-471b-b18b-7334bc82b8f8.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=34fecc7f-e976-4e26-99e7-724f6661edd7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06638C47_0BFD_4015_976A_B02AAF0995E0_153112.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B2AA21F4_3755_4750_82B7_15DDF1FDA788_174755.pdf)

