About
[
edit
]
Eicher Motors Limited, incorporated in 1982, is the listed company of the Eicher Group in India and a leading player in the Indian automobile industry and the global leader in middleweight motorcycles.
Eicher has a joint venture with Sweden’s AB Volvo to create Volvo Eicher Commercial Vehicles Limited (VECV). VECV is engaged in truck and bus operations, auto components business, and technical consulting services business
[1]
Key Points
[
edit
]
Iconic Brand
It is the owner of the iconic Royal Enfield brand which is focused on mid-sized motorcycles (250-750 cc). Classic, Bullet, Himalayan are some of the brands that come under its Royal Enfield brand. It is sold in 60+ countries globally. It also provides protective riding apparel, urban casual wear, and Motorcycle accessories and parts.
It has launched two BS-VI Compliant Motorcycles, i.e. Classic 350 BS-VI and Himalayan BS-VI in FY20
[1]
Commercial Vehicle segment
Its VECV segment makes- light & medium-duty trucks, heavy-duty trucks and buses, engineering components, and aggregates. It is also the manufacturer of medium-duty base engines for Euro VI requirements of the Volvo Group
[2]
It has launched India’s first BS-VI compliant CV range in FY20
[3]
Manufacturing Facility
It has 3 Manufacturing Facility around Chennai.
[4]
Its VECV’s manufacturing plant in Pithampur, Madhya Pradesh produces medium-duty five- and eight-liter engines.
[5]
Its VE PowerTrain plant is the first engine plant in India to produce a Euro-6 compliant base engine
[6]
A new body shop for Pro 2000 and Pro 8000 trucks has been commissioned and installed.
[5]
Capacity expansion
Its Pithampur Plant has the capacity to produce ~90,000 trucks per annum
[5]
Its Phase 1 capacity expansion for the Bhopal plant is 40k vehicles per annum
[7]
Its VE PowerTrain plant current capacity is 50,000 engines, scalable up to 100,000 engines
[6]
Distribution
It has 1889 dealers (989 stores and 900 studio stores) across 1,550 cities. Its network has grown 3 times in the last 5 years. They are planning to add 600 stores during FY21.
[8]
It has 308 dealers, 27 distributors for its Bus Segment
[9]
It has added 35 new stores across international markets in FY19-20, increasing its overall touchpoints to over 660 stores including 77 exclusive stores and 585 multi-brand outlets.
[10]
Market Share
Mid-size Motorcycles segment: >95% in FY20
VE Commercial Vehicles market share in domestic LMD  segment: 29.5% in FY20
[11]
Above 125cc segment: 26.6% in FY20
[12]
Commercial Vehicle: 14.6% in FY20
[13]
Overall Motorcycle segment: 6%
[10]
Eicher HD Trucks Market Share: 5.1% in FY20
[13]
Revenue Mix
Domestic: 91% In FY20
International: 9.1% in FY20 which was 2.8% in FY16
[14]
Product-wise Revenue
Two-wheelers: 88% of Revenue
Spare parts and other components: 7% of Revenue
Accessories and other allied products: 5% of Revenue
[15]
R&D
It has 2 technology centers, one each at Leicestershire, UK and Chennai, India
[4]
Last edited 5 months, 3 weeks ago
Request an update
© Protected by Copyright
