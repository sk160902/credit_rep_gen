# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/jsw-steel-ltd/jswsteel/500228/corp-announcements/)
- [Announcement under Regulation 30 (LODR)-Earnings Call Transcript
17h - Transcripts of the Q1FY2025 Earnings Conference Call conducted after the Board Meeting](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5644bf7f-daa7-4e61-a7bf-68700c116acc.pdf)
- [Compliances-Reg. 39 (3) - Details of Loss of Certificate / Duplicate Certificate 21h](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=11be8be3-6fbb-4775-bfe6-c80184b0def4.pdf)
- [Announcement under Regulation 30 (LODR)-Newspaper Publication
2d - Newspaper publication of financial results for the quarter ended 30.06.2024.](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d144b324-e9a3-4466-b274-4508ff2d1134.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bd05b0-a405-47ad-8194-e191fc868815.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c38180e4-8b40-4cc1-ba12-5e013ff0c6c1.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b5fea484-29c2-448d-9799-749e51d6527a.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\1a2804ad-bc66-444b-aa4a-ea2e604971f3.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/73336500228.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/68698500228.pdf)
- [Financial Year 2020
from bse](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280312.pdf)
- [](https://archives.nseindia.com/annual_reports/AR_JSWSTEEL_2011_2012_06072012103029.zip)
- [](https://www.bseindia.com/bseplus/AnnualReport/500228/5002280311.pdf)

## Credit Ratings
- [Rating update
5 Jul from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128631)
- [Rating update
21 Jun from care](https://www.careratings.com/upload/CompanyFiles/PR/202406150658_JSW_Steel_Limited.pdf)
- [Rating update
7 Dec 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202312141221_JSW_Steel_Limited.pdf)
- [Rating update
9 Nov 2023 from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=123418)
- [Rating update
20 Oct 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202310131042_JSW_Steel_Limited.pdf)
- [](https://www.careratings.com/upload/CompanyFiles/PR/202307140740_JSW_Steel_Limited.pdf)

## Concalls
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=51bd05b0-a405-47ad-8194-e191fc868815.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q4/Results-Conference-Call-4Q-FY24.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95118ad9-e338-403a-ae11-8796a9bcb326.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q3/JSWSteel-Earnings-transcript-Q3-FY24-250124.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d2bcd9d7-fc63-42de-b619-d2f234ff72f9.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q2/JSWSteel-call-transcript-2Q-2024.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4f51f2a9-2ebc-4641-805f-d3c0eb8e4029.pdf)
- [Transcript](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2023-24/Q1/Q1-FY24-Earnings-call-transcript-Jul21-2023VF-v2.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dfa37a9a-c01b-478b-ba35-5f0092d10651.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=19a90277-2030-4455-86fa-5ca52ae6351b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=88fce2df-adec-4819-8088-0a8f0fd278b7.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dd942300-61f5-48ec-9963-72d5ff5d7544.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=53617093-909f-461c-9ab8-db0be12f843b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5f2f1279-31ed-4a41-88fa-67279b31dc1b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a92009cb-b092-4d4a-9d22-0119687a4b51.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c230e1ac-cc81-4547-9716-b94ffb48e92e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9553cea5-54cb-46ee-8e80-b3dda204cbab.pdf)
- [](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2021-22/Q1/JSW_Steel_Q1_FY22_Earnings_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=410f3a74-e00d-45be-8859-a6b108c97ef4.pdf)
- [](https://www.jswsteel.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q4/JSWSteel-Q4%20FY21%20Earnings%20call%20Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a7f1eda2-bc7e-43a6-aa24-8987cbfe1054.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q3/JSW_Steel_Q3FY21_Earnings_Call_transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7a301da2-2697-4719-96ff-a094702b2842.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q2/JSWSteel-Q2FY-21-Transcript-Oct23-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4af281fb-ed68-4ab8-b2e9-a014d26092f4.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2020-21/Q1/JSWSteel-Q1%20FY21%20results%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8cc028b8-c085-4d93-860e-be7bfad751b6.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/Q4/JSW%20Steel_Q4FY20%20Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=964fc7d8-501c-4c1b-808b-fbf4f24493c0.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q3/JSWSteel_Q3-FY20-Transcript-24Jan-2020.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8ac81e89-504c-40f3-9745-2ffefbb69b50.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q2/JSWSteel-Q2-FY-20-Earnings-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d745393b-d1c8-4ef5-9ac9-d54d846326f9.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2019-20/q1/Q1-FY2020_JSWSteel-26Jul-2019.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=14569a17-9e74-4bd8-be85-3fe9414e2aae.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q4/Transcript_Q4_19.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=7b029253-9070-425e-a9d5-e106c961eba1.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q3/JSWSteel-Q3-FY2019_Call_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3f730a25-9cbb-4c41-93bf-5a6afc736604.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q2/JSWSteel-Q2-FY-19-Earnings-Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=72e93ab4-4b4c-43d1-a794-e796963e62a6.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2018-19/Q1/Q1_FY19_Transcript_25July_2018.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=81aedef0-1789-4dbd-b4c7-cc21cc0b6aa7.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q4/Q4FY2018_Call_Transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a027f16f-0037-4f7f-8c7c-68bef962fd7e.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q3/JSW%20Steel%20Q3%20FY18%20results%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f5fde30a-97bc-452e-b2e8-b56067c14b7b.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q2/JSW%20Steel%20Q2%20FY18%20results%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=dbc7528b-a7c2-48da-8832-a7b717ca2cf3.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2017-18/Q1/JSW%20Steel%20-%201QFY18%20results%20conference%20call%20transcript.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c7f05343-3cca-4d14-afe4-ab83cb3221e8.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2016-17/Q4/JSW%20Steel%20-%204QFY17%20results%20conference%20call%20transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Corporate%20Announcement/JSW%20Steel_3QFY17%20results%20conference%20call%20transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/Transcript_JSW_Steel_-_2QFY17_Earning_Call_Transcript.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2016-17/Q1/JSW%20Steel%20-%201QFY17%20Earning%20Call%20Transcript-040816.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=E3D3A6A0_0C96_41F9_BC87_AF976D312A52_150647.pdf)
- [](https://www.jsw.in/sites/default/files/assets/industry/steel/IR/Financial%20Performance/Financials/2015-16/Q3%20Transcript%2016.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=D2AE770D_E2D2_4211_80A4_66EC8D6A465A_124112.pdf)

