# Complete Company Data

## Modal Content
About
[
edit
]
State Bank of India is a Fortune 500 company. It is an Indian Multinational, Public Sector banking and financial services statutory body headquartered in Mumbai. It is the largest and oldest bank in India with over 200 years of history.
[1]
Key Points
[
edit
]
Ratios (Q1FY24)
Capital Adequacy Ratio - 14.50%
Net Interest Margin - 3.34%
Gross NPA - 4.77%
Net NPA - 1.23%
CASA Ratio - 45.15%
[1]
Branch Network
Presently, the bank operates a network of 22,219 branches and ~62617 ATMs across India. It also operates ~71,968 business correspondent outlets across India.
[2]
Market Share
The bank has a market share of 22.84% in deposits and 19.69% share in advances in India.
It has a strong customer base of ~45 crore customers.
[3]
Loan Book
Retail loans account for 39% of the loan book, followed by corporate (37%), SME (14%) and Agriculture (10%).
[4]
Retail Book -
Home loans account for 68% of the retail book, followed by xpress credit (22%), auto loans (9%), personal gold loans (2%) and others (9%).
[5]
Exposure
The bank has a well-diversified loan book exposed to various sectors. Top sectors include home loans (23%), infrastructure (15%), services (12%) and agriculture (10%).
~75% of the corporate advances are rated A and better ratings from rating agencies.
38% of the corporate book accounts for PSUs & Govt. departments.
[6]
Segmental NPAs
Presently, the total NPAs of the bank stands at 1,17,244 crores. agriculture segment accounts for the major ratio of NPAs i.e. 13.71% of all loans are NPA. Corporate segment accounts for 59,400 crores worth of NPAs i.e. 51% of total NPAs of the bank.
[7]
International Business
The bank has a global footprint with a network of 233 branches/offices in 32 countries.
[8]
It has  presence in USA, Canada, Brazil, Russia, Germany, France, Turkey, Australia, Bangladesh, Nepal, Sri Lanka and other countries.
[9]
Presently, Overseas business accounts for 3% of total deposits
[10]
and 13% of total advances.
[4]
Government Business
SBI has always been the banker of choice to the government of India and is the market leader in government business.
It had turnover of ~52,50,000 lakh crores and commissions of ~3,700 crores from government business in FY20.
[11]
Financial Inclusion Business
The bank has ~71,000 BC outlets which has primary focus on financial inclusion customers.
[12]
The bank accounts for 40% of all PMJDY accounts i.e. more than 12 crore accounts.
[13]
Presently, the deposits from PMJDY accounts are ~42,500 crores i.e. 1.2% of total deposits of the bank.
Digital Metrics
Increasing digitization resulted in ~40% of asset accounts and ~60% of liability customers added via digital channels in FY21.
[14]
67% of all transactions were initiated through digital channels in 2020 which is up from 58% in the previous year.
[2]
Subsidiaries Operations
The bank owns various subsidiaries which are engaged in related business activities :-
1. SBI Capital Markets Ltd (100% stake) -
SBICAP is a leading investment banker, offering investment banking and corporate advisory services to clients across three product categories i.e. project advisory and structured finance, equity capital markets and debt capital markets.
This company further has wholly owned subsidiaries in related businesses viz. SBICAP Securities, SBICAP Trustee Co., SBICAP Ventures & others.
[15]
2. SBI DHFI Ltd (72% stake) -
It is a primary dealer and supports the book building process and provide depth and liquidity to secondary markets in G-Sec. It also deals in money market instruments, non G-Sec debt instruments, amongst others.
[16]
3. SBI Cards and Payment Services Ltd (69% stake) -
It is a non-banking financial company that offers extensive credit card portfolio to individual cardholders and corporate clients. It has diversified customer acquisition network that enables to engage prospective customers across multiple channels.
[16]
The IPO of SBI Cards was launched in March 2020 wherein the company sold ~13 crore equity shares for a consideration of ₹10,350 crores.
[17]
4. SBI Life Insurance Co. Ltd (57.6% stake) -
It is one of the leading life insurance company in India which offers a wide range of individual and group insurance solutions that meet various life stage needs of customers.
[17]
5. SBI Funds Management Pvt Ltd (63% stake) -
It is a JV between SBI and AMUNDI (France). It is an asset management company with the fastest CAGR of 33% as against industrial average of 14% in the last 3 years.
[18]
6. SBI General Insurance Company Ltd (70% stake) -
It is a general insurance company which focuses on profitable growth in banc-assurance channel along  with other distribution channels and line of businesses. It is first non-life insurance company in India to cross 6,000 crores in a decade of operations.
[19]
Amalgamation of Associate Banks
In March 2017, the bank acquired its 5 associate state banks and Bharatiya Mahila Bank by allotting ~13.5 crore equity shares of SBI.
[20]
Last edited 10 months, 3 weeks ago
Request an update
© Protected by Copyright

# Profit & Loss Results

## Data Before Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 167,976 | 189,062 | 207,974 | 220,633 | 230,447 | 228,970 | 253,322 | 269,852 | 278,115 | 289,973 | 350,845 | 439,189 |
| Interest | 106,818 | 121,479 | 133,179 | 143,047 | 149,115 | 146,603 | 155,867 | 161,124 | 156,010 | 156,194 | 189,981 | 259,736 |
| Expenses + | 66,283 | 82,198 | 96,675 | 109,985 | 145,666 | 169,065 | 166,104 | 172,909 | 192,821 | 197,349 | 204,303 | 239,750 |
| Financing Profit | -5,124 | -14,614 | -21,879 | -32,399 | -64,334 | -86,697 | -68,649 | -64,181 | -70,715 | -63,570 | -43,439 | -60,297 |
| Financing Margin % | -3% | -8% | -11% | -15% | -28% | -38% | -27% | -24% | -25% | -22% | -12% | -14% |
| Other Income + | 32,584 | 37,882 | 49,315 | 52,828 | 68,193 | 77,557 | 77,365 | 98,159 | 107,222 | 117,000 | 122,534 | 155,386 |
| Depreciation | 1,577 | 1,942 | 1,581 | 2,252 | 2,915 | 3,105 | 3,496 | 3,662 | 3,711 | 3,691 | 3,696 | 3,849 |
| Profit before tax | 25,882 | 21,326 | 25,855 | 18,177 | 945 | -12,245 | 5,220 | 30,317 | 32,796 | 49,739 | 75,399 | 91,240 |
| Tax % | 29% | 32% | 32% | 30% | 141% | -66% | 41% | 40% | 26% | 27% | 25% | 25% |
| Net Profit + | 18,555 | 14,807 | 17,832 | 13,019 | -97 | -3,749 | 3,351 | 21,140 | 23,888 | 37,183 | 57,750 | 69,543 |
| EPS in Rs | 26.19 | 18.99 | 22.76 | 15.75 | 0.30 | -5.11 | 2.58 | 22.15 | 25.11 | 39.64 | 62.35 | 75.17 |
| Dividend Payout % | 16% | 16% | 15% | 17% | 859% | 0% | 0% | 0% | 16% | 18% | 18% | 18% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 99% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |



## Data from "Related Party Transactions" Modal
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Transactions |  |  |  |  |  |  |  |  |  |  |
| Interest Income |  |  |  |  | 0.01 | 4.94 | 168 | 213 | 117 | 143 |
| Interest expenditure |  |  |  |  |  |  | 19 | 31 | 81 | 14,314 |
| Income earned by way of dividend |  |  |  |  |  |  | 23 | 22 | 21 | 27 |
| Other Income |  | 3.46 | 0.30 | 0.17 | 0.90 | 0.97 | 79 | 6.18 | 3.80 | 3.66 |
| Other expenditure |  |  |  |  |  |  | 2.44 | 24 | 31 | 71 |
| Profit/(loss) on sale of land/'building and other assets |  |  |  |  |  |  |  |  | 0.91 | 1.92 |
| Management contracts |  |  |  |  |  |  | 39 | 1.63 | 2.21 | 2.21 |
| Borrowings |  |  |  |  |  |  |  |  |  | 1,518 |
| Deposit | 57 | 52 | 29 | 206 | 207 | 769 | 1,543 | 1,353 | 5,271 | 6,411 |
| Other Liabilities | 87 | 75 | 55 | 120 | 0.29 | 28 | 8.27 | 15 | 69 | 105 |
| Balance with Banks and Money at call and short notice |  |  |  |  |  |  |  | 636 | 2.72 | 709 |
| Advance |  |  |  |  |  |  | 17,763 | 2,219 | 1,153 | 2,205 |
| Investment |  | 42 | 81 | 77 | 108 | 11,016 | 14,551 | 12,818 | 11,064 | 8,233 |
| Other Assets |  | 0.13 | 0.07 | 0.07 | 224 | 230 | 188 | 488 | 528 | 513 |
| Non-fund commitments (LCs/BGs) |  |  |  |  |  |  | 2,935 | 2,935 | 23 | 96 |
| Profit/(loss) on sale of land/building and other assets |  |  |  |  |  |  |  | -0.83 |  |  |
| Profit/(loss) on sale of land/ building and other assets |  |  |  |  |  |  | 4.04 |  |  |  |
| Interest Expenditure | 2.78 | 1.86 | 0.18 | 0.09 |  | 0.82 |  |  |  |  |
| Income earned by way of Dividend | 34 | 27 | 34 | 29 | 22 | 19 |  |  |  |  |
| Other Expenditure | 9.01 | 5.70 | 12 | 12 | 2.28 | 4.17 |  |  |  |  |
| Management Contract | 310 | 401 | 463 | 2.05 | 3.24 | 5.15 |  |  |  |  |
| Balances with Banks and Money at call and short notice |  |  |  |  |  | 300 |  |  |  |  |
| Investments |  | 42 | 81 |  | 108 | 11,016 |  |  |  |  |
| Advances | 0.52 | 0.37 | 0.42 | 0.62 |  | 114 |  |  |  |  |
| Payables - Deposit | 36 | 39 | 15 | 45 |  |  |  |  |  |  |
| Payables - Other Liabilities | 29 | 42 | 48 | 1.19 |  |  |  |  |  |  |
| Receivables - Investments | 42 |  |  | 68 |  |  |  |  |  |  |
| Receivables - Other Assets | 0.34 |  |  | 0.07 |  |  |  |  |  |  |
| Balance with Banks | 5.94 | 2.12 |  |  |  |  |  |  |  |  |
| Receivables - Balances with Banks | 2.12 |  |  |  |  |  |  |  |  |  |
| Receivables - Advances | 0.24 |  |  |  |  |  |  |  |  |  |

## Data After Clicking "Product Segments" Button
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Revenue | 167,976 | 189,062 | 207,974 | 220,633 | 230,447 | 228,970 | 253,322 | 269,852 | 278,115 | 289,973 | 350,845 | 439,189 |
| Interest | 106,818 | 121,479 | 133,179 | 143,047 | 149,115 | 146,603 | 155,867 | 161,124 | 156,010 | 156,194 | 189,981 | 259,736 |
| Expenses + | 66,283 | 82,198 | 96,675 | 109,985 | 145,666 | 169,065 | 166,104 | 172,909 | 192,821 | 197,349 | 204,303 | 239,750 |
| Financing Profit | -5,124 | -14,614 | -21,879 | -32,399 | -64,334 | -86,697 | -68,649 | -64,181 | -70,715 | -63,570 | -43,439 | -60,297 |
| Financing Margin % | -3% | -8% | -11% | -15% | -28% | -38% | -27% | -24% | -25% | -22% | -12% | -14% |
| Other Income + | 32,584 | 37,882 | 49,315 | 52,828 | 68,193 | 77,557 | 77,365 | 98,159 | 107,222 | 117,000 | 122,534 | 155,386 |
| Depreciation | 1,577 | 1,942 | 1,581 | 2,252 | 2,915 | 3,105 | 3,496 | 3,662 | 3,711 | 3,691 | 3,696 | 3,849 |
| Profit before tax | 25,882 | 21,326 | 25,855 | 18,177 | 945 | -12,245 | 5,220 | 30,317 | 32,796 | 49,739 | 75,399 | 91,240 |
| Tax % | 29% | 32% | 32% | 30% | 141% | -66% | 41% | 40% | 26% | 27% | 25% | 25% |
| Net Profit + | 18,555 | 14,807 | 17,832 | 13,019 | -97 | -3,749 | 3,351 | 21,140 | 23,888 | 37,183 | 57,750 | 69,543 |
| EPS in Rs | 26.19 | 18.99 | 22.76 | 15.75 | 0.30 | -5.11 | 2.58 | 22.15 | 25.11 | 39.64 | 62.35 | 75.17 |
| Dividend Payout % | 16% | 16% | 15% | 17% | 859% | 0% | 0% | 0% | 16% | 18% | 18% | 18% |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 12% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 17% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 99% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 44% |  |  |  |  |  |  |  |  |  |  |  |
| TTM: | 21% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 20% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 25% |  |  |  |  |  |  |  |  |  |  |  |
| 1 Year: | 38% |  |  |  |  |  |  |  |  |  |  |  |
| 10 Years: | 9% |  |  |  |  |  |  |  |  |  |  |  |
| 5 Years: | 13% |  |  |  |  |  |  |  |  |  |  |  |
| 3 Years: | 16% |  |  |  |  |  |  |  |  |  |  |  |
| Last Year: | 17% |  |  |  |  |  |  |  |  |  |  |  |



# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 24,332 | 19,142 | 26,297 | 14,477 | 77,406 | -96,508 | 29,556 | 23,929 | 89,919 | 57,695 | -86,014 | 21,632 |
| Cash from Investing Activity + | -2,271 | -791 | -3,424 | -2,747 | -4,572 | 13,053 | 220 | -555 | -3,670 | -2,652 | -966 | -3,476 |
| Cash from Financing Activity + | -4,424 | 3,583 | -1,553 | 4,348 | -4,196 | 5,547 | 448 | 5,430 | 7,143 | -3,845 | 6,386 | -9,896 |
| Net Cash Flow | 17,637 | 21,934 | 21,320 | 16,078 | 68,638 | -77,908 | 30,223 | 28,803 | 93,392 | 51,198 | -80,593 | 8,260 |

## Ratios Data
| Unknown | Mar 2013 | Mar 2014 | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ROE % | 16% | 10% | 11% | 7% | -0% | -2% | 1% | 7% | 9% | 12% | 17% | 17% |

# Shareholding Pattern Results

## Quarterly Data
| Unknown | Sep 2021 | Dec 2021 | Mar 2022 | Jun 2022 | Sep 2022 | Dec 2022 | Mar 2023 | Jun 2023 | Sep 2023 | Dec 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 57.62% | 57.60% | 57.59% | 57.57% | 57.52% | 57.50% | 57.49% | 57.47% | 57.49% | 57.49% | 57.54% | 57.54% |
| FIIs + | 10.55% | 10.37% | 9.97% | 9.62% | 9.95% | 10.09% | 9.89% | 10.36% | 10.72% | 10.91% | 11.09% | 11.15% |
| DIIs + | 24.17% | 24.10% | 24.66% | 25.09% | 25.39% | 25.36% | 25.20% | 24.83% | 24.36% | 24.15% | 23.96% | 23.61% |
| Government + | 0.15% | 0.15% | 0.15% | 0.15% | 0.03% | 0.03% | 0.03% | 0.03% | 0.03% | 0.03% | 0.03% | 0.03% |
| Public + | 7.51% | 7.78% | 7.63% | 7.58% | 7.10% | 7.03% | 7.40% | 7.30% | 7.41% | 7.40% | 7.37% | 7.67% |
| No. of Shareholders | 26,40,152 | 29,18,312 | 29,82,372 | 30,52,751 | 28,37,266 | 27,97,196 | 29,93,298 | 29,48,536 | 30,29,116 | 30,47,685 | 31,50,350 | 36,13,127 |

## Yearly Data
| Unknown | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 | Jun 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Promoters + | 62.22% | 58.86% | 57.92% | 57.63% | 57.63% | 57.59% | 57.49% | 57.54% | 57.54% |
| FIIs + | 9.48% | 11.16% | 9.87% | 9.59% | 9.94% | 9.97% | 9.89% | 11.09% | 11.15% |
| DIIs + | 18.75% | 22.26% | 24.48% | 24.55% | 24.40% | 24.66% | 25.20% | 23.96% | 23.61% |
| Government + | 0.04% | 0.03% | 0.05% | 0.11% | 0.20% | 0.15% | 0.03% | 0.03% | 0.03% |
| Public + | 9.51% | 7.68% | 7.68% | 8.12% | 7.83% | 7.63% | 7.40% | 7.37% | 7.67% |
| No. of Shareholders | 15,18,711 | 15,73,070 | 14,55,377 | 24,46,100 | 26,86,848 | 29,82,372 | 29,93,298 | 31,50,350 | 36,13,127 |

# Documents Section Results

## Announcements
- [All](https://www.bseindia.com/stock-share-price/state-bank-of-india/sbin/500112/corp-announcements/)
- [Signing Of Non-Binding Mou With FCDO 1d](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c94cc8c0-d64b-4392-a4b5-3762dc400c40.pdf)
- [Announcement under Regulation 30 (LODR)-Analyst / Investor Meet - Intimation 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f880f8fd-b1d3-4cae-852d-39b9df3c6fba.pdf)
- [Board Meeting Intimation for Financial Results For The Quarter Ended 30.06.2024 22 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=6d100feb-650a-44bf-983c-5a9eb3875b79.pdf)
- [GRI Certified Sustainability Report FY 2023-24 20 Jul](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=8961d534-00fe-433d-9035-99540825c310.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=06d1c5f0-fa3d-4ef6-8f69-8b4c9ca837c3.pdf)

## Annual Reports
- [Financial Year 2024
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0e236470-9427-43c7-93e9-c8eb61bb1f72.pdf)
- [Financial Year 2023
from bse](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=\22d33d1d-af2a-4d2d-98c0-eff16cd73cb5.pdf)
- [Financial Year 2022
from bse](https://www.bseindia.com/bseplus/AnnualReport/500112/73059500112.pdf)
- [Financial Year 2021
from bse](https://www.bseindia.com/bseplus/AnnualReport/500112/68518500112.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120320.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120319.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120318.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120317.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120316.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120315.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120314.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120313.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120312.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120311.pdf)
- [](https://www.bseindia.com/bseplus/AnnualReport/500112/5001120310.pdf)
- [RIGHT ISSUE](https://www.sebi.gov.in/filings/rights-issues/feb-2008/state-bank-of-india-fast-track-issue_6259.html)

## Credit Ratings
- [Rating update
5 Jul from crisil](https://www.crisil.com/mnt/winshare/Ratings/RatingList/RatingDocs/StateBankofIndia_July%2005_%202024_RR_348098.html)
- [Rating update
5 Jul from care](https://www.careratings.com/upload/CompanyFiles/PR/202407150707_State_Bank_of_India.pdf)
- [Rating update
21 Jun from fitch](https://www.indiaratings.co.in/pressrelease/70546)
- [Rating update
21 Jun from icra](https://www.icra.in/Rationale/ShowRationaleReport/?Id=128229)
- [Rating update
6 Nov 2023 from care](https://www.careratings.com/upload/CompanyFiles/PR/202311121133_State_Bank_of_India.pdf)
- [](https://www.indiaratings.co.in/pressrelease/66783)

## Concalls
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=68b86c74-1a02-41cf-9daf-d040d60cd34d.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d7eaa420-b619-4865-b196-519921e57cbc.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=595ee5f3-1722-4ee7-974e-6b537cb498ad.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=0de1b244-29ba-40d3-8de7-aa64249297d7.pdf)
- [REC](https://sbi.co.in/documents/17836/41362884/030224-SBI+Analyst+Meet_3rd_Feb_24.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=1a58f0d8-f71e-4d4d-8dab-6e3e21d65281.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=501d3fc4-a24b-48ee-815a-87c711a08e9e.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d1a1746d-fa6e-48c4-bbab-c5b2e05ec4e7.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2698e2ad-5bf3-42e4-9ce0-15ea315461da.pdf)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c0592b75-f3d7-4e58-b582-060c9cff3bda.pdf)
- [PPT](https://www.sbi.co.in/documents/17836/1275616/180523-SBI+Analyst+Presentation+Q4FY23.pdf/254aa07d-32bc-37c0-048d-c6666d1e1619?t=1684399592252)
- [REC](https://sbi.co.in/documents/17836/30252825/180523-SBI_AnalystMeet+Audio+Recording_18.05.2023.mp3)
- [Transcript](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=98f6f60a-be7b-47bd-b961-71e79984bd2c.pdf)
- [PPT](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c433f9bf-fb1a-4d77-a804-c9908bdc8f25.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=d4197c79-9542-46a6-8389-eab7b17f0b9d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=65e56f27-ce21-495d-91f2-9db0baa3cea3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a89aeb98-b09e-4199-8993-da23e76f118f.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_13052022134116_BSENSEPRAnalystPPTMarch202213052022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=9a7dbf75-41cf-4806-b4a7-ae3a976c42fd.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_05022022134234_BSENSEAnalystPresentationDec202105022022.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4fd42357-9d95-4e4c-b5d7-4e169643b94c.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b52b4b6e-71cf-494d-893b-be3b2554c608.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=23225b11-e337-4259-9751-569175a984ad.pdf)
- [](https://sbi.co.in/documents/17836/4840865/02082020_SBI+Q1FY21+ANALYST+CONFERENCE+CALL+TRANSCRIPT.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=5eac345a-7d35-4966-9803-a5085bc0a0da.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c96c47e9-4664-4e89-bb47-a6ede7fe014e.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=38d64302-c438-4e34-b1a1-9f23f485cd59.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a76d3e75-5933-4d0d-b126-b0e86f1afee9.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=fa1bb923-f000-4f8e-ab4c-807d8da063cb.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=36efc9c3-a3b0-4a4c-bcc4-ae975db87cca.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=a1290736-7b9a-40b8-b458-43d6fc5098b3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=b2142dd5-5684-4074-b7fb-8e69c0197ec1.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4b2f1f50-a691-49ac-8cc7-c6a84ae95a7b.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=4075b384-c809-4c23-806f-450cfc827674.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=121b5497-6d06-43dc-8c97-2e9be85833a3.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=db2b5d52-5628-41c1-ba88-7b014a999ff2.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=f2783451-2853-442c-831d-c8c8788a01fc.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=c9a219a8-e851-4368-819b-6a4cbc1a425d.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=95659481-cfcf-46c8-a820-b868ebe0d855.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=2EF979D4_937A_4020_9E9B_E41807ACD41B_160702.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=B1C5608A_FE04_4F34_AE03_A6777062FA78_165011.pdf)
- [](https://www.bseindia.com/stockinfo/AnnPdfOpen.aspx?Pname=3754D016_CCCE_4034_8C4D_A38777A79E58_142755.pdf)
- [](https://archives.nseindia.com/corporate/SBIN_03112021135346_BSENSEAnalystAnnounce03112021.pdf)

# Peer Comparison Results

| S.No. | Name | CMP | Rs. | Mar | Cap | Rs.Cr. | P/E | CMP | / | BV | CMP | / | Sales | CMP | / | FCF | EV | / | EBITDA | 5Yrs | return | % | Div | Yld | % | ROCE | % | ROA | 12M | % | ROE | % | Asset | Turnover | Debt | / | Eq | Int | Coverage | Leverage | Rs. | Sales | Rs.Cr. | OPM | % | PAT | 12M | Rs.Cr. | Sales | Qtr | Rs.Cr. | PAT | Qtr | Rs.Cr. | Qtr | Sales | Var | % | Qtr | Profit | Var | % | EPS | 12M | Rs. | Debt | Rs.Cr. | Prom. | Hold. | % | Change | in | Prom | Hold | % | Earnings | Yield | % | Ind | PE | Pledged | % | Sales | growth | % | Profit | growth | % | EV | Rs.Cr. | Current | ratio | PEG | 3mth | return | % | 6mth | return | % | 3Yrs | return | % | 1Yr | return | % | ROE | 3Yr | % | ROE | 5Yr | % | Profit | Var | 5Yrs | % | Profit | Var | 3Yrs | % | Sales | Var | 5Yrs | % | Sales | Var | 3Yrs | % | ROE | Prev | Ann | % | ROCE | Prev | Yr | % | Quick | Rat | EPS | Ann | Rs. | EPS | Var | 5Yrs | % | 5Yrs | PE | 3Yrs | PE | 7Yrs | PE | Cash | Cycle | No. | Eq. | Shares | PY | Cr. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1. | St Bk of India | 864.30 | 771354.17 | 11.56 | 1.83 | 1.76 | -237.65 | 17.05 | 19.89 | 1.60 | 6.16 | 1.10 | 17.34 | 0.07 | 13.51 | 1.35 | 15.29 | 439188.51 | 45.41 | 67102.23 | 117469.38 | 21384.15 | 19.77 | 18.18 | 75.17 | 5606146.99 | 57.54 | 0.00 | 5.81 | 9.46 | 0.00 | 25.18 | 20.54 | 6050928.86 | 2.56 | 0.12 | 5.89 | 38.47 | 25.43 | 37.62 | 15.66 | 13.00 | 98.73 | 44.11 | 11.63 | 16.45 | 16.75 | 5.20 | 2.56 | 75.17 | 98.73 | 11.87 | 11.24 | 12.24 | 0.00 | 892.46 |
| 2. | Punjab Natl.Bank | 120.00 | 132132.23 | 14.53 | 1.18 | 1.21 | 31.83 | 17.38 | 11.60 | 1.26 | 5.46 | 0.59 | 8.54 | 0.07 | 13.15 | 1.21 | 14.01 | 109064.58 | 63.67 | 9102.91 | 28682.32 | 3342.20 | 18.01 | 79.27 | 8.27 | 1451810.86 | 73.15 | 0.00 | 5.70 | 9.46 | 0.00 | 25.58 | 171.99 | 1452542.90 | 4.88 | 0.60 | -13.73 | 12.65 | 44.34 | 88.65 | 5.40 | 4.44 | 24.17 | 52.35 | 15.90 | 10.00 | 3.34 | 4.10 | 4.88 | 8.27 | 19.11 | 16.71 | 15.21 | 17.41 | 0.00 | 1101.10 |
| 3. | Bank of Baroda | 250.40 | 129490.90 | 6.93 | 1.05 | 1.09 | -14.67 | 15.23 | 16.87 | 3.05 | 6.33 | 1.19 | 16.69 | 0.07 | 12.14 | 1.37 | 13.28 | 118379.22 | 62.51 | 18761.10 | 31072.17 | 5132.45 | 14.25 | -2.34 | 36.29 | 1453760.94 | 63.97 | 0.00 | 6.46 | 9.46 | 0.00 | 25.27 | 25.99 | 1482961.99 | 1.80 | 0.09 | -8.47 | 8.06 | 45.29 | 23.14 | 13.93 | 9.87 | 76.82 | 144.18 | 17.48 | 16.79 | 15.12 | 5.17 | 1.80 | 36.29 | 54.63 | 9.77 | 7.51 | 11.53 | 0.00 | 517.14 |
| 4. | I O B | 67.62 | 127818.20 | 45.85 | 4.54 | 5.08 | -31.53 | 22.57 | 41.94 | 0.00 | 5.41 | 0.80 | 9.98 | 0.07 | 11.32 | 1.24 | 11.91 | 25160.45 | 51.55 | 2788.05 | 6535.03 | 632.81 | 20.48 | 26.47 | 1.47 | 316292.55 | 96.38 | 0.00 | 4.47 | 9.46 | 0.00 | 23.40 | 26.33 | 425556.33 | 4.53 | 2.09 | -1.62 | 43.54 | 38.91 | 148.75 | 9.14 | -1.20 | 21.90 | 47.32 | 6.41 | 12.33 | 8.69 | 4.53 | 4.53 | 1.40 | 18.48 | 30.14 | 28.32 | 30.14 | 0.00 | 1890.24 |
| 5. | Canara Bank | 114.20 | 103586.85 | 6.63 | 1.11 | 0.91 | -11.64 | 13.80 | 18.41 | 2.85 | 6.63 | 1.06 | 17.94 | 0.08 | 14.87 | 1.27 | 15.83 | 114240.94 | 57.92 | 15607.15 | 29172.97 | 4067.51 | 14.63 | 8.79 | 17.21 | 1369780.03 | 62.93 | 0.00 | 7.26 | 9.46 | 0.00 | 23.11 | 21.80 | 1322202.19 | 2.58 | 0.07 | -9.42 | 20.23 | 55.50 | 62.25 | 14.35 | 10.51 | 90.75 | 74.70 | 18.18 | 16.30 | 14.79 | 5.33 | 2.58 | 16.84 | 60.00 | 6.81 | 6.03 | 7.34 | 0.00 | 907.07 |
| 6. | Union Bank (I) | 133.00 | 101526.95 | 7.19 | 1.02 | 0.98 | 5.23 | 14.18 | 13.48 | 2.70 | 6.55 | 1.03 | 15.64 | 0.07 | 12.82 | 1.32 | 13.78 | 103289.30 | 66.40 | 14167.24 | 26526.92 | 3641.78 | 12.34 | 11.31 | 18.84 | 1251567.63 | 74.76 | 0.00 | 7.06 | 9.46 | 0.00 | 19.38 | 38.89 | 1233448.73 | 3.24 | 0.16 | -12.50 | -5.93 | 54.29 | 43.36 | 11.95 | 8.79 | 46.36 | 69.30 | 23.95 | 13.14 | 11.38 | 5.02 | 3.24 | 18.07 | 25.31 | 6.84 | 6.43 | 7.50 | 0.00 | 683.47 |
| 7. | Indian Bank | 581.25 | 78292.37 | 9.29 | 1.32 | 1.41 | -26.11 | 17.02 | 21.67 | 2.05 | 5.92 | 1.12 | 15.35 | 0.07 | 11.80 | 1.34 | 12.52 | 55649.73 | 63.45 | 8421.32 | 14633.41 | 2295.61 | 19.41 | 51.06 | 62.51 | 711095.95 | 73.84 | 0.00 | 5.82 | 9.46 | 0.00 | 23.71 | 51.13 | 747211.41 | 2.18 | 0.11 | 7.81 | 23.24 | 60.52 | 72.80 | 12.56 | 11.26 | 85.67 | 38.80 | 23.74 | 12.48 | 11.80 | 4.55 | 2.18 | 62.51 | 51.07 | 6.77 | 6.93 | 7.97 | 0.00 | 124.54 |

# Quick Ratios

| Ticker | Label | Value |
| --- | --- | --- |
| SBIN | Market Cap | ₹ 7,70,863 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | Sales | ₹ 4,39,189 Cr. |
| SBIN | OPM | 45.4 % |
| SBIN | Profit after tax | ₹ 67,102 Cr. |
| SBIN | Mar Cap | ₹ 7,70,863 Cr. |
| SBIN | Sales Qtr | ₹ 1,17,469 Cr. |
| SBIN | PAT Qtr | ₹ 21,384 Cr. |
| SBIN | Qtr Sales Var | 19.8 % |
| SBIN | Qtr Profit Var | 18.2 % |
| SBIN | Price to Earning | 11.6 |
| SBIN | Dividend yield | 1.60 % |
| SBIN | Price to book value | 1.83 |
| SBIN | ROCE | 6.16 % |
| SBIN | Return on assets | 1.10 % |
| SBIN | Debt to equity | 13.5 |
| SBIN | Return on equity | 17.3 % |
| SBIN | EPS | ₹ 75.2 |
| SBIN | Debt | ₹ 56,06,147 Cr. |
| SBIN | Promoter holding | 57.5 % |
| SBIN | Change in Prom Hold | 0.00 % |
| SBIN | Earnings yield | 5.81 % |
| SBIN | Pledged percentage | 0.00 % |
| SBIN | Industry PE | 9.46 |
| SBIN | Sales growth | 25.2 % |
| SBIN | Profit growth | 20.5 % |
| SBIN | Current Price | ₹ 864 |
| SBIN | Price to Sales | 1.76 |
| SBIN | CMP / FCF | -238 |
| SBIN | EVEBITDA | 17.0 |
| SBIN | Enterprise Value | ₹ 60,50,438 Cr. |
| SBIN | Current ratio | 2.56 |
| SBIN | Int Coverage | 1.35 |
| SBIN | PEG Ratio | 0.12 |
| SBIN | Return over 3months | 5.89 % |
| SBIN | Return over 6months | 38.5 % |
| SBIN | No. Eq. Shares | 892 |
| SBIN | Sales growth 3Years | 16.4 % |
| SBIN | Sales growth 5Years | 11.6 % |
| SBIN | Profit Var 3Yrs | 44.1 % |
| SBIN | Profit Var 5Yrs | 98.7 % |
| SBIN | ROE 5Yr | 13.0 % |
| SBIN | ROE 3Yr | 15.7 % |
| SBIN | Return over 1year | 37.6 % |
| SBIN | Return over 3years | 25.4 % |
| SBIN | Return over 5years | 19.9 % |
| SBIN | Market Cap | ₹ 7,70,863 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | Sales last year | ₹ 4,39,189 Cr. |
| SBIN | OP Ann | ₹ 1,99,439 Cr. |
| SBIN | Other Inc Ann | ₹ 1,55,386 Cr. |
| SBIN | EBIDT last year | ₹ 3,54,850 Cr. |
| SBIN | Dep Ann | ₹ 3,849 Cr. |
| SBIN | EBIT last year | ₹ 3,51,001 Cr. |
| SBIN | Interest last year | ₹ 2,59,736 Cr. |
| SBIN | PBT Ann | ₹ 91,240 Cr. |
| SBIN | Tax last year | ₹ 23,102 Cr. |
| SBIN | PAT Ann | ₹ 67,102 Cr. |
| SBIN | Extra Ord Item Ann | ₹ -25.2 Cr. |
| SBIN | NP Ann | ₹ 69,543 Cr. |
| SBIN | Dividend last year | ₹ 12,227 Cr. |
| SBIN | Raw Material | 0.00 % |
| SBIN | Employee cost | ₹ 83,687 Cr. |
| SBIN | OPM last year | 45.4 % |
| SBIN | NPM last year | 15.8 % |
| SBIN | Operating profit | ₹ 1,99,439 Cr. |
| SBIN | Interest | ₹ 2,59,736 Cr. |
| SBIN | Depreciation | ₹ 3,849 Cr. |
| SBIN | EPS last year | ₹ 75.2 |
| SBIN | EBIT | ₹ 3,51,001 Cr. |
| SBIN | Net profit | ₹ 69,543 Cr. |
| SBIN | Current Tax | ₹ 25,371 Cr. |
| SBIN | Tax | ₹ 23,102 Cr. |
| SBIN | Other income | ₹ 1,55,386 Cr. |
| SBIN | Ann Date | 2,02,403 |
| SBIN | Sales Prev Ann | ₹ 3,50,845 Cr. |
| SBIN | OP Prev Ann | ₹ 1,46,541 Cr. |
| SBIN | Other Inc Prev Ann | ₹ 1,22,534 Cr. |
| SBIN | EBIDT Prev Ann | ₹ 2,69,104 Cr. |
| SBIN | Dep Prev Ann | ₹ 3,696 Cr. |
| SBIN | EBIT preceding year | ₹ 2,65,408 Cr. |
| SBIN | Interest Prev Ann | ₹ 1,89,981 Cr. |
| SBIN | PBT Prev Ann | ₹ 75,399 Cr. |
| SBIN | Tax preceding year | ₹ 18,840 Cr. |
| SBIN | PAT Prev Ann | ₹ 55,668 Cr. |
| SBIN | Extra Ord Prev Ann | ₹ -29.0 Cr. |
| SBIN | NP Prev Ann | ₹ 57,750 Cr. |
| SBIN | Dividend Prev Ann | ₹ 10,085 Cr. |
| SBIN | OPM preceding year | 41.8 % |
| SBIN | NPM preceding year | 16.5 % |
| SBIN | EPS preceding year | ₹ 62.4 |
| SBIN | Sales Prev 12M | ₹ 4,19,802 Cr. |
| SBIN | Profit Prev 12M | ₹ 66,109 Cr. |
| SBIN | Med Sales Gwth 10Yrs | 6.09 % |
| SBIN | Med Sales Gwth 5Yrs | 6.53 % |
| SBIN | Sales growth 7Years | 9.65 % |
| SBIN | Sales Var 10Yrs | 8.79 % |
| SBIN | EBIDT growth 3Years | 22.6 % |
| SBIN | EBIDT growth 5Years | 16.7 % |
| SBIN | EBIDT growth 7Years | 12.8 % |
| SBIN | EBIDT Var 10Yrs | 9.38 % |
| SBIN | EPS growth 3Years | 44.1 % |
| SBIN | EPS growth 5Years | 98.7 % |
| SBIN | EPS growth 7Years | 113 % |
| SBIN | EPS growth 10Years | 14.7 % |
| SBIN | Profit Var 7Yrs | 116 % |
| SBIN | Profit Var 10Yrs | 16.8 % |
| SBIN | Chg in Prom Hold 3Yr | -0.08 % |
| SBIN | Market Cap | ₹ 7,70,863 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | OP Qtr | ₹ 52,051 Cr. |
| SBIN | Other Inc Qtr | ₹ 47,445 Cr. |
| SBIN | EBIDT Qtr | ₹ 99,496 Cr. |
| SBIN | Dep Qtr | ₹ 0.00 Cr. |
| SBIN | EBIT latest quarter | ₹ 99,496 Cr. |
| SBIN | Interest Qtr | ₹ 70,644 Cr. |
| SBIN | PBT Qtr | ₹ 28,852 Cr. |
| SBIN | Tax latest quarter | ₹ 7,115 Cr. |
| SBIN | Extra Ord Item Qtr | ₹ 0.00 Cr. |
| SBIN | NP Qtr | ₹ 22,203 Cr. |
| SBIN | GPM latest quarter | 100 % |
| SBIN | OPM latest quarter | 44.3 % |
| SBIN | NPM latest quarter | 18.9 % |
| SBIN | Eq Cap Qtr | ₹ 892 Cr. |
| SBIN | EPS latest quarter | ₹ 24.0 |
| SBIN | OP 2Qtr Bk | ₹ 48,026 Cr. |
| SBIN | OP 3Qtr Bk | ₹ 52,380 Cr. |
| SBIN | Sales 2Qtr Bk | ₹ 1,07,391 Cr. |
| SBIN | Sales 3Qtr Bk | ₹ 1,01,460 Cr. |
| SBIN | NP 2Qtr Bk | ₹ 16,648 Cr. |
| SBIN | NP 3Qtr Bk | ₹ 19,094 Cr. |
| SBIN | Opert Prft Gwth | 36.1 % |
| SBIN | Last result date | 2,02,403 |
| SBIN | Exp Qtr Sales Var | 25.4 % |
| SBIN | Exp Qtr Sales | ₹ 1,27,175 Cr. |
| SBIN | Exp Qtr OP | ₹ 61,132 Cr. |
| SBIN | Exp Qtr NP | ₹ -9,488 Cr. |
| SBIN | Exp Qtr EPS | ₹ -10.2 |
| SBIN | Sales Prev Qtr | ₹ 1,12,868 Cr. |
| SBIN | OP Prev Qtr | ₹ 50,233 Cr. |
| SBIN | Other Inc Prev Qtr | ₹ 33,103 Cr. |
| SBIN | EBIDT Prev Qtr | ₹ 90,437 Cr. |
| SBIN | Dep Prev Qtr | ₹ 0.00 Cr. |
| SBIN | EBIT Prev Qtr | ₹ 90,437 Cr. |
| SBIN | Interest Prev Qtr | ₹ 68,092 Cr. |
| SBIN | PBT Prev Qtr | ₹ 15,245 Cr. |
| SBIN | Tax Prev Qtr | ₹ 3,962 Cr. |
| SBIN | PAT Prev Qtr | ₹ 16,077 Cr. |
| SBIN | Extra Ord Prev Qtr | ₹ -7,100 Cr. |
| SBIN | NP Prev Qtr | ₹ 11,598 Cr. |
| SBIN | OPM Prev Qtr | 44.5 % |
| SBIN | NPM Prev Qtr | 14.9 % |
| SBIN | Eq Cap Prev Qtr | ₹ Cr. |
| SBIN | EPS Prev Qtr | ₹ 12.4 |
| SBIN | Sales PY Qtr | ₹ 98,083 Cr. |
| SBIN | OP PY Qtr | ₹ 38,118 Cr. |
| SBIN | Other Inc PY Qtr | ₹ 38,769 Cr. |
| SBIN | EBIDT PY Qtr | ₹ 76,887 Cr. |
| SBIN | Dep PY Qtr | ₹ 0.00 Cr. |
| SBIN | EBIT PY Qtr | ₹ 76,887 Cr. |
| SBIN | Interest PY Qtr | ₹ 53,451 Cr. |
| SBIN | PBT PY Qtr | ₹ 23,436 Cr. |
| SBIN | Tax PY Qtr | ₹ 5,092 Cr. |
| SBIN | Market Cap | ₹ 7,70,863 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | Equity capital | ₹ 892 Cr. |
| SBIN | Preference capital | ₹ 0.00 Cr. |
| SBIN | Reserves | ₹ 4,14,047 Cr. |
| SBIN | Secured loan | ₹ 6,39,610 Cr. |
| SBIN | Unsecured loan | ₹ 49,66,537 Cr. |
| SBIN | Balance sheet total | ₹ 67,33,756 Cr. |
| SBIN | Gross block | ₹ 85,555 Cr. |
| SBIN | Revaluation reserve | ₹ 27,556 Cr. |
| SBIN | Accum Dep | ₹ 39,484 Cr. |
| SBIN | Net block | ₹ 46,072 Cr. |
| SBIN | CWIP | ₹ 42.4 Cr. |
| SBIN | Investments | ₹ 21,10,548 Cr. |
| SBIN | Current assets | ₹ 7,80,703 Cr. |
| SBIN | Current liabilities | ₹ 3,04,771 Cr. |
| SBIN | BV Unq Invest | ₹ 32,756 Cr. |
| SBIN | MV Quoted Inv | ₹ 0.00 Cr. |
| SBIN | Cont Liab | ₹ 24,65,418 Cr. |
| SBIN | Total Assets | ₹ 67,33,756 Cr. |
| SBIN | Working capital | ₹ 4,75,932 Cr. |
| SBIN | Lease liabilities | ₹ 0.00 Cr. |
| SBIN | Inventory | ₹ 0.00 Cr. |
| SBIN | Trade receivables | ₹ 0.00 Cr. |
| SBIN | Face value | ₹ 1.00 |
| SBIN | Cash Equivalents | ₹ 3,26,572 Cr. |
| SBIN | Adv Cust | ₹ 0.00 Cr. |
| SBIN | Trade Payables | ₹ 15,700 Cr. |
| SBIN | No. Eq. Shares PY | 892 |
| SBIN | Debt preceding year | ₹ 49,89,687 Cr. |
| SBIN | Work Cap PY | ₹ 4,31,810 Cr. |
| SBIN | Net Block PY | ₹ 45,880 Cr. |
| SBIN | Gross Block PY | ₹ 82,485 Cr. |
| SBIN | CWIP PY | ₹ 66.0 Cr. |
| SBIN | Work Cap 3Yr | ₹ 5,08,686 Cr. |
| SBIN | Work Cap 5Yr | ₹ 3,37,111 Cr. |
| SBIN | Work Cap 7Yr | ₹ 2,79,033 Cr. |
| SBIN | Work Cap 10Yr | ₹ 49,627 Cr. |
| SBIN | Debt 3Years back | ₹ 41,49,127 Cr. |
| SBIN | Debt 5Years back | ₹ 33,54,289 Cr. |
| SBIN | Debt 7Years back | ₹ 29,36,176 Cr. |
| SBIN | Debt 10Years back | ₹ 20,62,612 Cr. |
| SBIN | Net Block 3Yrs Back | ₹ 41,600 Cr. |
| SBIN | Net Block 5Yrs Back | ₹ 39,941 Cr. |
| SBIN | Net Block 7Yrs Back | ₹ 51,189 Cr. |
| SBIN | Market Cap | ₹ 7,70,953 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | CF Operations | ₹ 21,632 Cr. |
| SBIN | Free Cash Flow | ₹ 21,632 Cr. |
| SBIN | CF Investing | ₹ -3,476 Cr. |
| SBIN | CF Financing | ₹ -9,896 Cr. |
| SBIN | Net CF | ₹ 8,260 Cr. |
| SBIN | Cash Beginning | ₹ 3,18,312 Cr. |
| SBIN | Cash End | ₹ 3,26,572 Cr. |
| SBIN | FCF Prev Ann | ₹ -86,014 Cr. |
| SBIN | CF Operations PY | ₹ -86,014 Cr. |
| SBIN | CF Investing PY | ₹ -966 Cr. |
| SBIN | CF Financing PY | ₹ 6,386 Cr. |
| SBIN | Net CF PY | ₹ -80,593 Cr. |
| SBIN | Cash Beginning PY | ₹ 3,98,905 Cr. |
| SBIN | Cash End PY | ₹ 3,18,312 Cr. |
| SBIN | Free Cash Flow 3Yrs | ₹ -9,737 Cr. |
| SBIN | Free Cash Flow 5Yrs | ₹ 97,217 Cr. |
| SBIN | Free Cash Flow 7Yrs | ₹ 33,862 Cr. |
| SBIN | Free Cash Flow 10Yrs | ₹ 1,40,393 Cr. |
| SBIN | CF Opr 3Yrs | ₹ -6,686 Cr. |
| SBIN | CF Opr 5Yrs | ₹ 1,07,161 Cr. |
| SBIN | CF Opr 7Yrs | ₹ 40,209 Cr. |
| SBIN | CF Opr 10Yrs | ₹ 1,58,389 Cr. |
| SBIN | CF Inv 10Yrs | ₹ -8,790 Cr. |
| SBIN | CF Inv 7Yrs | ₹ 1,953 Cr. |
| SBIN | CF Inv 5Yrs | ₹ -11,319 Cr. |
| SBIN | CF Inv 3Yrs | ₹ -7,094 Cr. |
| SBIN | Cash 3Years back | ₹ 3,47,707 Cr. |
| SBIN | Cash 5Years back | ₹ 2,25,512 Cr. |
| SBIN | Cash 7Years back | ₹ 2,73,197 Cr. |
| SBIN | Market Cap | ₹ 7,70,953 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | No. Eq. Shares | 892 |
| SBIN | Book value | ₹ 465 |
| SBIN | Inven TO |  |
| SBIN | Quick ratio | 2.56 |
| SBIN | Exports percentage | 0.00 % |
| SBIN | Piotroski score | 8.00 |
| SBIN | G Factor | 7.00 |
| SBIN | Asset Turnover | 0.07 |
| SBIN | Financial leverage | 15.3 |
| SBIN | No. of Share Holders | 36,13,127 |
| SBIN | Unpledged Prom Hold | 57.5 % |
| SBIN | ROIC | 6.16 % |
| SBIN | Debtor days | 0.00 |
| SBIN | Industry PBV | 1.03 |
| SBIN | Credit rating |  |
| SBIN | WC Days | 124 |
| SBIN | Earning Power | 5.21 % |
| SBIN | Graham Number | ₹ 887 |
| SBIN | Cash Cycle | 0.00 |
| SBIN | Days Payable |  |
| SBIN | Days Receivable | 0.00 |
| SBIN | Inventory Days |  |
| SBIN | Public holding | 7.67 % |
| SBIN | FII holding | 11.2 % |
| SBIN | Chg in FII Hold | 0.06 % |
| SBIN | DII holding | 23.6 % |
| SBIN | Chg in DII Hold | -0.35 % |
| SBIN | B.V. Prev Ann | ₹ 402 |
| SBIN | ROCE Prev Yr | 5.20 % |
| SBIN | ROA Prev Yr | 1.02 % |
| SBIN | ROE Prev Ann | 16.8 % |
| SBIN | No. of Share Holders Prev Qtr | 31,50,350 |
| SBIN | No. Eq. Shares 10 Yrs | 747 |
| SBIN | BV 3yrs back | ₹ 309 |
| SBIN | BV 5yrs back | ₹ 281 |
| SBIN | BV 10yrs back | ₹ 216 |
| SBIN | Inven TO 3Yr |  |
| SBIN | Inven TO 5Yr |  |
| SBIN | Inven TO 7Yr |  |
| SBIN | Inven TO 10Yr |  |
| SBIN | Export 3Yr | 0.00 % |
| SBIN | Export 5Yr | 0.00 % |
| SBIN | Div 5Yrs | ₹ 6,444 Cr. |
| SBIN | ROCE 3Yr | 5.26 % |
| SBIN | ROCE 5Yr | 5.06 % |
| SBIN | ROCE 7Yr | 4.87 % |
| SBIN | ROCE 10Yr | 5.21 % |
| SBIN | ROE 10Yr | 8.99 % |
| SBIN | ROE 7Yr | 9.91 % |
| SBIN | ROE 5Yr Var | 79.5 % |
| SBIN | OPM 5Year | 38.1 % |
| SBIN | OPM 10Year | 38.8 % |
| SBIN | No. of Share Holders 1Yr | 29,48,536 |
| SBIN | Avg Div Payout 3Yrs | 18.1 % |
| SBIN | Debtor days 3yrs | 0.00 |
| SBIN | Debtor days 3yrs back | 0.00 |
| SBIN | Debtor days 5yrs back | 0.00 |
| SBIN | ROA 5Yr | 0.76 % |
| SBIN | ROA 3Yr | 0.95 % |
| SBIN | Market Cap | ₹ 7,70,953 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | Avg Vol 1Mth | 1,76,25,920 |
| SBIN | Avg Vol 1Wk | 1,63,79,408 |
| SBIN | Volume | 1,00,12,960 |
| SBIN | High price | ₹ 912 |
| SBIN | Low price | ₹ 543 |
| SBIN | High price all time | ₹ 912 |
| SBIN | Low price all time | ₹ 54.2 |
| SBIN | Return over 1day | 1.81 % |
| SBIN | Return over 1week | -4.59 % |
| SBIN | Return over 1month | 0.37 % |
| SBIN | DMA 50 | ₹ 840 |
| SBIN | DMA 200 | ₹ 743 |
| SBIN | DMA 50 previous day | ₹ 840 |
| SBIN | 200 DMA prev. | ₹ 742 |
| SBIN | RSI | 47.3 |
| SBIN | MACD | 7.69 |
| SBIN | MACD Previous Day | 9.82 |
| SBIN | MACD Signal | 10.1 |
| SBIN | MACD Signal Prev | 10.8 |
| SBIN | Avg Vol 1Yr | 1,93,01,477 |
| SBIN | Return over 7years | 16.1 % |
| SBIN | Return over 10years | 13.0 % |
| SBIN | Market Cap | ₹ 7,70,953 Cr. |
| SBIN | Current Price | ₹ 864 |
| SBIN | High / Low | ₹ 912 / 543 |
| SBIN | Stock P/E | 11.6 |
| SBIN | Book Value | ₹ 465 |
| SBIN | Dividend Yield | 1.60 % |
| SBIN | ROCE | 6.16 % |
| SBIN | ROE | 17.3 % |
| SBIN | Face Value | ₹ 1.00 |
| SBIN | WC to Sales | 108 % |
| SBIN | QoQ Profits | 91.4 % |
| SBIN | QoQ Sales | 4.08 % |
| SBIN | Net worth | ₹ 4,14,939 Cr. |
| SBIN | Market Cap to Sales | 1.76 |
| SBIN | Interest Coverage | 1.35 |
| SBIN | EV / EBIT | 17.2 |
| SBIN | Debt Capacity | -4.02 |
| SBIN | Debt To Profit | 80.6 |
| SBIN | Capital Employed | ₹ 5,22,046 Cr. |
| SBIN | CROIC | -0.06 % |
| SBIN | debtplus | 19.4 |
| SBIN | Leverage | ₹ 15.3 |
| SBIN | Dividend Payout | 18.2 % |
| SBIN | Intrinsic Value | ₹ 585 |
| SBIN | CDL | -1,005 % |
| SBIN | Cash by market cap | 0.42 |
| SBIN | 52w Index | 86.9 % |
| SBIN | Down from 52w high | 5.29 % |
| SBIN | Up from 52w low | 59.0 % |
| SBIN | From 52w high | 0.95 |
| SBIN | Mkt Cap To Debt Cap | 2.88 |
| SBIN | Dividend Payout | 18.2 % |
| SBIN | Graham | ₹ 887 |
| SBIN | Price to Cash Flow | 35.6 |
| SBIN | ROCE3yr avg | 5.26 % |
| SBIN | PB X PE | 21.1 |
| SBIN | NCAVPS | ₹ 533 |
| SBIN | Mar Cap to CF | 35.6 |
| SBIN | Altman Z Score | 0.59 |
| SBIN | M.Cap / Qtr Profit | 36.0 |