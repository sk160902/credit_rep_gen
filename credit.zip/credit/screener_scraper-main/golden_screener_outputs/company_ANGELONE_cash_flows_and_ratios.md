# Cash Flows and Ratios Results

## Cash Flows Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cash from Operating Activity + | 11 | -77 | -210 | -309 | 689 | 643 | -1,199 | 558 | 804 | -330 |
| Cash from Investing Activity + | -7 | -13 | -50 | 47 | -6 | -28 | 25 | -52 | -185 | -91 |
| Cash from Financing Activity + | 2 | 40 | 350 | 239 | -361 | -449 | 894 | -165 | -908 | 1,331 |
| Net Cash Flow | 5 | -51 | 91 | -23 | 323 | 166 | -280 | 340 | -289 | 910 |

## Ratios Data
| Unknown | Mar 2015 | Mar 2016 | Mar 2017 | Mar 2018 | Mar 2019 | Mar 2020 | Mar 2021 | Mar 2022 | Mar 2023 | Mar 2024 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Debtor Days | 218 | 361 | 712 | 75 | 101 | 19 | 64 | 90 | 45 | 42 |
| Inventory Days |  |  |  |  |  |  |  |  |  |  |
| Days Payable |  |  |  |  |  |  |  |  |  |  |
| Cash Conversion Cycle | 218 | 361 | 712 | 75 | 101 | 19 | 64 | 90 | 45 | 42 |
| Working Capital Days | 122 | 119 | 289 | 244 | 127 | -380 | -235 | -569 | -474 | -525 |
| ROCE % |  | 12% | 11% | 18% | 13% | 14% | 27% | 35% | 44% | 39% |